package com.example.ruhzena.ai

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.example.ruhzena.ai.agent.AgentClock
import com.example.ruhzena.ai.agent.AgentRequestPayload
import com.example.ruhzena.ai.agent.AgentStreamEvent
import com.example.ruhzena.ai.agent.AiAgentMemoryStore
import com.example.ruhzena.ai.agent.AiFailureKind
import com.example.ruhzena.ai.agent.AiModelSpec
import com.example.ruhzena.ai.agent.AiPersonality
import com.example.ruhzena.ai.agent.AiProviderAdapter
import com.example.ruhzena.ai.agent.AiProviderException
import com.example.ruhzena.ai.agent.AiProviderId
import com.example.ruhzena.ai.agent.HttpFailureClassifier
import com.example.ruhzena.ai.agent.IntelligentModelRouter
import com.example.ruhzena.ai.agent.ProviderHealthTracker
import com.example.ruhzena.ai.agent.RoomAiAgentMemoryStore
import com.example.ruhzena.ai.agent.RuhZenaAgentEngine
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.local.AiConversationSummaryEntity
import com.example.ruhzena.data.local.AiMemoryEntity
import com.example.ruhzena.data.local.AiMessageEntity
import com.example.ruhzena.data.local.AiProviderHealthEntity
import com.example.ruhzena.data.local.AiTaskStateEntity
import com.example.ruhzena.data.local.RuhZenaDataRepository
import com.example.ruhzena.data.local.RuhZenaDatabase
import com.example.ruhzena.data.local.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.net.SocketTimeoutException

/**
 * Comprehensive verification suite covering all 19 required persistent AI agent,
 * multi-provider failover, continuity, memory, personality, guardrail, and vision scenarios.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RuhZenaAgentFailoverTest {

    private class FakeClock(var currentMs: Long = 1_750_000_000_000L) : AgentClock {
        override fun nowMillis(): Long = currentMs
        fun advanceSeconds(seconds: Long) {
            currentMs += seconds * 1_000L
        }
    }

    private class InMemoryAgentStore : AiAgentMemoryStore {
        val messages = mutableListOf<AiMessageEntity>()
        val memories = mutableListOf<AiMemoryEntity>()
        var summary: AiConversationSummaryEntity? = null
        var task: AiTaskStateEntity? = null
        val healthMap = LinkedHashMap<String, AiProviderHealthEntity>()

        override suspend fun getAllMessages(): List<AiMessageEntity> = messages.toList()
        override suspend fun getActiveMemories(): List<AiMemoryEntity> = memories.filter { it.isActive && it.isApproved }
        override suspend fun getSummary(sessionId: String): AiConversationSummaryEntity? = summary
        override suspend fun saveSummary(summary: AiConversationSummaryEntity) {
            this.summary = summary
        }
        override suspend fun getActiveTask(): AiTaskStateEntity? = task?.takeIf { it.status == "ACTIVE" }
        override suspend fun saveTask(task: AiTaskStateEntity): Long {
            val assigned = if (task.id == 0L) task.copy(id = 1L) else task
            this.task = assigned
            return assigned.id
        }
        override suspend fun loadAllHealth(): List<AiProviderHealthEntity> = healthMap.values.toList()
        override suspend fun saveHealth(entity: AiProviderHealthEntity) {
            healthMap[entity.modelKey] = entity
        }
    }

    private class ScriptedAdapter(
        override val providerId: AiProviderId,
        private val configured: Boolean = true,
        private val onStream: (AiModelSpec, AgentRequestPayload) -> Flow<String> = { _, _ -> flow { emit("OK") } },
        private val onVision: suspend (AiModelSpec) -> MealPhotoAnalysis = {
            MealPhotoAnalysis(
                dishName = "Grilled Chicken & Dates",
                detectedItems = listOf("Grilled Chicken", "Dates"),
                calories = 480,
                proteinGrams = 38,
                carbsGrams = 42,
                fatGrams = 14,
                healthVerdict = "GOOD_CHOICE",
                recommendationReason = "Balanced halal protein and natural energy.",
                improvementTip = "Add leafy greens for extra fiber."
            )
        }
    ) : AiProviderAdapter {
        val capturedPayloads = mutableListOf<Pair<AiModelSpec, AgentRequestPayload>>()
        var callCount = 0

        override fun isConfigured(): Boolean = configured

        override fun streamCompletion(model: AiModelSpec, payload: AgentRequestPayload): Flow<String> {
            callCount++
            capturedPayloads.add(model to payload)
            return onStream(model, payload)
        }

        override suspend fun analyzeMealImage(
            model: AiModelSpec,
            bitmap: Bitmap,
            prefs: UserPreferences,
            mealType: String
        ): MealPhotoAnalysis {
            callCount++
            return onVision(model)
        }
    }

    private fun testModels(): List<AiModelSpec> = listOf(
        AiModelSpec(
            provider = AiProviderId.GROQ,
            modelId = "openai/gpt-oss-120b",
            displayName = "Groq Primary",
            priorityTier = 1,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 3_400,
            supportsVision = false,
            isHighReasoning = true
        ),
        AiModelSpec(
            provider = AiProviderId.GROQ,
            modelId = "qwen/qwen3-8-27b",
            displayName = "Groq Vision",
            priorityTier = 1,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 3_000,
            supportsVision = true,
            isHighReasoning = false
        ),
        AiModelSpec(
            provider = AiProviderId.OPENROUTER,
            modelId = "openrouter/free",
            displayName = "OpenRouter Free",
            priorityTier = 2,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 6_000,
            supportsVision = true,
            isHighReasoning = true
        ),
        AiModelSpec(
            provider = AiProviderId.CLOUDFLARE,
            modelId = "@cf/meta/llama-3.3-70b-instruct-fp8-fast",
            displayName = "Cloudflare Llama",
            priorityTier = 3,
            contextWindowTokens = 24_000,
            safePromptBudgetTokens = 4_000,
            supportsVision = false,
            isHighReasoning = true
        ),
        AiModelSpec(
            provider = AiProviderId.FIREBASE_GEMINI,
            modelId = "gemini-3.8-flash",
            displayName = "Firebase Gemini",
            priorityTier = 4,
            contextWindowTokens = 1_000_000,
            safePromptBudgetTokens = 12_000,
            supportsVision = true,
            isHighReasoning = true
        )
    )

    private fun buildEngine(
        adapters: List<AiProviderAdapter>,
        store: AiAgentMemoryStore = InMemoryAgentStore(),
        clock: FakeClock = FakeClock(),
        models: List<AiModelSpec> = testModels()
    ): RuhZenaAgentEngine {
        val tracker = ProviderHealthTracker(clock = clock, persistence = store)
        val router = IntelligentModelRouter(healthTracker = tracker, modelsProvider = { models })
        return RuhZenaAgentEngine(
            adapters = adapters,
            memoryStore = store,
            healthTracker = tracker,
            router = router,
            clock = clock
        )
    }

    // 1. Primary healthy success
    @Test
    fun scenario01_primaryModelHealthySuccess() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow {
                emit("Wa Alaikumus Salam! Here is calm guidance on Sabr.\n\n### Explanation\nAllah is with those who are patient.\n\n### Sources\n- Surah Al-Baqarah 2:153 (https://quran.com/2/153)")
            }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER)
        val engine = buildEngine(listOf(groq, openRouter))

        val events = engine.streamAgentResponse(
            userPrompt = "Explain patience in Quran",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList()

        val done = events.filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.GROQ, done.servedByProvider)
        assertFalse(done.usedFailover)
        assertEquals(1, done.attemptCount)
        assertEquals(0, openRouter.callCount)
        assertTrue(done.citedSources.any { it.contains("quran.com") })
    }

    // 2. HTTP 429 + Retry-After cooldown & automatic switch
    @Test
    fun scenario02_rateLimit429WithRetryAfterFailoverAndCooldown() = runBlocking {
        val clock = FakeClock()
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow {
                throw HttpFailureClassifier.classifyHttpFailure(429, "rate_limit_exceeded", retryAfterHeader = "120")
            }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            flow { emit("Seamless backup answer.\n\n### Explanation\nContinued smoothly.") }
        })
        val engine = buildEngine(listOf(groq, openRouter), clock = clock)

        val events = engine.streamAgentResponse(
            userPrompt = "Explain Surah Al-Ikhlas",
            personality = AiPersonality.PRACTICAL_EXPERT,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList()

        val done = events.filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, done.servedByProvider)
        assertTrue(done.usedFailover)

        val groqSpec = testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning }
        val health = engine.healthTracker.getState(groqSpec)
        assertEquals(AiFailureKind.RATE_LIMIT_429, health.lastErrorKind)
        assertEquals(clock.currentMs + 120_000L, health.cooldownUntilMillis)
        assertFalse(engine.healthTracker.isAvailableNow(groqSpec))
    }

    // 3. High-demand / overload (529 / overload) automatic failover
    @Test
    fun scenario03_highDemandOverloadFailover() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(529, "Model is currently overloaded due to high demand") }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            flow { emit("Handled seamlessly on OpenRouter.") }
        })
        val engine = buildEngine(listOf(groq, openRouter))

        val events = engine.streamAgentResponse(
            userPrompt = "How to structure Fajr routine?",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList()

        val done = events.filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, done.servedByProvider)
        assertTrue(events.filterIsInstance<AgentStreamEvent.Status>().any { it.isFailover })
    }

    // 4. HTTP 503 outage failover
    @Test
    fun scenario04_serverOutage503Failover() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(503, "Service Unavailable") }
        })
        val cloudflare = ScriptedAdapter(AiProviderId.CLOUDFLARE, onStream = { _, _ ->
            flow { emit("Cloudflare edge backup responded cleanly.") }
        })
        val engine = buildEngine(listOf(groq, cloudflare))

        val done = engine.streamAgentResponse(
            userPrompt = "Explain Zakat Nisab",
            personality = AiPersonality.PRACTICAL_EXPERT,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList().filterIsInstance<AgentStreamEvent.Completed>().single()

        assertEquals(AiProviderId.CLOUDFLARE, done.servedByProvider)
        assertTrue(done.usedFailover)
    }

    // 5. Timeout / slow stall failover
    @Test
    fun scenario05_timeoutFailover() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw SocketTimeoutException("Read timed out") }
        })
        val firebase = ScriptedAdapter(AiProviderId.FIREBASE_GEMINI, onStream = { _, _ ->
            flow { emit("Firebase Gemini answered after timeout failover.") }
        })
        val engine = buildEngine(listOf(groq, firebase))

        val done = engine.streamAgentResponse(
            userPrompt = "Give me a hydration tip",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList().filterIsInstance<AgentStreamEvent.Completed>().single()

        assertEquals(AiProviderId.FIREBASE_GEMINI, done.servedByProvider)
        val groqSpec = testModels().first { it.provider == AiProviderId.GROQ }
        assertEquals(AiFailureKind.TIMEOUT_OR_STALL, engine.healthTracker.getState(groqSpec).lastErrorKind)
    }

    // 6. Mid-stream disconnect recovery
    @Test
    fun scenario06_midStreamDisconnectRecovery() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow {
                emit("Surah Ad-Duha was revealed during a quiet pause in revelation to comfort the Prophet (peace be upon him). ")
                throw java.io.IOException("Connection reset by peer mid-stream")
            }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, payload ->
            flow {
                val lastMsg = payload.messages.last().content
                assertTrue("Continuation instruction must be passed", lastMsg.contains("INTERNAL CONTINUATION"))
                emit("It teaches believers that Allah has never abandoned them.\n\n### Explanation\nHope follows hardship.")
            }
        })
        val engine = buildEngine(listOf(groq, openRouter))

        val events = engine.streamAgentResponse(
            userPrompt = "Explain Surah Ad-Duha",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList()

        val done = events.filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, done.servedByProvider)
        assertTrue(done.mainReply.contains("comfort the Prophet"))
        assertTrue(done.mainReply.contains("never abandoned them"))
    }

    // 7. Invalid / decommissioned 404 model permanent skip for session
    @Test
    fun scenario07_invalidDecommissionedModelSkippedForSession() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(404, "model_not_found: model decommissioned") }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            flow { emit("OpenRouter healthy reply.") }
        })
        val models = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER }
        )
        val engine = buildEngine(listOf(groq, openRouter), models = models)

        // First call triggers 404 on Groq primary and disables it for session
        engine.streamAgentResponse("First question", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences()).toList()
        val groqCallsAfterFirst = groq.callCount
        assertEquals(1, groqCallsAfterFirst)

        // Second call immediately skips decommissioned Groq model without wasting latency
        val secondDone = engine.streamAgentResponse("Second question", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, secondDone.servedByProvider)
        assertEquals(groqCallsAfterFirst, groq.callCount)
        assertTrue(engine.healthTracker.getState(models.first()).sessionDisabled)
    }

    // 8. Quota exhausted cooldown prevents tight retry loops
    @Test
    fun scenario08_quotaExhaustedCooldownNoTightLoop() = runBlocking {
        val clock = FakeClock()
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(429, "insufficient_quota: daily limit reached") }
        })
        val firebase = ScriptedAdapter(AiProviderId.FIREBASE_GEMINI, onStream = { _, _ ->
            flow { emit("Firebase Gemini handled after quota cooldown.") }
        })
        val models = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.FIREBASE_GEMINI }
        )
        val engine = buildEngine(listOf(groq, firebase), clock = clock, models = models)

        engine.streamAgentResponse("Explain Wudu", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences()).toList()
        engine.streamAgentResponse("Explain Tayammum", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences()).toList()

        // Groq was only called once because 15-min quota cooldown kept it out of immediate loop
        assertEquals(1, groq.callCount)
        assertEquals(2, firebase.callCount)
        assertEquals(AiFailureKind.QUOTA_EXHAUSTED, engine.healthTracker.getState(models.first()).lastErrorKind)
    }

    // 9. Cross-provider tier failover: Groq -> OpenRouter -> Cloudflare -> Firebase AI Logic
    @Test
    fun scenario09_crossProviderTierCascadeGroqOpenRouterCloudflareFirebase() = runBlocking {
        val callOrder = mutableListOf<AiProviderId>()
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            callOrder.add(AiProviderId.GROQ)
            flow { throw HttpFailureClassifier.classifyHttpFailure(503, "Groq down") }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            callOrder.add(AiProviderId.OPENROUTER)
            flow { throw HttpFailureClassifier.classifyHttpFailure(429, "OpenRouter rate limited") }
        })
        val cloudflare = ScriptedAdapter(AiProviderId.CLOUDFLARE, onStream = { _, _ ->
            callOrder.add(AiProviderId.CLOUDFLARE)
            flow { throw HttpFailureClassifier.classifyHttpFailure(502, "Cloudflare gateway error") }
        })
        val firebase = ScriptedAdapter(AiProviderId.FIREBASE_GEMINI, onStream = { _, _ ->
            callOrder.add(AiProviderId.FIREBASE_GEMINI)
            flow { emit("Firebase AI Logic final tier succeeded seamlessly.") }
        })
        val singlePerProvider = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER },
            testModels().first { it.provider == AiProviderId.CLOUDFLARE },
            testModels().first { it.provider == AiProviderId.FIREBASE_GEMINI }
        )
        val engine = buildEngine(listOf(groq, openRouter, cloudflare, firebase), models = singlePerProvider)

        val done = engine.streamAgentResponse(
            userPrompt = "Explain Tafsir of Surah Al-Asr",
            personality = AiPersonality.PRACTICAL_EXPERT,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList().filterIsInstance<AgentStreamEvent.Completed>().single()

        assertEquals(
            listOf(AiProviderId.GROQ, AiProviderId.OPENROUTER, AiProviderId.CLOUDFLARE, AiProviderId.FIREBASE_GEMINI),
            callOrder
        )
        assertEquals(AiProviderId.FIREBASE_GEMINI, done.servedByProvider)
        assertEquals(4, done.attemptCount)
    }

    // 10. Sequential multi-provider failures across consecutive turns
    @Test
    fun scenario10_sequentialMultiProviderFailuresAcrossTurns() = runBlocking {
        var openRouterShouldFail = false
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(503, "Groq outage") }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            if (openRouterShouldFail) flow { throw HttpFailureClassifier.classifyHttpFailure(529, "Overloaded") }
            else flow { emit("Turn 1 via OpenRouter.") }
        })
        val cloudflare = ScriptedAdapter(AiProviderId.CLOUDFLARE, onStream = { _, _ ->
            flow { emit("Turn 2 via Cloudflare.") }
        })
        val singlePerProvider = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER },
            testModels().first { it.provider == AiProviderId.CLOUDFLARE }
        )
        val engine = buildEngine(listOf(groq, openRouter, cloudflare), models = singlePerProvider)

        val t1 = engine.streamAgentResponse("Turn 1 question", AiPersonality.PEACE_COMPANION, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, t1.servedByProvider)

        openRouterShouldFail = true
        val t2 = engine.streamAgentResponse("Turn 2 question", AiPersonality.PEACE_COMPANION, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.CLOUDFLARE, t2.servedByProvider)
    }

    // 11. All providers down -> calm user message, no raw HTTP codes, preserved prompt, clean terminal event
    @Test
    fun scenario11_allProvidersDownCalmFallbackAndPreservedPrompt() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(503, "upstream 503 error") }
        })
        val firebase = ScriptedAdapter(AiProviderId.FIREBASE_GEMINI, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(429, "quota exceeded 429") }
        })
        val models = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.FIREBASE_GEMINI }
        )
        val engine = buildEngine(listOf(groq, firebase), models = models)

        val prompt = "Help me organize my Ramadan Quran reading schedule"
        val events = engine.streamAgentResponse(prompt, AiPersonality.PEACE_COMPANION, AppLanguage.ENGLISH, UserPreferences()).toList()

        val failed = events.filterIsInstance<AgentStreamEvent.Failed>().single()
        assertTrue(failed.allProvidersExhausted)
        assertEquals(prompt, failed.preservedUserPrompt)
        assertFalse("Must never leak raw HTTP status codes", failed.friendlyMessage.contains("503") || failed.friendlyMessage.contains("429"))
        assertTrue(failed.friendlyMessage.contains("Retry", ignoreCase = true))
    }

    // 12. Cooldown expiry + automatic primary recovery probe via fake clock
    @Test
    fun scenario12_cooldownExpiryAutomaticallyRecoversPrimary() = runBlocking {
        val clock = FakeClock()
        var groqHealthy = false
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            if (!groqHealthy) flow { throw HttpFailureClassifier.classifyHttpFailure(429, "rate limit", retryAfterHeader = "60") }
            else flow { emit("Primary Groq recovered smoothly!") }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            flow { emit("OpenRouter holding steady during Groq cooldown.") }
        })
        val models = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER }
        )
        val engine = buildEngine(listOf(groq, openRouter), clock = clock, models = models)

        // Turn 1: Groq fails (60s cooldown) -> OpenRouter answers
        val r1 = engine.streamAgentResponse("Explain Surah Al-Fatihah", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, r1.servedByProvider)

        // Turn 2 at +30s: still in cooldown -> goes directly to OpenRouter
        clock.advanceSeconds(30)
        groqHealthy = true
        val r2 = engine.streamAgentResponse("Explain Surah Al-Nas", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, r2.servedByProvider)

        // Turn 3 at +65s total: cooldown expired -> automatically probes & recovers Groq primary!
        clock.advanceSeconds(35)
        val r3 = engine.streamAgentResponse("Explain Surah Al-Falaq", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.GROQ, r3.servedByProvider)
        assertFalse(r3.usedFailover)
    }

    // 13. Mid-long-conversation provider switch preserving rolling summary & full continuity
    @Test
    fun scenario13_longConversationRollingSummaryPreservedAcrossProviderSwitch() = runBlocking {
        val store = InMemoryAgentStore()
        // Populate 14 prior turns so rolling summary triggers (> 10 messages)
        for (i in 1..14) {
            store.messages.add(
                AiMessageEntity(
                    id = i.toLong(),
                    sessionId = "unified",
                    mode = "COMPANION",
                    role = if (i % 2 == 1) "USER" else "ASSISTANT",
                    content = if (i % 2 == 1) "Question $i about building consistent Tahajjud and fitness habits" else "Guidance $i on steady progress"
                )
            )
        }
        store.memories.add(
            AiMemoryEntity(id = 1, category = "FITNESS", content = "User has mild left knee sensitivity", isApproved = true, isActive = true)
        )

        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(503, "Groq down") }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            flow { emit("Continuing your Tahajjud & knee-safe plan seamlessly.") }
        })
        val models = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER }
        )
        val engine = buildEngine(listOf(groq, openRouter), store = store, models = models)

        val done = engine.streamAgentResponse(
            userPrompt = "What should my next workout step be?",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList().filterIsInstance<AgentStreamEvent.Completed>().single()

        assertEquals(AiProviderId.OPENROUTER, done.servedByProvider)
        assertNotNull("Rolling summary must be created and persisted", store.summary)
        val backupPayload = openRouter.capturedPayloads.single().second
        assertTrue("Backup provider must receive rolling summary", backupPayload.systemPrompt.contains("EARLIER CONVERSATION SUMMARY"))
        assertTrue("Backup provider must receive approved memory", backupPayload.systemPrompt.contains("mild left knee sensitivity"))
    }

    // 14. App restart persistence via real Room database
    @Test
    fun scenario14_roomPersistenceSurvivesEngineRestart() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = RuhZenaDatabase.getInstance(context)
        val repo = RuhZenaDataRepository(db)
        repo.clearAllAiHistory()

        repo.saveAiMessage(AiMessageEntity(sessionId = "unified", mode = "EXPERT", role = "USER", content = "My goal is memorizing Juz Amma"))
        repo.saveAiMessage(AiMessageEntity(sessionId = "unified", mode = "EXPERT", role = "ASSISTANT", content = "Let us build a 30-day Juz Amma schedule."))
        repo.saveAiMemory(AiMemoryEntity(category = "SPIRITUAL", content = "Memorizing Juz Amma after Fajr", isApproved = true, isActive = true))
        repo.upsertAiTask(
            AiTaskStateEntity(
                sessionId = "unified",
                title = "Juz Amma 30-Day Plan",
                objective = "Memorize 10 lines daily after Fajr",
                completedStepsJson = "[\"Surah An-Naba\"]",
                remainingStepsJson = "[\"Surah An-Nazi'at\"]",
                nextAction = "Review An-Naba and begin An-Nazi'at"
            )
        )

        // Instantiate a brand-new engine backed by RoomAiAgentMemoryStore (simulating cold app restart)
        val restartedStore = RoomAiAgentMemoryStore(repo)
        val firebase = ScriptedAdapter(AiProviderId.FIREBASE_GEMINI, onStream = { _, _ ->
            flow { emit("Welcome back! Let's review Surah An-Naba and start An-Nazi'at.") }
        })
        val engineAfterRestart = buildEngine(
            adapters = listOf(firebase),
            store = restartedStore,
            models = listOf(testModels().first { it.provider == AiProviderId.FIREBASE_GEMINI })
        )

        val done = engineAfterRestart.streamAgentResponse(
            userPrompt = "Continue where we left off",
            personality = AiPersonality.PRACTICAL_EXPERT,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList().filterIsInstance<AgentStreamEvent.Completed>().single()

        assertEquals(AiProviderId.FIREBASE_GEMINI, done.servedByProvider)
        val payload = firebase.capturedPayloads.single().second
        assertTrue(payload.systemPrompt.contains("Memorizing Juz Amma after Fajr"))
        assertTrue(payload.systemPrompt.contains("Juz Amma 30-Day Plan"))
        assertTrue(payload.messages.any { it.content.contains("Juz Amma") })
    }

    // 15. Multi-step task state created and resumed across failover
    @Test
    fun scenario15_multiStepTaskStateCreatedAndResumedAcrossFailover() = runBlocking {
        val store = InMemoryAgentStore()
        var groqFails = false
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            if (groqFails) flow { throw HttpFailureClassifier.classifyHttpFailure(503, "Groq down") }
            else flow {
                emit("Step 1 complete: baseline hydration set.\n[[TASK_UPDATE:Ramadan Prep Plan|Baseline hydration set|Plan Suhoor macros]]")
            }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            flow {
                emit("Step 2 complete: Suhoor protein and complex carbs scheduled.\n[[TASK_UPDATE:Ramadan Prep Plan|Plan Suhoor macros|Set Fajr alarm]]")
            }
        })
        val models = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER }
        )
        val engine = buildEngine(listOf(groq, openRouter), store = store, models = models)

        // Step 1 on Groq creates persistent task & strips internal tag from visible reply
        val step1 = engine.streamAgentResponse("Start my Ramadan prep plan", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertFalse("Internal TASK_UPDATE tag must be stripped from user text", step1.mainReply.contains("[[TASK_UPDATE"))
        assertEquals("Ramadan Prep Plan", store.task?.title)
        assertEquals("Plan Suhoor macros", store.task?.nextAction)

        // Step 2 fails over to OpenRouter and receives exact active task state
        groqFails = true
        val step2 = engine.streamAgentResponse("Do step 2 now", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences())
            .toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.OPENROUTER, step2.servedByProvider)
        val backupSystem = openRouter.capturedPayloads.single().second.systemPrompt
        assertTrue(backupSystem.contains("ACTIVE PERSISTENT MULTI-STEP TASK"))
        assertTrue(backupSystem.contains("Plan Suhoor macros"))
        assertEquals("Set Fajr alarm", store.task?.nextAction)
    }

    // 16. Partial-response continuation with overlap de-duplication
    @Test
    fun scenario16_partialResponseContinuationRemovesOverlapDuplication() {
        val partial = "Establishing Fajr prayer brings Barakah to your entire day and strengthens inner discipline."
        val overlappingContinuation = "strengthens inner discipline. Start by sleeping 30 minutes earlier after Isha."
        val merged = RuhZenaAgentEngine.mergeContinuationWithoutDuplication(partial, overlappingContinuation)

        assertEquals(
            "Establishing Fajr prayer brings Barakah to your entire day and strengthens inner discipline. Start by sleeping 30 minutes earlier after Isha.",
            merged
        )
        // Verify full prefix restart is also deduplicated cleanly
        val fullRestart = "$partial Moreover, keep water beside your bed."
        val mergedFull = RuhZenaAgentEngine.mergeContinuationWithoutDuplication(partial, fullRestart)
        assertEquals(fullRestart, mergedFull)
    }

    // 17. Both personalities preserved across provider switches
    @Test
    fun scenario17_bothPersonalitiesPreservedAcrossFailover() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ ->
            flow { throw HttpFailureClassifier.classifyHttpFailure(503, "Unavailable") }
        })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ ->
            flow { emit("Consistent personality answer.") }
        })
        val models = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER }
        )
        val engine = buildEngine(listOf(groq, openRouter), models = models)

        engine.streamAgentResponse(
            "I feel stressed today",
            AiPersonality.PEACE_COMPANION,
            AppLanguage.ENGLISH,
            UserPreferences(characterGender = "MALE", userName = "Tariq")
        ).toList()
        engine.streamAgentResponse(
            "Compare Hanafi and Shafi'i Witr",
            AiPersonality.PRACTICAL_EXPERT,
            AppLanguage.ENGLISH,
            UserPreferences(characterGender = "FEMALE", userName = "Amina")
        ).toList()

        val firstSystem = openRouter.capturedPayloads[0].second.systemPrompt
        val secondSystem = openRouter.capturedPayloads[1].second.systemPrompt
        assertTrue(firstSystem.contains("HEART & LIFE COMPANION"))
        assertTrue(firstSystem.contains("brother"))
        assertTrue(secondSystem.contains("SCHOLAR & STRATEGY COACH"))
        assertTrue(secondSystem.contains("sister"))
        // Both maintain unified RuhZena AI identity
        assertTrue(firstSystem.contains("You are RuhZena AI"))
        assertTrue(secondSystem.contains("You are RuhZena AI"))
    }

    // 18. Strict Islamic zero-fabrication citation guardrails enforced across EVERY provider
    @Test
    fun scenario18_islamicZeroFabricationGuardrailsEnforcedOnEveryProvider() = runBlocking {
        val groq = ScriptedAdapter(AiProviderId.GROQ, onStream = { _, _ -> flow { throw HttpFailureClassifier.classifyHttpFailure(503, "down") } })
        val openRouter = ScriptedAdapter(AiProviderId.OPENROUTER, onStream = { _, _ -> flow { throw HttpFailureClassifier.classifyHttpFailure(503, "down") } })
        val cloudflare = ScriptedAdapter(AiProviderId.CLOUDFLARE, onStream = { _, _ -> flow { throw HttpFailureClassifier.classifyHttpFailure(503, "down") } })
        val firebase = ScriptedAdapter(AiProviderId.FIREBASE_GEMINI, onStream = { _, _ -> flow { emit("Verified answer.") } })

        val singlePerProvider = listOf(
            testModels().first { it.provider == AiProviderId.GROQ && it.isHighReasoning },
            testModels().first { it.provider == AiProviderId.OPENROUTER },
            testModels().first { it.provider == AiProviderId.CLOUDFLARE },
            testModels().first { it.provider == AiProviderId.FIREBASE_GEMINI }
        )
        val engine = buildEngine(listOf(groq, openRouter, cloudflare, firebase), models = singlePerProvider)
        engine.streamAgentResponse("What is the ruling on Qasr prayer while traveling?", AiPersonality.PRACTICAL_EXPERT, AppLanguage.ENGLISH, UserPreferences()).toList()

        listOf(groq, openRouter, cloudflare, firebase).forEach { adapter ->
            val sys = adapter.capturedPayloads.single().second.systemPrompt
            assertTrue("${adapter.providerId} must enforce zero fabrication", sys.contains("Never fabricate, guess, or invent Quran"))
            assertTrue("${adapter.providerId} must mention Ikhtilaf", sys.contains("Ikhtilaf"))
            assertTrue("${adapter.providerId} must forbid mentioning provider names", sys.contains("Never mention underlying model names"))
        }
    }

    // 19. No endless loading / no duplicate terminal events + Memory approval extraction + Vision Failover
    @Test
    fun scenario19_noEndlessLoadingMemoryApprovalAndVisionFailover() = runBlocking {
        val groq = ScriptedAdapter(
            providerId = AiProviderId.GROQ,
            onStream = { _, _ ->
                flow {
                    emit("Noted! I will tailor your guidance accordingly.\n[[MEMORY_SUGGEST:NUTRITION|Prefers high-protein halal Mediterranean meals]]")
                }
            },
            onVision = { throw HttpFailureClassifier.classifyHttpFailure(429, "Groq vision rate limit") }
        )
        val openRouter = ScriptedAdapter(
            providerId = AiProviderId.OPENROUTER,
            onVision = {
                MealPhotoAnalysis(
                    dishName = "Halal Grilled Salmon Bowl",
                    detectedItems = listOf("Grilled Salmon", "Brown Rice", "Avocado"),
                    calories = 540,
                    proteinGrams = 42,
                    carbsGrams = 38,
                    fatGrams = 22,
                    healthVerdict = "GOOD_CHOICE",
                    recommendationReason = "Rich in omega-3 and lean halal protein.",
                    improvementTip = "Pair with a glass of water."
                )
            }
        )
        val engine = buildEngine(listOf(groq, openRouter))

        // Verify exactly one terminal event (no endless loading) and clean memory proposal extraction
        val events = engine.streamAgentResponse(
            userPrompt = "Remember that I prefer high-protein halal Mediterranean meals",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences()
        ).toList()

        val terminals = events.filter { it is AgentStreamEvent.Completed || it is AgentStreamEvent.Failed }
        assertEquals(1, terminals.size)
        val completed = terminals.single() as AgentStreamEvent.Completed
        assertNotNull("Memory proposal should be extracted for user approval", completed.memoryProposal)
        assertEquals("NUTRITION", completed.memoryProposal?.category)
        assertFalse("Internal MEMORY_SUGGEST tag must not leak to UI", completed.mainReply.contains("[[MEMORY_SUGGEST"))

        // Verify Nutrition Vision Failover automatically skips rate-limited Groq Vision to OpenRouter Vision
        val bitmap = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        val (analysis, usedModel) = engine.analyzeMealPhotoWithFailover(bitmap, UserPreferences(), "Lunch")
        assertEquals("Halal Grilled Salmon Bowl", analysis.dishName)
        assertEquals(AiProviderId.OPENROUTER, usedModel.provider)
        assertTrue(usedModel.supportsVision)
    }
}
