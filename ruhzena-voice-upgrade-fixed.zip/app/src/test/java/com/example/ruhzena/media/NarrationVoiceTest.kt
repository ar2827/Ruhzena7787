package com.example.ruhzena.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class NarrationVoiceTest {

    // ---- gender resolution -------------------------------------------------------------------

    @Test fun onboardingGenderWinsOverLegacyStyle() {
        val femaleWithMaleStyle = NarrationVoiceResolver.resolve("FEMALE", "CALM_SCHOLAR")
        assertEquals(NarrationGender.FEMALE, femaleWithMaleStyle.gender)
        assertEquals("GENTLE_FEMALE", femaleWithMaleStyle.styleId)

        val maleWithFemaleStyle = NarrationVoiceResolver.resolve("MALE", "GENTLE_FEMALE")
        assertEquals(NarrationGender.MALE, maleWithFemaleStyle.gender)
        assertEquals("WARM_HUMAN", maleWithFemaleStyle.styleId)
    }

    @Test fun maleKeepsChosenMaleTone() {
        val v = NarrationVoiceResolver.resolve("male", "CALM_SCHOLAR")
        assertEquals(NarrationGender.MALE, v.gender)
        assertEquals("CALM_SCHOLAR", v.styleId)
    }

    @Test fun legacyAccountWithoutGenderHonoursSavedStyleThenDefaultsToMale() {
        assertEquals(NarrationGender.FEMALE, NarrationVoiceResolver.resolve("", "GENTLE_FEMALE").gender)
        assertEquals(NarrationGender.MALE, NarrationVoiceResolver.resolve("", "WARM_HUMAN").gender)
        assertEquals(NarrationGender.MALE, NarrationVoiceResolver.resolve(null, null).gender)
        assertEquals(NarrationGender.MALE, NarrationVoiceResolver.resolve("garbage", "").gender)
    }

    @Test fun everyGenderMapsToItsOwnFixedGeminiVoice() {
        val male = NarrationVoiceResolver.resolve("MALE", "")
        val female = NarrationVoiceResolver.resolve("FEMALE", "")
        assertNotEquals(male.geminiVoice, female.geminiVoice)
        assertEquals(male, NarrationVoiceResolver.resolve("MALE", "WARM_HUMAN")) // deterministic
        NarrationGender.values().forEach { g ->
            NarrationVoiceResolver.stylesFor(g).forEach { style ->
                assertEquals(g, NarrationVoiceResolver.genderOfStyle(style))
            }
        }
    }

    // ---- cache keys --------------------------------------------------------------------------

    @Test fun cacheKeySeparatesGenderLanguageTypeAndText() {
        val m = NarrationVoiceResolver.resolve("MALE", "")
        val f = NarrationVoiceResolver.resolve("FEMALE", "")
        val base = NarrationCacheKeys.build(NarrationType.STORY, "English", m, "hello")
        assertNotEquals(base, NarrationCacheKeys.build(NarrationType.STORY, "English", f, "hello"))
        assertNotEquals(base, NarrationCacheKeys.build(NarrationType.STORY, "Bengali", m, "hello"))
        assertNotEquals(base, NarrationCacheKeys.build(NarrationType.AI_REPLY, "English", m, "hello"))
        assertNotEquals(base, NarrationCacheKeys.build(NarrationType.STORY, "English", m, "hello!"))
        assertEquals(base, NarrationCacheKeys.build(NarrationType.STORY, "English", m, "hello"))
    }

    @Test fun cacheKeyChangesWhenToneVoiceChanges() {
        val warm = NarrationVoiceResolver.resolve("MALE", "WARM_HUMAN")
        val calm = NarrationVoiceResolver.resolve("MALE", "CALM_SCHOLAR")
        assertNotEquals(
            NarrationCacheKeys.build(NarrationType.AI_REPLY, "English", warm, "x"),
            NarrationCacheKeys.build(NarrationType.AI_REPLY, "English", calm, "x")
        )
    }

    // ---- chunking ----------------------------------------------------------------------------

    @Test fun firstChunkIsCompleteSentenceAndWithinLimit() {
        val text = "Bismillah. " + "This is a fairly long second sentence that continues for a while. ".repeat(10)
        val chunks = NarrationChunker.split(text, firstMax = 130, nextMax = 380)
        assertTrue(chunks.size > 1)
        assertTrue(chunks.first().text.length <= 130)
        assertTrue(chunks.drop(1).all { it.text.length <= 380 })
    }

    @Test fun chunksPreserveAllWordsInOrder() {
        val text = "One. Two three! Four five six? " + "Seven eight nine ten, eleven twelve. ".repeat(30) + "Last words here."
        val joined = NarrationChunker.split(text, 60, 200).joinToString(" ") { it.text }
        assertEquals(text.split(Regex("\\s+")).filter { it.isNotEmpty() }, joined.split(Regex("\\s+")).filter { it.isNotEmpty() })
    }

    @Test fun paragraphBreaksAreFlaggedAndNeverCrossed() {
        val text = "First paragraph sentence one. Sentence two.\n\nSecond paragraph begins here. It continues."
        val chunks = NarrationChunker.split(text, 130, 380)
        assertEquals(2, chunks.size)
        assertTrue(chunks[0].paragraphBreakAfter)
        assertFalse(chunks[1].paragraphBreakAfter)
        assertFalse(chunks[0].text.contains("Second"))
    }

    @Test fun banglaAndArabicSentenceEndingsSplit() {
        val bn = "এটি প্রথম বাক্য। এটি দ্বিতীয় বাক্য। এটি তৃতীয় বাক্য।"
        assertEquals(3, NarrationChunker.split(bn, 20, 20).size)
        val ar = "هذه جملة أولى؟ هذه جملة ثانية؟"
        assertEquals(2, NarrationChunker.split(ar, 16, 16).size)
    }

    @Test fun overlongSentenceIsBrokenAndEmptyInputIsEmpty() {
        val long = "word ".repeat(200).trim() + "."
        val chunks = NarrationChunker.split(long, 130, 380)
        assertTrue(chunks.size >= 2)
        assertTrue(chunks.all { it.text.length <= 380 })
        assertTrue(NarrationChunker.split("   ", 130, 380).isEmpty())
    }

    // ---- prompts -----------------------------------------------------------------------------

    @Test fun promptsDoNotInstructGenderInText() {
        NarrationType.values().forEach { t ->
            val p = NarrationPrompts.build(t, "English", "Hello there.").lowercase()
            assertFalse(p.contains("male")) // covers "female" too
            assertTrue(p.endsWith("hello there."))
        }
    }

    // ---- device voice gender classifier ------------------------------------------------------

    @Test fun deviceVoiceClassifierPrefersExplicitFemaleOverMaleSubstring() {
        assertEquals(NarrationGender.FEMALE, DeviceVoiceGender.classify("en-us-x-sfg-local"))
        assertEquals(NarrationGender.FEMALE, DeviceVoiceGender.classify("Some Female Voice"))
        assertEquals(NarrationGender.MALE, DeviceVoiceGender.classify("en-us-x-iom-network"))
        assertEquals(NarrationGender.MALE, DeviceVoiceGender.classify("voice", "male"))
        assertNull(DeviceVoiceGender.classify("en-us-x-unknown-local"))
    }

    @Test fun compensationPitchMovesTowardRequestedGender() {
        assertTrue(DeviceVoiceGender.compensationPitch(NarrationGender.FEMALE, DeviceMatch.UNKNOWN_GENDER) > 1f)
        assertTrue(DeviceVoiceGender.compensationPitch(NarrationGender.MALE, DeviceMatch.UNKNOWN_GENDER) < 1f)
        assertEquals(1f, DeviceVoiceGender.compensationPitch(NarrationGender.MALE, DeviceMatch.MATCHED), 0f)
    }

    // ---- disk cache --------------------------------------------------------------------------

    private fun tempDir(): File = Files.createTempDirectory("rz_cache").toFile()

    @Test fun cacheCommitThenLookupRoundTrips() {
        val cache = NarrationAudioCache(tempDir())
        val w = cache.beginWrite("abc", 24_000)!!
        w.write(ByteArray(4096) { 1 })
        assertTrue(w.commit())
        val hit = cache.lookup("abc")
        assertNotNull(hit)
        assertEquals(24_000, hit!!.sampleRate)
        assertEquals(4096L, hit.pcmBytes)
    }

    @Test fun abortedOrTinyWritesNeverBecomeHits() {
        val cache = NarrationAudioCache(tempDir())
        val aborted = cache.beginWrite("k1", 24_000)!!
        aborted.write(ByteArray(8192))
        aborted.abort()
        assertNull(cache.lookup("k1"))

        val tiny = cache.beginWrite("k2", 24_000)!!
        tiny.write(ByteArray(10))
        assertFalse(tiny.commit())
        assertNull(cache.lookup("k2"))
    }

    @Test fun corruptFilesAreRejectedAndRemoved() {
        val dir = tempDir()
        val cache = NarrationAudioCache(dir)
        val f = File(dir, "bad.rzpcm")
        f.writeBytes(ByteArray(5000) { 7 }) // wrong magic
        assertNull(cache.lookup("bad"))
        assertFalse(f.exists())
    }

    @Test fun cleanupRemovesLegacyAndStaleFilesAndEnforcesSizeCap() {
        val dir = tempDir()
        File(dir, "v3_deadbeef.bin").writeBytes(ByteArray(10))
        File(dir, "v3_deadbeef.bin.mime").writeText("audio/pcm")
        val cache = NarrationAudioCache(dir, maxBytes = 20_000)
        repeat(4) { i ->
            val w = cache.beginWrite("k$i", 24_000)!!
            w.write(ByteArray(10_000))
            w.commit()
            File(dir, "k$i.rzpcm").setLastModified(1_000_000L + i * 10_000L) // k0 oldest, 10s apart
        }
        cache.cleanup(now = 1_000_000L + 100_000L)
        assertFalse(File(dir, "v3_deadbeef.bin").exists())
        assertFalse(File(dir, "v3_deadbeef.bin.mime").exists())
        val remaining = dir.listFiles()!!.filter { it.name.endsWith(".rzpcm") }
        assertTrue(remaining.sumOf { it.length() } <= 20_000)
        assertFalse(File(dir, "k0.rzpcm").exists()) // oldest evicted first
        assertTrue(File(dir, "k3.rzpcm").exists())
    }
}
