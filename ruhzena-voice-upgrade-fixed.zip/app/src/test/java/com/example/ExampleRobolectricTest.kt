package com.example

import android.content.Context
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeUp
import androidx.test.core.app.ApplicationProvider
import com.example.ruhzena.ai.IslamicKnowledgeCorpus
import com.example.ruhzena.ai.RuhZenaAiCoordinator
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.local.RuhZenaDataRepository
import com.example.ruhzena.data.local.RuhZenaDatabase
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.UserPreferencesRepository
import com.example.ruhzena.notifications.MotivationKnowledgeCatalog
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h915dp-xxhdpi")
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun readAppNameAndResources() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RuhZena", appName)
    }

    @Test
    fun bothAiCoachesHandleGreetingsAndSpecializedQueriesOffline(): Unit = runBlocking {
        val coordinator = RuhZenaAiCoordinator()

        val greetingIslamic = coordinator.answerIslamicQuestion(
            query = "Assalamu Alaikum",
            language = AppLanguage.ENGLISH,
            researchOnlineEnabled = false,
            isOnline = false
        )
        assertTrue(greetingIslamic.aiSynthesis.contains("Wa Alaikumus Salam"))

        val casualHiIslamic = coordinator.answerIslamicQuestion(
            query = "hi",
            language = AppLanguage.ENGLISH,
            researchOnlineEnabled = false,
            isOnline = false
        )
        assertTrue(casualHiIslamic.aiSynthesis.startsWith("Assalamu Alaikum"))
        assertTrue(!casualHiIslamic.aiSynthesis.startsWith("Wa Alaikumus Salam"))

        val unknownIslamic = coordinator.answerIslamicQuestion(
            query = "cryptocurrency staking rules",
            language = AppLanguage.ENGLISH,
            researchOnlineEnabled = false,
            isOnline = false
        )
        assertTrue(unknownIslamic.quranicEvidence.contains("16:43"))
        assertTrue(unknownIslamic.aiSynthesis.contains("scholar"))

        val prefs = UserPreferences()
        val sleepReply = coordinator.answerWellnessQuestion("Why am I tired and sleeping poorly?", prefs, 1200, 360, 2)
        assertTrue(sleepReply.contains("Fajr"))

        val kneeReply = coordinator.answerWellnessQuestion("My knee hurts during squats", prefs, 1200, 420, 2)
        assertTrue(kneeReply.contains("Glute Bridges"))

        val suhoorReply = coordinator.answerWellnessQuestion("Best Suhoor and Iftar protein food?", prefs, 1200, 420, 2)
        assertTrue(suhoorReply.contains("Suhoor"))

        val fatLossReply = coordinator.answerWellnessQuestion("How to lose fat safely?", prefs, 1500, 420, 3)
        assertTrue(fatLossReply.contains("deficit"))
    }

    @Test
    fun islamicCorpusScoredMatchingAndCatalogIntegrity() {
        val salahMatches = IslamicKnowledgeCorpus.retrieveScoredMatches("Importance of Salah and Fajr")
        assertTrue(salahMatches.isNotEmpty())
        assertEquals("salah_prayer", salahMatches.first().first.id)
        assertTrue(salahMatches.first().second >= 10)

        val banglaMatches = IslamicKnowledgeCorpus.retrieveScoredMatches("নামাজ এবং ধৈর্য সম্পর্কে বলুন")
        assertTrue(banglaMatches.isNotEmpty())

        val hourInsights = (0..23).map { MotivationKnowledgeCatalog.forHour(it) }
        assertTrue(hourInsights.all {
            it.motivationEn.isNotBlank() && it.motivationBn.isNotBlank() &&
                it.knowledgeEn.isNotBlank() && it.knowledgeBn.isNotBlank()
        })

        assertTrue(com.example.ruhzena.data.islamic.IslamicContentData.duaList.size >= 50)
        // Verify full systemic Adhkar coverage & guided Tasbih routines across all 6 categories
        com.example.ruhzena.data.islamic.AdhkarCategory.entries.forEach { cat ->
            val catItems = com.example.ruhzena.data.islamic.IslamicContentData.adhkarList.filter { it.category == cat }
            assertTrue("Category $cat should have rich authentic Adhkar", catItems.size >= 7)
            val routine = com.example.ruhzena.data.islamic.IslamicContentData.tasbihRoutineForCategory(cat)
            assertTrue("Category $cat should have ordered guided Tasbih steps", routine.size >= 3)
        }
        val afterPrayerRoutine = com.example.ruhzena.data.islamic.IslamicContentData.tasbihRoutineForCategory(
            com.example.ruhzena.data.islamic.AdhkarCategory.AFTER_PRAYER
        )
        assertEquals(listOf(33, 33, 33, 1), afterPrayerRoutine.map { it.targetCount })

        assertEquals(8, com.example.ruhzena.data.islamic.IslamicAcademyCurriculum.guidedModules.size)
        assertTrue(com.example.ruhzena.data.islamic.IslamicAcademyCurriculum.guidedModules.all { it.quiz.size == 3 })
        assertEquals(8, com.example.ruhzena.data.islamic.IslamicAcademyCurriculum.detailedSalahSteps.size)
        assertEquals(4, com.example.ruhzena.data.islamic.IslamicAcademyCurriculum.detailedWuduSteps.size)
        assertEquals(8, com.example.ruhzena.data.islamic.IslamicAcademyCurriculum.narratedStories.size)
    }

    @Test
    fun fullJsonBackupExportAndRestoreRoundTrip(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = RuhZenaDatabase.getInstance(context)
        val dataRepo = RuhZenaDataRepository(db)
        val prefsRepo = UserPreferencesRepository(context)

        dataRepo.addHabit("Test Fajr Habit", "Spirituality", true, "05:00")
        dataRepo.addJournalEntry("Backup Reflection", "Sincere growth", "Peaceful", "2L Water")
        dataRepo.addWater(350)

        val exportedPrefs = UserPreferences(
            language = AppLanguage.BANGLA,
            onboardingCompleted = true,
            userName = "Tariq",
            ageYears = 27,
            weightKg = 74,
            heightCm = 176,
            fitnessLevel = "Intermediate"
        )
        val jsonPayload = dataRepo.exportFullBackupJson(exportedPrefs)
        assertTrue(jsonPayload.contains("Tariq"))
        assertTrue(jsonPayload.contains("Backup Reflection"))

        val restoreResult = dataRepo.importFullBackupJson(jsonPayload, prefsRepo)
        assertTrue(restoreResult.isSuccess)
        val summary = restoreResult.getOrThrow()
        assertTrue(summary.habitsRestored >= 1)
        assertTrue(summary.journalRestored >= 1)
        assertTrue(summary.wellnessLogsRestored >= 1)

        val restoredPrefs = prefsRepo.preferencesFlow.first()
        assertEquals("Tariq", restoredPrefs.userName)
        assertEquals(74, restoredPrefs.weightKg)
    }

    @OptIn(ExperimentalTestApi::class)
    @Test
    fun fullCoreUserJourneyAcrossAllFourPillars() {
        composeRule.waitForIdle()

        // 1. 2-Page Onboarding: Test 8 languages, Dark/Light glass toggle, mandatory Country + Step 2 empty inputs & validation
        composeRule.onNodeWithTag("onboarding_lang_bn").performScrollTo().performClick()
        composeRule.waitUntilExactlyOneExists(hasText("রূহযেনায় স্বাগতম"), timeoutMillis = 5_000)
        composeRule.onNodeWithText("রূহযেনায় স্বাগতম").assertIsDisplayed()

        composeRule.onNodeWithTag("onboarding_lang_en").performScrollTo().performClick()
        composeRule.waitUntilExactlyOneExists(hasText("Welcome to RuhZena"), timeoutMillis = 5_000)
        assertTrue(composeRule.onAllNodesWithText("100% Local-First", substring = true).fetchSemanticsNodes().isEmpty())

        composeRule.onNodeWithTag("onboarding_theme_light").performScrollTo().performClick()
        composeRule.onNodeWithTag("onboarding_theme_dark").performScrollTo().performClick()

        // Country is mandatory before entering Step 2
        composeRule.onNodeWithTag("onboarding_enter_button").performScrollTo().performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("onboarding_step1_error"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("onboarding_country_BD").performScrollTo().performClick()
        composeRule.onNodeWithTag("onboarding_enter_button").performScrollTo().performClick()

        composeRule.waitUntilExactlyOneExists(hasTestTag("onboarding_name_input"), timeoutMillis = 5_000)
        val initialAgeText = composeRule.onNodeWithTag("onboarding_age_input")
            .fetchSemanticsNode().config.getOrNull(SemanticsProperties.EditableText)?.text.orEmpty()
        assertEquals("", initialAgeText)
        val initialWeightText = composeRule.onNodeWithTag("onboarding_weight_input")
            .fetchSemanticsNode().config.getOrNull(SemanticsProperties.EditableText)?.text.orEmpty()
        assertEquals("", initialWeightText)
        val initialHeightText = composeRule.onNodeWithTag("onboarding_height_input")
            .fetchSemanticsNode().config.getOrNull(SemanticsProperties.EditableText)?.text.orEmpty()
        assertEquals("", initialHeightText)

        // Mandatory validation blocks advancing when empty
        composeRule.onNodeWithTag("start_ruhzena_button").performScrollTo().performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("onboarding_validation_error"), timeoutMillis = 5_000)

        composeRule.onNodeWithTag("onboarding_name_input").performTextInput("Zayd")
        composeRule.onNodeWithTag("onboarding_age_input").performTextInput("25")
        composeRule.onNodeWithTag("onboarding_weight_input").performTextInput("68")
        composeRule.onNodeWithTag("onboarding_height_input").performTextInput("172")
        composeRule.onNodeWithTag("onboarding_gender_male").performScrollTo().performClick()
        composeRule.onNodeWithTag("start_ruhzena_button").performScrollTo().performClick()

        composeRule.waitUntilExactlyOneExists(hasTestTag("home_next_prayer_card"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("home_metric_nutrition").assertIsDisplayed()
        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("home_motivation_window_card"))
        composeRule.onNodeWithTag("home_motivation_window_card").assertIsDisplayed().performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("next_insight_button"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("next_insight_button").performClick()
        composeRule.onNodeWithTag("window_add_water_button").performClick()
        composeRule.onNodeWithTag("close_motivation_window_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("home_list").performScrollToNode(hasTestTag("home_continue_reading_card"))
        composeRule.onNodeWithTag("home_continue_reading_card").assertIsDisplayed()

        // 2. Settings Bottom Sheet: verify backup buttons exist & close cleanly
        composeRule.onNodeWithTag("home_settings_button").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("close_settings_button"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("settings_backup_export_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("close_settings_button").performClick()
        composeRule.waitForIdle()

        // 3. Spirituality Hub: Quran search, open Surah 1 reader, toggle pronunciation, open Ayah Explanation + deeper context
        composeRule.onNodeWithTag("nav_spirituality").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("surah_search_input"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("surah_row_1").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("ayah_card_1"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("toggle_pronunciation_button").performClick()
        composeRule.onNodeWithTag("ayah_explain_1").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("ayah_explanation_dialog"), timeoutMillis = 5_000)
        composeRule.waitUntilExactlyOneExists(hasTestTag("ayah_deeper_context_body"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("ayah_deeper_context_body").assertIsDisplayed()
        composeRule.onNodeWithTag("close_ayah_explanation_button").performClick()
        composeRule.onNodeWithTag("quran_back_to_list").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("surah_search_input"), timeoutMillis = 5_000)

        // Prayer & Qibla tab via direct 1-tap horizontal liquid-glass tab + compass dial
        composeRule.waitUntilExactlyOneExists(hasTestTag("spirituality_tab_prayer_qibla"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("spirituality_tab_prayer_qibla").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("detect_gps_button"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("qibla_compass_dial").assertIsDisplayed()
        assertTrue(composeRule.onAllNodesWithText("Magnetometer", substring = true).fetchSemanticsNodes().isEmpty())

        // Adhkar & Dua tab: Systemic progress + step counter + bottom Guided Tasbih CTA transitions directly to Guided Tasbih
        composeRule.onNodeWithTag("spirituality_tab_adhkar_dua").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("adhkar_systemic_progress_card"), timeoutMillis = 5_000)
        composeRule.waitUntilExactlyOneExists(hasTestTag("adhkar_card_adhkar_morning_ayat_kursi"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("adhkar_count_button_adhkar_morning_ayat_kursi").performClick()
        composeRule.onNodeWithTag("adhkar_card_adhkar_morning_ayat_kursi").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("detail_back_button"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("detail_back_button").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("adhkar_dua_list"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("adhkar_dua_list").performScrollToNode(hasTestTag("adhkar_start_guided_tasbih"))
        composeRule.onNodeWithTag("adhkar_start_guided_tasbih").performClick()

        // Guided Tasbih session activates automatically with step pills, then exit to Free Tasbih mode & verify virtues popup
        composeRule.waitUntilExactlyOneExists(hasTestTag("tasbih_guided_header"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("tasbih_tap_circle").performClick()
        composeRule.waitUntilExactlyOneExists(hasText("1"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("tasbih_exit_guided_button").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("tasbih_dropdown_button"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("tasbih_pronunciation_text", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithTag("tasbih_virtue_button").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("tasbih_virtue_popup"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("close_tasbih_virtue_popup").performClick()
        composeRule.waitForIdle()

        // 4. Dedicated Islamic Learning Academy (Beginner vs Experienced Entry Phase -> Step-by-Step + 6 Cleanly Organized Tabs)
        composeRule.onNodeWithTag("nav_learn").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("learning_experience_gate"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("learning_choose_beginner").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("learning_module_step_1"), timeoutMillis = 5_000)
        assertTrue(composeRule.onAllNodesWithTag("learning_tab_kids").fetchSemanticsNodes().isEmpty())
        composeRule.onNodeWithTag("learning_module_step_1").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("module_start_quiz_button"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("module_start_quiz_button").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("quiz_q0_opt0"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("quiz_q0_opt0").performClick()
        composeRule.onNodeWithTag("quiz_q1_opt1").performClick()
        composeRule.onNodeWithTag("quiz_q2_opt1").performClick()
        composeRule.onNodeWithTag("module_submit_quiz_button").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("module_quiz_continue_button"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("module_quiz_continue_button").performClick()

        composeRule.waitUntilExactlyOneExists(hasTestTag("learning_tab_pray"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("learning_tab_pray").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("pray_listen_arabic_button"), timeoutMillis = 5_000)

        composeRule.onNodeWithTag("learning_tab_arabic_studio").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("arabic_drawing_canvas"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("arabic_drawing_canvas").assertIsDisplayed()

        // Verify dedicated Stories tab is separated cleanly from Writing & Encyclopedia
        composeRule.onNodeWithTag("learning_tab_stories").performScrollTo().performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("learning_stories_list"), timeoutMillis = 5_000)

        // 5. Single Unified RuhZena AI Page (monochrome logo nav button, no 2-mode switcher, no manual online/offline toggle)
        composeRule.onNodeWithTag("nav_ai").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("ai_prompt_input"), timeoutMillis = 5_000)
        assertTrue(composeRule.onAllNodesWithTag("ai_research_switch").fetchSemanticsNodes().isEmpty())
        assertTrue(composeRule.onAllNodesWithTag("ai_personality_expert").fetchSemanticsNodes().isEmpty())
        composeRule.onNodeWithTag("ai_prompt_input").performTextInput("Importance of Salah prayer")
        composeRule.onNodeWithTag("ai_send_button").performClick()
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithText("Quranic Evidence", substring = true)
                .fetchSemanticsNodes().isNotEmpty() ||
                composeRule.onAllNodesWithText("Salah", substring = true).fetchSemanticsNodes().size >= 2
        }

        // Ask a fitness/wellness question directly in the same unified single-page AI chat
        composeRule.onNodeWithTag("ai_prompt_input").performTextInput("Build my home workout plan")
        composeRule.onNodeWithTag("ai_send_button").performClick()
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithText("RuhZena AI", substring = true)
                .fetchSemanticsNodes().isNotEmpty()
        }

        // 6. Life Hub -> Wellness: Recommended Plan + Guided Workout Preview + 3D Exercise Studio + Hydration logging
        composeRule.mainClock.autoAdvance = false
        composeRule.onNodeWithTag("nav_life").performClick()
        composeRule.mainClock.advanceTimeBy(600)

        // Verify personalized recommended plan card renders
        composeRule.onNodeWithTag("recommended_program_card").assertIsDisplayed()

        // Open Full Body Foundation preview modal and start guided workout
        composeRule.onNodeWithTag("program_card_full_body_foundation").performScrollTo().performClick()
        composeRule.mainClock.advanceTimeBy(300)
        composeRule.onNodeWithTag("start_guided_workout_button").assertIsDisplayed().performClick()
        composeRule.mainClock.advanceTimeBy(300)
        composeRule.onNodeWithTag("guided_skip_ready_button").assertIsDisplayed().performClick()
        composeRule.mainClock.advanceTimeBy(300)
        composeRule.onNodeWithTag("guided_close_button").performClick()
        composeRule.mainClock.advanceTimeBy(300)

        // Verify Form Library Studio & Studio Photo switcher + Push-Up chip
        repeat(8) {
            val visible = runCatching {
                composeRule.onNodeWithTag("exercise_chip_push_up").assertIsDisplayed()
                true
            }.getOrDefault(false)
            if (!visible) {
                composeRule.onNodeWithTag("workouts_list").performTouchInput {
                    swipeUp(startY = bottom * 0.75f, endY = bottom * 0.25f)
                }
                composeRule.mainClock.advanceTimeBy(200)
            }
        }
        composeRule.onNodeWithTag("exercise_chip_push_up").assertIsDisplayed().performClick()
        composeRule.mainClock.advanceTimeBy(200)

        repeat(6) {
            val visible = runCatching {
                composeRule.onNodeWithTag("demo_toggle_muscle_focus").assertIsDisplayed()
                true
            }.getOrDefault(false)
            if (!visible) {
                composeRule.onNodeWithTag("workouts_list").performTouchInput {
                    swipeUp(startY = bottom * 0.75f, endY = bottom * 0.35f)
                }
                composeRule.mainClock.advanceTimeBy(200)
            }
        }
        composeRule.onNodeWithTag("demo_toggle_muscle_focus").assertIsDisplayed().performClick()
        composeRule.mainClock.advanceTimeBy(150)
        composeRule.onNodeWithTag("demo_toggle_motion_guides").assertIsDisplayed().performClick()
        composeRule.mainClock.advanceTimeBy(150)
        composeRule.onNodeWithTag("exercise_live_motion_viewport").assertIsDisplayed()

        repeat(6) {
            val visible = runCatching {
                composeRule.onNodeWithTag("demo_next_step_button").assertIsDisplayed()
                true
            }.getOrDefault(false)
            if (!visible) {
                composeRule.onNodeWithTag("workouts_list").performTouchInput {
                    swipeUp(startY = bottom * 0.75f, endY = bottom * 0.25f)
                }
                composeRule.mainClock.advanceTimeBy(200)
            }
        }
        composeRule.onNodeWithTag("demo_next_step_button").assertIsDisplayed().performClick()
        composeRule.mainClock.advanceTimeBy(150)

        composeRule.onNodeWithTag("wellness_tab_hydration").performClick()
        composeRule.mainClock.advanceTimeBy(300)
        composeRule.mainClock.autoAdvance = true

        composeRule.waitUntilExactlyOneExists(hasTestTag("add_water_250"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("add_water_250").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("500 ml", substring = true)
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("hydration_list").performScrollToNode(hasTestTag("hydration_why_card"))
        composeRule.onNodeWithTag("hydration_why_card").assertIsDisplayed()

        // Verify Sleep tab is removed and Nutrition scanner/presets render
        assertTrue(composeRule.onAllNodesWithTag("wellness_tab_sleep").fetchSemanticsNodes().isEmpty())
        composeRule.onNodeWithTag("wellness_tab_nutrition").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("meal_photo_scanner_card"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("meal_photo_scanner_card").assertIsDisplayed()
        composeRule.onNodeWithTag("nutrition_list").performScrollToNode(hasTestTag("meal_presets_card"))
        composeRule.onNodeWithTag("meal_presets_card").assertIsDisplayed()

        // 7. Life Hub -> Discipline & Journal: Add habit + Add private journal reflection
        composeRule.onNodeWithTag("life_tab_discipline").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("new_habit_input"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("new_habit_input").performTextInput("Evening Quran Reflection")
        composeRule.onNodeWithTag("add_habit_button").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            runCatching {
                composeRule.onNodeWithTag("habits_list")
                    .performScrollToNode(hasText("Evening Quran Reflection", substring = true))
                true
            }.getOrDefault(false)
        }
        composeRule.onNodeWithText("Evening Quran Reflection", substring = true).assertIsDisplayed()

        composeRule.onNodeWithTag("discipline_tab_journal").performClick()
        composeRule.waitUntilExactlyOneExists(hasTestTag("journal_title_input"), timeoutMillis = 5_000)
        composeRule.onNodeWithTag("journal_title_input").performTextInput("Grateful Morning")
        composeRule.onNodeWithTag("journal_content_input").performTextInput("Completed Fajr and light mobility.")
        composeRule.onNodeWithTag("save_journal_button").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            runCatching {
                composeRule.onNodeWithTag("journal_list")
                    .performScrollToNode(hasText("Grateful Morning", substring = true))
                true
            }.getOrDefault(false)
        }
        composeRule.onNodeWithText("Grateful Morning", substring = true).assertIsDisplayed()
    }
}
