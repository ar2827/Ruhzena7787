package com.example.ruhzena.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.IslamicContentData
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.local.BookmarkEntity
import com.example.ruhzena.ui.exercises.ExerciseLibrary
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.LocalRuhZenaPalette

sealed interface GlobalSearchAction {
    data class OpenSurah(val surahNumber: Int) : GlobalSearchAction
    data object OpenAdhkar : GlobalSearchAction
    data object OpenDua : GlobalSearchAction
    data object OpenTasbih : GlobalSearchAction
    data object OpenLessons : GlobalSearchAction
    data object OpenWorkouts : GlobalSearchAction
}

private data class SearchHitItem(
    val id: String,
    val type: String,
    val title: String,
    val subtitle: String,
    val action: GlobalSearchAction
)

@Composable
fun GlobalSearchDialog(
    onAction: (GlobalSearchAction) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    var query by remember { mutableStateOf("") }
    var filterType by remember { mutableStateOf("ALL") }

    val hits = remember(query, filterType, isBn) {
        val q = query.trim().lowercase()
        val list = mutableListOf<SearchHitItem>()

        if (filterType == "ALL" || filterType == "QURAN") {
            SurahCatalog.allSurahs.filter { s ->
                q.isEmpty() ||
                    s.englishName.lowercase().contains(q) ||
                    s.englishMeaning.lowercase().contains(q) ||
                    s.banglaName.contains(q) ||
                    s.arabicName.contains(q) ||
                    s.number.toString() == q
            }.take(if (q.isEmpty()) 5 else 25).forEach { s ->
                list += SearchHitItem(
                    id = "surah_${s.number}",
                    type = "Quran",
                    title = "${s.number}. ${if (isBn) s.banglaName else s.englishName} (${s.arabicName})",
                    subtitle = "${s.englishMeaning} • ${s.ayahCount} Ayahs",
                    action = GlobalSearchAction.OpenSurah(s.number)
                )
            }
        }
        if (filterType == "ALL" || filterType == "ADHKAR") {
            IslamicContentData.adhkarList.filter { d ->
                q.isEmpty() || d.titleEn.lowercase().contains(q) || d.titleBn.contains(q) || d.translationEn.lowercase().contains(q)
            }.take(if (q.isEmpty()) 4 else 15).forEach { d ->
                list += SearchHitItem(
                    id = "dhikr_${d.id}",
                    type = "Adhkar",
                    title = if (isBn) d.titleBn else d.titleEn,
                    subtitle = d.sourceRef,
                    action = GlobalSearchAction.OpenAdhkar
                )
            }
        }
        if (filterType == "ALL" || filterType == "DUA") {
            IslamicContentData.duaList.filter { d ->
                q.isEmpty() || d.titleEn.lowercase().contains(q) || d.titleBn.contains(q) ||
                    d.categoryEn.lowercase().contains(q) || d.translationEn.lowercase().contains(q)
            }.take(if (q.isEmpty()) 4 else 20).forEach { d ->
                list += SearchHitItem(
                    id = "dua_${d.id}",
                    type = "Dua",
                    title = if (isBn) d.titleBn else d.titleEn,
                    subtitle = "${if (isBn) d.categoryBn else d.categoryEn} • ${d.sourceRef}",
                    action = GlobalSearchAction.OpenDua
                )
            }
        }
        if (filterType == "ALL" || filterType == "TASBIH") {
            IslamicContentData.tasbihPresets.filter { t ->
                q.isEmpty() || t.titleEn.lowercase().contains(q) || t.titleBn.contains(q) || t.meaningEn.lowercase().contains(q)
            }.take(if (q.isEmpty()) 3 else 15).forEach { t ->
                list += SearchHitItem(
                    id = "tasbih_${t.id}",
                    type = "Tasbih",
                    title = if (isBn) t.titleBn else t.titleEn,
                    subtitle = if (isBn) t.meaningBn else t.meaningEn,
                    action = GlobalSearchAction.OpenTasbih
                )
            }
        }
        if (filterType == "ALL" || filterType == "WORKOUTS") {
            ExerciseLibrary.exercises.filter { e ->
                q.isEmpty() || e.nameEn.lowercase().contains(q) || e.nameBn.contains(q) || e.categoryEn.lowercase().contains(q)
            }.take(if (q.isEmpty()) 4 else 15).forEach { e ->
                list += SearchHitItem(
                    id = "ex_${e.id}",
                    type = "Training",
                    title = if (isBn) e.nameBn else e.nameEn,
                    subtitle = if (isBn) e.categoryBn else e.categoryEn,
                    action = GlobalSearchAction.OpenWorkouts
                )
            }
        }
        list
    }

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .testTag("global_search_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = palette.surfaceBg,
            border = BorderStroke(1.dp, palette.borderAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBn) "সব কিছু খুঁজুন" else "Unified Search",
                        style = MaterialTheme.typography.titleLarge,
                        color = palette.textPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textPrimary)
                    }
                }

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = {
                        Text(
                            if (isBn) "এখানে লিখুন" else "Type here",
                            color = palette.textMuted
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accentSoft) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accentPrimary,
                        unfocusedBorderColor = palette.borderNeutral,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("global_search_input")
                )

                val filters = listOf("ALL", "QURAN", "DUA", "ADHKAR", "TASBIH", "WORKOUTS")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filters) { f ->
                        GlassFilterChip(
                            label = f,
                            selected = filterType == f,
                            onClick = { filterType = f }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(hits, key = { it.id }) { hit ->
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(12.dp),
                            onClick = {
                                onAction(hit.action)
                                onDismiss()
                            }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = hit.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                StatusPillBadge(label = hit.type, accentColor = palette.gold)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = hit.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookmarksHubDialog(
    bookmarks: List<BookmarkEntity>,
    onOpenBookmark: (BookmarkEntity) -> Unit,
    onRemoveBookmark: (BookmarkEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    var selectedType by remember { mutableStateOf("ALL") }

    val filtered = remember(bookmarks, selectedType) {
        if (selectedType == "ALL") bookmarks else bookmarks.filter { it.itemType == selectedType }
    }

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .testTag("bookmarks_hub_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = palette.surfaceBg,
            border = BorderStroke(1.dp, palette.borderAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bookmark, contentDescription = null, tint = palette.gold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBn) "সংরক্ষিত বুকমার্ক (${bookmarks.size})" else "Saved Bookmarks (${bookmarks.size})",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textPrimary)
                    }
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("ALL", "QURAN", "ADHKAR", "DUA")) { type ->
                        GlassFilterChip(
                            label = type,
                            selected = selectedType == type,
                            onClick = { selectedType = type }
                        )
                    }
                }

                if (filtered.isEmpty()) {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = if (isBn) {
                                "এখনো কোনো বুকমার্ক সংরক্ষিত নেই। কুরআন, যিকির বা দুআ কার্ডের বুকমার্ক আইকনে ট্যাপ করুন।"
                            } else {
                                "No bookmarks yet. Tap the bookmark icon on any Quran Ayah, Dhikr, or Dua to save it here."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textSecondary
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filtered, key = { it.key }) { bm ->
                            GlassCard(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(12.dp),
                                onClick = {
                                    onOpenBookmark(bm)
                                    onDismiss()
                                }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    StatusPillBadge(label = bm.itemType, accentColor = palette.accentSoft)
                                    IconButton(onClick = { onRemoveBookmark(bm) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = palette.coral)
                                    }
                                }
                                Text(bm.title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                                if (bm.arabicText.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = bm.arabicText,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            fontFamily = ArabicFontFamily,
                                            textDirection = TextDirection.Rtl
                                        ),
                                        color = palette.gold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                if (bm.subtitle.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = bm.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
