package com.example.ruhzena.ai.agent

import com.example.ruhzena.data.local.AiProviderHealthEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.min

/**
 * Curated registry preserving ALL 14 original models across the 4 core providers:
 * - Tier 1: Groq (5 models)
 * - Tier 2: OpenRouter (5 models + background free-catalog discovery)
 * - Tier 3: Cloudflare Workers AI (2 models)
 * - Tier 4: Firebase AI Logic / Google Gemini (2 models)
 */
object AiModelCatalog {
    val defaultModels: List<AiModelSpec> = listOf(
        // =========================================================================
        // TIER 1: Groq (ALL 5 ORIGINAL MODELS PRESERVED INTACT)
        // =========================================================================
        AiModelSpec(
            provider = AiProviderId.GROQ,
            modelId = "openai/gpt-oss-120b",
            displayName = "Groq GPT-OSS 120B",
            priorityTier = 1,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 3_400,
            supportsVision = false,
            supportsTools = true,
            isHighReasoning = true,
            maxOutputTokens = 1_500
        ),
        AiModelSpec(
            provider = AiProviderId.GROQ,
            modelId = "llama-3.3-70b-versatile",
            displayName = "Groq Llama 3.3 70B",
            priorityTier = 1,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 3_400,
            supportsVision = false,
            supportsTools = true,
            isHighReasoning = true,
            maxOutputTokens = 1_500
        ),
        AiModelSpec(
            provider = AiProviderId.GROQ,
            modelId = "openai/gpt-oss-20b",
            displayName = "Groq GPT-OSS 20B",
            priorityTier = 1,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 3_200,
            supportsVision = false,
            isUltraFast = true,
            maxOutputTokens = 1_300
        ),
        AiModelSpec(
            provider = AiProviderId.GROQ,
            modelId = "llama-3.1-8b-instant",
            displayName = "Groq Llama 3.1 8B Instant",
            priorityTier = 1,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 2_800,
            supportsVision = false,
            isUltraFast = true,
            maxOutputTokens = 1_100
        ),
        AiModelSpec(
            provider = AiProviderId.GROQ,
            modelId = "qwen/qwen3-8-27b",
            displayName = "Groq Qwen Vision",
            priorityTier = 1,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 3_000,
            supportsVision = true,
            maxOutputTokens = 1_200
        ),

        // =========================================================================
        // TIER 2: OpenRouter (ALL 5 ORIGINAL MODELS PRESERVED INTACT)
        // =========================================================================
        AiModelSpec(
            provider = AiProviderId.OPENROUTER,
            modelId = "openrouter/free",
            displayName = "OpenRouter Free Auto-Router",
            priorityTier = 2,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 6_000,
            supportsVision = true,
            supportsTools = true,
            isHighReasoning = true,
            maxOutputTokens = 1_500
        ),
        AiModelSpec(
            provider = AiProviderId.OPENROUTER,
            modelId = "google/gemma-4-31b-it:free",
            displayName = "OpenRouter Gemma 4 31B Free",
            priorityTier = 2,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 6_000,
            supportsVision = true,
            isHighReasoning = true,
            maxOutputTokens = 1_500
        ),
        AiModelSpec(
            provider = AiProviderId.OPENROUTER,
            modelId = "nvidia/nemotron-3-ultra-550b-a55b:free",
            displayName = "OpenRouter Nemotron Ultra Free",
            priorityTier = 2,
            contextWindowTokens = 256_000,
            safePromptBudgetTokens = 8_000,
            supportsVision = false,
            isHighReasoning = true,
            maxOutputTokens = 1_600
        ),
        AiModelSpec(
            provider = AiProviderId.OPENROUTER,
            modelId = "nvidia/nemotron-3.5-super-vl:free",
            displayName = "OpenRouter Nemotron Vision Free",
            priorityTier = 2,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 5_000,
            supportsVision = true,
            maxOutputTokens = 1_200
        ),
        AiModelSpec(
            provider = AiProviderId.OPENROUTER,
            modelId = "google/gemma-4-26b-a4b-it:free",
            displayName = "OpenRouter Gemma 4 26B Free",
            priorityTier = 2,
            contextWindowTokens = 128_000,
            safePromptBudgetTokens = 5_500,
            supportsVision = true,
            isUltraFast = true,
            maxOutputTokens = 1_300
        ),

        // =========================================================================
        // TIER 3: Cloudflare Workers AI (ALL 2 ORIGINAL MODELS PRESERVED INTACT)
        // =========================================================================
        AiModelSpec(
            provider = AiProviderId.CLOUDFLARE,
            modelId = "@cf/meta/llama-3.3-70b-instruct-fp8-fast",
            displayName = "Cloudflare Llama 3.3 70B Fast",
            priorityTier = 3,
            contextWindowTokens = 24_000,
            safePromptBudgetTokens = 4_000,
            supportsVision = false,
            isHighReasoning = true,
            maxOutputTokens = 1_400
        ),
        AiModelSpec(
            provider = AiProviderId.CLOUDFLARE,
            modelId = "@cf/google/gemma-4-26b-a4b-it",
            displayName = "Cloudflare Gemma 4 26B Vision",
            priorityTier = 3,
            contextWindowTokens = 32_000,
            safePromptBudgetTokens = 4_000,
            supportsVision = true,
            supportsTools = true,
            isUltraFast = true,
            maxOutputTokens = 1_300
        ),

        // =========================================================================
        // TIER 4: Firebase AI Logic / Google Gemini (ALL 2 ORIGINAL MODELS PRESERVED INTACT)
        // =========================================================================
        AiModelSpec(
            provider = AiProviderId.FIREBASE_GEMINI,
            modelId = "gemini-3.8-flash",
            displayName = "Firebase Gemini 3.8 Flash",
            priorityTier = 4,
            contextWindowTokens = 1_000_000,
            safePromptBudgetTokens = 12_000,
            supportsVision = true,
            supportsTools = true,
            isHighReasoning = true,
            maxOutputTokens = 1_800
        ),
        AiModelSpec(
            provider = AiProviderId.FIREBASE_GEMINI,
            modelId = "gemini-3.5-flash-lite",
            displayName = "Firebase Gemini 3.5 Flash-Lite",
            priorityTier = 4,
            contextWindowTokens = 1_000_000,
            safePromptBudgetTokens = 10_000,
            supportsVision = true,
            isUltraFast = true,
            maxOutputTokens = 1_400
        )
    )

    fun primaryModelForProvider(providerId: AiProviderId): AiModelSpec? =
        defaultModels.firstOrNull { it.provider == providerId }
}

interface HealthPersistenceSink {
    suspend fun loadAllHealth(): List<AiProviderHealthEntity>
    suspend fun saveHealth(entity: AiProviderHealthEntity)
}

/**
 * Tracks per-model health, EWMA total latency, EWMA first-token latency (TTFT),
 * progressive cooldowns, and session-level disables for unavailable/auth-invalid models.
 */
class ProviderHealthTracker(
    private val clock: AgentClock = SystemAgentClock,
    private val persistence: HealthPersistenceSink? = null
) {
    private val mutex = Mutex()
    private val states = LinkedHashMap<String, ProviderHealthState>()
    @Volatile
    private var loadedFromDisk = false

    suspend fun ensureLoaded() {
        if (loadedFromDisk) return
        mutex.withLock {
            if (loadedFromDisk) return
            loadedFromDisk = true
            persistence?.loadAllHealth()?.forEach { e ->
                val provider = runCatching { AiProviderId.valueOf(e.providerId) }.getOrNull() ?: return@forEach
                val errKind = e.lastErrorKind.takeIf { it.isNotBlank() }?.let {
                    runCatching { AiFailureKind.valueOf(it) }.getOrNull()
                }
                states[e.modelKey] = ProviderHealthState(
                    modelKey = e.modelKey,
                    provider = provider,
                    modelId = e.modelId,
                    consecutiveFailures = e.consecutiveFailures,
                    cooldownUntilMillis = e.cooldownUntilMillis,
                    lastLatencyMs = e.lastLatencyMs,
                    lastErrorKind = errKind,
                    lastErrorSummary = e.lastErrorSummary,
                    totalSuccesses = e.totalSuccesses,
                    totalFailures = e.totalFailures,
                    sessionDisabled = false
                )
            }
        }
    }

    suspend fun getState(spec: AiModelSpec): ProviderHealthState = mutex.withLock {
        states[spec.modelKey] ?: ProviderHealthState(spec.modelKey, spec.provider, spec.modelId)
    }

    suspend fun getAllStates(): List<ProviderHealthState> = mutex.withLock {
        states.values.toList()
    }

    suspend fun isAvailableNow(spec: AiModelSpec): Boolean = mutex.withLock {
        val st = states[spec.modelKey] ?: return true
        if (st.sessionDisabled) return false
        return !st.isInCooldown(clock.nowMillis())
    }

    fun currentTimeMillis(): Long = clock.nowMillis()

    suspend fun snapshotStates(): Map<String, ProviderHealthState> = mutex.withLock {
        HashMap(states)
    }

    suspend fun recordSuccess(spec: AiModelSpec, latencyMs: Long, firstTokenMs: Long = latencyMs) {
        val now = clock.nowMillis()
        val updated = mutex.withLock {
            val prev = states[spec.modelKey] ?: ProviderHealthState(spec.modelKey, spec.provider, spec.modelId)
            val ewmaTotal = if (prev.lastLatencyMs <= 0L) latencyMs else ((prev.lastLatencyMs * 6 + latencyMs * 4) / 10)
            val ewmaTtft = if (prev.firstTokenLatencyMs <= 0L) firstTokenMs else ((prev.firstTokenLatencyMs * 6 + firstTokenMs * 4) / 10)
            prev.copy(
                consecutiveFailures = 0,
                cooldownUntilMillis = 0L,
                lastLatencyMs = ewmaTotal,
                firstTokenLatencyMs = ewmaTtft,
                lastErrorKind = null,
                lastErrorSummary = "",
                totalSuccesses = prev.totalSuccesses + 1,
                sessionDisabled = false
            ).also { states[spec.modelKey] = it }
        }
        persist(updated, now)
    }

    suspend fun recordFailure(
        spec: AiModelSpec,
        kind: AiFailureKind,
        retryAfterSeconds: Long? = null,
        summary: String = ""
    ) {
        val now = clock.nowMillis()
        val updated = mutex.withLock {
            val prev = states[spec.modelKey] ?: ProviderHealthState(spec.modelKey, spec.provider, spec.modelId)
            val failures = prev.consecutiveFailures + 1
            val cooldownMs = computeCooldownMillis(kind, failures, retryAfterSeconds)
            val disableForSession = kind == AiFailureKind.MODEL_UNAVAILABLE || kind == AiFailureKind.AUTH_INVALID
            prev.copy(
                consecutiveFailures = failures,
                cooldownUntilMillis = if (cooldownMs > 0L) now + cooldownMs else 0L,
                lastErrorKind = kind,
                lastErrorSummary = summary.take(160),
                totalFailures = prev.totalFailures + 1,
                sessionDisabled = disableForSession
            ).also { states[spec.modelKey] = it }
        }
        persist(updated, now)
    }

    suspend fun resetAll() {
        mutex.withLock { states.clear() }
    }

    private fun computeCooldownMillis(
        kind: AiFailureKind,
        consecutiveFailures: Int,
        retryAfterSeconds: Long?
    ): Long {
        val explicitMs = retryAfterSeconds?.coerceIn(5L, 3600L)?.times(1000L)
        val multiplier = min(consecutiveFailures, 5).toLong()
        return when (kind) {
            AiFailureKind.RATE_LIMIT_429 -> explicitMs ?: (60_000L * multiplier)
            AiFailureKind.QUOTA_EXHAUSTED -> explicitMs ?: (30 * 60_000L)
            AiFailureKind.HIGH_DEMAND_OVERLOAD -> explicitMs ?: (45_000L * multiplier)
            AiFailureKind.SERVER_OUTAGE_5XX -> explicitMs ?: (60_000L * multiplier)
            AiFailureKind.TIMEOUT_OR_STALL -> 45_000L * multiplier
            AiFailureKind.MID_STREAM_INTERRUPT -> 20_000L * multiplier
            AiFailureKind.NETWORK_ERROR -> 15_000L * multiplier
            AiFailureKind.MODEL_UNAVAILABLE -> 6 * 60 * 60_000L
            AiFailureKind.AUTH_INVALID -> 60 * 60_000L
            AiFailureKind.EMPTY_RESPONSE -> 15_000L
            AiFailureKind.UNKNOWN -> 30_000L
        }
    }

    private suspend fun persist(st: ProviderHealthState, now: Long) {
        runCatching {
            persistence?.saveHealth(
                AiProviderHealthEntity(
                    modelKey = st.modelKey,
                    providerId = st.provider.name,
                    modelId = st.modelId,
                    consecutiveFailures = st.consecutiveFailures,
                    cooldownUntilMillis = st.cooldownUntilMillis,
                    lastLatencyMs = st.lastLatencyMs,
                    lastErrorKind = st.lastErrorKind?.name.orEmpty(),
                    lastErrorSummary = st.lastErrorSummary,
                    totalSuccesses = st.totalSuccesses,
                    totalFailures = st.totalFailures,
                    sessionDisabled = st.sessionDisabled,
                    updatedAt = now
                )
            )
        }
    }
}

/**
 * Classifies queries and dynamically ranks healthy models across the 4 core providers:
 * - Preserves Tier 1 (Groq) -> Tier 2 (OpenRouter) -> Tier 3 (Cloudflare) -> Tier 4 (Firebase Gemini)
 * - Routes fast models (`llama-3.1-8b-instant`, `gpt-oss-20b`, `gemma-4-26b`, `gemini-3.5-flash-lite`)
 *   for ordinary/simple questions and high-reasoning models (`gpt-oss-120b`, `llama-3.3-70b-versatile`,
 *   `openrouter/free`, `gemma-4-31b`, `nemotron-3-ultra`, `gemini-3.8-flash`) for complex reasoning,
 *   coding, multi-step planning, and Islamic knowledge.
 * - Uses real measured EWMA TTFT + total latency + reliability to pick the fastest healthy model
 *   and switches immediately to an independent provider on failure.
 */
class IntelligentModelRouter(
    private val healthTracker: ProviderHealthTracker,
    private val modelsProvider: () -> List<AiModelSpec> = { AiModelCatalog.defaultModels }
) {
    private val dynamicOpenRouterFreeModels = mutableListOf<AiModelSpec>()
    @Volatile
    private var lastOpenRouterDiscoveryMs: Long = 0L

    fun classifyQuery(
        query: String,
        requiresVision: Boolean = false,
        requiresStructuredJson: Boolean = false,
        estimatedInputTokens: Int = 400
    ): QueryProfile {
        val q = query.lowercase().trim()
        val wordCount = q.split(Regex("\\s+")).count { it.isNotBlank() }

        val domain = when {
            q.containsAny(
                "quran", "ayah", "surah", "hadith", "sunnah", "fiqh", "halal", "haram", "bid'ah", "bidah",
                "salah", "namaz", "wudu", "zakat", "ramadan", "fasting", "hijab", "tafsir", "prophet",
                "sahaba", "dua", "dhikr", "allah", "islam", "madhhab", "hanafi", "shafi", "maliki", "hanbali",
                "qasr", "witr", "tahajjud", "fajr", "tawbah", "sabr", "tawakkul", "কুরআন", "হাদিস", "নামাজ", "রোজা", "দোয়া"
            ) -> QueryDomain.ISLAMIC_KNOWLEDGE

            q.containsAny(
                "code", "kotlin", "python", "javascript", "typescript", "sql", "bug", "compile",
                "algorithm", "function", "regex", "json", "api", "debug", "refactor", "architecture"
            ) -> QueryDomain.CODING_TECHNICAL

            q.containsAny(
                "plan", "step by step", "roadmap", "schedule", "routine", "day by day", "week", "multi-step", "project", "পরিকল্পনা"
            ) -> QueryDomain.MULTI_STEP_PLANNING

            q.containsAny(
                "workout", "exercise", "calories", "protein", "meal", "hydration", "water", "muscle", "weight", "diet", "sleep", "ব্যায়াম", "খাবার"
            ) -> QueryDomain.WELLNESS_FITNESS

            q.containsAny(
                "anxious", "sad", "stressed", "depressed", "lonely", "overwhelmed", "cry", "heart", "scared", "struggling", "দুঃখ", "হতাশ"
            ) -> QueryDomain.EMOTIONAL_SUPPORT

            else -> QueryDomain.EVERYDAY_CHAT
        }

        val asksDeepAnalysis = q.containsAny(
            "explain", "compare", "difference", "detailed", "analyze", "why", "evidence",
            "ruling", "proof", "derive", "in depth", "বিস্তারিত", "পার্থক্য", "ব্যাখ্যা"
        )

        val complexity = when {
            requiresVision || requiresStructuredJson || wordCount >= 32 ||
                domain == QueryDomain.ISLAMIC_KNOWLEDGE ||
                domain == QueryDomain.CODING_TECHNICAL ||
                domain == QueryDomain.MULTI_STEP_PLANNING ||
                asksDeepAnalysis ->
                QueryComplexity.COMPLEX

            wordCount <= 14 && (domain == QueryDomain.EVERYDAY_CHAT || domain == QueryDomain.WELLNESS_FITNESS) ->
                QueryComplexity.SIMPLE

            else -> QueryComplexity.STANDARD
        }

        return QueryProfile(
            domain = domain,
            complexity = complexity,
            requiresVision = requiresVision,
            requiresStructuredJson = requiresStructuredJson,
            estimatedInputTokens = estimatedInputTokens
        )
    }

    suspend fun rankCandidates(
        profile: QueryProfile,
        configuredProviders: Set<AiProviderId>,
        excludeModelKeys: Set<String> = emptySet(),
        preferredSkipProvider: AiProviderId? = null
    ): List<AiModelSpec> {
        healthTracker.ensureLoaded()
        val nowMs = healthTracker.currentTimeMillis()
        val healthSnapshot = healthTracker.snapshotStates()
        val combinedCatalog = (modelsProvider() + dynamicOpenRouterFreeModels).distinctBy { it.modelKey }

        val eligible = combinedCatalog.filter { spec ->
            spec.provider in configuredProviders &&
                spec.modelKey !in excludeModelKeys &&
                (!profile.requiresVision || spec.supportsVision) &&
                spec.contextWindowTokens >= profile.estimatedInputTokens + 512
        }

        val scored = eligible.mapNotNull { spec ->
            // Always verify availability through tracker (honors injected FakeClock in tests!)
            if (!healthTracker.isAvailableNow(spec)) return@mapNotNull null
            val health = healthSnapshot[spec.modelKey]
                ?: ProviderHealthState(spec.modelKey, spec.provider, spec.modelId)

            var score = 1200.0
            // Base tier priority (1=Groq, 2=OpenRouter, 3=Cloudflare, 4=Firebase Gemini)
            score -= spec.priorityTier * 130.0

            // Task complexity & speed fit
            when (profile.complexity) {
                QueryComplexity.COMPLEX -> {
                    if (spec.isHighReasoning) score += 95.0
                    if (spec.isUltraFast && !spec.isHighReasoning) score -= 55.0
                }
                QueryComplexity.SIMPLE -> {
                    if (spec.isUltraFast) score += 120.0
                    if (spec.isHighReasoning && !spec.isUltraFast) score -= 25.0
                }
                QueryComplexity.STANDARD -> {
                    if (spec.isUltraFast) score += 65.0
                    if (spec.isHighReasoning) score += 35.0
                }
            }

            if ((profile.domain == QueryDomain.ISLAMIC_KNOWLEDGE || profile.domain == QueryDomain.CODING_TECHNICAL) && spec.isHighReasoning) {
                score += 50.0
            }
            if (profile.requiresVision && spec.supportsVision) {
                score += 45.0
            }

            // Immediately jump away from a provider that just failed on this turn
            if (preferredSkipProvider != null && spec.provider == preferredSkipProvider) {
                score -= 260.0
            }

            // Real measured speed score (70% TTFT + 30% total latency) so faster healthy models win cleanly
            val effectiveSpeedMs = when {
                health.firstTokenLatencyMs > 0L && health.lastLatencyMs > 0L ->
                    (health.firstTokenLatencyMs * 7 + health.lastLatencyMs * 3) / 10
                health.firstTokenLatencyMs > 0L -> health.firstTokenLatencyMs
                health.lastLatencyMs > 0L -> health.lastLatencyMs
                else -> 0L
            }
            if (effectiveSpeedMs in 1L..25_000L) {
                val speedMultiplier = when (profile.complexity) {
                    QueryComplexity.SIMPLE -> 2.4
                    QueryComplexity.STANDARD -> 1.7
                    QueryComplexity.COMPLEX -> 1.1
                }
                score += (((2_200L - effectiveSpeedMs).coerceIn(-4_500L, 1_800L) / 60.0) * speedMultiplier)
                if (effectiveSpeedMs <= 800L) score += 15.0
                if (effectiveSpeedMs >= 4_500L) score -= 60.0
            }

            // Reliability score from observed success/failure ratio
            val totalCalls = health.totalSuccesses + health.totalFailures
            if (totalCalls >= 2) {
                val successRate = health.totalSuccesses.toDouble() / totalCalls.toDouble()
                score += (successRate - 0.7) * 80.0
            }

            // Half-open recovery: once a model's cooldown has fully expired, decay its failure penalty
            // so a primary tier model automatically gets probed and recovers cleanly instead of being
            // permanently buried behind fallback tiers.
            val cooldownExpiredRecovery = health.cooldownUntilMillis > 0L && nowMs >= health.cooldownUntilMillis
            val failurePenaltyPerStrike = if (cooldownExpiredRecovery) 12.0 else 45.0
            score -= min(health.consecutiveFailures, 4) * failurePenaltyPerStrike

            spec to score
        }.sortedByDescending { it.second }.map { it.first }

        return interleaveForProviderDiversity(scored, preferImmediateSwitch = preferredSkipProvider != null)
    }

    private fun interleaveForProviderDiversity(
        sorted: List<AiModelSpec>,
        preferImmediateSwitch: Boolean
    ): List<AiModelSpec> {
        if (sorted.size <= 2) return sorted
        val result = mutableListOf<AiModelSpec>()
        val remaining = sorted.toMutableList()

        val first = remaining.removeAt(0)
        result.add(first)

        val secondDifferentProvider = remaining.firstOrNull { it.provider != first.provider }
        val sameProviderFallback = remaining.firstOrNull { it.provider == first.provider }

        if (!preferImmediateSwitch && sameProviderFallback != null && first.provider == AiProviderId.GROQ) {
            remaining.remove(sameProviderFallback)
            result.add(sameProviderFallback)
        } else if (secondDifferentProvider != null) {
            remaining.remove(secondDifferentProvider)
            result.add(secondDifferentProvider)
        }

        while (remaining.isNotEmpty()) {
            val lastProvider = result.last().provider
            val next = remaining.firstOrNull { it.provider != lastProvider } ?: remaining.first()
            remaining.remove(next)
            result.add(next)
        }
        return result
    }

    suspend fun refreshOpenRouterFreeCatalogIfStale(
        httpClient: OkHttpClient,
        nowMillis: Long = System.currentTimeMillis()
    ) = withContext(Dispatchers.IO) {
        if (nowMillis - lastOpenRouterDiscoveryMs < TimeUnit.HOURS.toMillis(6)) return@withContext
        lastOpenRouterDiscoveryMs = nowMillis
        runCatching {
            val req = Request.Builder()
                .url("https://openrouter.ai/api/v1/models")
                .header("User-Agent", "RuhZenaAndroid/2.0")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("data") ?: return@use
                val discovered = mutableListOf<AiModelSpec>()
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val id = item.optString("id").trim()
                    if (!id.endsWith(":free")) continue
                    val pricing = item.optJSONObject("pricing")
                    val promptPrice = pricing?.optString("prompt")?.toDoubleOrNull() ?: 1.0
                    val completionPrice = pricing?.optString("completion")?.toDoubleOrNull() ?: 1.0
                    if (promptPrice > 0.0 || completionPrice > 0.0) continue
                    val ctx = item.optInt("context_length", 32_000).coerceAtLeast(8_192)
                    val arch = item.optJSONObject("architecture")?.optString("modality").orEmpty()
                    val hasVision = arch.contains("image", ignoreCase = true)
                    val name = item.optString("name").ifBlank { id }
                    discovered.add(
                        AiModelSpec(
                            provider = AiProviderId.OPENROUTER,
                            modelId = id,
                            displayName = "OpenRouter $name",
                            priorityTier = 2,
                            contextWindowTokens = ctx,
                            safePromptBudgetTokens = min(ctx / 3, 6_000),
                            supportsVision = hasVision,
                            isHighReasoning = id.contains("70b", true) || id.contains("ultra", true) || id.contains("31b", true),
                            maxOutputTokens = 1_400
                        )
                    )
                    if (discovered.size >= 6) break
                }
                if (discovered.isNotEmpty()) {
                    dynamicOpenRouterFreeModels.clear()
                    dynamicOpenRouterFreeModels.addAll(discovered)
                }
            }
        }
    }

    private fun String.containsAny(vararg needles: String): Boolean =
        needles.any { this.contains(it, ignoreCase = true) }
}
