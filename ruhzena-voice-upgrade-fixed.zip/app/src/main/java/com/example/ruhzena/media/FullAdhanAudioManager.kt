package com.example.ruhzena.media

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

private const val ADHAN_TAG = "FullAdhanAudioManager"

enum class AdhanMuezzin(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val locationEn: String,
    val mirrorUrls: List<String>
) {
    MAKKAH(
        id = "MAKKAH",
        nameEn = "Masjid al-Haram (Makkah)",
        nameBn = "মসজিদুল হারাম (মক্কা)",
        locationEn = "Full Adhan • Makkah",
        mirrorUrls = listOf(
            "https://www.islamcan.com/audio/adhan/azan1.mp3",
            "https://cdn.aladhan.com/audio/adhans/a1.mp3",
            "https://media.blubrry.com/muslim_central_quran/podcasts.qurancentral.com/adhan/adhan-makkah.mp3"
        )
    ),
    MADINAH(
        id = "MADINAH",
        nameEn = "Al-Masjid an-Nabawi (Madinah)",
        nameBn = "মসজিদে নববী (মদিনা)",
        locationEn = "Full Adhan • Madinah",
        mirrorUrls = listOf(
            "https://www.islamcan.com/audio/adhan/azan2.mp3",
            "https://cdn.aladhan.com/audio/adhans/a2.mp3",
            "https://media.blubrry.com/muslim_central_quran/podcasts.qurancentral.com/adhan/adhan-madinah.mp3"
        )
    ),
    ALAFASY(
        id = "ALAFASY",
        nameEn = "Mishary Rashid Alafasy",
        nameBn = "মিশারি রশিদ আল-আফাসি",
        locationEn = "Full Adhan • Kuwait",
        mirrorUrls = listOf(
            "https://www.islamcan.com/audio/adhan/azan15.mp3",
            "https://media.blubrry.com/muslim_central_quran/podcasts.qurancentral.com/adhan/mishary-rashid-alafasy-adhan.mp3",
            "https://cdn.aladhan.com/audio/adhans/a4.mp3"
        )
    ),
    AL_AQSA(
        id = "AL_AQSA",
        nameEn = "Masjid Al-Aqsa (Jerusalem)",
        nameBn = "মসজিদুল আকসা (জেরুজালেম)",
        locationEn = "Full Adhan • Al-Aqsa",
        mirrorUrls = listOf(
            "https://www.islamcan.com/audio/adhan/azan3.mp3",
            "https://cdn.aladhan.com/audio/adhans/a3.mp3"
        )
    );

    companion object {
        fun fromId(id: String?): AdhanMuezzin =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: MAKKAH
    }
}

/**
 * Plays an authentic FULL human Muezzin Adhan (~3 minutes) for Prayer alerts and Settings preview.
 * Automatically caches the full MP3 locally on device so subsequent Adhan alerts play
 * instantaneously even completely offline, and displays futuristic liquid-glass Pause/Stop
 * controls directly in the phone's notification bar.
 */
object FullAdhanAudioManager {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    @Volatile
    private var mediaPlayer: MediaPlayer? = null
    private var activeJob: Job? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _activeMuezzinId = MutableStateFlow<String?>(null)
    val activeMuezzinId: StateFlow<String?> = _activeMuezzinId.asStateFlow()

    private fun cacheFile(context: Context, muezzin: AdhanMuezzin): File {
        val dir = File(context.applicationContext.filesDir, "adhan_cache").apply { mkdirs() }
        return File(dir, "full_adhan_${muezzin.id.lowercase()}.mp3")
    }

    /**
     * Silently pre-downloads the selected Full Adhan MP3 in the background so that when a Salah
     * time arrives (even if offline), the real full Adhan plays immediately with zero wait.
     */
    fun prefetchFullAdhan(context: Context, muezzinId: String = AdhanMuezzin.MAKKAH.id) {
        val appCtx = context.applicationContext
        val muezzin = AdhanMuezzin.fromId(muezzinId)
        scope.launch {
            val target = cacheFile(appCtx, muezzin)
            if (!target.exists() || target.length() < 40_000L) {
                downloadMuezzinToCache(muezzin, target)
            }
        }
    }

    /**
     * Plays the full Muezzin Adhan immediately (from local cache if present, or streaming + caching
     * on first run, falling back cleanly to bundled Adhan audio if offline before initial download).
     */
    fun playFullAdhan(
        context: Context,
        muezzinId: String = AdhanMuezzin.MAKKAH.id,
        prayerTitle: String = "Adhan • Call to Prayer"
    ) {
        val appCtx = context.applicationContext
        val muezzin = AdhanMuezzin.fromId(muezzinId)
        stop(appCtx)

        _activeMuezzinId.value = muezzin.id
        activeJob = scope.launch {
            val cached = cacheFile(appCtx, muezzin)
            val readyFile = if (cached.exists() && cached.length() > 40_000L) {
                cached
            } else {
                // Attempt quick download so full Adhan plays cleanly & caches for future offline use
                if (downloadMuezzinToCache(muezzin, cached)) cached else null
            }

            if (readyFile != null && readyFile.exists()) {
                startPlayerFromFile(appCtx, readyFile, muezzin, prayerTitle)
            } else {
                // Last-resort streaming direct URL, or bundled fallback if fully offline
                val streamed = tryStartDirectStream(appCtx, muezzin, prayerTitle)
                if (!streamed) {
                    startBundledFallback(appCtx, muezzin, prayerTitle)
                }
            }
        }
    }

    fun togglePauseResume(context: Context, prayerTitle: String = "Adhan • Call to Prayer") {
        val mp = mediaPlayer ?: return
        val muezzin = AdhanMuezzin.fromId(_activeMuezzinId.value)
        runCatching {
            if (mp.isPlaying) {
                mp.pause()
                _isPlaying.value = false
                _isPaused.value = true
                publishMediaNotification(context.applicationContext, muezzin, prayerTitle, playing = false)
            } else {
                mp.start()
                _isPlaying.value = true
                _isPaused.value = false
                publishMediaNotification(context.applicationContext, muezzin, prayerTitle, playing = true)
            }
        }
    }

    fun stop(context: Context? = null) {
        activeJob?.cancel()
        activeJob = null
        mediaPlayer?.let { mp ->
            runCatching {
                if (mp.isPlaying) mp.stop()
                mp.release()
            }
        }
        mediaPlayer = null
        _isPlaying.value = false
        _isPaused.value = false
        _activeMuezzinId.value = null
        if (context != null) {
            RuhZenaMediaNotificationManager.dismiss(context.applicationContext, RuhZenaMediaNotificationManager.AudioSource.ADHAN)
        }
    }

    private fun downloadMuezzinToCache(muezzin: AdhanMuezzin, destination: File): Boolean {
        for (url in muezzin.mirrorUrls) {
            val ok = runCatching {
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "RuhZena-Android/1.0")
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use false
                    val body = resp.body ?: return@use false
                    val bytes = body.bytes()
                    if (bytes.size < 30_000) return@use false
                    val tmp = File(destination.parentFile, "${destination.name}.tmp")
                    tmp.writeBytes(bytes)
                    tmp.renameTo(destination)
                }
            }.getOrDefault(false)
            if (ok && destination.exists() && destination.length() > 30_000L) {
                Log.d(ADHAN_TAG, "Cached full Adhan (${muezzin.id}): ${destination.length()} bytes")
                return true
            }
        }
        return false
    }

    private fun startPlayerFromFile(
        appCtx: Context,
        file: File,
        muezzin: AdhanMuezzin,
        prayerTitle: String
    ) {
        runCatching {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    stop(appCtx)
                }
                setOnErrorListener { _, _, _ ->
                    stop(appCtx)
                    true
                }
                prepare()
                start()
            }
            mediaPlayer = mp
            _isPlaying.value = true
            _isPaused.value = false
            publishMediaNotification(appCtx, muezzin, prayerTitle, playing = true)
        }.onFailure {
            Log.w(ADHAN_TAG, "Failed playing cached Adhan file, falling back", it)
            startBundledFallback(appCtx, muezzin, prayerTitle)
        }
    }

    private fun tryStartDirectStream(
        appCtx: Context,
        muezzin: AdhanMuezzin,
        prayerTitle: String
    ): Boolean {
        for (url in muezzin.mirrorUrls) {
            val ok = runCatching {
                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setDataSource(url)
                    setOnCompletionListener { stop(appCtx) }
                    setOnErrorListener { _, _, _ ->
                        stop(appCtx)
                        true
                    }
                    prepare()
                    start()
                }
                mediaPlayer = mp
                _isPlaying.value = true
                _isPaused.value = false
                publishMediaNotification(appCtx, muezzin, prayerTitle, playing = true)
                true
            }.getOrDefault(false)
            if (ok) return true
        }
        return false
    }

    private fun startBundledFallback(
        appCtx: Context,
        muezzin: AdhanMuezzin,
        prayerTitle: String
    ) {
        runCatching {
            val uri = Uri.parse("android.resource://${appCtx.packageName}/${R.raw.ruhzena_adhan_prayer}")
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(appCtx, uri)
                setOnCompletionListener { stop(appCtx) }
                setOnErrorListener { _, _, _ ->
                    stop(appCtx)
                    true
                }
                prepare()
                start()
            }
            mediaPlayer = mp
            _isPlaying.value = true
            _isPaused.value = false
            publishMediaNotification(appCtx, muezzin, prayerTitle, playing = true)
        }
    }

    private fun publishMediaNotification(
        appCtx: Context,
        muezzin: AdhanMuezzin,
        prayerTitle: String,
        playing: Boolean
    ) {
        RuhZenaMediaNotificationManager.showOrUpdate(
            context = appCtx,
            control = RuhZenaMediaNotificationManager.ActiveMediaControl(
                source = RuhZenaMediaNotificationManager.AudioSource.ADHAN,
                title = prayerTitle,
                subtitle = muezzin.nameEn,
                badge = "FULL ADHAN • RUHZENA",
                isPlaying = playing,
                canSkip = false,
                onPlayPause = { togglePauseResume(appCtx, prayerTitle) },
                onStop = { stop(appCtx) }
            )
        )
    }
}
