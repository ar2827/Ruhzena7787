package com.example.ruhzena.ai.agent

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.BuildConfig
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class ProviderCredentialsSnapshot(
    val groqApiKey: String = "",
    val openRouterApiKey: String = "",
    val cloudflareAccountId: String = "",
    val cloudflareApiToken: String = "",
    val customProxyBaseUrl: String = ""
) {
    val hasGroq: Boolean get() = groqApiKey.isNotBlank()
    val hasOpenRouter: Boolean get() = openRouterApiKey.isNotBlank()
    val hasCloudflare: Boolean get() = cloudflareAccountId.isNotBlank() && cloudflareApiToken.isNotBlank()

    fun isProviderConfigured(providerId: AiProviderId): Boolean = when (providerId) {
        AiProviderId.GROQ -> hasGroq
        AiProviderId.OPENROUTER -> hasOpenRouter
        AiProviderId.CLOUDFLARE -> hasCloudflare
        AiProviderId.FIREBASE_GEMINI -> true
        AiProviderId.OFFLINE_CORPUS -> true
    }

    fun apiKeyFor(providerId: AiProviderId): String = when (providerId) {
        AiProviderId.GROQ -> groqApiKey
        AiProviderId.OPENROUTER -> openRouterApiKey
        AiProviderId.CLOUDFLARE -> cloudflareApiToken
        else -> ""
    }
}

interface AiCredentialProvider {
    fun getSnapshot(): ProviderCredentialsSnapshot
    fun saveUserOverrides(
        groqKey: String? = null,
        openRouterKey: String? = null,
        cloudflareAccountId: String? = null,
        cloudflareApiToken: String? = null,
        customProxyBaseUrl: String? = null
    )
    fun clearUserOverrides()
}

/**
 * Inbuilt + Keystore-encrypted credential store for RuhZena AI's 4 core providers
 * (Groq, OpenRouter, Cloudflare Workers AI, and keyless Firebase AI Logic / Gemini).
 *
 * Uses an in-memory volatile cache invalidated on mutation so hot-path routing & request
 * execution avoid redundant Android Keystore AES-GCM decryptions per message.
 */
class SecureAiCredentialStore(context: Context) : AiCredentialProvider {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Volatile
    private var cachedSnapshot: ProviderCredentialsSnapshot? = null

    private fun cleanBuiltIn(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return ""
        val upper = trimmed.uppercase()
        if (upper.endsWith("_DEFAULT_VALUE") || upper.startsWith("YOUR_") || upper == "NULL") return ""
        return trimmed
    }

    private fun resolveKey(prefKey: String, builtInValue: String): String =
        readDecrypted(prefKey).trim().ifBlank { cleanBuiltIn(builtInValue) }

    override fun getSnapshot(): ProviderCredentialsSnapshot {
        cachedSnapshot?.let { return it }
        val rawProxy = readDecrypted(KEY_CUSTOM_PROXY).trim().trimEnd('/')
        val safeProxy = if (rawProxy.startsWith("https://", ignoreCase = true)) rawProxy else ""

        return ProviderCredentialsSnapshot(
            groqApiKey = resolveKey(KEY_GROQ, BuildConfig.GROQ_API_KEY),
            openRouterApiKey = resolveKey(KEY_OPENROUTER, BuildConfig.OPENROUTER_API_KEY),
            cloudflareAccountId = resolveKey(KEY_CF_ACCOUNT, BuildConfig.CLOUDFLARE_ACCOUNT_ID),
            cloudflareApiToken = resolveKey(KEY_CF_TOKEN, BuildConfig.CLOUDFLARE_API_TOKEN),
            customProxyBaseUrl = safeProxy
        ).also { cachedSnapshot = it }
    }

    override fun saveUserOverrides(
        groqKey: String?,
        openRouterKey: String?,
        cloudflareAccountId: String?,
        cloudflareApiToken: String?,
        customProxyBaseUrl: String?
    ) {
        val editor = prefs.edit()
        groqKey?.let { writeEncrypted(editor, KEY_GROQ, it.trim()) }
        openRouterKey?.let { writeEncrypted(editor, KEY_OPENROUTER, it.trim()) }
        cloudflareAccountId?.let { writeEncrypted(editor, KEY_CF_ACCOUNT, it.trim()) }
        cloudflareApiToken?.let { writeEncrypted(editor, KEY_CF_TOKEN, it.trim()) }
        customProxyBaseUrl?.let { raw ->
            val trimmed = raw.trim().trimEnd('/')
            if (trimmed.isEmpty() || trimmed.startsWith("https://", ignoreCase = true)) {
                writeEncrypted(editor, KEY_CUSTOM_PROXY, trimmed)
            }
        }
        editor.apply()
        cachedSnapshot = null
    }

    override fun clearUserOverrides() {
        prefs.edit().clear().apply()
        cachedSnapshot = null
    }

    private fun writeEncrypted(editor: SharedPreferences.Editor, key: String, plaintext: String) {
        if (plaintext.isBlank()) {
            editor.remove(key)
            return
        }
        val secretKey = getOrCreateSecretKey()
        if (secretKey == null) {
            val encoded = Base64.encodeToString(plaintext.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            editor.putString(key, "b64:$encoded")
            return
        }
        runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(1 + iv.size + ciphertext.size)
            combined[0] = iv.size.toByte()
            System.arraycopy(iv, 0, combined, 1, iv.size)
            System.arraycopy(ciphertext, 0, combined, 1 + iv.size, ciphertext.size)
            val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
            editor.putString(key, "gcm:$encoded")
        }.onFailure {
            val encoded = Base64.encodeToString(plaintext.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            editor.putString(key, "b64:$encoded")
        }
    }

    private fun readDecrypted(key: String): String {
        val raw = prefs.getString(key, null).orEmpty()
        if (raw.isBlank()) return ""
        return when {
            raw.startsWith("gcm:") -> runCatching {
                val secretKey = getOrCreateSecretKey() ?: return ""
                val bytes = Base64.decode(raw.removePrefix("gcm:"), Base64.NO_WRAP)
                if (bytes.size < 2) return ""
                val ivLen = bytes[0].toInt() and 0xFF
                val iv = bytes.copyOfRange(1, 1 + ivLen)
                val ciphertext = bytes.copyOfRange(1 + ivLen, bytes.size)
                val cipher = Cipher.getInstance(TRANSFORMATION)
                cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
                String(cipher.doFinal(ciphertext), Charsets.UTF_8)
            }.getOrDefault("")
            raw.startsWith("b64:") -> runCatching {
                String(Base64.decode(raw.removePrefix("b64:"), Base64.NO_WRAP), Charsets.UTF_8)
            }.getOrDefault("")
            else -> ""
        }
    }

    private fun getOrCreateSecretKey(): SecretKey? = runCatching {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGen.init(spec)
        keyGen.generateKey()
    }.getOrNull()

    companion object {
        private const val PREFS_NAME = "ruhzena_ai_secure_creds"
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val KEY_ALIAS = "ruhzena_ai_cred_master_key_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"

        private const val KEY_GROQ = "cred_groq"
        private const val KEY_OPENROUTER = "cred_openrouter"
        private const val KEY_CF_ACCOUNT = "cred_cf_account"
        private const val KEY_CF_TOKEN = "cred_cf_token"
        private const val KEY_CUSTOM_PROXY = "cred_custom_proxy"
    }
}
