package com.example.ruhzena.core.sensors

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Looper
import android.view.Surface
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.example.ruhzena.data.islamic.CityPreset
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.roundToInt

data class CompassState(
    val azimuthDegrees: Float = 0f,
    val pitchDegrees: Float = 0f,
    val rollDegrees: Float = 0f,
    val magneticFieldMicroTesla: Float = 0f,
    val magneticInterference: Boolean = false,
    val sensorAvailable: Boolean = false,
    val hasLiveReading: Boolean = false,
    val declinationDeg: Float = 0f,
    val accuracy: Int = SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM,
    val sensorSource: String = "Idle"
)

class CompassSensorManager(private val context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val geomagneticRotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)
    private val gravitySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
    private val accelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    @Suppress("DEPRECATION")
    private val legacyOrientationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ORIENTATION)

    private val _state = MutableStateFlow(
        CompassState(
            sensorAvailable = rotationSensor != null ||
                geomagneticRotationSensor != null ||
                ((gravitySensor != null || accelSensor != null) && magSensor != null) ||
                legacyOrientationSensor != null
        )
    )
    val state: StateFlow<CompassState> = _state.asStateFlow()

    private val rotationMatrix = FloatArray(9)
    private val remappedMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private val rawTiltAngles = FloatArray(3)
    private val gravity = FloatArray(3)
    private val geomagnetic = FloatArray(3)
    private var hasGravity = false
    private var hasGeo = false
    private var lastRotationVectorMillis = 0L
    private var lastAccelMagMillis = 0L
    private var smoothedAzimuth = 0f
    private var smoothedPitch = 0f
    private var smoothedRoll = 0f
    private var smoothedFieldUt = 0f
    private var hasSmoothedInit = false
    private var isUprightMode = false
    private var declinationDegrees = 0f

    fun setCoordinates(latitude: Double, longitude: Double) {
        val field = runCatching {
            GeomagneticField(latitude.toFloat(), longitude.toFloat(), 0f, System.currentTimeMillis())
        }.getOrNull()
        declinationDegrees = field?.declination ?: 0f
        _state.value = _state.value.copy(declinationDeg = declinationDegrees)
    }

    fun start() {
        val sm = sensorManager ?: return
        lastRotationVectorMillis = 0L
        lastAccelMagMillis = 0L
        hasSmoothedInit = false
        isUprightMode = false
        var registered = false
        val rate = SensorManager.SENSOR_DELAY_GAME
        if (rotationSensor != null) {
            registered = sm.registerListener(this, rotationSensor, rate) || registered
        }
        if (geomagneticRotationSensor != null) {
            registered = sm.registerListener(this, geomagneticRotationSensor, rate) || registered
        }
        if (magSensor != null) {
            val magOk = sm.registerListener(this, magSensor, rate)
            val gravOk = if (gravitySensor != null) {
                sm.registerListener(this, gravitySensor, rate)
            } else {
                false
            }
            val accOk = if (accelSensor != null) {
                sm.registerListener(this, accelSensor, rate)
            } else {
                false
            }
            registered = registered || (magOk && (gravOk || accOk))
        }
        if (legacyOrientationSensor != null) {
            registered = sm.registerListener(this, legacyOrientationSensor, rate) || registered
        }
        _state.value = _state.value.copy(
            sensorAvailable = registered || _state.value.sensorAvailable,
            sensorSource = if (registered) "Listening" else "Unavailable"
        )
    }

    fun restart() {
        stop()
        start()
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
        lastRotationVectorMillis = 0L
        lastAccelMagMillis = 0L
        hasGravity = false
        hasGeo = false
        hasSmoothedInit = false
    }

    @Suppress("DEPRECATION")
    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR,
            Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> {
                if (event.values.size < 3) return
                val hasNonZero = event.values.take(3).any { abs(it) > 1e-5f }
                if (!hasNonZero) return
                val vector = if (event.values.size > 4) event.values.copyOfRange(0, 4) else event.values
                runCatching {
                    SensorManager.getRotationMatrixFromVector(rotationMatrix, vector)
                    val azimuth = extractTiltCompensatedAzimuth(rotationMatrix)
                    if (!azimuth.isNaN()) {
                        lastRotationVectorMillis = System.currentTimeMillis()
                        val (pitchDeg, rollDeg) = extractPitchRoll(rotationMatrix)
                        val src = if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) "Fusion" else "GeoFusion"
                        updateAzimuth(azimuth + declinationDegrees, pitchDeg, rollDeg, src)
                    }
                }
            }
            Sensor.TYPE_GRAVITY -> {
                System.arraycopy(event.values, 0, gravity, 0, 3)
                hasGravity = true
                if (System.currentTimeMillis() - lastRotationVectorMillis > 350L) {
                    computeFallback()
                }
            }
            Sensor.TYPE_ACCELEROMETER -> {
                if (gravitySensor == null || !hasGravity) {
                    val alpha = 0.82f
                    if (!hasGravity) {
                        System.arraycopy(event.values, 0, gravity, 0, 3)
                        hasGravity = true
                    } else {
                        gravity[0] = alpha * gravity[0] + (1f - alpha) * event.values[0]
                        gravity[1] = alpha * gravity[1] + (1f - alpha) * event.values[1]
                        gravity[2] = alpha * gravity[2] + (1f - alpha) * event.values[2]
                    }
                }
                if (System.currentTimeMillis() - lastRotationVectorMillis > 350L) {
                    computeFallback()
                }
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                val rawFieldUt = kotlin.math.sqrt(
                    event.values[0] * event.values[0] +
                        event.values[1] * event.values[1] +
                        event.values[2] * event.values[2]
                )
                smoothedFieldUt = if (smoothedFieldUt <= 0.1f) rawFieldUt else smoothedFieldUt * 0.85f + rawFieldUt * 0.15f
                val interference = smoothedFieldUt > 72f || (smoothedFieldUt in 0.5f..18f)

                val alpha = 0.80f
                if (!hasGeo) {
                    System.arraycopy(event.values, 0, geomagnetic, 0, 3)
                    hasGeo = true
                } else {
                    geomagnetic[0] = alpha * geomagnetic[0] + (1f - alpha) * event.values[0]
                    geomagnetic[1] = alpha * geomagnetic[1] + (1f - alpha) * event.values[1]
                    geomagnetic[2] = alpha * geomagnetic[2] + (1f - alpha) * event.values[2]
                }
                _state.value = _state.value.copy(
                    magneticFieldMicroTesla = smoothedFieldUt,
                    magneticInterference = interference
                )
                if (System.currentTimeMillis() - lastRotationVectorMillis > 350L) {
                    computeFallback()
                }
            }
            Sensor.TYPE_ORIENTATION -> {
                val now = System.currentTimeMillis()
                if (now - lastRotationVectorMillis > 600L && now - lastAccelMagMillis > 600L && event.values.isNotEmpty()) {
                    val rawHeading = event.values[0]
                    val pitchDeg = event.values.getOrNull(1)?.let { -it } ?: 0f
                    val rollDeg = event.values.getOrNull(2) ?: 0f
                    if (!rawHeading.isNaN()) {
                        updateAzimuth(rawHeading + declinationDegrees, pitchDeg, rollDeg, "Orientation")
                    }
                }
            }
        }
    }

    private fun computeFallback() {
        if (!hasGravity || !hasGeo) return
        val magMag = geomagnetic[0] * geomagnetic[0] + geomagnetic[1] * geomagnetic[1] + geomagnetic[2] * geomagnetic[2]
        if (magMag < 1e-4f) return
        if (SensorManager.getRotationMatrix(rotationMatrix, null, gravity, geomagnetic)) {
            val azimuth = extractTiltCompensatedAzimuth(rotationMatrix)
            if (!azimuth.isNaN()) {
                lastAccelMagMillis = System.currentTimeMillis()
                val (pitchDeg, rollDeg) = extractPitchRoll(rotationMatrix)
                updateAzimuth(azimuth + declinationDegrees, pitchDeg, rollDeg, "Magnetometer")
            }
        }
    }

    private fun extractPitchRoll(rawMatrix: FloatArray): Pair<Float, Float> {
        SensorManager.getOrientation(rawMatrix, rawTiltAngles)
        val pitch = Math.toDegrees(rawTiltAngles[1].toDouble()).toFloat().takeIf { !it.isNaN() } ?: 0f
        val roll = Math.toDegrees(rawTiltAngles[2].toDouble()).toFloat().takeIf { !it.isNaN() } ?: 0f
        return pitch to roll
    }

    private fun extractTiltCompensatedAzimuth(rawMatrix: FloatArray): Float {
        val displayRot = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display?.rotation ?: Surface.ROTATION_0
            } else {
                @Suppress("DEPRECATION")
                (context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.defaultDisplay?.rotation ?: Surface.ROTATION_0
            }
        }.getOrDefault(Surface.ROTATION_0)

        // Hysteresis prevents abrupt 180-degree heading flips during normal handheld tilting (~30-55 deg)
        val absZ = abs(rawMatrix[8])
        if (!isUprightMode && absZ < 0.38f) {
            isUprightMode = true
        } else if (isUprightMode && absZ > 0.56f) {
            isUprightMode = false
        }

        val (axisX, axisY) = if (isUprightMode) {
            when (displayRot) {
                Surface.ROTATION_90 -> SensorManager.AXIS_Z to SensorManager.AXIS_MINUS_X
                Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_Z
                Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Z to SensorManager.AXIS_X
                else -> SensorManager.AXIS_X to SensorManager.AXIS_Z
            }
        } else {
            when (displayRot) {
                Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
                Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
                Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
                else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
            }
        }

        SensorManager.remapCoordinateSystem(rawMatrix, axisX, axisY, remappedMatrix)
        SensorManager.getOrientation(remappedMatrix, orientationAngles)
        val rawRad = orientationAngles[0].toDouble()
        if (rawRad.isNaN()) return Float.NaN
        return ((Math.toDegrees(rawRad) + 360.0) % 360.0).toFloat()
    }

    private fun updateAzimuth(rawTrueNorthDeg: Float, pitchDeg: Float, rollDeg: Float, source: String) {
        val normalized = ((rawTrueNorthDeg % 360f) + 360f) % 360f
        if (!hasSmoothedInit) {
            smoothedAzimuth = normalized
            smoothedPitch = pitchDeg
            smoothedRoll = rollDeg
            hasSmoothedInit = true
        } else {
            val diff = ((normalized - smoothedAzimuth + 540f) % 360f) - 180f
            smoothedAzimuth = (smoothedAzimuth + diff * 0.22f + 360f) % 360f
            smoothedPitch += (pitchDeg - smoothedPitch) * 0.25f
            smoothedRoll += (rollDeg - smoothedRoll) * 0.25f
        }
        _state.value = _state.value.copy(
            azimuthDegrees = smoothedAzimuth.roundToInt().toFloat(),
            pitchDegrees = smoothedPitch,
            rollDegrees = smoothedRoll,
            magneticFieldMicroTesla = smoothedFieldUt,
            sensorAvailable = true,
            hasLiveReading = true,
            declinationDeg = declinationDegrees,
            sensorSource = source
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (sensor?.type == Sensor.TYPE_MAGNETIC_FIELD || sensor?.type == Sensor.TYPE_ROTATION_VECTOR) {
            _state.value = _state.value.copy(accuracy = accuracy)
        }
    }
}

data class ResolvedLocation(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String = TimeZone.getDefault().id,
    val isApproximateNetwork: Boolean = false
)

sealed interface LocationFetchResult {
    data class Success(val location: ResolvedLocation) : LocationFetchResult
    data object PermissionMissing : LocationFetchResult
    data object LocationServicesDisabled : LocationFetchResult
    data object Unavailable : LocationFetchResult
}

object LocationHelper {
    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(7, TimeUnit.SECONDS)
            .build()
        }

    fun hasCoarseLocationPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun isLocationEnabled(context: Context): Boolean {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        return runCatching { LocationManagerCompat.isLocationEnabled(lm) }.getOrDefault(false)
    }

    @SuppressLint("MissingPermission")
    suspend fun fetchCurrentOrLastLocation(context: Context): LocationFetchResult {
        if (!hasCoarseLocationPermission(context)) return LocationFetchResult.PermissionMissing
        if (!isLocationEnabled(context)) return LocationFetchResult.LocationServicesDisabled

        val client = LocationServices.getFusedLocationProviderClient(context)

        // 1. Try fresh Play Services Fused current location (4.5s timeout)
        val cts = CancellationTokenSource()
        val fusedFresh: Location? = withTimeoutOrNull(4500L) {
            suspendCancellableCoroutine { cont ->
                cont.invokeOnCancellation { cts.cancel() }
                runCatching {
                    client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token)
                        .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                        .addOnFailureListener { if (cont.isActive) cont.resume(null) }
                }.onFailure {
                    if (cont.isActive) cont.resume(null)
                }
            }
        }

        // 2. Try native Android LocationManagerCompat.getCurrentLocation on enabled providers (4s timeout)
        val nativeFresh: Location? = fusedFresh ?: requestNativeCurrentLocation(context)

        // 3. Fallback to cached fused lastLocation or LocationManager lastKnownLocation
        val cachedLocation: Location? = nativeFresh
            ?: withTimeoutOrNull(2000L) {
                suspendCancellableCoroutine { cont ->
                    runCatching {
                        client.lastLocation
                            .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                            .addOnFailureListener { if (cont.isActive) cont.resume(null) }
                    }.onFailure { if (cont.isActive) cont.resume(null) }
                }
            }
            ?: readLocationManagerFallback(context)

        if (cachedLocation != null) {
            val resolvedLabel = reverseGeocodeLabel(context, cachedLocation.latitude, cachedLocation.longitude)
            return LocationFetchResult.Success(
                ResolvedLocation(
                    name = resolvedLabel,
                    latitude = cachedLocation.latitude,
                    longitude = cachedLocation.longitude,
                    timeZoneId = TimeZone.getDefault().id,
                    isApproximateNetwork = false
                )
            )
        }

        // 4. Online coarse city fallback when GPS/PlayServices returned null (e.g., indoors / restricted HAL)
        val networkCoarse = fetchNetworkCityFallback()
        if (networkCoarse != null) {
            return LocationFetchResult.Success(networkCoarse)
        }

        return LocationFetchResult.Unavailable
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestNativeCurrentLocation(context: Context): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providersToTry = listOf(
            LocationManager.NETWORK_PROVIDER,
            LocationManager.GPS_PROVIDER
        ).filter { p -> runCatching { lm.isProviderEnabled(p) }.getOrDefault(false) }

        for (provider in providersToTry) {
            val loc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val cs = CancellationSignal()
                withTimeoutOrNull(3500L) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        cont.invokeOnCancellation { cs.cancel() }
                        runCatching {
                            lm.getCurrentLocation(
                                provider,
                                cs,
                                ContextCompat.getMainExecutor(context)
                            ) { location ->
                                if (cont.isActive) cont.resume(location)
                            }
                        }.onFailure {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                }
            } else {
                withTimeoutOrNull(3500L) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        val listener = object : LocationListener {
                            override fun onLocationChanged(location: Location) {
                                lm.removeUpdates(this)
                                if (cont.isActive) cont.resume(location)
                            }
                            override fun onProviderDisabled(provider: String) {}
                            override fun onProviderEnabled(provider: String) {}
                        }
                        cont.invokeOnCancellation { runCatching { lm.removeUpdates(listener) } }
                        runCatching {
                            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
                        }.onFailure {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                }
            }
            if (loc != null) return loc
        }
        return null
    }

    suspend fun fetchLastKnownLocation(context: Context): ResolvedLocation? =
        (fetchCurrentOrLastLocation(context) as? LocationFetchResult.Success)?.location

    @SuppressLint("MissingPermission")
    private fun readLocationManagerFallback(context: Context): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providers = runCatching { lm.getProviders(true) }.getOrDefault(emptyList())
        var best: Location? = null
        for (provider in providers) {
            val candidate = runCatching { lm.getLastKnownLocation(provider) }.getOrNull() ?: continue
            if (best == null || candidate.time > best.time) {
                best = candidate
            }
        }
        return best
    }

    private suspend fun fetchNetworkCityFallback(): ResolvedLocation? = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder()
                .url("https://ipwho.is/")
                .header("User-Agent", "RuhZenaAndroid/1.0")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val obj = JSONObject(resp.body?.string().orEmpty())
                if (!obj.optBoolean("success", false)) return@use null
                val lat = obj.optDouble("latitude", Double.NaN)
                val lon = obj.optDouble("longitude", Double.NaN)
                if (lat.isNaN() || lon.isNaN()) return@use null
                val city = obj.optString("city").trim()
                val country = obj.optString("country").trim()
                val tz = obj.optJSONObject("timezone")?.optString("id")?.ifBlank { null }
                    ?: TimeZone.getDefault().id
                val label = listOf(city, country).filter { it.isNotBlank() }.joinToString(", ")
                    .ifBlank { "Lat %.2f, Lon %.2f".format(Locale.US, lat, lon) }
                ResolvedLocation(
                    name = label,
                    latitude = lat,
                    longitude = lon,
                    timeZoneId = tz,
                    isApproximateNetwork = true
                )
            }
        }.getOrNull()
    }

    private suspend fun reverseGeocodeLabel(context: Context, lat: Double, lon: Double): String =
        withContext(Dispatchers.IO) {
            val fromPlatform = runCatching {
                @Suppress("DEPRECATION")
                val list = Geocoder(context, Locale.getDefault()).getFromLocation(lat, lon, 1)
                val addr = list?.firstOrNull()
                listOfNotNull(addr?.locality ?: addr?.subAdminArea ?: addr?.adminArea, addr?.countryName)
                    .distinct()
                    .joinToString(", ")
            }.getOrNull().orEmpty()
            if (fromPlatform.isNotBlank()) return@withContext fromPlatform

            val fromNominatim = runCatching {
                val url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lon&zoom=10"
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "RuhZenaAndroid/1.0 (https://github.com/ruhzena)")
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use ""
                    val body = resp.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val addr = obj.optJSONObject("address")
                    val city = addr?.optString("city")
                        ?.ifBlank { addr.optString("town") }
                        ?.ifBlank { addr.optString("village") }
                        ?.ifBlank { addr.optString("state") }
                    val country = addr?.optString("country")
                    listOfNotNull(city?.takeIf { it.isNotBlank() }, country?.takeIf { it.isNotBlank() })
                        .joinToString(", ")
                }
            }.getOrNull().orEmpty()
            if (fromNominatim.isNotBlank()) return@withContext fromNominatim

            "Lat %.2f, Lon %.2f".format(Locale.US, lat, lon)
        }

    suspend fun searchCityOnline(query: String): List<CityPreset> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.length < 2) return@withContext emptyList()

        val localMatches = PrayerCalculator.cityPresets.filter {
            it.name.contains(trimmed, ignoreCase = true)
        }

        val encoded = URLEncoder.encode(trimmed, "UTF-8")
        val openMeteoMatches = runCatching {
            val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=6&language=en&format=json"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "RuhZenaAndroid/1.0")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use emptyList<CityPreset>()
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("results") ?: return@use emptyList<CityPreset>()
                buildList {
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val name = item.optString("name")
                        val admin = item.optString("admin1")
                        val country = item.optString("country")
                        val lat = item.optDouble("latitude", Double.NaN)
                        val lon = item.optDouble("longitude", Double.NaN)
                        val tz = item.optString("timezone").ifBlank { TimeZone.getDefault().id }
                        if (name.isBlank() || lat.isNaN() || lon.isNaN()) continue
                        val display = listOf(name, admin, country)
                            .filter { it.isNotBlank() }
                            .distinct()
                            .joinToString(", ")
                        add(CityPreset(display, lat, lon, tz))
                    }
                }
            }
        }.getOrDefault(emptyList())

        val nominatimMatches = if (openMeteoMatches.isEmpty()) {
            runCatching {
                val url = "https://nominatim.openstreetmap.org/search?q=$encoded&format=jsonv2&limit=5"
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "RuhZenaAndroid/1.0 (https://github.com/ruhzena)")
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use emptyList<CityPreset>()
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    buildList {
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i) ?: continue
                            val display = item.optString("display_name")
                                .split(",")
                                .take(2)
                                .joinToString(",")
                                .trim()
                            val lat = item.optString("lat").toDoubleOrNull() ?: continue
                            val lon = item.optString("lon").toDoubleOrNull() ?: continue
                            if (display.isNotBlank()) {
                                add(CityPreset(display, lat, lon, TimeZone.getDefault().id))
                            }
                        }
                    }
                }
            }.getOrDefault(emptyList())
        } else {
            emptyList()
        }

        (localMatches + openMeteoMatches + nominatimMatches).distinctBy { it.name.lowercase(Locale.US) }
    }
}
