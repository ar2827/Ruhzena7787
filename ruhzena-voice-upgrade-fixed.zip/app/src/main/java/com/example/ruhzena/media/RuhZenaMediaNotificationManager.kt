package com.example.ruhzena.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.ruhzena.notifications.NotificationActionReceiver
import com.example.ruhzena.notifications.RuhZenaNotificationHelper

/**
 * Unified Dynamic Liquid-Glass Notification Player for ALL RuhZena audio:
 *  - Quran Recitation & Hifz Loops (live progress bar, timestamps, Ayah counter, Prev/Play-Pause/Next/Stop)
 *  - Hisn al-Muslim / Dua Human Audio
 *  - Stories, Lessons & AI Voice
 *  - Actual Full Muezzin Adhan
 */
object RuhZenaMediaNotificationManager {

    const val CHANNEL_MEDIA_PLAYBACK = "ruhzena_media_glass_v2"
    const val MEDIA_NOTIFICATION_ID = 4401

    enum class AudioSource {
        QURAN,
        SPEECH,
        ADHAN
    }

    enum class GlassThemeVariant {
        QURAN_EMERALD,
        HIFZ_VIOLET,
        ADHAN_GOLD,
        VOICE_CYAN
    }

    data class ActiveMediaControl(
        val source: AudioSource,
        val title: String,
        val subtitle: String,
        val badge: String,
        val isPlaying: Boolean,
        val canSkip: Boolean = false,
        val positionMs: Long = 0L,
        val durationMs: Long = 0L,
        val metaPill: String = "",
        val themeVariant: GlassThemeVariant = when (source) {
            AudioSource.QURAN -> GlassThemeVariant.QURAN_EMERALD
            AudioSource.ADHAN -> GlassThemeVariant.ADHAN_GOLD
            AudioSource.SPEECH -> GlassThemeVariant.VOICE_CYAN
        },
        val onPlayPause: () -> Unit,
        val onPrev: (() -> Unit)? = null,
        val onNext: (() -> Unit)? = null,
        val onStop: () -> Unit
    )

    @Volatile
    private var activeControl: ActiveMediaControl? = null

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        runCatching { manager.deleteNotificationChannel("ruhzena_media_glass_v1") }
        val existing = manager.getNotificationChannel(CHANNEL_MEDIA_PLAYBACK)
        if (existing != null) return
        val channel = NotificationChannel(
            CHANNEL_MEDIA_PLAYBACK,
            "RuhZena Quran & Audio Player",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Dynamic liquid-glass player controls for Quran, Hifz, Stories, and Full Adhan"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    fun showOrUpdate(context: Context, control: ActiveMediaControl) {
        activeControl = control
        if (!RuhZenaNotificationHelper.hasNotificationPermission(context)) return
        ensureChannel(context)
        val notification = buildNotification(context, control)
        runCatching {
            NotificationManagerCompat.from(context).notify(MEDIA_NOTIFICATION_ID, notification)
        }
    }

    fun buildCurrentOrFallbackNotification(
        context: Context,
        fallbackTitle: String = "RuhZena Quran Player",
        fallbackSubtitle: String = "Quran Audio",
        isPlaying: Boolean = true
    ): Notification {
        ensureChannel(context)
        val control = activeControl ?: ActiveMediaControl(
            source = AudioSource.QURAN,
            title = fallbackTitle,
            subtitle = fallbackSubtitle,
            badge = "QURAN PLAYER",
            isPlaying = isPlaying,
            canSkip = true,
            onPlayPause = {},
            onStop = {}
        )
        return buildNotification(context, control)
    }

    fun buildNotification(context: Context, control: ActiveMediaControl): Notification {
        ensureChannel(context)
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_audio_source", control.source.name)
        }
        val openAppPi = PendingIntent.getActivity(
            context,
            4400,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPausePi = mediaActionPendingIntent(context, 4401, NotificationActionReceiver.ACTION_MEDIA_PLAY_PAUSE)
        val prevPi = mediaActionPendingIntent(context, 4402, NotificationActionReceiver.ACTION_MEDIA_PREV)
        val nextPi = mediaActionPendingIntent(context, 4403, NotificationActionReceiver.ACTION_MEDIA_NEXT)
        val stopPi = mediaActionPendingIntent(context, 4404, NotificationActionReceiver.ACTION_MEDIA_STOP)

        val playPauseIcon = if (control.isPlaying) {
            android.R.drawable.ic_media_pause
        } else {
            android.R.drawable.ic_media_play
        }
        val playPauseText = if (control.isPlaying) "Pause" else "Resume"

        val bgRes = when (control.themeVariant) {
            GlassThemeVariant.QURAN_EMERALD -> R.drawable.notif_media_glass_quran_bg
            GlassThemeVariant.HIFZ_VIOLET -> R.drawable.notif_media_glass_hifz_bg
            GlassThemeVariant.ADHAN_GOLD -> R.drawable.notif_media_glass_adhan_bg
            GlassThemeVariant.VOICE_CYAN -> R.drawable.notif_liquid_glass_bg
        }
        val accentColor = when (control.themeVariant) {
            GlassThemeVariant.QURAN_EMERALD -> 0xFF14B8A6.toInt()
            GlassThemeVariant.HIFZ_VIOLET -> 0xFFA78BFA.toInt()
            GlassThemeVariant.ADHAN_GOLD -> 0xFFCFA75E.toInt()
            GlassThemeVariant.VOICE_CYAN -> 0xFF22D3EE.toInt()
        }

        val hasDuration = control.durationMs > 0L
        val progressPermille = if (hasDuration) {
            ((control.positionMs.coerceIn(0L, control.durationMs) * 1000L) / control.durationMs).toInt()
        } else {
            0
        }

        val collapsedView = RemoteViews(context.packageName, R.layout.notification_media_glass_collapsed).apply {
            setInt(R.id.media_root_container, "setBackgroundResource", bgRes)
            setTextViewText(R.id.media_title, control.title)
            setTextViewText(R.id.media_subtitle, control.subtitle)
            setImageViewResource(R.id.media_btn_play_pause, playPauseIcon)
            setOnClickPendingIntent(R.id.media_btn_play_pause, playPausePi)
            setOnClickPendingIntent(R.id.media_btn_stop, stopPi)

            if (hasDuration) {
                setViewVisibility(R.id.media_progress_mini, View.VISIBLE)
                setProgressBar(R.id.media_progress_mini, 1000, progressPermille, false)
            } else {
                setViewVisibility(R.id.media_progress_mini, View.GONE)
            }

            if (control.canSkip && control.onPrev != null && control.onNext != null) {
                setViewVisibility(R.id.media_btn_prev, View.VISIBLE)
                setViewVisibility(R.id.media_btn_next, View.VISIBLE)
                setOnClickPendingIntent(R.id.media_btn_prev, prevPi)
                setOnClickPendingIntent(R.id.media_btn_next, nextPi)
            } else {
                setViewVisibility(R.id.media_btn_prev, View.GONE)
                setViewVisibility(R.id.media_btn_next, View.GONE)
            }
        }

        val expandedView = RemoteViews(context.packageName, R.layout.notification_media_glass_expanded).apply {
            setInt(R.id.media_root_container, "setBackgroundResource", bgRes)
            setTextViewText(R.id.media_badge, control.badge)
            setTextViewText(R.id.media_meta_pill, control.metaPill)
            setViewVisibility(R.id.media_meta_pill, if (control.metaPill.isNotBlank()) View.VISIBLE else View.GONE)
            setTextViewText(R.id.media_title, control.title)
            setTextViewText(R.id.media_subtitle, control.subtitle)
            setImageViewResource(R.id.media_play_pause_icon, playPauseIcon)
            setTextViewText(R.id.media_play_pause_label, playPauseText)
            setOnClickPendingIntent(R.id.media_btn_play_pause_pill, playPausePi)
            setOnClickPendingIntent(R.id.media_btn_stop, stopPi)

            if (hasDuration) {
                setViewVisibility(R.id.media_progress_row, View.VISIBLE)
                setProgressBar(R.id.media_progress, 1000, progressPermille, false)
                setTextViewText(R.id.media_time_elapsed, formatTimeMs(control.positionMs))
                setTextViewText(R.id.media_time_total, formatTimeMs(control.durationMs))
            } else {
                setViewVisibility(R.id.media_progress_row, View.GONE)
            }

            if (control.canSkip && control.onPrev != null && control.onNext != null) {
                setViewVisibility(R.id.media_btn_prev, View.VISIBLE)
                setViewVisibility(R.id.media_btn_next, View.VISIBLE)
                setOnClickPendingIntent(R.id.media_btn_prev, prevPi)
                setOnClickPendingIntent(R.id.media_btn_next, nextPi)
            } else {
                setViewVisibility(R.id.media_btn_prev, View.GONE)
                setViewVisibility(R.id.media_btn_next, View.GONE)
            }
        }

        return NotificationCompat.Builder(context, CHANNEL_MEDIA_PLAYBACK)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(control.title)
            .setContentText(control.subtitle)
            .setSubText(control.badge)
            .setColor(accentColor)
            .setOngoing(control.isPlaying)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openAppPi)
            .setCustomContentView(collapsedView)
            .setCustomBigContentView(expandedView)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .build()
    }

    fun dismiss(context: Context, source: AudioSource? = null) {
        if (source != null && activeControl?.source != source) return
        activeControl = null
        runCatching {
            NotificationManagerCompat.from(context).cancel(MEDIA_NOTIFICATION_ID)
        }
    }

    fun handleAction(context: Context, action: String) {
        val current = activeControl ?: return
        when (action) {
            NotificationActionReceiver.ACTION_MEDIA_PLAY_PAUSE -> current.onPlayPause()
            NotificationActionReceiver.ACTION_MEDIA_PREV -> current.onPrev?.invoke()
            NotificationActionReceiver.ACTION_MEDIA_NEXT -> current.onNext?.invoke()
            NotificationActionReceiver.ACTION_MEDIA_STOP -> {
                current.onStop()
                dismiss(context)
            }
        }
    }

    private fun formatTimeMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val min = totalSec / 60L
        val sec = totalSec % 60L
        return "$min:${sec.toString().padStart(2, '0')}"
    }

    private fun mediaActionPendingIntent(context: Context, requestCode: Int, action: String): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
