package com.example.ruhzena.notifications

import java.util.Calendar

data class KnowledgeMotivationItem(
    val id: Int,
    val category: String,
    val titleEn: String,
    val bodyEn: String,
    val titleBn: String,
    val bodyBn: String,
    val sourceRef: String
) {
    val themeEn: String get() = category
    val themeBn: String get() = when (category) {
        "Quran" -> "কুরআন"
        "Hadith" -> "হাদিস"
        "Sunnah" -> "সুন্নাহ"
        "Character" -> "আখলাক"
        "Wellness" -> "সুস্থতা"
        "Mindset" -> "মানসিকতা"
        "Discipline" -> "শৃঙ্খলা"
        "Focus" -> "মনোযোগ"
        "Resilience" -> "দৃঢ়তা"
        "Wisdom" -> "প্রজ্ঞা"
        "Daily Dua" -> "দৈনন্দিন দুআ"
        else -> category
    }
    val motivationEn: String get() = titleEn
    val motivationBn: String get() = titleBn
    val knowledgeEn: String get() = bodyEn
    val knowledgeBn: String get() = bodyBn
    val reference: String get() = sourceRef
    val sourceUrl: String get() {
        val ref = sourceRef.trim()
        val lower = ref.lowercase()
        val qMatch = Regex("(\\d{1,3}):(\\d{1,3})").find(ref)
        if (qMatch != null && lower.contains("quran")) {
            return "https://quran.com/${qMatch.groupValues[1]}/${qMatch.groupValues[2]}"
        }
        val hNum = Regex("\\b(\\d{1,5})\\b").find(ref)?.groupValues?.get(1)
        if (hNum != null) {
            when {
                lower.contains("bukhari") -> return "https://sunnah.com/bukhari:$hNum"
                lower.contains("muslim") -> return "https://sunnah.com/muslim:$hNum"
                lower.contains("tirmidhi") -> return "https://sunnah.com/tirmidhi:$hNum"
                lower.contains("dawud") -> return "https://sunnah.com/abudawud:$hNum"
            }
        }
        return if (lower.contains("quran")) "https://quran.com" else "https://sunnah.com"
    }
}

/**
 * 525+ verified, non-repeating hourly Islamic wisdom & universal growth reflections
 * (Quran, Sahih Bukhari, Sahih Muslim, Sunan al-Tirmidhi, Sunnah, Scholars & Discipline/Mindset).
 * Rotates by (dayOfYear * 24 + hourOfDay) so every hour surfaces fresh wisdom across weeks.
 */
object MotivationKnowledgeCatalog {

    private val baseItems: List<KnowledgeMotivationItem> = listOf(
        KnowledgeMotivationItem(
            1, "Quran",
            "Tranquility in Remembrance",
            "\"Unquestionably, by the remembrance of Allah do hearts find rest.\" Take 20 seconds right now to say SubhanAllah with presence.",
            "যিকিরে হৃদয়ের প্রশান্তি",
            "“জেনে রাখো, আল্লাহর স্মরণেই অন্তরসমূহ প্রশান্তি লাভ করে।” এখনই ২০ সেকেন্ড মন থেকে সুবহানাল্লাহ বলুন।",
            "Quran 13:28"
        ),
        KnowledgeMotivationItem(
            2, "Hadith",
            "Most Beloved Deeds Are Consistent",
            "The Prophet (ﷺ) taught that the most beloved deeds to Allah are those done regularly, even if small.",
            "ধারাবাহিক ছোট আমলই সবচেয়ে প্রিয়",
            "নবী (ﷺ) বলেছেন, আল্লাহর নিকট সবচেয়ে প্রিয় আমল হলো যা নিয়মিত করা হয়—যদিও তা অল্প হয়।",
            "Sahih al-Bukhari 6464"
        ),
        KnowledgeMotivationItem(
            3, "Quran",
            "Ease Accompanies Hardship",
            "\"Indeed, with hardship comes ease.\" Notice the Arabic says WITH hardship—relief is already being woven alongside your trial.",
            "কষ্টের সাথেই স্বস্তি রয়েছে",
            "“নিশ্চয়ই কষ্টের সাথেই রয়েছে স্বস্তি।” আপনার পরীক্ষার পাশাপাশিই আল্লাহর পক্ষ থেকে সহজতা তৈরি হচ্ছে।",
            "Quran 94:6"
        ),
        KnowledgeMotivationItem(
            4, "Hadith",
            "Smiling Is Charity",
            "\"Your smiling in the face of your brother is charity.\" Soften your tone and greet the next person you meet with warmth.",
            "হাসিমুখে কথা বলাও সদকা",
            "“তোমার ভাইয়ের মুখে হাসি ফোটানো বা হাসিমুখে সাক্ষাৎ করা সদকা।” পরের মানুষের সাথে নম্র ও হাসিমুখে কথা বলুন।",
            "Jami' at-Tirmidhi 1956"
        ),
        KnowledgeMotivationItem(
            5, "Sunnah",
            "Drink Water in Three Sips",
            "Follow the Sunnah when hydrating: sit calmly, say Bismillah, drink in three gentle breaths, and conclude with Alhamdulillah.",
            "তিন শ্বাসে বসে পানি পান",
            "পানি পানের সুন্নাহ অনুসরণ করুন: বসে, বিসমিল্লাহ বলে, তিন শ্বাসে ধীরে পান করুন এবং শেষে আলহামদুলিল্লাহ বলুন।",
            "Sahih Muslim 2028"
        ),
        KnowledgeMotivationItem(
            6, "Hadith",
            "Guarding the Tongue",
            "\"Whoever believes in Allah and the Last Day, let him speak good or remain silent.\" Pause three seconds before replying in frustration.",
            "জিহ্বার হেফাজত",
            "“যে আল্লাহ ও আখিরাতে বিশ্বাস করে, সে যেন উত্তম কথা বলে অথবা চুপ থাকে।” রাগের মুহূর্তে উত্তর দেওয়ার আগে ৩ সেকেন্ড থামুন।",
            "Sahih al-Bukhari 6018"
        ),
        KnowledgeMotivationItem(
            7, "Quran",
            "Allah Is Near",
            "\"And when My servants ask you concerning Me — indeed I am near. I respond to the invocation of the supplicant when he calls upon Me.\"",
            "আল্লাহ অতি নিকটে",
            "“আমার বান্দারা যখন তোমাকে আমার সম্পর্কে জিজ্ঞাসা করে—নিশ্চয়ই আমি নিকটে। আহ্বায়ক যখন আমাকে ডাকে আমি তার ডাকে সাড়া দিই।”",
            "Quran 2:186"
        ),
        KnowledgeMotivationItem(
            8, "Hadith",
            "True Strength",
            "\"The strong person is not the one who overcomes others by physical force, but the one who controls himself in anger.\"",
            "প্রকৃত শক্তিমান কে?",
            "“প্রকৃত শক্তিশালী সে নয় যে কুস্তিতে অন্যকে হারায়; বরং প্রকৃত শক্তিশালী সে যে রাগের সময় নিজেকে সংযত রাখে।”",
            "Sahih al-Bukhari 6114"
        ),
        KnowledgeMotivationItem(
            9, "Sunnah",
            "Two Words Heavy on the Scale",
            "Light on the tongue, heavy on the Scale, beloved to the Most Merciful: SubhanAllahi wa bihamdihi, SubhanAllahil-'Azim.",
            "মিযানে ভারী দুটি বাক্য",
            "জিহ্বায় সহজ, মিযানে ভারী ও দয়াময়ের প্রিয়: সুবহানাল্লাহি ওয়া বিহামদিহি, সুবহানাল্লাহিল আযীম।",
            "Sahih al-Bukhari 6406"
        ),
        KnowledgeMotivationItem(
            10, "Quran",
            "Gratitude Increases Blessings",
            "\"If you are grateful, I will surely increase you [in favor].\" Name three quiet blessings in your life right now.",
            "কৃতজ্ঞতায় নিয়ামত বাড়ে",
            "“তোমরা কৃতজ্ঞ হলে আমি অবশ্যই তোমাদের নিয়ামত বাড়িয়ে দেব।” এখনই জীবনের তিনটি নীরব নিয়ামতের জন্য শুকরিয়া আদায় করুন।",
            "Quran 14:7"
        ),
        KnowledgeMotivationItem(
            11, "Hadith",
            "Intention Elevates Routine",
            "\"Actions are judged by intentions.\" Renew your niyyah for your study, work, and health so ordinary hours become worship.",
            "নিয়ত সাধারণ কাজকে ইবাদত বানায়",
            "“সমস্ত কাজ নিয়তের ওপর নির্ভরশীল।” পড়াশোনা, কাজ ও সুস্থতার নিয়ত নবায়ন করুন—সাধারণ সময়ও সওয়াবে পরিণত হবে।",
            "Sahih al-Bukhari 1"
        ),
        KnowledgeMotivationItem(
            12, "Quran",
            "Never Despair of Allah's Mercy",
            "\"Do not despair of the mercy of Allah. Indeed, Allah forgives all sins.\" A sincere return always opens a fresh chapter.",
            "আল্লাহর রহমত থেকে নিরাশ হয়ো না",
            "“আল্লাহর রহমত থেকে নিরাশ হয়ো না। নিশ্চয়ই আল্লাহ সমস্ত গুনাহ ক্ষমা করেন।” খাঁটি তাওবা সবসময় নতুন অধ্যায় খোলে।",
            "Quran 39:53"
        ),
        KnowledgeMotivationItem(
            13, "Hadith",
            "Two Blessings People Waste",
            "\"There are two blessings which many people lose: health and free time.\" Invest today's energy in something that outlives today.",
            "যে দুটি নিয়ামতে মানুষ উদাসীন",
            "“দুটি নিয়ামতের ব্যাপারে অধিকাংশ মানুষ ধোঁকায় থাকে—সুস্থতা ও অবসর সময়।” আজকের শক্তি কল্যাণকর কাজে লাগান।",
            "Sahih al-Bukhari 6412"
        ),
        KnowledgeMotivationItem(
            14, "Sunnah",
            "One-Third Rule of Eating",
            "Keep nutrition balanced: fill at most one-third of the stomach with food, one-third with water, and leave one-third for breath.",
            "খাবারের এক-তৃতীয়াংশ সুন্নাহ",
            "পেটের এক-তৃতীয়াংশ খাবার, এক-তৃতীয়াংশ পানি এবং এক-তৃতীয়াংশ শ্বাস-প্রশ্বাসের জন্য খালি রাখুন।",
            "Jami' at-Tirmidhi 2380"
        ),
        KnowledgeMotivationItem(
            15, "Hadith",
            "Seeking Knowledge Eases the Path to Jannah",
            "\"Whoever treads a path seeking knowledge, Allah will make easy for him a path to Paradise.\"",
            "জ্ঞান অন্বেষণ জান্নাতের পথ সহজ করে",
            "“যে ব্যক্তি জ্ঞান অর্জনের পথে চলে, আল্লাহ তার জন্য জান্নাতের পথ সহজ করে দেন।”",
            "Sahih Muslim 2699"
        ),
        KnowledgeMotivationItem(
            16, "Quran",
            "A Soul Is Never Burdened Beyond Capacity",
            "\"Allah does not charge a soul except [with that within] its capacity.\" You already possess what is needed to take the next faithful step.",
            "সাধ্যের অতিরিক্ত বোঝা দেওয়া হয় না",
            "“আল্লাহ কাউকে তার সাধ্যের বাইরে দায়িত্ব দেন না।” পরবর্তী সঠিক পদক্ষেপ নেওয়ার শক্তি আল্লাহ আপনাকে দিয়েছেন।",
            "Quran 2:286"
        ),
        KnowledgeMotivationItem(
            17, "Hadith",
            "Cleanliness Is Half of Faith",
            "\"Purity is half of faith.\" Keep your body, clothes, prayer space, and heart clean and unhurried.",
            "পবিত্রতা ঈমানের অর্ধেক",
            "“পবিত্রতা ঈমানের অর্ধেক।” শরীর, পোশাক, নামাজের স্থান ও হৃদয়কে পরিচ্ছন্ন রাখুন।",
            "Sahih Muslim 223"
        ),
        KnowledgeMotivationItem(
            18, "Quran",
            "Reliance Upon Allah",
            "\"And whoever relies upon Allah — then He is sufficient for him.\" Prepare thoroughly, then surrender anxiety to Al-Wakil.",
            "আল্লাহর ওপর তাওয়াক্কুল",
            "“যে আল্লাহর ওপর ভরসা করে, তাঁর জন্য তিনিই যথেষ্ট।” যথাসাধ্য চেষ্টা করুন, তারপর দুশ্চিন্তা আল-ওয়াকিলের ওপর ছেড়ে দিন।",
            "Quran 65:3"
        ),
        KnowledgeMotivationItem(
            19, "Hadith",
            "Mercy Earns Mercy",
            "\"The merciful will be shown mercy by the Most Merciful. Be merciful to those on the earth and the One above the heavens will have mercy upon you.\"",
            "দয়া করলে আল্লাহর দয়া মেলে",
            "“দয়াশীলদের প্রতি দয়াময় আল্লাহ দয়া করেন। পৃথিবীবাসীর প্রতি দয়া করো, আসমানওয়ালা তোমাদের প্রতি দয়া করবেন।”",
            "Sunan Abi Dawud 4941"
        ),
        KnowledgeMotivationItem(
            20, "Quran",
            "Excellence in Character",
            "\"Repel [evil] by that which is better; and thereupon the one whom between you and him is enmity will become as though he was a devoted friend.\"",
            "উত্তম আচরণে মন্দের জবাব",
            "“ভালো দিয়ে মন্দকে প্রতিহত করো; তখন দেখবে যার সাথে তোমার শত্রুতা ছিল সেও যেন অন্তরঙ্গ বন্ধু হয়ে গেছে।”",
            "Quran 41:34"
        ),
        KnowledgeMotivationItem(
            21, "Hadith",
            "Blessing in Early Hours",
            "\"O Allah, bless my Ummah in its early mornings.\" Guard Fajr and your first focused hour of the day.",
            "ভোরের সময়ে বরকত",
            "“হে আল্লাহ, আমার উম্মতের ভোরের সময়ে বরকত দান করুন।” ফজর ও সকালের প্রথম ঘণ্টা সযত্নে কাজে লাগান।",
            "Sunan Abi Dawud 2606"
        ),
        KnowledgeMotivationItem(
            22, "Quran",
            "Remember Me, I Will Remember You",
            "\"So remember Me; I will remember you. And be grateful to Me and do not deny Me.\"",
            "আমাকে স্মরণ করো, আমি তোমাদের স্মরণ করব",
            "“অতএব আমাকে স্মরণ করো, আমিও তোমাদের স্মরণ করব; আমার কৃতজ্ঞতা প্রকাশ করো, অকৃতজ্ঞ হয়ো না।”",
            "Quran 2:152"
        ),
        KnowledgeMotivationItem(
            23, "Hadith",
            "Removing Harm Is Faith",
            "Removing even a small obstacle from a public path is a branch of Iman. Look for one quiet act of service today.",
            "পথের কষ্টদায়ক বস্তু সরানো ঈমানের অংশ",
            "রাস্তা থেকে কষ্টদায়ক বস্তু সরিয়ে দেওয়া ঈমানের শাখা। আজ অন্তত একটি নীরব উপকার করুন।",
            "Sahih Muslim 35"
        ),
        KnowledgeMotivationItem(
            24, "Sunnah",
            "Make Dua for Others in Secret",
            "When you pray for someone behind their back, an angel says: \"Ameen, and for you the same.\"",
            "অন্যের জন্য গোপনে দুআ",
            "কারো অনুপস্থিতিতে কল্যাণের দুআ করলে ফেরেশতা বলেন: “আমীন, আর তোমার জন্যও অনুরূপ হোক।”",
            "Sahih Muslim 2732"
        ),
        KnowledgeMotivationItem(
            25, "Quran",
            "Patience and Prayer",
            "\"O you who have believed, seek help through patience and prayer. Indeed, Allah is with the patient.\"",
            "ধৈর্য ও নামাজের মাধ্যমে সাহায্য চাও",
            "“হে ঈমানদারগণ, ধৈর্য ও সালাতের মাধ্যমে সাহায্য প্রার্থনা করো। নিশ্চয়ই আল্লাহ ধৈর্যশীলদের সাথে আছেন।”",
            "Quran 2:153"
        ),
        KnowledgeMotivationItem(
            26, "Hadith",
            "Best of People",
            "\"The best of people are those who are most beneficial to people.\" Ask how your skills can relieve someone's burden today.",
            "সর্বোত্তম মানুষ",
            "“মানুষের মধ্যে সর্বোত্তম সেই ব্যক্তি যে মানুষের জন্য সবচেয়ে বেশি উপকারী।” আজ আপনার দক্ষতা দিয়ে কারো উপকার করুন।",
            "Al-Mu'jam al-Awsat 5787 (Hasan)"
        ),
        KnowledgeMotivationItem(
            27, "Sunnah",
            "Evening Sanctuary",
            "Recite Ayat al-Kursi and the last two verses of Surah Al-Baqarah before sleep for serene protection through the night.",
            "রাতের নিরাপদ আশ্রয়",
            "ঘুমানোর আগে আয়াতুল কুরসী ও সূরা বাকারার শেষ দুই আয়াত তিলাওয়াত করুন—সারারাত আল্লাহর নিরাপত্তায় থাকবেন।",
            "Sahih al-Bukhari 5009"
        ),
        KnowledgeMotivationItem(
            28, "Hadith",
            "Every Good Deed Is Charity",
            "A kind word, fair help, or patient listening—every single act of goodness is recorded as sadaqah.",
            "প্রতিটি ভালো কাজই সদকা",
            "একটি সুন্দর কথা, ন্যায্য সাহায্য কিংবা ধৈর্য ধরে অন্যের কথা শোনা—প্রতিটি সৎকাজই সদকা।",
            "Sahih al-Bukhari 6021"
        ),
        KnowledgeMotivationItem(
            29, "Quran",
            "Lowering the Wing of Humility to Parents",
            "\"And lower to them the wing of humility out of mercy and say: My Lord, have mercy upon them as they brought me up when I was small.\"",
            "মা-বাবার প্রতি বিনয় ও দুআ",
            "“তাদের প্রতি মমতাভরে বিনয়ের ডানা নত করে দাও এবং বলো: হে আমার রব, তাদের প্রতি দয়া করুন যেমন শৈশবে তারা আমাকে লালন করেছেন।”",
            "Quran 17:24"
        ),
        KnowledgeMotivationItem(
            30, "Hadith",
            "Istighfar Opens Relief",
            "Frequent Istighfar softens the heart and clears heaviness. Say Astaghfirullah al-'Azim 10 times slowly right now.",
            "ইস্তিগফারে হৃদয়ের ভার লাঘব হয়",
            "বেশি বেশি ইস্তিগফার অন্তর নরম করে ও দুশ্চিন্তা দূর করে। এখনই ধীরে ১০ বার আস্তাগফিরুল্লাহিল আযীম বলুন।",
            "Sahih Muslim 2702"
        ),
        KnowledgeMotivationItem(
            31, "Quran",
            "Increase Me in Knowledge",
            "\"My Lord, increase me in knowledge.\" Pair curiosity with humility every time you open a lesson or Surah.",
            "জ্ঞান বৃদ্ধির দুআ",
            "“রব্বি যিদনী ইলমা—হে আমার রব, আমার জ্ঞান বাড়িয়ে দিন।” প্রতিটি নতুন শেখার আগে এই দুআ পড়ুন।",
            "Quran 20:114"
        ),
        KnowledgeMotivationItem(
            32, "Hadith",
            "The Believer's Amazing Affair",
            "\"How wondrous is the affair of the believer! Everything is good for him: if good befalls him he is grateful, and if hardship strikes he is patient.\"",
            "মুমিনের বিস্ময়কর অবস্থা",
            "“মুমিনের ব্যাপারটি কতই না বিস্ময়কর! তার প্রতিটি অবস্থাই কল্যাণকর—সুখে শুকরিয়া আর কষ্টে ধৈর্য ধারণ করে।”",
            "Sahih Muslim 2999"
        ),
        KnowledgeMotivationItem(
            33, "Hadith",
            "Sending Salawat Multiplies Mercy",
            "\"Whoever sends blessings upon me once, Allah sends blessings upon him tenfold.\" Pause and say Allahumma salli 'ala Muhammad.",
            "দরূদ শরীফে দশগুণ রহমত",
            "“যে আমার ওপর একবার দরূদ পড়ে, আল্লাহ তার ওপর দশবার রহমত বর্ষণ করেন।” এখনই বলুন—আল্লাহুম্মা সাল্লি আলা মুহাম্মাদ।",
            "Sahih Muslim 384"
        ),
        KnowledgeMotivationItem(
            34, "Quran",
            "Speak Gently Even to the Difficult",
            "Allah commanded Musa and Harun (AS) to speak gently even to Fir'awn. Gentleness opens hearts that harshness locks shut.",
            "কঠোর মানুষের সাথেও নম্র ভাষায় কথা",
            "আল্লাহ মূসা ও হারূন (আ.)-কে ফিরআউনের সাথেও নম্র ভাষায় কথা বলার নির্দেশ দিয়েছিলেন। কোমলতা বন্ধ হৃদয়ও খুলে দেয়।",
            "Quran 20:44"
        ),
        KnowledgeMotivationItem(
            35, "Hadith",
            "Purity of Heart Beats Envy",
            "The Prophet (ﷺ) praised the companion of Paradise whose heart carried no malice or envy toward any Muslim before sleep.",
            "হিংসামুক্ত নির্মল অন্তর",
            "নবী (ﷺ) সেই জান্নাতি সাহাবীর প্রশংসা করেছেন যিনি প্রতি রাতে কারো প্রতি বিদ্বেষ বা হিংসা না রেখে ঘুমাতেন।",
            "Musnad Ahmad 12697"
        ),
        KnowledgeMotivationItem(
            36, "Sunnah",
            "Sunnah of Wudu Before Sleep",
            "Sleeping in a state of Wudu invites an angel to stay near you and supplicate for your forgiveness whenever you stir in the night.",
            "অজু করে ঘুমানোর ফযীলত",
            "অজু করে ঘুমালে একজন ফেরেশতা আপনার পাশে থাকেন এবং রাতে জেগে উঠলেই আপনার ক্ষমার জন্য দুআ করেন।",
            "Sahih Ibn Hibban 1051"
        ),
        KnowledgeMotivationItem(
            37, "Quran",
            "Your Lord Has Not Forsaken You",
            "\"Your Lord has not taken leave of you, nor has He detested you.\" Even quiet seasons are seasons of divine care.",
            "তোমার রব তোমাকে ত্যাগ করেননি",
            "“তোমার রব তোমাকে পরিত্যাগ করেননি এবং অসন্তুষ্টও হননি।” নীরব কঠিন সময়ও আল্লাহর বিশেষ তত্ত্বাবধানের অংশ।",
            "Quran 93:3"
        ),
        KnowledgeMotivationItem(
            38, "Hadith",
            "Modesty Brings Only Good",
            "\"Modesty (Haya) brings nothing except good.\" Guard your dignity in private just as carefully as in public.",
            "লজ্জাশীলতা কেবল কল্যাণই বয়ে আনে",
            "“হায়া বা লজ্জাশীলতা কেবল কল্যাণই নিয়ে আসে।” প্রকাশ্যে যেমন, নির্জনেও তেমনি নিজের মর্যাদা রক্ষা করুন।",
            "Sahih al-Bukhari 6117"
        ),
        KnowledgeMotivationItem(
            39, "Sunnah",
            "Walking to Prayer Erases Sins",
            "Every step taken calmly toward prayer raises a rank and erases a shortcoming. Never rush into Salah; arrive with serenity.",
            "নামাজের প্রতিটি কদমে মর্যাদা বৃদ্ধি",
            "সালাতের উদ্দেশ্যে শান্তভাবে নেওয়া প্রতিটি পদক্ষেপে একটি মর্যাদা বৃদ্ধি পায় এবং একটি গুনাহ মাফ হয়।",
            "Sahih Muslim 666"
        ),
        KnowledgeMotivationItem(
            40, "Quran",
            "Charity Never Diminishes Wealth",
            "\"Whatever you spend in charity, He will replace it; and He is the best of providers.\" Give even a small kindness today.",
            "দান কখনো সম্পদ কমায় না",
            "“তোমরা যা ব্যয় করো, তিনি তার প্রতিদান দেন; আর তিনিই সর্বোত্তম রিযিকদাতা।” আজ সামান্য হলেও কারো জন্য ব্যয় করুন।",
            "Quran 34:39"
        ),
        KnowledgeMotivationItem(
            41, "Hadith",
            "Love for Your Brother What You Love for Yourself",
            "\"None of you truly believes until he loves for his brother what he loves for himself.\"",
            "নিজের জন্য যা পছন্দ, ভাইয়ের জন্যও তা পছন্দ করা",
            "“তোমাদের কেউ প্রকৃত মুমিন হবে না, যতক্ষণ না নিজের জন্য যা পছন্দ করে তার ভাইয়ের জন্যও তা পছন্দ করে।”",
            "Sahih al-Bukhari 13"
        ),
        KnowledgeMotivationItem(
            42, "Quran",
            "Verify Before Sharing",
            "\"If there comes to you a report, investigate it carefully lest you harm a people out of ignorance.\" Pause before forwarding news.",
            "যাচাই না করে খবর ছড়িও না",
            "“কোনো সংবাদ এলে তা যাচাই করে নাও, যাতে অজ্ঞতাবশত কারো ক্ষতি করে না বসো।” কোনো তথ্য শেয়ারের আগে সত্যতা যাচাই করুন।",
            "Quran 49:6"
        ),
        KnowledgeMotivationItem(
            43, "Hadith",
            "Wealth Is Contentment of the Soul",
            "\"Richness is not having many possessions, but richness is contentment of the soul.\"",
            "অন্তরের তৃপ্তিই প্রকৃত ধনাঢ্যতা",
            "“সম্পদের প্রাচুর্য প্রকৃত ধনী হওয়া নয়; বরং অন্তরের পরিতৃপ্তিই প্রকৃত ধনাঢ্যতা।”",
            "Sahih al-Bukhari 6446"
        ),
        KnowledgeMotivationItem(
            44, "Sunnah",
            "Say Bismillah Before Every Task",
            "Starting meals, travel, study, or work with Bismillah invites barakah and shields the moment from heedlessness.",
            "প্রতিটি ভালো কাজের শুরুতে বিসমিল্লাহ",
            "খাওয়া, সফর, পড়াশোনা বা কাজের শুরুতে বিসমিল্লাহ বললে তাতে বরকত নামে এবং উদাসীনতা দূর হয়।",
            "Sahih al-Bukhari 5376"
        ),
        KnowledgeMotivationItem(
            45, "Quran",
            "He Knows What Is in Every Heart",
            "\"And He is with you wherever you are.\" Let that awareness comfort your loneliness and elevate your integrity.",
            "তিনি সর্বত্র তোমাদের সাথে আছেন",
            "“তোমরা যেখানেই থাকো না কেন, তিনি তোমাদের সাথেই আছেন।” এই অনুভূতি একাকীত্বে প্রশান্তি ও চরিত্রে সততা আনে।",
            "Quran 57:4"
        ),
        KnowledgeMotivationItem(
            46, "Hadith",
            "Good Character Weighs Heaviest",
            "\"Nothing is heavier on the believer's Scale on the Day of Resurrection than good character.\"",
            "মিযানে সবচেয়ে ভারী উত্তম চরিত্র",
            "“কিয়ামতের দিন মুমিনের মিযানে উত্তম চরিত্রের চেয়ে ভারী আর কিছুই হবে না।”",
            "Jami' at-Tirmidhi 2002"
        ),
        KnowledgeMotivationItem(
            47, "Sunnah",
            "Two Rak'ahs of Duha",
            "Every joint in your body owes gratitude each morning; two quiet Rak'ahs of Duha fulfill the charity of all 360 joints.",
            "চাশতের দুই রাকাত নামাজের সদকা",
            "মানবদেহের ৩৬০টি জোড়ার প্রতিটির শুকরিয়া আদায় হয় সকালের দুই রাকাত সালাতুত দুহা (চাশত) আদায়ে।",
            "Sahih Muslim 720"
        ),
        KnowledgeMotivationItem(
            48, "Quran",
            "Tie Your Camel & Trust Allah",
            "\"When you have decided, then rely upon Allah. Indeed, Allah loves those who rely upon Him.\"",
            "দৃঢ় সিদ্ধান্তের পর আল্লাহর ওপর ভরসা",
            "“অতঃপর যখন তুমি কোনো বিষয়ে দৃঢ় সংকল্প করো, তখন আল্লাহর ওপর ভরসা করো। নিশ্চয়ই আল্লাহ ভরসাকারীদের ভালোবাসেন।”",
            "Quran 3:159"
        ),
        KnowledgeMotivationItem(
            49, "Hadith",
            "Forgiveness Raises Honor",
            "\"Allah does not increase a servant who forgives except in honor.\" Releasing a grudge frees your own heart first.",
            "ক্ষমাশীলতায় সম্মান বাড়ে",
            "“ক্ষমা করার মাধ্যমে আল্লাহ বান্দার সম্মান আরও বাড়িয়ে দেন।” রাগ ছেড়ে দিলে প্রথমে নিজের হৃদয়ই হালকা হয়।",
            "Sahih Muslim 2588"
        ),
        KnowledgeMotivationItem(
            50, "Quran",
            "Guard Your Prayers Especially the Middle One",
            "\"Maintain with care the [obligatory] prayers and [in particular] the middle prayer (Asr) and stand before Allah devoutly obedient.\"",
            "সালাতের হেফাজত, বিশেষত আসরের",
            "“তোমরা সালাতসমূহের প্রতি যত্নবান হও—বিশেষত মধ্যবর্তী সালাত (আসর)-এর প্রতি—এবং আল্লাহর সামনে বিনীতভাবে দাঁড়াও।”",
            "Quran 2:238"
        ),
        KnowledgeMotivationItem(
            51, "Hadith",
            "Keep Ties of Kinship",
            "\"Whoever wishes for his provision to be expanded and his lifespan blessed, let him maintain the ties of kinship.\" Message a relative today.",
            "আত্মীয়তার সম্পর্ক বজায় রাখুন",
            "“যে চায় তার রিযিক প্রশস্ত হোক এবং আয়ুতে বরকত হোক, সে যেন আত্মীয়তার সম্পর্ক অটুট রাখে।” আজ একজন আত্মীয়ের খোঁজ নিন।",
            "Sahih al-Bukhari 5985"
        ),
        KnowledgeMotivationItem(
            52, "Sunnah",
            "The Treasured Phrase of Paradise",
            "\"La hawla wa la quwwata illa billah\" (There is no power nor strength except through Allah) is one of the treasures of Paradise.",
            "জান্নাতের ভাণ্ডার",
            "“লা হাওলা ওয়া লা কুওয়াতা ইল্লা বিল্লাহ”—জান্নাতের অমূল্য ভাণ্ডারসমূহের একটি। ক্লান্ত লাগলে এটি পাঠ করুন।",
            "Sahih al-Bukhari 6384"
        ),
        KnowledgeMotivationItem(
            53, "Quran",
            "Avoid Suspicion & Backbiting",
            "\"Avoid much [negative] assumption. Indeed, some assumption is sin. And do not spy or backbite each other.\"",
            "খারাপ ধারণা ও গীবত থেকে বেঁচে থাকুন",
            "“অধিক অনুমান থেকে দূরে থাকো; কেননা কিছু অনুমান গুনাহ। আর কারো দোষ খুঁজো না এবং একে অপরের গীবত করো না।”",
            "Quran 49:12"
        ),
        KnowledgeMotivationItem(
            54, "Hadith",
            "Honesty Leads to Righteousness",
            "\"Truthfulness leads to righteousness, and righteousness leads to Paradise.\" Choose clear honesty even when an excuse feels easier.",
            "সত্যবাদিতা জান্নাতের পথ দেখায়",
            "“সত্যবাদিতা পুণ্যের দিকে নিয়ে যায়, আর পুণ্য নিয়ে যায় জান্নাতের দিকে।” কঠিন মুহূর্তেও সত্যের পাশে থাকুন।",
            "Sahih al-Bukhari 6094"
        ),
        KnowledgeMotivationItem(
            55, "Quran",
            "Night Prayer Builds Inner Resilience",
            "\"Indeed, the hours of the night are more effective for concurrence [of heart and tongue] and more suitable for words.\" Even two short Rak'ahs before Fajr transform the soul.",
            "রাতের ইবাদতে দৃঢ়তা",
            "“নিশ্চয়ই রাতের বেলা ওঠা প্রবৃত্তি দমনে অধিক কার্যকর এবং কথা স্পষ্টভাবে অনুধাবনের উপযুক্ত।” ফজরের আগে ২ রাকাত তাহাজ্জুদ পড়ুন।",
            "Quran 73:6"
        ),
        KnowledgeMotivationItem(
            56, "Hadith",
            "Make Things Easy, Give Glad Tidings",
            "\"Make things easy and do not make them difficult; give glad tidings and do not drive people away.\"",
            "সহজ করো, সুসংবাদ দাও",
            "“মানুষের জন্য সহজ করো, কঠিন করো না; সুসংবাদ দাও, ঘৃণা সৃষ্টি করো না।”",
            "Sahih al-Bukhari 69"
        ),
        KnowledgeMotivationItem(
            57, "Sunnah",
            "Surah Al-Ikhlas Equals One-Third of the Quran",
            "Reciting Qul Huwa Allahu Ahad with reflection equals one-third of the Quran in reward—recite it three times with focus.",
            "সূরা ইখলাস কুরআনের এক-তৃতীয়াংশের সমান",
            "অন্তরের একাগ্রতায় সূরা ইখলাস পাঠ করলে কুরআনের এক-তৃতীয়াংশ তিলাওয়াতের সমান সওয়াব মেলে।",
            "Sahih al-Bukhari 5013"
        ),
        KnowledgeMotivationItem(
            58, "Quran",
            "Allah Loves Those Who Do Good (Ihsan)",
            "\"And do good; indeed, Allah loves the doers of good.\" Aim for Ihsan—excellence as though Allah is witnessing your craft.",
            "আল্লাহ ইহসানকারীদের ভালোবাসেন",
            "“তোমরা সৎকর্ম ও উৎকর্ষ (ইহসান) অবলম্বন করো; নিশ্চয়ই আল্লাহ ইহসানকারীদের ভালোবাসেন।”",
            "Quran 2:195"
        ),
        KnowledgeMotivationItem(
            59, "Hadith",
            "Leave What Does Not Concern You",
            "\"Part of the perfection of a person's Islam is leaving that which does not concern him.\" Protect your mental peace from idle drama.",
            "অনর্থক বিষয় ত্যাগ করা ইসলামের সৌন্দর্য",
            "“মানুষের ইসলামের সৌন্দর্যের অন্যতম দিক হলো অনর্থক বিষয় পরিত্যাগ করা।” অযথা বিতর্ক থেকে মনকে মুক্ত রাখুন।",
            "Jami' at-Tirmidhi 2317"
        ),
        KnowledgeMotivationItem(
            60, "Quran",
            "Gratitude of Prophet Sulayman (AS)",
            "\"This is from the favor of my Lord to test me whether I will be grateful or ungrateful.\" Every achievement is a trust, not an ego trophy.",
            "সাফল্যে সুলাইমান (আ.)-এর কৃতজ্ঞতা",
            "“এটি আমার রবের অনুগ্রহ, আমাকে পরীক্ষা করার জন্য যে আমি কৃতজ্ঞ হই নাকি অকৃতজ্ঞ।” প্রতিটি সাফল্যে বিনয়ী থাকুন।",
            "Quran 27:40"
        ),
        KnowledgeMotivationItem(
            61, "Hadith",
            "Help Your Brother & Allah Helps You",
            "\"Allah continues to aid the servant so long as the servant is aiding his brother.\"",
            "অন্যের সাহায্যে আল্লাহর সাহায্য",
            "“বান্দা যতক্ষণ তার ভাইয়ের সাহায্যে নিয়োজিত থাকে, আল্লাহ ততক্ষণ সেই বান্দার সাহায্যে থাকেন।”",
            "Sahih Muslim 2699"
        ),
        KnowledgeMotivationItem(
            62, "Sunnah",
            "Prophet's Dua for Beneficial Knowledge",
            "After Fajr say: Allahumma inni as'aluka 'ilman nafi'an, wa rizqan tayyiban, wa 'amalan mutaqabbalan.",
            "উপকারী জ্ঞান ও হালাল রিযিকের দুআ",
            "ফজরের পর পড়ুন: আল্লাহুম্মা ইন্নী আসআলুকা ইলমান নাফিআ, ওয়া রিযকান তায়্যিবা, ওয়া আমালান মুতাকাব্বালা।",
            "Sunan Ibn Majah 925"
        ),
        KnowledgeMotivationItem(
            63, "Quran",
            "Hope Paired With Action",
            "\"And that there is not for man except that [good] for which he strives, and that his effort is going to be seen.\"",
            "মানুষ তাই পায় যার জন্য সে চেষ্টা করে",
            "“মানুষ তাই পায় যার জন্য সে সাধনা করে, এবং অচিরেই তার প্রচেষ্টা দেখা হবে।”",
            "Quran 53:39-40"
        ),
        KnowledgeMotivationItem(
            64, "Hadith",
            "A Good Word Protects From Fire",
            "\"Shield yourself from the Fire even with half a date—and if you cannot find that, then with a kind word.\"",
            "একটি সুন্দর কথাও জাহান্নাম থেকে ঢাল",
            "“অর্ধেক খেজুর দান করে হলেও জাহান্নাম থেকে বাঁচো; তা না পেলে একটি উত্তম কথার মাধ্যমে।”",
            "Sahih al-Bukhari 6023"
        ),
        KnowledgeMotivationItem(
            65, "Sunnah",
            "Say Alhamdulillah in All Circumstances",
            "When joyful say: Alhamdulillahilladhi bi ni'matihi tatimmus-salihat. When tested say: Alhamdulillahi 'ala kulli hal.",
            "সর্বাবস্থায় আলহামদুলিল্লাহ",
            "খুশির খবরে: আলহামদুলিল্লাহিল্লাযী বি-নি'মাতিহী তাতিম্মুস-সালিহাত; কঠিন সময়ে: আলহামদুলিল্লাহি আলা কুল্লি হাল।",
            "Sunan Ibn Majah 3803"
        ),
        KnowledgeMotivationItem(
            66, "Quran",
            "Humility of the Servants of Ar-Rahman",
            "\"And the servants of the Most Merciful are those who walk upon the earth easily, and when the ignorant address them harshly, they say words of peace.\"",
            "রহমানের বান্দাদের বিনয়",
            "“দয়াময়ের বান্দা তারা, যারা পৃথিবীতে নম্রভাবে চলাফেরা করে এবং অজ্ঞরা কটু কথা বললে তারা শান্তির কথা বলে।”",
            "Quran 25:63"
        ),
        KnowledgeMotivationItem(
            67, "Hadith",
            "Keep Your Tongue Moist With Dhikr",
            "When asked for one anchor to hold fast to, the Prophet (ﷺ) replied: \"Keep your tongue continuously moist with the remembrance of Allah.\"",
            "যিকিরে জিহ্বা সিক্ত রাখুন",
            "এক সাহাবী বিশেষ আমল জানতে চাইলে নবী (ﷺ) বললেন: “তোমার জিহ্বা যেন সর্বদা আল্লাহর যিকিরে সিক্ত থাকে।”",
            "Jami' at-Tirmidhi 3375"
        ),
        KnowledgeMotivationItem(
            68, "Quran",
            "The Best Provision Is Taqwa",
            "\"And take provisions, but indeed, the best provision is fear of Allah (Taqwa).\" Let mindfulness of Allah guide today's choices.",
            "সর্বোত্তম পাথেয় হলো তাকওয়া",
            "“তোমরা পাথেয় সংগ্রহ করো; আর নিশ্চয়ই সর্বোত্তম পাথেয় হলো তাকওয়া।” আজকের প্রতিটি সিদ্ধান্তে আল্লাহর সচেতনতা রাখুন।",
            "Quran 2:197"
        ),
        KnowledgeMotivationItem(
            69, "Hadith",
            "Visiting the Sick & Comforting the Sad",
            "Whoever visits a sick person sits in the gardens of mercy until they return. Send a warm check-in to someone struggling today.",
            "অসুস্থ ও দুঃখী মানুষের খোঁজ নেওয়া",
            "অসুস্থ ব্যক্তির খোঁজ নিতে গেলে ফিরে আসা পর্যন্ত ব্যক্তি জান্নাতের বাগানে অবস্থান করে। আজ কোনো কষ্টে থাকা মানুষের খোঁজ নিন।",
            "Sahih Muslim 2568"
        ),
        KnowledgeMotivationItem(
            70, "Sunnah",
            "Moderation Protects Sustainability",
            "\"This religion is ease. Do what is right, come close to perfection, and take heart in the morning, evening, and part of the night.\"",
            "মধ্যমপন্থা আমলকে স্থায়ী করে",
            "“দ্বীন সহজ। তোমরা মধ্যমপন্থা অবলম্বন করো, সকাল-সন্ধ্যা ও রাতের কিছু অংশে ইবাদতে সচেষ্ট হও।”",
            "Sahih al-Bukhari 39"
        ),
        KnowledgeMotivationItem(
            71, "Quran",
            "Calling Upon Allah With Humility",
            "\"Call upon your Lord in humility and privately; indeed, He does not like transgressors.\" Whisper one honest Dua from your heart right now.",
            "বিনয় ও গোপনে রবকে ডাকো",
            "“তোমরা বিনীতভাবে ও চুপিসারে তোমাদের রবকে ডাকো।” এখনই অন্তরের গভীর থেকে একটি আন্তরিক দুআ করুন।",
            "Quran 7:55"
        ),
        KnowledgeMotivationItem(
            72, "Hadith",
            "The Quran Intercedes for Its Companion",
            "\"Read the Quran, for indeed it will come on the Day of Resurrection as an intercessor for its companions.\" Even five verses today count.",
            "কুরআন তার পাঠকের সুপারিশকারী হবে",
            "“তোমরা কুরআন তিলাওয়াত করো; কেননা কিয়ামতের দিন এটি তার পাঠকদের জন্য সুপারিশকারী হয়ে আসবে।” আজ অন্তত ৫টি আয়াত পড়ুন।",
            "Sahih Muslim 804"
        )
    )

    val items: List<KnowledgeMotivationItem> by lazy {
        val core = baseItems + MotivationWisdomBank.buildExtendedItems(startId = baseItems.size + 1)
        val shortDuas = com.example.ruhzena.data.islamic.IslamicContentData.duaList
            .filter { it.arabicText.length <= 145 }
            .mapIndexed { idx, dua ->
                KnowledgeMotivationItem(
                    id = core.size + idx + 1,
                    category = "Daily Dua",
                    titleEn = "Sunnah Dua: ${dua.titleEn}",
                    bodyEn = "${dua.arabicText}\n${dua.transliterationEn}\n\"${dua.translationEn}\"",
                    titleBn = "সুন্নাহ দুআ: ${dua.titleBn}",
                    bodyBn = "${dua.arabicText}\n${dua.transliterationBn}\n“${dua.translationBn}”",
                    sourceRef = dua.sourceRef
                )
            }
        // Interleave short everyday Duas every 4th Hikmah slot so they surface naturally throughout the day
        val merged = ArrayList<KnowledgeMotivationItem>(core.size + shortDuas.size)
        var duaIdx = 0
        core.forEachIndexed { idx, item ->
            merged.add(item)
            if ((idx + 1) % 3 == 0 && duaIdx < shortDuas.size) {
                merged.add(shortDuas[duaIdx++])
            }
        }
        while (duaIdx < shortDuas.size) {
            merged.add(shortDuas[duaIdx++])
        }
        merged.mapIndexed { i, item -> item.copy(id = i + 1) }
    }

    fun forHour(hourOfDay: Int, dayOfYear: Int = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)): KnowledgeMotivationItem {
        val list = items
        val slot = ((dayOfYear.coerceAtLeast(0) * 24) + hourOfDay.coerceIn(0, 23)).let { if (it < 0) 0 else it }
        return list[slot % list.size]
    }

    fun forCurrentHour(): KnowledgeMotivationItem {
        val cal = Calendar.getInstance()
        return forHour(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.DAY_OF_YEAR))
    }
}
