package com.example.ruhzena.ui.components

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ruhzena.ui.exercises.MuscleZone
import com.example.ui.theme.RuhZenaGlassPalette
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class FigureWardrobe {
    PRAYER,
    HALAL_ATHLETIC
}

/**
 * Full 22-point articulated human body pose in normalized viewport coordinates (0..1).
 * Shared by both the Salah/Wudu Animated Coach and the Athletic Workout Engine.
 */
data class HumanRigPose(
    val head: Offset,
    val neck: Offset,
    val chest: Offset,
    val waist: Offset,
    val pelvis: Offset,
    val nearShoulder: Offset,
    val nearElbow: Offset,
    val nearWrist: Offset,
    val nearHand: Offset,
    val farShoulder: Offset,
    val farElbow: Offset,
    val farWrist: Offset,
    val farHand: Offset,
    val nearHip: Offset,
    val nearKnee: Offset,
    val nearAnkle: Offset,
    val nearFoot: Offset,
    val farHip: Offset,
    val farKnee: Offset,
    val farAnkle: Offset,
    val farFoot: Offset,
    val headPitchDeg: Float = 0f,
    val headYawDeg: Float = 0f,           // -55f = look left, +55f = look right (Taslim)
    val indexFingerRaised: Boolean = false, // Tashahhud Shahadah testimony
    val palmsOpenQibla: Boolean = false,    // Takbiratul Ihram
    val isSeatedOrKneeling: Boolean = false,
    val isProstrating: Boolean = false,
    val waterFlowTarget: Offset? = null     // Animated water stream during Wudu
)

fun lerpOffset(a: Offset, b: Offset, t: Float): Offset =
    Offset(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)

fun lerpFloat(a: Float, b: Float, t: Float): Float = a + (b - a) * t

fun interpolateHumanPose(a: HumanRigPose, b: HumanRigPose, t: Float): HumanRigPose = HumanRigPose(
    head = lerpOffset(a.head, b.head, t),
    neck = lerpOffset(a.neck, b.neck, t),
    chest = lerpOffset(a.chest, b.chest, t),
    waist = lerpOffset(a.waist, b.waist, t),
    pelvis = lerpOffset(a.pelvis, b.pelvis, t),
    nearShoulder = lerpOffset(a.nearShoulder, b.nearShoulder, t),
    nearElbow = lerpOffset(a.nearElbow, b.nearElbow, t),
    nearWrist = lerpOffset(a.nearWrist, b.nearWrist, t),
    nearHand = lerpOffset(a.nearHand, b.nearHand, t),
    farShoulder = lerpOffset(a.farShoulder, b.farShoulder, t),
    farElbow = lerpOffset(a.farElbow, b.farElbow, t),
    farWrist = lerpOffset(a.farWrist, b.farWrist, t),
    farHand = lerpOffset(a.farHand, b.farHand, t),
    nearHip = lerpOffset(a.nearHip, b.nearHip, t),
    nearKnee = lerpOffset(a.nearKnee, b.nearKnee, t),
    nearAnkle = lerpOffset(a.nearAnkle, b.nearAnkle, t),
    nearFoot = lerpOffset(a.nearFoot, b.nearFoot, t),
    farHip = lerpOffset(a.farHip, b.farHip, t),
    farKnee = lerpOffset(a.farKnee, b.farKnee, t),
    farAnkle = lerpOffset(a.farAnkle, b.farAnkle, t),
    farFoot = lerpOffset(a.farFoot, b.farFoot, t),
    headPitchDeg = lerpFloat(a.headPitchDeg, b.headPitchDeg, t),
    headYawDeg = lerpFloat(a.headYawDeg, b.headYawDeg, t),
    indexFingerRaised = if (t < 0.5f) a.indexFingerRaised else b.indexFingerRaised,
    palmsOpenQibla = if (t < 0.5f) a.palmsOpenQibla else b.palmsOpenQibla,
    isSeatedOrKneeling = if (t < 0.5f) a.isSeatedOrKneeling else b.isSeatedOrKneeling,
    isProstrating = if (t < 0.5f) a.isProstrating else b.isProstrating,
    waterFlowTarget = if (t < 0.5f) a.waterFlowTarget else b.waterFlowTarget
)

private data class ClothingMaterials(
    val skinLight: Color,
    val skinMid: Color,
    val skinShadow: Color,
    val topLight: Color,
    val topMid: Color,
    val topShadow: Color,
    val topAccent: Color,
    val bottomLight: Color,
    val bottomMid: Color,
    val bottomShadow: Color,
    val headCoverLight: Color,
    val headCoverMid: Color,
    val headCoverShadow: Color,
    val shoeMain: Color,
    val shoeSole: Color
)

private fun resolveMaterials(
    wardrobe: FigureWardrobe,
    isFemale: Boolean
): ClothingMaterials {
    // Realistic sculpted matte skin tones (warm neutral natural studio lighting)
    val skinLight = Color(0xFFE3B997)
    val skinMid = Color(0xFFC99873)
    val skinShadow = Color(0xFF936647)

    return when (wardrobe) {
        FigureWardrobe.PRAYER -> if (isFemale) {
            // Refined Pearl-Silver & Soft Graphite Modest Prayer Abaya / Khimar
            ClothingMaterials(
                skinLight = skinLight,
                skinMid = skinMid,
                skinShadow = skinShadow,
                topLight = Color(0xFFE4E7EE),
                topMid = Color(0xFFC5CCD8),
                topShadow = Color(0xFF7D8594),
                topAccent = Color(0xFFD8BC82),
                bottomLight = Color(0xFFD5DBE6),
                bottomMid = Color(0xFFB3BBC9),
                bottomShadow = Color(0xFF6B7382),
                headCoverLight = Color(0xFFEDF0F5),
                headCoverMid = Color(0xFFCFD5E0),
                headCoverShadow = Color(0xFF8891A1),
                shoeMain = Color(0xFF9CA3B0),
                shoeSole = Color(0xFF6B7280)
            )
        } else {
            // Tailored Crisp Pearl-Ivory Male Thobe / Jubbah & White Kufi Cap
            ClothingMaterials(
                skinLight = skinLight,
                skinMid = skinMid,
                skinShadow = skinShadow,
                topLight = Color(0xFFF6F7FA),
                topMid = Color(0xFFDCE0E8),
                topShadow = Color(0xFF8F97A6),
                topAccent = Color(0xFFC9AE72),
                bottomLight = Color(0xFFEDEFF4),
                bottomMid = Color(0xFFCDD3DE),
                bottomShadow = Color(0xFF818A9A),
                headCoverLight = Color(0xFFFFFFFF),
                headCoverMid = Color(0xFFE2E6EE),
                headCoverShadow = Color(0xFF9BA3B2),
                shoeMain = skinMid,
                shoeSole = skinShadow
            )
        }

        FigureWardrobe.HALAL_ATHLETIC -> if (isFemale) {
            // Modest Halal Female Athletic Wear: Sport Hijab + Long Athletic Tunic + Full Track Pants
            ClothingMaterials(
                skinLight = skinLight,
                skinMid = skinMid,
                skinShadow = skinShadow,
                topLight = Color(0xFF565E6D),
                topMid = Color(0xFF39404C),
                topShadow = Color(0xFF1F242C),
                topAccent = Color(0xFFD9E0EA),
                bottomLight = Color(0xFF323741),
                bottomMid = Color(0xFF21252C),
                bottomShadow = Color(0xFF111419),
                headCoverLight = Color(0xFF454C59),
                headCoverMid = Color(0xFF2C313B),
                headCoverShadow = Color(0xFF171A20),
                shoeMain = Color(0xFFCFD6E0),
                shoeSole = Color(0xFFF2F5F9)
            )
        } else {
            // Modest Halal Male Athletic Wear: Performance Long/Fitted Top + Full Training Joggers (Covers knees/Awrah)
            ClothingMaterials(
                skinLight = skinLight,
                skinMid = skinMid,
                skinShadow = skinShadow,
                topLight = Color(0xFF4F5663),
                topMid = Color(0xFF323742),
                topShadow = Color(0xFF1A1E25),
                topAccent = Color(0xFFE2E8F0),
                bottomLight = Color(0xFF2D323C),
                bottomMid = Color(0xFF1D2128),
                bottomShadow = Color(0xFF0E1015),
                headCoverLight = Color(0xFF2E333D),
                headCoverMid = Color(0xFF1C2027),
                headCoverShadow = Color(0xFF0E1116),
                shoeMain = Color(0xFFD5DCE6),
                shoeSole = Color(0xFFF5F7FA)
            )
        }
    }
}

/**
 * Renders the complete next-gen 3D-shaded realistic human figure with studio lighting,
 * directional key + platinum rim shading, proper cloth physics/draping, and optional
 * active muscle focus or prayer rug environment.
 */
fun DrawScope.drawRealisticHumanFigure(
    pose: HumanRigPose,
    floorYNorm: Float,
    wardrobe: FigureWardrobe,
    isFemale: Boolean,
    palette: RuhZenaGlassPalette,
    activeMuscleZone: MuscleZone? = null,
    musclePulse: Float = 0.5f,
    showMuscleFocus: Boolean = false,
    showPrayerMat: Boolean = false,
    showWaterEffect: Boolean = false,
    animTimeSec: Float = 0f
) {
    val w = size.width
    val h = size.height
    val scale = min(w, h) / 260f
    val floorY = h * floorYNorm
    val mat = resolveMaterials(wardrobe, isFemale)

    fun pt(n: Offset): Offset = Offset(n.x * w, n.y * h)

    // 1. Cinematic Studio Stage Floor, Perspective Grid & Rim Backdrop Light
    drawStudioEnvironment(
        floorY = floorY,
        palette = palette,
        showPrayerMat = showPrayerMat,
        pose = pose
    )

    // 2. Grounded Ambient Occlusion & Contact Shadow
    val groundPointsX = listOf(
        pt(pose.nearFoot).x,
        pt(pose.farFoot).x,
        pt(pose.pelvis).x,
        if (pose.isProstrating) pt(pose.head).x else pt(pose.nearFoot).x
    )
    val shadowLeft = (groundPointsX.minOrNull() ?: (w * 0.4f)) - 22f * scale
    val shadowRight = (groundPointsX.maxOrNull() ?: (w * 0.6f)) + 22f * scale
    val shadowW = (shadowRight - shadowLeft).coerceAtLeast(56f * scale)
    val shadowCenterX = (shadowLeft + shadowRight) * 0.5f
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.Black.copy(alpha = if (palette.isLight) 0.28f else 0.62f),
                Color.Black.copy(alpha = if (palette.isLight) 0.12f else 0.28f),
                Color.Transparent
            ),
            center = Offset(shadowCenterX, floorY + 2f * scale),
            radius = shadowW * 0.62f
        ),
        topLeft = Offset(shadowCenterX - shadowW * 0.58f, floorY - 7f * scale),
        size = Size(shadowW * 1.16f, 18f * scale)
    )

    val headP = pt(pose.head)
    val neckP = pt(pose.neck)
    val chestP = pt(pose.chest)
    val waistP = pt(pose.waist)
    val pelvisP = pt(pose.pelvis)
    val nSh = pt(pose.nearShoulder)
    val nEl = pt(pose.nearElbow)
    val nWr = pt(pose.nearWrist)
    val nHa = pt(pose.nearHand)
    val fSh = pt(pose.farShoulder)
    val fEl = pt(pose.farElbow)
    val fWr = pt(pose.farWrist)
    val fHa = pt(pose.farHand)
    val nHip = pt(pose.nearHip)
    val nKn = pt(pose.nearKnee)
    val nAn = pt(pose.nearAnkle)
    val nFt = pt(pose.nearFoot)
    val fHip = pt(pose.farHip)
    val fKn = pt(pose.farKnee)
    val fAn = pt(pose.farAnkle)
    val fFt = pt(pose.farFoot)

    val shoulderW = (if (isFemale) 13.5f else 17.5f) * scale
    val waistW = (if (isFemale) 11.5f else 13.5f) * scale
    val hipW = (if (isFemale) 14.5f else 14.0f) * scale
    val thighTopR = (if (isFemale) 9.8f else 10.6f) * scale
    val thighBotR = (if (isFemale) 7.0f else 7.6f) * scale
    val calfTopR = (if (isFemale) 6.8f else 7.4f) * scale
    val calfBotR = (if (isFemale) 4.4f else 4.9f) * scale
    val upperArmTopR = (if (isFemale) 6.2f else 7.8f) * scale
    val upperArmBotR = (if (isFemale) 5.0f else 6.1f) * scale
    val foreArmTopR = (if (isFemale) 4.8f else 5.8f) * scale
    val foreArmBotR = (if (isFemale) 3.4f else 4.0f) * scale

    // Depth dimming factor for far-side limbs (gives real 3D parallax depth!)
    fun dimColor(c: Color, factor: Float = 0.76f): Color = Color(
        red = (c.red * factor).coerceIn(0f, 1f),
        green = (c.green * factor).coerceIn(0f, 1f),
        blue = (c.blue * factor).coerceIn(0f, 1f),
        alpha = c.alpha
    )

    // =========================================================================
    // LAYER A: FAR-SIDE ARM & LEG (Behind Torso — cooler depth shading)
    // =========================================================================
    // Far Leg
    drawSculptedSegment(
        start = fHip, end = fKn,
        rStart = thighTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.18f else 1.04f),
        rEnd = thighBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.16f else 1.02f),
        light = dimColor(mat.bottomLight),
        mid = dimColor(mat.bottomMid),
        shadow = dimColor(mat.bottomShadow),
        rimHighlight = false
    )
    drawSculptedSegment(
        start = fKn, end = fAn,
        rStart = calfTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.12f else 1.02f),
        rEnd = calfBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.05f else 1.0f),
        light = dimColor(mat.bottomLight),
        mid = dimColor(mat.bottomMid),
        shadow = dimColor(mat.bottomShadow),
        rimHighlight = false
    )
    drawFootOrShoe(
        ankle = fAn, foot = fFt, scale = scale,
        wardrobe = wardrobe, isFemale = isFemale,
        mat = mat, isFarSide = true
    )

    // Far Arm
    val farSleeveEnd = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) {
        lerpOffset(fSh, fEl, 0.72f)
    } else {
        fWr
    }
    drawSculptedSegment(
        start = fSh, end = fEl,
        rStart = upperArmTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.18f else 1.02f),
        rEnd = upperArmBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.14f else 1.0f),
        light = dimColor(mat.topLight),
        mid = dimColor(mat.topMid),
        shadow = dimColor(mat.topShadow),
        rimHighlight = false
    )
    val farForearmLight = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) dimColor(mat.skinLight) else dimColor(mat.topLight)
    val farForearmMid = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) dimColor(mat.skinMid) else dimColor(mat.topMid)
    val farForearmShadow = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) dimColor(mat.skinShadow) else dimColor(mat.topShadow)
    drawSculptedSegment(
        start = fEl, end = fWr,
        rStart = foreArmTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.15f else 1.0f),
        rEnd = foreArmBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.12f else 1.0f),
        light = farForearmLight,
        mid = farForearmMid,
        shadow = farForearmShadow,
        rimHighlight = false
    )
    if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) {
        drawSculptedSegment(
            start = fSh, end = farSleeveEnd,
            rStart = upperArmTopR * 1.06f,
            rEnd = upperArmBotR * 1.06f,
            light = dimColor(mat.topLight),
            mid = dimColor(mat.topMid),
            shadow = dimColor(mat.topShadow),
            rimHighlight = false
        )
    }
    drawHand(
        wrist = fWr, handTip = fHa, scale = scale,
        skinLight = dimColor(mat.skinLight),
        skinMid = dimColor(mat.skinMid),
        skinShadow = dimColor(mat.skinShadow),
        palmsOpenQibla = pose.palmsOpenQibla,
        indexFingerRaised = false
    )

    // =========================================================================
    // LAYER B: VOLUMETRIC TORSO, PRAYER THOBE/ABAYA DRAPE OR HALAL ATHLETIC TOP
    // =========================================================================
    drawSculptedTorsoAndGarment(
        neck = neckP,
        chest = chestP,
        waist = waistP,
        pelvis = pelvisP,
        nearKnee = nKn,
        nearAnkle = nAn,
        farAnkle = fAn,
        shoulderW = shoulderW,
        waistW = waistW,
        hipW = hipW,
        scale = scale,
        wardrobe = wardrobe,
        isFemale = isFemale,
        isSeatedOrKneeling = pose.isSeatedOrKneeling,
        isProstrating = pose.isProstrating,
        mat = mat
    )

    // =========================================================================
    // LAYER C: NECK & SCULPTED BLANK-FACE ANATOMICAL HEAD + HEADWEAR
    // =========================================================================
    drawNeckAndBlankHead(
        head = headP,
        neck = neckP,
        chest = chestP,
        scale = scale,
        wardrobe = wardrobe,
        isFemale = isFemale,
        headPitchDeg = pose.headPitchDeg,
        headYawDeg = pose.headYawDeg,
        mat = mat
    )

    // =========================================================================
    // LAYER D: NEAR-SIDE LEG (In front of lower garment where appropriate)
    // =========================================================================
    val drawVisibleNearLeg = wardrobe == FigureWardrobe.HALAL_ATHLETIC ||
        pose.isSeatedOrKneeling || pose.isProstrating || !isFemale

    if (drawVisibleNearLeg) {
        val legLight = if (wardrobe == FigureWardrobe.PRAYER) mat.bottomLight else mat.bottomLight
        val legMid = if (wardrobe == FigureWardrobe.PRAYER) mat.bottomMid else mat.bottomMid
        val legShadow = if (wardrobe == FigureWardrobe.PRAYER) mat.bottomShadow else mat.bottomShadow

        // Thigh (with realistic quadriceps fullness & hip crease shadow)
        drawSculptedSegment(
            start = nHip, end = nKn,
            rStart = thighTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.24f else 1.10f),
            rEnd = thighBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.18f else 1.05f),
            light = legLight,
            mid = legMid,
            shadow = legShadow,
            rimHighlight = true,
            muscleDefinition = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC) 0.9f else 0.25f
        )
        // Knee patella anatomical cap + posterior popliteal crease occlusion
        drawCircle(
            brush = Brush.radialGradient(
                listOf(legLight.copy(alpha = 0.82f), legMid, legShadow),
                center = nKn - Offset(1.8f * scale, 1.8f * scale),
                radius = thighBotR * 1.10f
            ),
            radius = thighBotR * 0.98f,
            center = nKn
        )
        drawArc(
            color = Color.Black.copy(alpha = 0.22f),
            startAngle = 115f,
            sweepAngle = 100f,
            useCenter = false,
            topLeft = Offset(nKn.x - thighBotR * 0.72f, nKn.y - thighBotR * 0.72f),
            size = Size(thighBotR * 1.44f, thighBotR * 1.44f),
            style = Stroke(width = 1.4f * scale, cap = StrokeCap.Round)
        )
        // Calf (gastrocnemius sweep tapering cleanly into Achilles & ankle malleolus)
        drawSculptedSegment(
            start = nKn, end = nAn,
            rStart = calfTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.15f else 1.08f),
            rEnd = calfBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.08f else 1.00f),
            light = legLight,
            mid = legMid,
            shadow = legShadow,
            rimHighlight = true,
            muscleDefinition = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC) 0.85f else 0.2f
        )
        // Crisp athletic side piping & tapered ankle cuff on performance joggers
        if (wardrobe == FigureWardrobe.HALAL_ATHLETIC) {
            drawLine(
                color = mat.topAccent.copy(alpha = 0.34f),
                start = nHip,
                end = nKn,
                strokeWidth = 1.6f * scale,
                cap = StrokeCap.Round
            )
            drawLine(
                color = mat.topAccent.copy(alpha = 0.28f),
                start = nKn,
                end = nAn,
                strokeWidth = 1.4f * scale,
                cap = StrokeCap.Round
            )
            // Ribbed athletic ankle cuff
            val cuffDir = unitDir(nKn, nAn)
            val cuffPerp = Offset(-cuffDir.y, cuffDir.x)
            drawLine(
                color = mat.bottomShadow,
                start = nAn - cuffPerp * (calfBotR * 1.04f),
                end = nAn + cuffPerp * (calfBotR * 1.04f),
                strokeWidth = 3.2f * scale,
                cap = StrokeCap.Round
            )
        }
    }

    drawFootOrShoe(
        ankle = nAn, foot = nFt, scale = scale,
        wardrobe = wardrobe, isFemale = isFemale,
        mat = mat, isFarSide = false
    )

    // =========================================================================
    // LAYER E: NEAR-SIDE ARM & HAND (Foreground Key-Lit Limb)
    // =========================================================================
    // Sculpted deltoid shoulder cap with subtle anterior/lateral ridge highlight
    val deltR = upperArmTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.20f else 1.14f)
    drawCircle(
        brush = Brush.radialGradient(
            listOf(mat.topLight, mat.topMid, mat.topShadow),
            center = nSh - Offset(2.8f * scale, 2.8f * scale),
            radius = deltR * 1.45f
        ),
        radius = deltR,
        center = nSh
    )
    if (wardrobe == FigureWardrobe.HALAL_ATHLETIC) {
        drawArc(
            color = Color.White.copy(alpha = 0.24f),
            startAngle = -145f,
            sweepAngle = 78f,
            useCenter = false,
            topLeft = Offset(nSh.x - deltR * 0.82f, nSh.y - deltR * 0.82f),
            size = Size(deltR * 1.64f, deltR * 1.64f),
            style = Stroke(width = 1.5f * scale, cap = StrokeCap.Round)
        )
    }
    // Upper arm (bicep / tricep separation shading)
    drawSculptedSegment(
        start = nSh, end = nEl,
        rStart = upperArmTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.22f else 1.08f),
        rEnd = upperArmBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.18f else 1.02f),
        light = mat.topLight,
        mid = mat.topMid,
        shadow = mat.topShadow,
        rimHighlight = true,
        muscleDefinition = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC) 0.95f else 0.25f
    )
    // Elbow crease ambient occlusion & sleeve cuff on athletic male short-sleeve
    val nearForearmLight = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) mat.skinLight else mat.topLight
    val nearForearmMid = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) mat.skinMid else mat.topMid
    val nearForearmShadow = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) mat.skinShadow else mat.topShadow
    if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) {
        val sleeveEnd = lerpOffset(nSh, nEl, 0.72f)
        val armDir = unitDir(nSh, nEl)
        val armPerp = Offset(-armDir.y, armDir.x)
        // Exposed lower bicep skin before sleeve edge
        drawSculptedSegment(
            start = sleeveEnd, end = nEl,
            rStart = upperArmBotR * 1.04f,
            rEnd = upperArmBotR * 0.96f,
            light = mat.skinLight,
            mid = mat.skinMid,
            shadow = mat.skinShadow,
            rimHighlight = true,
            muscleDefinition = 0.85f
        )
        // Crisp performance sleeve hem band
        drawLine(
            color = mat.topAccent.copy(alpha = 0.55f),
            start = sleeveEnd - armPerp * (upperArmBotR * 1.08f),
            end = sleeveEnd + armPerp * (upperArmBotR * 1.08f),
            strokeWidth = 2.0f * scale,
            cap = StrokeCap.Round
        )
    }
    // Forearm (brachioradialis taper to wrist bone)
    drawSculptedSegment(
        start = nEl, end = nWr,
        rStart = foreArmTopR * (if (wardrobe == FigureWardrobe.PRAYER) 1.16f else 1.04f),
        rEnd = foreArmBotR * (if (wardrobe == FigureWardrobe.PRAYER) 1.12f else 0.98f),
        light = nearForearmLight,
        mid = nearForearmMid,
        shadow = nearForearmShadow,
        rimHighlight = true,
        muscleDefinition = if (wardrobe == FigureWardrobe.HALAL_ATHLETIC && !isFemale) 0.9f else 0.25f
    )
    if (wardrobe == FigureWardrobe.PRAYER) {
        // Tailored embroidered sleeve cuff trim
        val cuffDir = unitDir(nEl, nWr)
        val perp = Offset(-cuffDir.y, cuffDir.x)
        drawLine(
            color = mat.topAccent.copy(alpha = 0.68f),
            start = nWr - perp * (foreArmBotR * 1.14f),
            end = nWr + perp * (foreArmBotR * 1.14f),
            strokeWidth = 2.0f * scale,
            cap = StrokeCap.Round
        )
    }
    drawHand(
        wrist = nWr, handTip = nHa, scale = scale,
        skinLight = mat.skinLight,
        skinMid = mat.skinMid,
        skinShadow = mat.skinShadow,
        palmsOpenQibla = pose.palmsOpenQibla,
        indexFingerRaised = pose.indexFingerRaised
    )

    // =========================================================================
    // LAYER F: ACTIVE MUSCLE FOCUS ILLUMINATION (WORKOUT MODE) OR WUDU WATER
    // =========================================================================
    if (showMuscleFocus && activeMuscleZone != null) {
        drawActiveMuscleOverlay(
            zone = activeMuscleZone,
            pulse = musclePulse,
            scale = scale,
            chest = chestP,
            waist = waistP,
            pelvis = pelvisP,
            shoulder = nSh,
            elbow = nEl,
            hip = nHip,
            knee = nKn,
            ankle = nAn,
            glowColor = palette.gold
        )
    }

    if (showWaterEffect && pose.waterFlowTarget != null) {
        drawWuduWaterDroplets(
            target = pt(pose.waterFlowTarget),
            scale = scale,
            animTimeSec = animTimeSec
        )
    }
}

private fun DrawScope.drawStudioEnvironment(
    floorY: Float,
    palette: RuhZenaGlassPalette,
    showPrayerMat: Boolean,
    pose: HumanRigPose
) {
    val w = size.width
    val h = size.height
    val scale = min(w, h) / 260f

    // Subtle overhead studio key-light cone (Brushed Silver atmosphere)
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                if (palette.isLight) Color.White.copy(alpha = 0.72f) else Color(0xFF3A404B).copy(alpha = 0.42f),
                Color.Transparent
            ),
            center = Offset(w * 0.38f, h * 0.14f),
            radius = max(w, h) * 0.72f
        ),
        size = size
    )

    // Floor surface plane
    drawRect(
        brush = Brush.verticalGradient(
            colors = if (palette.isLight) {
                listOf(Color(0xFFD5DAE2).copy(alpha = 0.55f), Color(0xFFC5CCD6).copy(alpha = 0.85f))
            } else {
                listOf(Color(0xFF191D24), Color(0xFF0C0E12))
            },
            startY = floorY,
            endY = h
        ),
        topLeft = Offset(0f, floorY),
        size = Size(w, (h - floorY).coerceAtLeast(0f))
    )

    // Floor horizon specular line
    drawLine(
        brush = Brush.horizontalGradient(
            listOf(Color.Transparent, palette.borderAccent.copy(alpha = 0.55f), Color.Transparent)
        ),
        start = Offset(w * 0.06f, floorY),
        end = Offset(w * 0.94f, floorY),
        strokeWidth = 1.2f * scale
    )

    // Perspective depth grid lines on studio floor
    for (i in 1..3) {
        val gy = floorY + (h - floorY) * (i / 4f)
        drawLine(
            color = palette.borderNeutral.copy(alpha = 0.16f),
            start = Offset(w * 0.08f, gy),
            end = Offset(w * 0.92f, gy),
            strokeWidth = 0.7f * scale
        )
    }

    if (showPrayerMat) {
        // Woven Janamaz Prayer Rug with geometric Mihrab arch border & woven fringes facing right (Qibla)
        val matLeft = w * 0.12f
        val matRight = w * 0.89f
        val matTop = floorY - 3.5f * scale
        val matBottom = floorY + 14.5f * scale
        val matMidY = (matTop + matBottom) * 0.5f
        val matPath = Path().apply {
            moveTo(matLeft + 15f * scale, matTop)
            lineTo(matRight - 15f * scale, matTop)
            lineTo(matRight, matBottom)
            lineTo(matLeft, matBottom)
            close()
        }
        drawPath(
            path = matPath,
            brush = Brush.horizontalGradient(
                listOf(Color(0xFF1F242D), Color(0xFF343C4A), Color(0xFF2B323F), Color(0xFF1F242D))
            )
        )
        // Outer metallic gold border + inner double weave border
        drawPath(
            path = matPath,
            color = palette.gold.copy(alpha = 0.78f),
            style = Stroke(width = 1.6f * scale)
        )
        val innerMatPath = Path().apply {
            moveTo(matLeft + 21f * scale, matTop + 2.5f * scale)
            lineTo(matRight - 21f * scale, matTop + 2.5f * scale)
            lineTo(matRight - 8f * scale, matBottom - 2.5f * scale)
            lineTo(matLeft + 8f * scale, matBottom - 2.5f * scale)
            close()
        }
        drawPath(
            path = innerMatPath,
            color = palette.gold.copy(alpha = 0.36f),
            style = Stroke(width = 0.9f * scale)
        )
        // Woven fringe tassels at left and right ends of the prayer rug
        for (i in 0..4) {
            val frac = i / 4f
            val ty = lerpFloat(matTop + 2f * scale, matBottom - 2f * scale, frac)
            val lx = lerpFloat(matLeft + 13f * scale, matLeft, frac)
            val rx = lerpFloat(matRight - 13f * scale, matRight, frac)
            drawLine(palette.gold.copy(alpha = 0.52f), Offset(lx - 5f * scale, ty), Offset(lx, ty), strokeWidth = 1.0f * scale, cap = StrokeCap.Round)
            drawLine(palette.gold.copy(alpha = 0.52f), Offset(rx, ty), Offset(rx + 5f * scale, ty), strokeWidth = 1.0f * scale, cap = StrokeCap.Round)
        }
        // Geometric Mihrab pointed arch pointing right (Qibla direction)
        val qx = matRight - 14f * scale
        val qArrow = Path().apply {
            moveTo(qx - 14f * scale, matMidY - 4.2f * scale)
            quadraticTo(qx - 4f * scale, matMidY - 3.2f * scale, qx + 3f * scale, matMidY)
            quadraticTo(qx - 4f * scale, matMidY + 3.2f * scale, qx - 14f * scale, matMidY + 4.2f * scale)
        }
        drawPath(qArrow, color = palette.gold.copy(alpha = 0.80f), style = Stroke(1.35f * scale, cap = StrokeCap.Round))
    }
}

private fun DrawScope.drawSculptedTorsoAndGarment(
    neck: Offset,
    chest: Offset,
    waist: Offset,
    pelvis: Offset,
    nearKnee: Offset,
    nearAnkle: Offset,
    farAnkle: Offset,
    shoulderW: Float,
    waistW: Float,
    hipW: Float,
    scale: Float,
    wardrobe: FigureWardrobe,
    isFemale: Boolean,
    isSeatedOrKneeling: Boolean,
    isProstrating: Boolean,
    mat: ClothingMaterials
) {
    val spineDir = unitDir(pelvis, neck)
    val perp = Offset(-spineDir.y, spineDir.x)

    // Anatomical torso polygon (broad upper chest tapering to waist and hips)
    val torsoPath = Path().apply {
        val sW = shoulderW * (if (wardrobe == FigureWardrobe.PRAYER && isFemale) 1.22f else 1.02f)
        val wW = waistW * (if (wardrobe == FigureWardrobe.PRAYER) 1.25f else if (isFemale) 1.15f else 0.96f)
        val hW = hipW * (if (wardrobe == FigureWardrobe.PRAYER) 1.38f else if (isFemale) 1.24f else 1.02f)

        val pNeckL = neck - perp * (sW * 0.42f)
        val pNeckR = neck + perp * (sW * 0.42f)
        val pChestL = chest - perp * (sW * 0.92f)
        val pChestR = chest + perp * (sW * 0.92f)
        val pWaistL = waist - perp * (wW * 0.88f)
        val pWaistR = waist + perp * (wW * 0.88f)
        val pHipL = pelvis - perp * (hW * 0.95f)
        val pHipR = pelvis + perp * (hW * 0.95f)

        moveTo(pNeckL.x, pNeckL.y)
        cubicTo(pChestL.x, pChestL.y, pWaistL.x, pWaistL.y, pHipL.x, pHipL.y)
        lineTo(pHipR.x, pHipR.y)
        cubicTo(pWaistR.x, pWaistR.y, pChestR.x, pChestR.y, pNeckR.x, pNeckR.y)
        close()
    }

    drawPath(
        path = torsoPath,
        brush = Brush.linearGradient(
            colors = listOf(mat.topLight, mat.topMid, mat.topShadow),
            start = chest - perp * shoulderW,
            end = pelvis + perp * hipW
        )
    )
    // Crisp specular edge rim along front/top of torso
    drawPath(
        path = torsoPath,
        color = mat.topLight.copy(alpha = 0.42f),
        style = Stroke(width = 1.1f * scale, join = StrokeJoin.Round)
    )

    if (wardrobe == FigureWardrobe.PRAYER) {
        // Dynamic Flowing Thobe / Abaya Skirt Drape
        if (!isSeatedOrKneeling && !isProstrating) {
            val hemMid = lerpOffset(nearAnkle, farAnkle, 0.45f)
            val hemTopY = if (isFemale) hemMid.y + 4f * scale else hemMid.y - 10f * scale
            val hemCenter = Offset(lerpFloat(pelvis.x, hemMid.x, 0.7f), hemTopY)
            val hemHalfW = if (isFemale) hipW * 1.75f else hipW * 1.48f
            val skirtPath = Path().apply {
                val pHipL = pelvis - perp * (hipW * 1.15f)
                val pHipR = pelvis + perp * (hipW * 1.15f)
                moveTo(pHipL.x, pHipL.y)
                quadraticTo(
                    lerpFloat(pHipL.x, hemCenter.x - hemHalfW, 0.55f),
                    lerpFloat(pHipL.y, hemCenter.y, 0.55f),
                    hemCenter.x - hemHalfW,
                    hemCenter.y
                )
                quadraticTo(
                    hemCenter.x,
                    hemCenter.y + 4f * scale,
                    hemCenter.x + hemHalfW,
                    hemCenter.y
                )
                quadraticTo(
                    lerpFloat(pHipR.x, hemCenter.x + hemHalfW, 0.55f),
                    lerpFloat(pHipR.y, hemCenter.y, 0.55f),
                    pHipR.x,
                    pHipR.y
                )
                close()
            }
            drawPath(
                path = skirtPath,
                brush = Brush.linearGradient(
                    colors = listOf(mat.topLight, mat.topMid, mat.topShadow),
                    start = Offset(hemCenter.x - hemHalfW, pelvis.y),
                    end = Offset(hemCenter.x + hemHalfW, hemCenter.y)
                )
            )
            // Realistic vertical cloth fold highlights
            for (fold in listOf(-0.42f, 0.05f, 0.45f)) {
                drawLine(
                    color = mat.topShadow.copy(alpha = 0.28f),
                    start = pelvis + perp * (hipW * fold),
                    end = Offset(hemCenter.x + hemHalfW * fold, hemCenter.y - 2f * scale),
                    strokeWidth = 1.2f * scale,
                    cap = StrokeCap.Round
                )
            }
            // Gold-silver embroidered hem trim
            drawLine(
                color = mat.topAccent.copy(alpha = 0.48f),
                start = Offset(hemCenter.x - hemHalfW * 0.92f, hemCenter.y - 2f * scale),
                end = Offset(hemCenter.x + hemHalfW * 0.92f, hemCenter.y - 2f * scale),
                strokeWidth = 1.5f * scale,
                cap = StrokeCap.Round
            )
        } else if (isSeatedOrKneeling) {
            // Seated robe drape smoothly covering thighs and lap
            val lapPath = Path().apply {
                moveTo(pelvis.x - hipW * 1.1f, pelvis.y - 4f * scale)
                quadraticTo(
                    lerpFloat(pelvis.x, nearKnee.x, 0.5f),
                    min(pelvis.y, nearKnee.y) - 10f * scale,
                    nearKnee.x + 8f * scale,
                    nearKnee.y + 4f * scale
                )
                lineTo(nearAnkle.x + 6f * scale, nearAnkle.y + 5f * scale)
                lineTo(pelvis.x - hipW * 1.0f, nearAnkle.y + 4f * scale)
                close()
            }
            drawPath(
                path = lapPath,
                brush = Brush.verticalGradient(
                    listOf(mat.topLight, mat.topMid, mat.topShadow),
                    startY = min(pelvis.y, nearKnee.y) - 10f * scale,
                    endY = nearAnkle.y + 6f * scale
                )
            )
        }

        // Thobe stand-collar & buttoned placket (Male) or Layered Khimar drape with fold highlights (Female)
        if (!isFemale) {
            val collarStart = neck - perp * (shoulderW * 0.34f)
            val collarEnd = neck + perp * (shoulderW * 0.34f)
            drawLine(
                color = mat.topAccent.copy(alpha = 0.82f),
                start = collarStart,
                end = collarEnd,
                strokeWidth = 2.6f * scale,
                cap = StrokeCap.Round
            )
            val placketEnd = lerpOffset(neck, waist, 0.56f)
            drawLine(
                color = mat.topAccent.copy(alpha = 0.78f),
                start = neck,
                end = placketEnd,
                strokeWidth = 2.2f * scale,
                cap = StrokeCap.Round
            )
            // Subtle tailored placket buttons
            for (b in listOf(0.28f, 0.56f, 0.84f)) {
                drawCircle(
                    color = mat.topLight,
                    radius = 1.2f * scale,
                    center = lerpOffset(neck, placketEnd, b)
                )
            }
        } else {
            // Graceful flowing Khimar cape draping from neck over chest/shoulders with layered pleats
            val khimarPath = Path().apply {
                moveTo(neck.x - shoulderW * 0.68f, neck.y)
                quadraticTo(chest.x - shoulderW * 1.28f, chest.y + 6f * scale, waist.x - waistW * 1.24f, waist.y + 10f * scale)
                quadraticTo(waist.x, waist.y + 18f * scale, waist.x + waistW * 1.28f, waist.y + 8f * scale)
                quadraticTo(chest.x + shoulderW * 1.22f, chest.y + 4f * scale, neck.x + shoulderW * 0.68f, neck.y)
                close()
            }
            drawPath(
                path = khimarPath,
                brush = Brush.verticalGradient(
                    listOf(mat.headCoverLight, mat.headCoverMid, mat.headCoverShadow),
                    startY = neck.y,
                    endY = waist.y + 18f * scale
                )
            )
            for (f in listOf(-0.36f, 0.08f, 0.42f)) {
                drawLine(
                    color = mat.headCoverShadow.copy(alpha = 0.32f),
                    start = Offset(neck.x + shoulderW * f * 0.45f, neck.y + 3f * scale),
                    end = Offset(waist.x + waistW * f * 0.95f, waist.y + 12f * scale),
                    strokeWidth = 1.2f * scale,
                    cap = StrokeCap.Round
                )
            }
            drawPath(
                path = khimarPath,
                color = mat.topAccent.copy(alpha = 0.42f),
                style = Stroke(width = 1.1f * scale)
            )
        }
    } else {
        // ATHLETIC WARDROBE: Raglan seams, sculpted pectoral/core contour shading & modest tunic hem
        if (isFemale) {
            // Modest extended athletic tunic skirt covering hips cleanly
            val tunicBottom = pelvis - spineDir * (14f * scale)
            val tunicPath = Path().apply {
                val pWaistL = waist - perp * (waistW * 1.06f)
                val pWaistR = waist + perp * (waistW * 1.06f)
                val pBotL = tunicBottom - perp * (hipW * 1.30f)
                val pBotR = tunicBottom + perp * (hipW * 1.30f)
                moveTo(pWaistL.x, pWaistL.y)
                lineTo(pBotL.x, pBotL.y)
                quadraticTo(tunicBottom.x, tunicBottom.y + 3.5f * scale, pBotR.x, pBotR.y)
                lineTo(pWaistR.x, pWaistR.y)
                close()
            }
            drawPath(
                path = tunicPath,
                brush = Brush.linearGradient(
                    listOf(mat.topLight, mat.topMid, mat.topShadow),
                    start = waist - perp * waistW,
                    end = tunicBottom + perp * hipW
                )
            )
            drawLine(
                color = mat.topAccent.copy(alpha = 0.36f),
                start = tunicBottom - perp * (hipW * 1.22f),
                end = tunicBottom + perp * (hipW * 1.22f),
                strokeWidth = 1.4f * scale,
                cap = StrokeCap.Round
            )
        } else {
            // Sculpted pectoral, clavicle & core contour shading under athletic performance top
            drawOval(
                brush = Brush.radialGradient(
                    listOf(mat.topLight.copy(alpha = 0.34f), Color.Transparent),
                    center = chest - perp * (shoulderW * 0.16f),
                    radius = shoulderW * 0.72f
                ),
                topLeft = Offset(chest.x - shoulderW * 0.68f, chest.y - 5f * scale),
                size = Size(shoulderW * 1.36f, 12f * scale)
            )
            // Subtle oblique & core contour lines
            val absTop = lerpOffset(chest, waist, 0.35f)
            val absBot = lerpOffset(waist, pelvis, 0.65f)
            drawLine(
                color = mat.topShadow.copy(alpha = 0.36f),
                start = absTop,
                end = absBot,
                strokeWidth = 1.3f * scale,
                cap = StrokeCap.Round
            )
            // Raglan performance side piping
            drawLine(
                color = mat.topAccent.copy(alpha = 0.42f),
                start = chest + perp * (shoulderW * 0.66f),
                end = pelvis + perp * (hipW * 0.74f),
                strokeWidth = 1.5f * scale,
                cap = StrokeCap.Round
            )
        }
        // Athletic collar & taped waistband seam
        drawLine(
            color = mat.topAccent.copy(alpha = 0.44f),
            start = neck - perp * (shoulderW * 0.36f),
            end = neck + perp * (shoulderW * 0.36f),
            strokeWidth = 1.8f * scale,
            cap = StrokeCap.Round
        )
        drawLine(
            color = mat.topAccent.copy(alpha = 0.42f),
            start = pelvis - perp * (hipW * 0.94f),
            end = pelvis + perp * (hipW * 0.94f),
            strokeWidth = 2.2f * scale,
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawNeckAndBlankHead(
    head: Offset,
    neck: Offset,
    chest: Offset,
    scale: Float,
    wardrobe: FigureWardrobe,
    isFemale: Boolean,
    headPitchDeg: Float,
    headYawDeg: Float,
    mat: ClothingMaterials
) {
    // Sculpted neck column
    val neckColorLight = if (isFemale) mat.headCoverLight else mat.skinLight
    val neckColorMid = if (isFemale) mat.headCoverMid else mat.skinMid
    val neckColorShadow = if (isFemale) mat.headCoverShadow else mat.skinShadow
    drawSculptedSegment(
        start = neck,
        end = lerpOffset(neck, head, 0.72f),
        rStart = 5.4f * scale,
        rEnd = 4.6f * scale,
        light = neckColorLight,
        mid = neckColorMid,
        shadow = neckColorShadow,
        rimHighlight = false
    )

    val headR = (if (isFemale) 11.4f else 12.2f) * scale
    val yawShift = (headYawDeg / 55f).coerceIn(-1f, 1f) * 3.8f * scale
    val pitchShift = (headPitchDeg / 45f).coerceIn(-1f, 1f) * 2.5f * scale

    // Sculpted Blank Matte Head (GTA/studio mannequin precision — ZERO cartoon face!)
    val headCenter = Offset(head.x + yawShift * 0.35f, head.y + pitchShift * 0.25f)

    if (isFemale) {
        // Modest Hijab / Sport Hijab outer volume framing the sculpted blank head
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(mat.headCoverLight, mat.headCoverMid, mat.headCoverShadow),
                center = headCenter - Offset(3.5f * scale, 4f * scale),
                radius = headR * 1.48f
            ),
            radius = headR * 1.24f,
            center = Offset(headCenter.x - 1.5f * scale, headCenter.y - 0.5f * scale)
        )
        // Draped hijab wrap covering neck and chin cleanly
        val wrapPath = Path().apply {
            moveTo(headCenter.x - headR * 1.15f, headCenter.y + headR * 0.1f)
            quadraticTo(headCenter.x - headR * 0.9f, neck.y + 8f * scale, chest.x - 10f * scale, chest.y + 4f * scale)
            lineTo(chest.x + 12f * scale, chest.y + 4f * scale)
            quadraticTo(headCenter.x + headR * 0.85f, neck.y + 6f * scale, headCenter.x + headR * 0.95f, headCenter.y + headR * 0.35f)
            close()
        }
        drawPath(
            path = wrapPath,
            brush = Brush.verticalGradient(
                listOf(mat.headCoverMid, mat.headCoverShadow),
                startY = headCenter.y,
                endY = chest.y + 6f * scale
            )
        )
        // Clean blank face oval subtly shifted with headYawDeg (shows Taslim head turn clearly!)
        val faceCenter = Offset(headCenter.x + 3.2f * scale + yawShift, headCenter.y + 1.2f * scale + pitchShift * 0.4f)
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(mat.skinLight, mat.skinMid, mat.skinShadow),
                center = faceCenter - Offset(2f * scale, 2f * scale),
                radius = headR * 0.88f
            ),
            topLeft = Offset(faceCenter.x - headR * 0.62f, faceCenter.y - headR * 0.74f),
            size = Size(headR * 1.24f, headR * 1.44f)
        )
        // Subtle specular forehead rim to convey 3D curvature without adding any face features
        drawArc(
            color = Color.White.copy(alpha = 0.25f),
            startAngle = -140f,
            sweepAngle = 70f,
            useCenter = false,
            topLeft = Offset(faceCenter.x - headR * 0.56f, faceCenter.y - headR * 0.68f),
            size = Size(headR * 1.12f, headR * 1.24f),
            style = Stroke(width = 1.2f * scale, cap = StrokeCap.Round)
        )
    } else {
        // Male Sculpted Blank Head (anatomical jawline + cranium volume + subtle rim light)
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(mat.skinLight, mat.skinMid, mat.skinShadow),
                center = headCenter - Offset(3.2f * scale - yawShift * 0.5f, 3.8f * scale),
                radius = headR * 1.35f
            ),
            topLeft = Offset(headCenter.x - headR * 0.86f, headCenter.y - headR * 0.96f),
            size = Size(headR * 1.72f, headR * 1.98f)
        )
        // Directional 3D plane shading showing head orientation (especially clear during Taslim right/left turns)
        val turnBandX = headCenter.x + yawShift * 1.05f
        drawOval(
            color = Color.White.copy(alpha = 0.16f),
            topLeft = Offset(turnBandX - headR * 0.34f, headCenter.y - headR * 0.52f + pitchShift * 0.3f),
            size = Size(headR * 0.68f, headR * 0.92f)
        )
        if (wardrobe == FigureWardrobe.PRAYER) {
            // Crisp White Kufi / Taqiyah Prayer Cap
            val kufiPath = Path().apply {
                moveTo(headCenter.x - headR * 0.92f, headCenter.y - headR * 0.22f)
                quadraticTo(
                    headCenter.x,
                    headCenter.y - headR * 1.28f,
                    headCenter.x + headR * 0.92f,
                    headCenter.y - headR * 0.22f
                )
                quadraticTo(
                    headCenter.x,
                    headCenter.y - headR * 0.42f,
                    headCenter.x - headR * 0.92f,
                    headCenter.y - headR * 0.22f
                )
                close()
            }
            drawPath(
                path = kufiPath,
                brush = Brush.linearGradient(
                    listOf(mat.headCoverLight, mat.headCoverMid, mat.headCoverShadow),
                    start = Offset(headCenter.x - headR, headCenter.y - headR),
                    end = Offset(headCenter.x + headR, headCenter.y)
                )
            )
            drawPath(
                path = kufiPath,
                color = mat.topAccent.copy(alpha = 0.55f),
                style = Stroke(width = 1.0f * scale)
            )
        } else {
            // Clean sculpted athletic short-hair silhouette cap (dark charcoal, zero facial features)
            val hairPath = Path().apply {
                moveTo(headCenter.x - headR * 0.9f, headCenter.y - headR * 0.12f)
                quadraticTo(
                    headCenter.x - headR * 0.1f,
                    headCenter.y - headR * 1.24f,
                    headCenter.x + headR * 0.84f,
                    headCenter.y - headR * 0.38f
                )
                quadraticTo(
                    headCenter.x - headR * 0.2f,
                    headCenter.y - headR * 0.55f,
                    headCenter.x - headR * 0.9f,
                    headCenter.y - headR * 0.12f
                )
                close()
            }
            drawPath(
                path = hairPath,
                brush = Brush.linearGradient(
                    listOf(mat.headCoverLight, mat.headCoverMid, mat.headCoverShadow),
                    start = Offset(headCenter.x - headR, headCenter.y - headR),
                    end = Offset(headCenter.x + headR, headCenter.y)
                )
            )
        }
    }
}

private fun DrawScope.drawSculptedSegment(
    start: Offset,
    end: Offset,
    rStart: Float,
    rEnd: Float,
    light: Color,
    mid: Color,
    shadow: Color,
    rimHighlight: Boolean,
    muscleDefinition: Float = 0.35f
) {
    val dx = end.x - start.x
    val dy = end.y - start.y
    val len = hypot(dx, dy)
    if (len < 0.5f) {
        drawCircle(color = mid, radius = (rStart + rEnd) * 0.5f, center = start)
        return
    }
    val nx = -dy / len
    val ny = dx / len
    val perp = Offset(nx, ny)
    val midPt = Offset((start.x + end.x) * 0.5f, (start.y + end.y) * 0.5f)
    // Natural anatomical belly curve fuller at 36% along limb (bicep/quad/calf bulge)
    val bellyPt = Offset(start.x + dx * 0.36f, start.y + dy * 0.36f)
    val bellyFactor = 1.07f + muscleDefinition * 0.06f
    val bellyR = (rStart * 0.64f + rEnd * 0.36f) * bellyFactor

    val sL = start - perp * rStart
    val sR = start + perp * rStart
    val bL = bellyPt - perp * bellyR
    val bR = bellyPt + perp * bellyR
    val eL = end - perp * rEnd
    val eR = end + perp * rEnd

    val limbPath = Path().apply {
        moveTo(sL.x, sL.y)
        quadraticTo(bL.x, bL.y, eL.x, eL.y)
        lineTo(eR.x, eR.y)
        quadraticTo(bR.x, bR.y, sR.x, sR.y)
        close()
    }

    // 4-stop studio cylindrical volumetric gradient (specular key -> mid -> core shadow -> soft bounce)
    val bounceLight = Color(
        red = (mid.red * 0.72f + shadow.red * 0.28f).coerceIn(0f, 1f),
        green = (mid.green * 0.72f + shadow.green * 0.28f).coerceIn(0f, 1f),
        blue = (mid.blue * 0.72f + shadow.blue * 0.28f).coerceIn(0f, 1f),
        alpha = mid.alpha
    )
    drawPath(
        path = limbPath,
        brush = Brush.linearGradient(
            colors = listOf(light, mid, shadow, bounceLight),
            start = midPt - perp * max(rStart, rEnd),
            end = midPt + perp * max(rStart, rEnd)
        )
    )
    // Subtle anatomical muscle separation groove along muscular athletic limbs
    if (muscleDefinition > 0.55f && len > 12f) {
        drawLine(
            color = shadow.copy(alpha = 0.24f * muscleDefinition),
            start = Offset(start.x + dx * 0.22f, start.y + dy * 0.22f) + perp * (rStart * 0.14f),
            end = Offset(start.x + dx * 0.76f, start.y + dy * 0.76f) + perp * (rEnd * 0.16f),
            strokeWidth = max(1.0f, rEnd * 0.20f),
            cap = StrokeCap.Round
        )
    }
    // Round joint caps so elbows/knees bend organically without pinching
    drawCircle(
        brush = Brush.radialGradient(
            listOf(light, mid, shadow),
            center = start - perp * (rStart * 0.3f),
            radius = rStart * 1.2f
        ),
        radius = rStart * 0.96f,
        center = start
    )
    drawCircle(
        brush = Brush.radialGradient(
            listOf(light, mid, shadow),
            center = end - perp * (rEnd * 0.3f),
            radius = rEnd * 1.2f
        ),
        radius = rEnd * 0.96f,
        center = end
    )
    if (rimHighlight) {
        drawLine(
            color = Color.White.copy(alpha = 0.26f),
            start = start - perp * (rStart * 0.72f),
            end = end - perp * (rEnd * 0.72f),
            strokeWidth = max(1.1f, rEnd * 0.24f),
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawHand(
    wrist: Offset,
    handTip: Offset,
    scale: Float,
    skinLight: Color,
    skinMid: Color,
    skinShadow: Color,
    palmsOpenQibla: Boolean,
    indexFingerRaised: Boolean
) {
    val dir = unitDir(wrist, handTip)
    val perp = Offset(-dir.y, dir.x)
    val palmR = 3.9f * scale

    // Sculpted metacarpal palm body
    drawSculptedSegment(
        start = wrist,
        end = handTip,
        rStart = palmR * 0.82f,
        rEnd = palmR * 0.88f,
        light = skinLight,
        mid = skinMid,
        shadow = skinShadow,
        rimHighlight = true,
        muscleDefinition = 0.2f
    )

    // Anatomical thumb opposition joint
    val thumbBase = lerpOffset(wrist, handTip, 0.42f) - perp * (palmR * 0.75f)
    val thumbTip = thumbBase + (dir * 0.65f - perp * 0.62f) * (4.4f * scale)
    drawLine(
        color = skinLight,
        start = thumbBase,
        end = thumbTip,
        strokeWidth = 1.9f * scale,
        cap = StrokeCap.Round
    )

    when {
        palmsOpenQibla -> {
            // 4 cleanly articulated open fingers facing Qibla during Takbiratul Ihram
            val lengths = listOf(4.6f, 5.4f, 5.0f, 4.1f)
            val offsets = listOf(-2.4f, -0.8f, 0.8f, 2.3f)
            for (i in 0..3) {
                val fBase = handTip + perp * (offsets[i] * scale)
                val fTip = fBase + dir * (lengths[i] * scale)
                drawLine(
                    color = if (i < 2) skinLight else skinMid,
                    start = fBase,
                    end = fTip,
                    strokeWidth = 1.55f * scale,
                    cap = StrokeCap.Round
                )
            }
        }
        indexFingerRaised -> {
            // Curled middle/ring/pinky fingers + distinct raised right index finger for Tashahhud Shahadah
            for (i in listOf(0.5f, 1.5f, 2.4f)) {
                val curlBase = handTip + perp * (i * scale)
                drawCircle(
                    color = skinShadow,
                    radius = 1.15f * scale,
                    center = curlBase + dir * (1.2f * scale)
                )
            }
            val fingerStart = handTip - perp * (1.1f * scale)
            val fingerEnd = Offset(fingerStart.x + 8.0f * scale, fingerStart.y - 5.6f * scale)
            drawLine(
                color = skinLight,
                start = fingerStart,
                end = fingerEnd,
                strokeWidth = 2.2f * scale,
                cap = StrokeCap.Round
            )
            // Subtle luminous focus indicator around raised Shahadah finger
            drawCircle(
                color = Color(0xFFE3C485).copy(alpha = 0.50f),
                radius = 5.5f * scale,
                center = fingerEnd,
                style = Stroke(width = 1.2f * scale)
            )
        }
        else -> {
            // Relaxed natural 4-finger silhouette contour
            val lengths = listOf(3.6f, 4.1f, 3.8f, 3.1f)
            val offsets = listOf(-2.1f, -0.7f, 0.7f, 2.0f)
            for (i in 0..3) {
                val fBase = handTip + perp * (offsets[i] * scale)
                val fTip = fBase + dir * (lengths[i] * scale)
                drawLine(
                    color = if (i == 0) skinLight else skinMid,
                    start = fBase,
                    end = fTip,
                    strokeWidth = 1.45f * scale,
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

private fun DrawScope.drawFootOrShoe(
    ankle: Offset,
    foot: Offset,
    scale: Float,
    wardrobe: FigureWardrobe,
    isFemale: Boolean,
    mat: ClothingMaterials,
    isFarSide: Boolean
) {
    val factor = if (isFarSide) 0.76f else 1f
    fun c(col: Color) = Color(col.red * factor, col.green * factor, col.blue * factor, col.alpha)
    val dir = unitDir(ankle, foot)
    val perp = Offset(-dir.y, dir.x)

    if (wardrobe == FigureWardrobe.PRAYER) {
        // Modest prayer feet: Female feet covered smoothly by prayer garment/socks; Male anatomical barefoot
        val mainC = if (isFemale) c(mat.bottomMid) else c(mat.skinMid)
        val lightC = if (isFemale) c(mat.bottomLight) else c(mat.skinLight)
        val shadowC = if (isFemale) c(mat.bottomShadow) else c(mat.skinShadow)
        // Contoured heel + instep arch + forefoot
        val heel = ankle - dir * (2.6f * scale) + Offset(0f, 1.5f * scale)
        drawSculptedSegment(
            start = heel,
            end = foot,
            rStart = 4.3f * scale,
            rEnd = 3.2f * scale,
            light = lightC,
            mid = mainC,
            shadow = shadowC,
            rimHighlight = !isFarSide,
            muscleDefinition = 0.2f
        )
        if (!isFemale && !isFarSide) {
            // Subtle ankle malleolus & toe contour on male barefoot prayer foot
            drawCircle(
                color = lightC.copy(alpha = 0.55f),
                radius = 1.8f * scale,
                center = ankle - Offset(0.5f * scale, 0.5f * scale)
            )
        }
    } else {
        // Sculpted Multi-Panel Athletic Training Sneaker (heel counter + mesh upper + laces + contoured midsole)
        val heel = ankle - dir * (3.2f * scale) + Offset(0f, 1.4f * scale)
        val soleY = max(ankle.y, foot.y) + 2.6f * scale
        drawSculptedSegment(
            start = heel,
            end = foot + dir * (1.8f * scale),
            rStart = 5.0f * scale,
            rEnd = 3.9f * scale,
            light = c(mat.shoeMain),
            mid = c(mat.bottomMid),
            shadow = c(mat.bottomShadow),
            rimHighlight = !isFarSide,
            muscleDefinition = 0.15f
        )
        // Heel counter panel accent
        drawCircle(
            color = c(mat.topShadow),
            radius = 3.6f * scale,
            center = heel + Offset(0f, 0.6f * scale)
        )
        // Subtle athletic micro-laces across vamp
        if (!isFarSide) {
            for (f in listOf(0.35f, 0.52f, 0.68f)) {
                val lp = lerpOffset(ankle, foot, f) - perp * (2.2f * scale)
                drawLine(
                    color = c(mat.shoeSole).copy(alpha = 0.85f),
                    start = lp - dir * (0.9f * scale),
                    end = lp + dir * (0.9f * scale),
                    strokeWidth = 1.0f * scale,
                    cap = StrokeCap.Round
                )
            }
        }
        // Sculpted two-tone athletic midsole & dark rubber outsole tread
        drawLine(
            color = c(mat.shoeSole),
            start = Offset(heel.x - 1.5f * scale, soleY),
            end = Offset(foot.x + 3.2f * scale, soleY),
            strokeWidth = 2.8f * scale,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF14181F).copy(alpha = if (isFarSide) 0.55f else 0.85f),
            start = Offset(heel.x - 1.2f * scale, soleY + 1.5f * scale),
            end = Offset(foot.x + 3.0f * scale, soleY + 1.5f * scale),
            strokeWidth = 1.2f * scale,
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawActiveMuscleOverlay(
    zone: MuscleZone,
    pulse: Float,
    scale: Float,
    chest: Offset,
    waist: Offset,
    pelvis: Offset,
    shoulder: Offset,
    elbow: Offset,
    hip: Offset,
    knee: Offset,
    ankle: Offset,
    glowColor: Color
) {
    val alpha = 0.22f + 0.24f * pulse
    val targets = when (zone) {
        MuscleZone.CHEST_ARMS -> listOf(chest to 18f * scale, shoulder to 13f * scale, lerpOffset(shoulder, elbow, 0.5f) to 11f * scale)
        MuscleZone.CORE -> listOf(waist to 20f * scale, lerpOffset(chest, pelvis, 0.5f) to 18f * scale)
        MuscleZone.LEGS_GLUTES -> listOf(pelvis to 17f * scale, lerpOffset(hip, knee, 0.45f) to 16f * scale, lerpOffset(knee, ankle, 0.4f) to 11f * scale)
        MuscleZone.SPINE_BACK -> listOf(chest to 17f * scale, waist to 16f * scale, pelvis to 15f * scale)
        MuscleZone.FULL_BODY -> listOf(chest to 16f * scale, waist to 15f * scale, lerpOffset(hip, knee, 0.45f) to 15f * scale)
    }
    targets.forEach { (center, radius) ->
        drawCircle(
            brush = Brush.radialGradient(
                listOf(glowColor.copy(alpha = alpha), glowColor.copy(alpha = alpha * 0.25f), Color.Transparent),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )
    }
}

private fun DrawScope.drawWuduWaterDroplets(
    target: Offset,
    scale: Float,
    animTimeSec: Float
) {
    val waterColor = Color(0xFFA7D8F5)
    for (i in 0..5) {
        val phase = (animTimeSec * 1.9f + i * 0.17f) % 1f
        val xOff = sin((i * 1.4f + animTimeSec * 3f).toDouble()).toFloat() * 7f * scale
        val yStart = target.y - 24f * scale
        val yCur = yStart + phase * 34f * scale
        val dropAlpha = (1f - phase).coerceIn(0.15f, 0.85f)
        drawCircle(
            color = waterColor.copy(alpha = dropAlpha),
            radius = (2.0f + (1f - phase) * 1.4f) * scale,
            center = Offset(target.x + xOff, yCur)
        )
    }
}

fun unitDir(from: Offset, to: Offset): Offset {
    val dx = to.x - from.x
    val dy = to.y - from.y
    val len = hypot(dx, dy).coerceAtLeast(0.001f)
    return Offset(dx / len, dy / len)
}
