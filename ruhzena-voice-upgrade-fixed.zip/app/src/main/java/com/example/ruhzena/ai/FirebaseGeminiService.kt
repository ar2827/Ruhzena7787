package com.example.ruhzena.ai

import android.graphics.Bitmap
import android.util.Log
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.islamic.AyahExplanation
import com.example.ruhzena.data.islamic.QuranAyah
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.local.MealLogEntity
import com.example.ruhzena.data.local.UserPreferences
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.roundToInt

data class MealPhotoAnalysis(
    val dishName: String,
    val detectedItems: List<String>,
    val calories: Int,
    val proteinGrams: Int,
    val carbsGrams: Int,
    val fatGrams: Int,
    val healthVerdict: String, // GOOD_CHOICE, MODERATE, LIMIT
    val recommendationReason: String,
    val improvementTip: String
)

data class ParsedChatSections(
    val mainReply: String,
    val explanation: String,
    val citedSources: List<String>,
    val topic: String,
    val actionTags: List<String> = emptyList()
)

object FirebaseGeminiService {
    private const val TAG = "FirebaseGeminiService"
    private const val MODEL_ID = "gemini-3.8-flash"
    private val VALID_ACTION_TAGS = setOf("QIBLA", "ADHKAR", "HABIT_RECOVERY", "BREATHING", "MY_DAY")

    private val islamicChatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_ID,
            systemInstruction = content {
                text(
                    """
                    You are RuhZena AI (Knowledge & Solver Mode), a warm, empathetic, deeply knowledgeable Islamic & life companion.
                    Never mention underlying model names or technical platforms; your identity is exclusively RuhZena AI.
                    Understand the user's intent naturally—even casual, emotional, multi-part, or follow-up questions in any language.
                    CRITICAL ACCURACY RULES:
                    1. Never invent, guess, or fabricate Quran Surah:Ayah numbers, Hadith numbers, or narrator grades. Only cite exact references you are completely certain of.
                    2. If a matter has recognized scholarly differences (Ikhtilaf across Hanafi, Shafi'i, Maliki, Hanbali, etc.), present them fairly and gently advise consulting a qualified local scholar for personal fatwas.
                    3. Always structure your response cleanly using these exact headings:
                    [Conversational, warm, direct answer addressing the user's exact question clearly and kindly]

                    ### Explanation
                    [Deeper context, wisdom, historical/tafsir background, and practical everyday steps]

                    ### Sources
                    - [Source Title & Reference] (https://quran.com/... or https://sunnah.com/... or verified scholarly link)

                    4. Optionally, ONLY when directly helpful to the user's question, add at most 1 or 2 action tags on the final line from this exact set:
                    [[ACTION:QIBLA]] [[ACTION:ADHKAR]] [[ACTION:HABIT_RECOVERY]] [[ACTION:BREATHING]] [[ACTION:MY_DAY]]
                    """.trimIndent()
                )
            }
        )
    }

    private val wellnessChatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_ID,
            systemInstruction = content {
                text(
                    """
                    You are RuhZena AI (Life & Companion Mode), a warm, empathetic personal wellness, discipline, mindset, fitness, hydration, and nutrition companion.
                    Never mention underlying model names or technical platforms; your identity is exclusively RuhZena AI.
                    Listen with genuine care and adapt guidance to the live user telemetry provided (energy, hydration, nutrition, habits, and fitness level).
                    Do not give medical diagnoses; include a gentle reminder to consult a clinician for medical concerns when relevant.
                    Always structure your response cleanly with:
                    [Warm, empathetic, conversational answer directly supporting the user with clear, realistic steps]

                    ### Explanation
                    [Physiological, psychological, or Prophetic wisdom explaining why this helps]

                    ### Sources
                    - [Evidence/Reference Name] (https://... e.g. https://www.who.int/... or https://ods.od.nih.gov/... or https://www.nhs.uk/...)

                    Optionally, ONLY when directly helpful, add at most 1 or 2 action tags on the final line from:
                    [[ACTION:HABIT_RECOVERY]] [[ACTION:BREATHING]] [[ACTION:MY_DAY]] [[ACTION:ADHKAR]]
                    """.trimIndent()
                )
            }
        )
    }

    private val tafsirSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Concise title of this Ayah theme in the requested language"),
            "deeperContext" to Schema.string(
                description = "Surrounding Surah flow, themes before/after this verse, and established historical context (Asbab al-Nuzul if authentically known; explicitly state if no single specific incident is recorded)"
            ),
            "explanation" to Schema.string(
                description = "Deep, clear Tafsir explanation of key Arabic words, theological/spiritual nuance, and intended meaning in context"
            ),
            "lifeLesson" to Schema.string(
                description = "Practical, compassionate reflection & action a believer can apply in daily life"
            ),
            "sourceNote" to Schema.string(
                description = "Classical Tafsir references consulted (e.g. Tafsir Ibn Kathir, Al-Sa'di, Maariful Quran)"
            )
        )
    )

    private val tafsirModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_ID,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = tafsirSchema
            },
            systemInstruction = content {
                text(
                    """
                    You are an authentic Islamic Tafsir scholar providing deep, accurate, contextual verse explanations rooted in classical Tafsir (Ibn Kathir, Al-Tabari, Al-Sa'di, Maariful Quran).
                    Explain verses in their true surrounding Surah context and historical background. Never fabricate Asbab al-Nuzul stories—if a verse was revealed generally without a single famous incident, clearly explain the Makki/Madani context and surrounding Surah progression instead.
                    """.trimIndent()
                )
            }
        )
    }

    private val mealPhotoSchema = Schema.obj(
        properties = mapOf(
            "dishName" to Schema.string(description = "Recognized dish or meal name in the requested language"),
            "detectedItems" to Schema.array(
                items = Schema.string(),
                description = "List of visible food items/portions on the plate"
            ),
            "calories" to Schema.integer(description = "Estimated total calories in kcal"),
            "proteinGrams" to Schema.integer(description = "Estimated protein in grams"),
            "carbsGrams" to Schema.integer(description = "Estimated carbohydrates in grams"),
            "fatGrams" to Schema.integer(description = "Estimated fat in grams"),
            "healthVerdict" to Schema.enumeration(
                values = listOf("GOOD_CHOICE", "MODERATE", "LIMIT"),
                description = "Whether this meal suits the user's profile and fitness goal"
            ),
            "recommendationReason" to Schema.string(
                description = "Clear explanation of why this meal is Good, Moderate, or best Limited for the user's goal"
            ),
            "improvementTip" to Schema.string(
                description = "Practical suggestion to balance or improve the meal (e.g. add fiber, hydration, portion swap)"
            )
        )
    )

    private val mealPhotoModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_ID,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = mealPhotoSchema
            },
            systemInstruction = content {
                text(
                    """
                    You are an expert nutritionist & dietary coach evaluating real meal photos accurately.
                    Identify South Asian, Middle Eastern, Bangladeshi, and international dishes realistically.
                    Provide conservative, realistic calorie and macronutrient estimates based on visible portion size, and evaluate healthiness honestly for the user's fitness goal.
                    """.trimIndent()
                )
            }
        )
    }

    fun streamChatReply(
        mode: String,
        query: String,
        language: AppLanguage,
        history: List<Pair<Boolean, String>>,
        prefs: UserPreferences,
        waterTodayMl: Int,
        mealsToday: List<MealLogEntity>,
        workoutsThisWeek: Int,
        habitsDoneCount: Int,
        totalHabitsCount: Int
    ): Flow<String> = flow {
        val isBn = language == AppLanguage.BANGLA
        val model = if (mode == "ISLAMIC") islamicChatModel else wellnessChatModel

        val chatHistory: List<Content> = history
            .takeLast(8)
            .filter { it.second.isNotBlank() }
            .map { (isUser, text) ->
                content(role = if (isUser) "user" else "model") {
                    text(text.take(1500))
                }
            }

        val chat = model.startChat(history = chatHistory)
        val augmentedPrompt = buildString {
            append("Respond in natural, warm ${if (isBn) "Bangla (বাংলা)" else "English"}.\n")
            if (mode == "WELLNESS") {
                val totalCal = mealsToday.sumOf { it.calories }
                val totalProtein = mealsToday.sumOf { it.proteinGrams }
                append("User Telemetry -> ")
                if (prefs.userName.isNotBlank()) append("Name: ${prefs.userName}, ")
                append("Age: ${prefs.ageYears}, Weight: ${prefs.weightKg}kg, Height: ${prefs.heightCm}cm, ")
                append("Level: ${prefs.fitnessLevel}, Goal: ${prefs.fitnessGoal}, Equipment: ${prefs.availableEquipment}, ")
                append("Limitations: ${prefs.fitnessLimitation}, Water today: $waterTodayMl/${prefs.hydrationGoalMl} ml, ")
                append("Fuel today: $totalCal kcal (${totalProtein}g protein), Workouts this week: $workoutsThisWeek, ")
                append("Habits done today: $habitsDoneCount/$totalHabitsCount.\n")
            }
            append("User Question: $query")
        }

        val sb = StringBuilder()
        withTimeout(60_000L) {
            chat.sendMessageStream(augmentedPrompt).collect { chunk ->
                val part = chunk.text.orEmpty()
                if (part.isNotEmpty()) {
                    sb.append(part)
                    emit(sb.toString())
                }
            }
        }
        if (sb.isBlank()) {
            throw IllegalStateException("Model returned an empty response.")
        }
    }

    suspend fun explainAyahInDepth(
        ayah: QuranAyah,
        language: AppLanguage
    ): AyahExplanation {
        val isBn = language == AppLanguage.BANGLA
        val meta = SurahCatalog.getMeta(ayah.surahNumber)
        val prompt = buildString {
            append("Language for all JSON string values: ${if (isBn) "Bangla (বাংলা)" else "English"}.\n")
            append("Surah ${meta.number}: ${meta.englishName} (${meta.englishMeaning}) — ${meta.revelationPlace}, ${meta.ayahCount} ayahs.\n")
            append("Ayah ${ayah.surahNumber}:${ayah.ayahNumber}:\n")
            append("Arabic: ${ayah.arabicText}\n")
            append("Translation (EN): ${ayah.englishTranslation}\n")
            append("Translation (BN): ${ayah.banglaTranslation}\n")
            append("Explain deeply what this verse means according to its surrounding Surah narrative, historical context (Asbab al-Nuzul if authentically known), Arabic nuances, and practical life takeaways.")
        }

        var responseText: String? = null
        var lastException: Exception? = null
        val fallbackModels = listOf(MODEL_ID, "gemini-3.5-flash-lite")
        for (modelId in fallbackModels) {
            try {
                val activeTafsirModel = if (modelId == MODEL_ID) {
                    tafsirModel
                } else {
                    Firebase.ai.generativeModel(
                        modelName = modelId,
                        generationConfig = generationConfig {
                            responseMimeType = "application/json"
                            responseSchema = tafsirSchema
                        }
                    )
                }
                val response = withTimeout(28_000L) {
                    activeTafsirModel.generateContent(prompt)
                }
                if (!response.text.isNullOrBlank()) {
                    responseText = response.text
                    break
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                lastException = e
                Log.w(TAG, "Tafsir model $modelId failed, trying fallback if available: ${e.message}")
            }
        }
        val raw = responseText ?: throw (lastException ?: IllegalStateException("Empty Tafsir response from model."))
        val obj = JSONObject(raw)

        val title = obj.optString("title").ifBlank {
            if (isBn) "আয়াত ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.banglaName}"
            else "Ayah ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.englishName}"
        }
        val deeperContext = obj.optString("deeperContext")
        val explanation = obj.optString("explanation")
        val lifeLesson = obj.optString("lifeLesson")
        val sourceNote = obj.optString("sourceNote", "Classical Tafsir Synthesis")

        return AyahExplanation(
            surahNumber = ayah.surahNumber,
            ayahNumber = ayah.ayahNumber,
            titleEn = if (!isBn) title else "Ayah ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.englishName}",
            titleBn = if (isBn) title else "আয়াত ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.banglaName}",
            explanationEn = if (!isBn) explanation else "",
            explanationBn = if (isBn) explanation else "",
            lifeLessonEn = if (!isBn) lifeLesson else "",
            lifeLessonBn = if (isBn) lifeLesson else "",
            surahContextEn = "Surah ${meta.number}: ${meta.englishName} (${meta.arabicName}) • ${meta.revelationPlace} • ${meta.ayahCount} Ayahs",
            surahContextBn = "সূরা ${meta.number}: ${meta.banglaName} (${meta.arabicName}) • ${if (meta.revelationPlace == "Meccan") "মক্কী" else "মাদানী"} • ${meta.ayahCount} আয়াত",
            sourceNote = sourceNote,
            deeperContextEn = if (!isBn) deeperContext else "",
            deeperContextBn = if (isBn) deeperContext else ""
        )
    }

    suspend fun analyzeMealPhoto(
        bitmap: Bitmap,
        prefs: UserPreferences,
        mealType: String,
        modelOverride: String = MODEL_ID
    ): MealPhotoAnalysis {
        val isBn = prefs.language == AppLanguage.BANGLA
        val scaled = scaleBitmapIfNeeded(bitmap, maxDim = 1024)
        val prompt = buildString {
            append("Language for dishName, detectedItems, recommendationReason, improvementTip: ${if (isBn) "Bangla (বাংলা)" else "English"}.\n")
            append("Meal slot: $mealType.\n")
            append("User goal: ${prefs.fitnessGoal} | Fitness level: ${prefs.fitnessLevel} | Weight: ${prefs.weightKg}kg | Limitations: ${prefs.fitnessLimitation}.\n")
            append("Analyze this meal photo carefully. Estimate realistic calories and protein/carbs/fat grams, judge whether it is GOOD_CHOICE, MODERATE, or LIMIT for this user's goal, explain why clearly, and suggest one practical improvement.")
        }

        val activeModel = if (modelOverride == MODEL_ID) {
            mealPhotoModel
        } else {
            Firebase.ai.generativeModel(
                modelName = modelOverride,
                generationConfig = generationConfig {
                    responseMimeType = "application/json"
                    responseSchema = mealPhotoSchema
                }
            )
        }

        val response = withTimeout(60_000L) {
            activeModel.generateContent(
                content {
                    image(scaled)
                    text(prompt)
                }
            )
        }
        val raw = response.text ?: throw IllegalStateException("Empty meal analysis returned.")
        val obj = JSONObject(raw)
        val itemsArr = obj.optJSONArray("detectedItems")
        val items = buildList {
            if (itemsArr != null) {
                for (i in 0 until itemsArr.length()) {
                    itemsArr.optString(i).takeIf { it.isNotBlank() }?.let(::add)
                }
            }
        }
        return MealPhotoAnalysis(
            dishName = obj.optString("dishName").ifBlank { if (isBn) "শনাক্তকৃত খাবার" else "Analyzed Meal" },
            detectedItems = items,
            calories = obj.optInt("calories", 350).coerceAtLeast(10),
            proteinGrams = obj.optInt("proteinGrams", 15).coerceAtLeast(0),
            carbsGrams = obj.optInt("carbsGrams", 35).coerceAtLeast(0),
            fatGrams = obj.optInt("fatGrams", 12).coerceAtLeast(0),
            healthVerdict = obj.optString("healthVerdict", "MODERATE"),
            recommendationReason = obj.optString("recommendationReason"),
            improvementTip = obj.optString("improvementTip")
        )
    }

    fun parseChatSections(rawText: String, query: String): ParsedChatSections {
        val actionRegex = Regex("""\[\[ACTION:([A-Za-z0-9_:\- ]+)]]""")
        val llmExtractedActions = actionRegex.findAll(rawText)
            .map { it.groupValues[1].trim() }
            .filter { RuhZenaInAppRouter.isValidActionTag(it) }
            .distinct()
            .take(4)
            .toList()

        val sanitizedText = actionRegex.replace(rawText, "").trim()

        val explanationMarker = Regex("""(?im)^#{2,3}\s*explanation.*$""")
        val sourcesMarker = Regex("""(?im)^#{2,3}\s*sources.*$""")

        val expMatch = explanationMarker.find(sanitizedText)
        val srcMatch = sourcesMarker.find(sanitizedText)

        val mainReply = when {
            expMatch != null -> sanitizedText.substring(0, expMatch.range.first).trim()
            srcMatch != null -> sanitizedText.substring(0, srcMatch.range.first).trim()
            else -> sanitizedText.trim()
        }

        val explanation = when {
            expMatch != null && srcMatch != null && srcMatch.range.first > expMatch.range.last ->
                sanitizedText.substring(expMatch.range.last + 1, srcMatch.range.first).trim()
            expMatch != null ->
                sanitizedText.substring(expMatch.range.last + 1).trim()
            else -> ""
        }

        val urlRegex = Regex("""https?://[^\s)\]>,"']+""")
        val mdLinkRegex = Regex("""\[([^\]]+)]\((https?://[^\s)]+)\)""")

        val extractedSources = buildList {
            // 1. Parse structured lines inside ### Sources block first (preserving label + URL or named citation)
            if (srcMatch != null) {
                val srcSection = sanitizedText.substring(srcMatch.range.last + 1).trim()
                srcSection.lines().forEach { line ->
                    val cleanedLine = line.trim().removePrefix("-").removePrefix("*").removePrefix("•").trim()
                    if (cleanedLine.isNotBlank() && !cleanedLine.startsWith("#")) {
                        val mdMatch = mdLinkRegex.find(cleanedLine)
                        if (mdMatch != null) {
                            val label = mdMatch.groupValues[1].trim()
                            val url = mdMatch.groupValues[2].trimEnd('.', ',', ';', ')')
                            add("$label|$url")
                        } else {
                            val inlineUrl = urlRegex.find(cleanedLine)?.value?.trimEnd('.', ',', ';', ')')
                            if (inlineUrl != null) {
                                val label = cleanedLine.replace(inlineUrl, "")
                                    .replace("(", "").replace(")", "")
                                    .replace("[", "").replace("]", "")
                                    .trim(' ', '-', ':', '•')
                                if (label.length >= 3) add("$label|$inlineUrl") else add(inlineUrl)
                            } else if (cleanedLine.length in 4..120) {
                                // Plain citation like "Sahih al-Bukhari 6464" or "Quran 2:286" -> resolved clickable in UI
                                add(cleanedLine.replace("**", "").replace("__", "").trim())
                            }
                        }
                    }
                }
            }
            // 2. Also capture any markdown links or bare URLs mentioned anywhere in the reply
            mdLinkRegex.findAll(sanitizedText).forEach { m ->
                val url = m.groupValues[2].trimEnd('.', ',', ';', ')')
                if (none { it.contains(url) }) {
                    add("${m.groupValues[1].trim()}|$url")
                }
            }
            urlRegex.findAll(sanitizedText).forEach { m ->
                val url = m.value.trimEnd('.', ',', ';', ')')
                if (none { it.contains(url) }) {
                    add(url)
                }
            }
        }.distinct().take(8)

        val resolvedMain = mainReply.ifBlank { sanitizedText.trim() }
        val mergedActions = RuhZenaInAppRouter.detectInAppActions(
            userQuery = query,
            aiReply = resolvedMain,
            llmEmittedTags = llmExtractedActions
        )

        return ParsedChatSections(
            mainReply = resolvedMain,
            explanation = explanation,
            citedSources = extractedSources,
            topic = query.trim().take(60),
            actionTags = mergedActions
        )
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
        val longest = max(bitmap.width, bitmap.height)
        if (longest <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / longest.toFloat()
        val w = (bitmap.width * ratio).roundToInt().coerceAtLeast(1)
        val h = (bitmap.height * ratio).roundToInt().coerceAtLeast(1)
        return try {
            Bitmap.createScaledBitmap(bitmap, w, h, true)
        } catch (e: Exception) {
            Log.w(TAG, "Bitmap scaling fallback", e)
            bitmap
        }
    }
}
