package com.example.ruhzena.data.cloud

import android.content.Context
import android.util.Log
import com.example.R
import com.example.ruhzena.data.local.BookmarkEntity
import com.example.ruhzena.data.local.HabitEntity
import com.example.ruhzena.data.local.JournalEntryEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.data.local.WorkoutLogEntity
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

private const val CLOUD_TAG = "RuhZenaCloudRepo"

private val ALLOWED_LANGUAGES = setOf("ENGLISH", "BANGLA", "ARABIC")
private val ALLOWED_GENDERS = setOf("", "MALE", "FEMALE")
private val ALLOWED_HABIT_CATEGORIES = setOf("Spirituality", "Health", "Discipline", "Learning")
private val ALLOWED_BOOKMARK_TYPES = setOf("QURAN", "DUA", "ADHKAR", "LESSON")

data class CloudPullBundle(
    val profile: CloudUserProfile?,
    val habits: List<CloudHabit>,
    val journal: List<CloudJournalEntry>,
    val workouts: List<CloudWorkoutLog>,
    val waterLogs: List<CloudWaterLog>,
    val bookmarks: List<CloudBookmark>
)

class RuhZenaCloudRepository(context: Context) {
    private val appContext = context.applicationContext

    private val firestore: FirebaseFirestore by lazy {
        val dbId = appContext.getString(R.string.firestore_database_id)
        FirebaseFirestore.getInstance(dbId)
    }

    private fun requireUserId(): String =
        Firebase.auth.currentUser?.uid ?: throw IllegalStateException("User not signed in")

    private fun sanitizeDocId(raw: String, prefix: String): String {
        val cleaned = raw.trim().replace(Regex("[^a-zA-Z0-9_-]"), "_")
            .replace(Regex("_+"), "_")
            .trim('_')
        val candidate = if (cleaned.isNotEmpty()) "${prefix}_$cleaned" else "${prefix}_${System.currentTimeMillis()}"
        return candidate.take(120)
    }

    private fun userDocRef(uid: String) = firestore.collection("users").document(uid)

    fun observeUserProfile(uid: String): Flow<CloudUserProfile?> {
        val path = "users/$uid"
        return userDocRef(uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObject(
                    CloudUserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { cause ->
                val unwrapped = unwrapFirestoreError(cause)
                if (unwrapped is CancellationException) throw unwrapped
                logFirestoreError(unwrapped, OperationType.GET, path)
                emit(null)
            }
    }

    fun observeHabits(uid: String): Flow<List<CloudHabit>> {
        val path = "users/$uid/habits"
        return userDocRef(uid)
            .collection("habits")
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { qs ->
                qs.documents.mapNotNull { doc ->
                    doc.toObject(CloudHabit::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
            }
            .catch { cause ->
                val unwrapped = unwrapFirestoreError(cause)
                if (unwrapped is CancellationException) throw unwrapped
                logFirestoreError(unwrapped, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    suspend fun upsertUserProfile(
        prefs: UserPreferences,
        displayNameOverride: String? = null,
        emailOverride: String? = null
    ): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val path = "users/$uid"
        return try {
            val docRef = userDocRef(uid)
            val existing = docRef.get().await()
            val authUser = Firebase.auth.currentUser
            val safeName = (displayNameOverride ?: prefs.userName.ifBlank { authUser?.displayName.orEmpty() })
                .trim().take(80)
            val safeEmail = (emailOverride ?: authUser?.email.orEmpty()).trim().take(120)
            val safeLang = prefs.language.name.takeIf { it in ALLOWED_LANGUAGES } ?: "ENGLISH"
            val safeGender = prefs.characterGender.takeIf { it in ALLOWED_GENDERS } ?: ""
            val safeHydration = prefs.hydrationGoalMl.coerceIn(500, 10000)
            val safeTasbih = prefs.tasbihTotalCount.coerceIn(0, 10_000_000)
            val safeSurah = prefs.lastReadSurah.coerceIn(1, 114)
            val safeAyah = prefs.lastReadAyah.coerceIn(1, 286)

            if (!existing.exists()) {
                val createData = mapOf<String, Any?>(
                    "userId" to uid,
                    "displayName" to safeName,
                    "email" to safeEmail,
                    "language" to safeLang,
                    "characterGender" to safeGender,
                    "hydrationGoalMl" to safeHydration,
                    "tasbihTotalCount" to safeTasbih,
                    "lastReadSurah" to safeSurah,
                    "lastReadAyah" to safeAyah,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(createData).await()
            } else {
                val updateData = mapOf<String, Any?>(
                    "displayName" to safeName,
                    "email" to safeEmail,
                    "language" to safeLang,
                    // A device that hasn't got the gender yet must not wipe the saved cloud value.
                    "characterGender" to safeGender.ifBlank { null },
                    "hydrationGoalMl" to safeHydration,
                    "tasbihTotalCount" to safeTasbih,
                    "lastReadSurah" to safeSurah,
                    "lastReadAyah" to safeAyah,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.update(updateData).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun upsertHabit(habit: HabitEntity): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val docId = sanitizeDocId(habit.title.lowercase(), "habit")
        val path = "users/$uid/habits/$docId"
        return try {
            val docRef = userDocRef(uid).collection("habits").document(docId)
            val existing = docRef.get().await()
            val safeTitle = habit.title.trim().take(120).ifBlank { "Daily Habit" }
            val safeCat = habit.category.takeIf { it in ALLOWED_HABIT_CATEGORIES } ?: "Spirituality"
            val safeStreak = habit.currentStreak.coerceIn(0, 100_000)
            val safeBest = habit.bestStreak.coerceIn(0, 100_000)
            val safeDate = habit.lastCompletedDate.trim().take(16)
            val safeRecovery = habit.recoveryNote.trim().take(500)

            if (!existing.exists()) {
                val createData = mapOf<String, Any?>(
                    "userId" to uid,
                    "title" to safeTitle,
                    "category" to safeCat,
                    "currentStreak" to safeStreak,
                    "bestStreak" to safeBest,
                    "lastCompletedDate" to safeDate,
                    "recoveryNote" to safeRecovery,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(createData).await()
            } else {
                val updateData = mapOf<String, Any?>(
                    "title" to safeTitle,
                    "category" to safeCat,
                    "currentStreak" to safeStreak,
                    "bestStreak" to safeBest,
                    "lastCompletedDate" to safeDate,
                    "recoveryNote" to safeRecovery,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.update(updateData).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteHabitByTitle(title: String): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val docId = sanitizeDocId(title.lowercase(), "habit")
        val path = "users/$uid/habits/$docId"
        return try {
            userDocRef(uid).collection("habits").document(docId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveJournalEntry(entry: JournalEntryEntity): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val docId = sanitizeDocId("${entry.dateKey}_${entry.timestamp}", "journal")
        val path = "users/$uid/journal/$docId"
        return try {
            val docRef = userDocRef(uid).collection("journal").document(docId)
            val existing = docRef.get().await()
            val safeTitle = entry.title.trim().take(150).ifBlank { "Reflection" }
            val safeContent = entry.content.trim().take(4000).ifBlank { "-" }
            val safeMood = entry.mood.trim().take(40).ifBlank { "Grateful" }
            val safeAchievement = entry.achievement.trim().take(300)
            val safeDate = entry.dateKey.trim().take(16).ifBlank { "2026-01-01" }

            if (!existing.exists()) {
                val createData = mapOf<String, Any?>(
                    "userId" to uid,
                    "title" to safeTitle,
                    "content" to safeContent,
                    "mood" to safeMood,
                    "achievement" to safeAchievement,
                    "dateKey" to safeDate,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(createData).await()
            } else {
                val updateData = mapOf<String, Any?>(
                    "title" to safeTitle,
                    "content" to safeContent,
                    "mood" to safeMood,
                    "achievement" to safeAchievement,
                    "dateKey" to safeDate,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.update(updateData).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveWorkoutLog(log: WorkoutLogEntity): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val docId = sanitizeDocId("${log.dateKey}_${log.timestamp}", "workout")
        val path = "users/$uid/workouts/$docId"
        return try {
            val docRef = userDocRef(uid).collection("workouts").document(docId)
            val existing = docRef.get().await()
            val safeTitle = log.routineTitle.trim().take(120).ifBlank { "Workout Session" }
            val safeExercises = log.exercisesCompleted.coerceIn(0, 200)
            val safeDuration = log.durationMinutes.coerceIn(0, 600)
            val safeCalories = log.estimatedCalories.coerceIn(0, 5000)
            val safeDate = log.dateKey.trim().take(16).ifBlank { "2026-01-01" }

            if (!existing.exists()) {
                val createData = mapOf<String, Any?>(
                    "userId" to uid,
                    "routineTitle" to safeTitle,
                    "exercisesCompleted" to safeExercises,
                    "durationMinutes" to safeDuration,
                    "estimatedCalories" to safeCalories,
                    "dateKey" to safeDate,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(createData).await()
            } else {
                val updateData = mapOf<String, Any?>(
                    "routineTitle" to safeTitle,
                    "exercisesCompleted" to safeExercises,
                    "durationMinutes" to safeDuration,
                    "estimatedCalories" to safeCalories,
                    "dateKey" to safeDate,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.update(updateData).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveWaterLog(log: WaterLogEntity): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val docId = sanitizeDocId("${log.dateKey}_${log.timestamp}", "water")
        val path = "users/$uid/water_logs/$docId"
        return try {
            val docRef = userDocRef(uid).collection("water_logs").document(docId)
            val existing = docRef.get().await()
            val safeAmount = log.amountMl.coerceIn(1, 5000)
            val safeDate = log.dateKey.trim().take(16).ifBlank { "2026-01-01" }

            if (!existing.exists()) {
                val createData = mapOf<String, Any?>(
                    "userId" to uid,
                    "amountMl" to safeAmount,
                    "dateKey" to safeDate,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(createData).await()
            } else {
                val updateData = mapOf<String, Any?>(
                    "amountMl" to safeAmount,
                    "dateKey" to safeDate,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.update(updateData).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveBookmark(bookmark: BookmarkEntity): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val docId = sanitizeDocId(bookmark.key, "bm")
        val path = "users/$uid/bookmarks/$docId"
        return try {
            val docRef = userDocRef(uid).collection("bookmarks").document(docId)
            val existing = docRef.get().await()
            val safeType = bookmark.itemType.takeIf { it in ALLOWED_BOOKMARK_TYPES } ?: "QURAN"
            val safeTitle = bookmark.title.trim().take(160).ifBlank { "Bookmark" }
            val safeSubtitle = bookmark.subtitle.trim().take(300)
            val safeArabic = bookmark.arabicText.trim().take(2000)
            val safeSurah = bookmark.surahNumber.coerceIn(0, 114)
            val safeAyah = bookmark.ayahNumber.coerceIn(0, 286)

            if (!existing.exists()) {
                val createData = mapOf<String, Any?>(
                    "userId" to uid,
                    "itemType" to safeType,
                    "title" to safeTitle,
                    "subtitle" to safeSubtitle,
                    "arabicText" to safeArabic,
                    "surahNumber" to safeSurah,
                    "ayahNumber" to safeAyah,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(createData).await()
            } else {
                val updateData = mapOf<String, Any?>(
                    "itemType" to safeType,
                    "title" to safeTitle,
                    "subtitle" to safeSubtitle,
                    "arabicText" to safeArabic,
                    "surahNumber" to safeSurah,
                    "ayahNumber" to safeAyah,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.update(updateData).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteBookmark(bookmarkKey: String): Result<Unit> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val docId = sanitizeDocId(bookmarkKey, "bm")
        val path = "users/$uid/bookmarks/$docId"
        return try {
            userDocRef(uid).collection("bookmarks").document(docId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun pullCloudBundle(): Result<CloudPullBundle> {
        val uid = runCatching { requireUserId() }.getOrElse { return Result.failure(it) }
        val basePath = "users/$uid"
        return try {
            val profileSnap = userDocRef(uid).get().await()
            val profile = profileSnap.toObject(
                CloudUserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )

            val habits = userDocRef(uid).collection("habits").get().await().documents.mapNotNull {
                it.toObject(CloudHabit::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            val journal = userDocRef(uid).collection("journal").get().await().documents.mapNotNull {
                it.toObject(CloudJournalEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            val workouts = userDocRef(uid).collection("workouts").get().await().documents.mapNotNull {
                it.toObject(CloudWorkoutLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            val waterLogs = userDocRef(uid).collection("water_logs").get().await().documents.mapNotNull {
                it.toObject(CloudWaterLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            val bookmarks = userDocRef(uid).collection("bookmarks").get().await().documents.mapNotNull {
                it.toObject(CloudBookmark::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }

            Log.d(
                CLOUD_TAG,
                "Pulled cloud bundle: habits=${habits.size}, journal=${journal.size}, workouts=${workouts.size}, water=${waterLogs.size}, bookmarks=${bookmarks.size}"
            )
            Result.success(
                CloudPullBundle(
                    profile = profile,
                    habits = habits,
                    journal = journal,
                    workouts = workouts,
                    waterLogs = waterLogs,
                    bookmarks = bookmarks
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logFirestoreError(e, OperationType.LIST, basePath)
            Result.failure(e)
        }
    }

    companion object {
        fun unwrapFirestoreError(cause: Throwable): Throwable {
            if (cause is FirebaseFirestoreException) return cause
            var cursor: Throwable? = cause.cause
            while (cursor != null) {
                if (cursor is FirebaseFirestoreException) return cursor
                cursor = cursor.cause
            }
            return cause
        }
    }
}
