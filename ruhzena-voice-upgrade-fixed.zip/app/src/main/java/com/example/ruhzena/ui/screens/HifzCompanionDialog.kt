package com.example.ruhzena.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.QuranReciter
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.media.AudioPlaybackState
import com.example.ruhzena.ui.QuranReaderUiState
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette

@Composable
fun HifzCompanionDialog(
    prefs: UserPreferences,
    quranState: QuranReaderUiState,
    audioState: AudioPlaybackState,
    onSelectSurah: (Int) -> Unit,
    onSelectReciter: (QuranReciter) -> Unit,
    onStartHifzLoop: (surahNumber: Int, startAyah: Int, endAyah: Int, repeatCount: Int, pauseGapSec: Int) -> Unit,
    onStopAudio: () -> Unit,
    onCompleteHifzSession: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val strings = LocalStrings.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    var selectedSurahNum by rememberSaveable { mutableIntStateOf(prefs.hifzTargetSurah.coerceIn(1, 114)) }
    val surahMeta = remember(selectedSurahNum) { SurahCatalog.getMeta(selectedSurahNum) }

    var startAyah by rememberSaveable { mutableIntStateOf(1) }
    var endAyah by rememberSaveable { mutableIntStateOf(minOf(3, surahMeta.ayahCount)) }
    var repeatPerAyah by rememberSaveable { mutableIntStateOf(5) }
    var pauseGapSeconds by rememberSaveable { mutableIntStateOf(3) }
    var hideArabicSelfTest by rememberSaveable { mutableStateOf(false) }
    var revealedAyahs by remember { mutableStateOf(setOf<Int>()) }
    var surahMenuExpanded by remember { mutableStateOf(false) }
    var reciterMenuExpanded by remember { mutableStateOf(false) }
    var sessionCompletedBanner by remember { mutableStateOf(false) }

    LaunchedEffect(selectedSurahNum) {
        if (quranState.selectedSurahNumber != selectedSurahNum) {
            onSelectSurah(selectedSurahNum)
        }
        val meta = SurahCatalog.getMeta(selectedSurahNum)
        startAyah = startAyah.coerceIn(1, meta.ayahCount)
        endAyah = endAyah.coerceIn(startAyah, meta.ayahCount)
        revealedAyahs = emptySet()
    }

    val activeReciter = remember(prefs.selectedReciterId) {
        SurahCatalog.reciters.firstOrNull { it.id == prefs.selectedReciterId }
            ?: SurahCatalog.reciters.first()
    }

    val ayahsInRange = remember(quranState.ayahs, quranState.selectedSurahNumber, selectedSurahNum, startAyah, endAyah) {
        if (quranState.selectedSurahNumber == selectedSurahNum) {
            quranState.ayahs.filter { it.ayahNumber in startAyah..endAyah }
        } else {
            emptyList()
        }
    }

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler { onDismiss() }

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("hifz_companion_dialog"),
            color = palette.voidBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "হিফজ মুখস্থ সহায়ক" else "Hifz Memorization Companion",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary
                        )
                        Text(
                            text = if (isBn) "মানব ক্বারীর আয়াত লুপ, বিরতি এবং আত্ম-পরীক্ষা" else "Human reciter ayah range loop, recall pause & self-test",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.accentSoft
                        )
                    }
                    StatusPillBadge(
                        label = "${prefs.hifzRevisionStreak} ${if (isBn) "সেশন" else "streak"}",
                        accentColor = palette.gold
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_hifz_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textPrimary)
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Surah & Reciter Picker Card
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                            Text(
                                text = if (isBn) "সূরা ও ক্বারী নির্বাচন" else "Surah & Human Reciter",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Box {
                                Surface(
                                    onClick = { surahMenuExpanded = true },
                                    shape = RoundedCornerShape(12.dp),
                                    color = palette.blockBg,
                                    border = BorderStroke(0.8.dp, palette.borderAccent),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("hifz_surah_dropdown")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${surahMeta.number}. ${if (isBn) surahMeta.banglaName else surahMeta.englishName} (${surahMeta.ayahCount} ${strings.ayahsLabel})",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = palette.textPrimary,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = palette.gold)
                                    }
                                }
                                DropdownMenu(
                                    expanded = surahMenuExpanded,
                                    onDismissRequest = { surahMenuExpanded = false },
                                    modifier = Modifier
                                        .heightIn(max = 360.dp)
                                        .background(palette.surfaceBg)
                                ) {
                                    SurahCatalog.allSurahs.forEach { s ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    "${s.number}. ${if (isBn) s.banglaName else s.englishName} (${s.arabicName})",
                                                    color = if (s.number == selectedSurahNum) palette.accentSoft else palette.textPrimary
                                                )
                                            },
                                            onClick = {
                                                selectedSurahNum = s.number
                                                startAyah = 1
                                                endAyah = minOf(3, s.ayahCount)
                                                surahMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Box {
                                Surface(
                                    onClick = { reciterMenuExpanded = true },
                                    shape = RoundedCornerShape(12.dp),
                                    color = palette.blockBg,
                                    border = BorderStroke(0.8.dp, palette.borderNeutral),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = if (isBn) activeReciter.nameBn else activeReciter.nameEn,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = palette.textPrimary,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = palette.gold)
                                    }
                                }
                                DropdownMenu(
                                    expanded = reciterMenuExpanded,
                                    onDismissRequest = { reciterMenuExpanded = false },
                                    modifier = Modifier
                                        .heightIn(max = 320.dp)
                                        .background(palette.surfaceBg)
                                ) {
                                    SurahCatalog.reciters.forEach { rec ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    if (isBn) rec.nameBn else rec.nameEn,
                                                    color = if (rec.id == activeReciter.id) palette.accentSoft else palette.textPrimary
                                                )
                                            },
                                            onClick = {
                                                onSelectReciter(rec)
                                                reciterMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Range, Repeats (1..100), Pause Gap & Active Recall Toggle
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = if (isBn) "লুপ, পুনরাবৃত্তি ও বিরতি সেটিংস" else "Ayah Range, Repeat & Recall Pause",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                HifzStepperBox(
                                    label = if (isBn) "শুরু আয়াত" else "Start Ayah",
                                    value = startAyah,
                                    onDec = {
                                        if (startAyah > 1) startAyah--
                                    },
                                    onInc = {
                                        if (startAyah < surahMeta.ayahCount) {
                                            startAyah++
                                            if (endAyah < startAyah) endAyah = startAyah
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                                HifzStepperBox(
                                    label = if (isBn) "শেষ আয়াত" else "End Ayah",
                                    value = endAyah,
                                    onDec = {
                                        if (endAyah > startAyah) endAyah--
                                    },
                                    onInc = {
                                        if (endAyah < surahMeta.ayahCount) endAyah++
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isBn) "প্রতি আয়াত পুনরাবৃত্তি: $repeatPerAyah বার (১–১০০)" else "Repeats per Ayah: ${repeatPerAyah}x (1–100)",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.gold
                                )
                                Row {
                                    IconButton(
                                        onClick = { if (repeatPerAyah > 1) repeatPerAyah-- },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease repeats", tint = palette.textPrimary)
                                    }
                                    IconButton(
                                        onClick = { if (repeatPerAyah < 100) repeatPerAyah++ },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase repeats", tint = palette.textPrimary)
                                    }
                                }
                            }

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(listOf(1, 3, 5, 10, 20, 50, 100)) { cnt ->
                                    GlassFilterChip(
                                        label = "${cnt}x",
                                        selected = repeatPerAyah == cnt,
                                        onClick = { repeatPerAyah = cnt }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (isBn) "আয়াত শেষে বিরতি (স্মরণ করার সময়)" else "Pause Gap After Each Play (Memory Recall)",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.textSecondary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(listOf(0, 3, 5, 8, 10)) { sec ->
                                    GlassFilterChip(
                                        label = if (sec == 0) (if (isBn) "বিরতি নেই" else "No pause") else "${sec}s",
                                        selected = pauseGapSeconds == sec,
                                        onClick = { pauseGapSeconds = sec }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            if (audioState.isHifzMode && audioState.activeSurahNumber == selectedSurahNum) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(palette.accentContainer, RoundedCornerShape(12.dp))
                                        .border(0.8.dp, palette.borderAccent, RoundedCornerShape(12.dp))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (audioState.isHifzGapPause) {
                                            if (isBn) "মুখস্থ পড়ুন... (${pauseGapSeconds}s বিরতি)" else "Your turn: recite from memory (${pauseGapSeconds}s)"
                                        } else {
                                            "${strings.ayahsLabel} ${audioState.currentAyahNumber} • ${audioState.hifzRepeatIndex}/${audioState.hifzTotalRepeats}"
                                        },
                                        style = MaterialTheme.typography.labelLarge,
                                        color = palette.accentSoft
                                    )
                                    GlassFilterChip(
                                        label = if (isBn) "থামান" else "Stop",
                                        selected = false,
                                        icon = Icons.Default.Stop,
                                        onClick = onStopAudio
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                EmeraldActionButton(
                                    text = if (isBn) "হিফজ লুপ শুরু করুন" else "Start Hifz Loop",
                                    icon = Icons.Default.PlayArrow,
                                    onClick = {
                                        onStartHifzLoop(selectedSurahNum, startAyah, endAyah, repeatPerAyah, pauseGapSeconds)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("hifz_start_loop_button")
                                )
                                GlassFilterChip(
                                    label = if (hideArabicSelfTest) {
                                        if (isBn) "আরবি দেখান" else "Reveal"
                                    } else {
                                        if (isBn) "আত্ম-পরীক্ষা (লুকান)" else "Hide Text"
                                    },
                                    selected = hideArabicSelfTest,
                                    icon = if (hideArabicSelfTest) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    onClick = {
                                        hideArabicSelfTest = !hideArabicSelfTest
                                        revealedAyahs = emptySet()
                                    },
                                    modifier = Modifier.testTag("hifz_hide_arabic_toggle")
                                )
                            }
                        }
                    }

                    // Active Ayahs Memory Practice Cards
                    items(ayahsInRange, key = { it.globalNumber }) { ayah ->
                        val isPeeked = !hideArabicSelfTest || revealedAyahs.contains(ayah.ayahNumber)
                        val isCurrentlyPlaying = audioState.isHifzMode &&
                            audioState.activeSurahNumber == selectedSurahNum &&
                            audioState.currentAyahNumber == ayah.ayahNumber

                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("hifz_ayah_card_${ayah.ayahNumber}"),
                            accentBorder = isCurrentlyPlaying
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusPillBadge(
                                    label = "${surahMeta.number}:${ayah.ayahNumber}",
                                    accentColor = if (isCurrentlyPlaying) palette.accentSoft else palette.gold
                                )
                                if (hideArabicSelfTest) {
                                    GlassFilterChip(
                                        label = if (isPeeked) (if (isBn) "লুকান" else "Mask") else (if (isBn) "উঁকি দিন" else "Peek"),
                                        selected = isPeeked,
                                        onClick = {
                                            revealedAyahs = if (isPeeked) {
                                                revealedAyahs - ayah.ayahNumber
                                            } else {
                                                revealedAyahs + ayah.ayahNumber
                                            }
                                        }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            if (isPeeked) {
                                Text(
                                    text = ayah.arabicText,
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        fontFamily = ArabicFontFamily,
                                        fontSize = 23.sp,
                                        lineHeight = 38.sp,
                                        textDirection = TextDirection.Rtl
                                    ),
                                    color = palette.textPrimary,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                val firstWordHint = ayah.arabicText.split(" ").take(2).joinToString(" ")
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(palette.blockBg, RoundedCornerShape(12.dp))
                                        .border(0.8.dp, palette.borderNeutral, RoundedCornerShape(12.dp))
                                        .clickable { revealedAyahs = revealedAyahs + ayah.ayahNumber }
                                        .padding(14.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isBn) "$firstWordHint ... (মুখস্থ বলুন, দেখতে ট্যাপ করুন)" else "$firstWordHint ... (Recite from memory • Tap to peek)",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = palette.gold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isBn && ayah.banglaTranslation.isNotBlank()) ayah.banglaTranslation else ayah.englishTranslation,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                    }

                    // Complete Hifz Revision Session Button
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                            if (sessionCompletedBanner) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = palette.accentSoft)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isBn) "মাশাআল্লাহ! হিফজ সেশন লগ করা হয়েছে।" else "MashaAllah! Revision streak +1 recorded.",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = palette.accentSoft
                                    )
                                }
                            }
                            EmeraldActionButton(
                                text = if (isBn) "হিফজ সেশন সম্পন্ন (+১ স্ট্রিক)" else "Complete Hifz Session (+1 Streak)",
                                icon = Icons.Default.LocalFireDepartment,
                                onClick = {
                                    onCompleteHifzSession(selectedSurahNum)
                                    sessionCompletedBanner = true
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("hifz_complete_session_button")
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HifzStepperBox(
    label: String,
    value: Int,
    onDec: () -> Unit,
    onInc: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    Column(
        modifier = modifier
            .background(palette.blockBg, RoundedCornerShape(12.dp))
            .border(0.7.dp, palette.borderNeutral, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = onDec, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Remove, contentDescription = "Decrease $label", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
            }
            Text(
                text = value.toString(),
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = palette.textPrimary
            )
            IconButton(onClick = onInc, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Add, contentDescription = "Increase $label", tint = palette.accentSoft, modifier = Modifier.size(18.dp))
            }
        }
    }
}
