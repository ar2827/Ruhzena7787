package com.example.ruhzena.ui.exercises

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.ui.components.SolvedFkSkeleton
import com.example.ruhzena.ui.components.drawAnatomicalAthleticHuman
import com.example.ruhzena.ui.components.lerpFkPose
import com.example.ruhzena.ui.components.solveExerciseBiomechanics
import com.example.ruhzena.ui.components.solveFkSkeleton
import com.example.ui.theme.LocalRuhZenaPalette
import com.example.ui.theme.RuhZenaGlassPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * Biomechanical Real-Time Exercise Demonstration Viewport.
 *
 * Driven 100% by the Unified 28-Joint Anatomical Rig (`AnatomicalFkRigEngine` + `ExerciseChoreographyLibrary`):
 * - Analytical 2-Bone IK locks hands & feet solidly onto floors and stationary benches (ZERO bounce!).
 * - Multi-segment flexible spine articulates Cat-Cow, Cobra, Hollow Body, V-Ups, and Superman smoothly.
 * - Full coverage for all 27 exercises including Diamond, Army/Military, Wide, Decline, Pike & Archer Push-Ups.
 */
@Composable
fun SculptedExerciseViewport(
    exercise: ExerciseItem,
    isPlaying: Boolean = true,
    isSlowMotion: Boolean = false,
    playbackSpeedMultiplier: Float = if (isSlowMotion) 0.5f else 1.0f,
    height: Dp = 276.dp,
    @Suppress("UNUSED_PARAMETER") showStudioPhoto: Boolean = false,
    showMuscleFocus: Boolean = true,
    @Suppress("UNUSED_PARAMETER") showMotionGuides: Boolean = false,
    forcedProgress: Float? = null,
    characterGender: String = "MALE",
    @Suppress("UNUSED_PARAMETER") yawDeg: Float = 0f,
    @Suppress("UNUSED_PARAMETER") pitchDeg: Float = 0f,
    @Suppress("UNUSED_PARAMETER") zoom: Float = 1f,
    @Suppress("UNUSED_PARAMETER") onRotateDelta: ((deltaYaw: Float, deltaPitch: Float) -> Unit)? = null,
    @Suppress("UNUSED_PARAMETER") onZoomStep: ((deltaZoom: Float) -> Unit)? = null,
    @Suppress("UNUSED_PARAMETER") onResetCamera: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val isFemale = characterGender.equals("FEMALE", ignoreCase = true)

    var progress by remember(exercise.id) { mutableFloatStateOf(0f) }

    LaunchedEffect(exercise.id, isPlaying, playbackSpeedMultiplier, forcedProgress) {
        if (forcedProgress != null) {
            progress = forcedProgress
            return@LaunchedEffect
        }
        if (!isPlaying) return@LaunchedEffect
        var lastTimeNanos = 0L
        val cycleSpeed = 0.88f * playbackSpeedMultiplier
        while (isPlaying) {
            withFrameNanos { frameNanos ->
                if (lastTimeNanos != 0L) {
                    val dt = ((frameNanos - lastTimeNanos) / 1_000_000_000f).coerceAtMost(0.06f)
                    progress = (progress + dt * cycleSpeed) % 4f
                }
                lastTimeNanos = frameNanos
            }
        }
    }

    val effectiveProgress = forcedProgress ?: progress
    val phaseIndex = floor(effectiveProgress).toInt().coerceIn(0, 3)
    val nextPhaseIndex = (phaseIndex + 1) % 4
    val bio = solveExerciseBiomechanics(
        exerciseId = exercise.id,
        effectiveProgress = effectiveProgress,
        activeZone = exercise.activeZone
    )
    val easedT = bio.easedT

    val currentPhase = exercise.phases[phaseIndex]
    val fkKeyframes = remember(exercise.id) { ExerciseChoreographyLibrary.keyframesFor(exercise.id) }
    val liveFkPose = remember(fkKeyframes, phaseIndex, nextPhaseIndex, easedT) {
        lerpFkPose(fkKeyframes[phaseIndex], fkKeyframes[nextPhaseIndex], easedT)
    }

    val muscleActivation = maxOf(
        bio.pecTension,
        bio.deltTension,
        bio.tricepTension,
        bio.coreTension,
        bio.quadTension,
        bio.gluteTension,
        bio.calfTension
    ).coerceIn(0.18f, 1f)

    val breathText = when (currentPhase.breathing) {
        BreathingCue.INHALE -> if (isBn) "শ্বাস নিন" else "INHALE"
        BreathingCue.EXHALE -> if (isBn) "শ্বাস ছাড়ুন" else "EXHALE"
        BreathingCue.STEADY -> if (isBn) "স্বাভাবিক শ্বাস" else "STEADY"
    }
    val breathColor = when (currentPhase.breathing) {
        BreathingCue.INHALE -> palette.sky
        BreathingCue.EXHALE -> palette.accentSoft
        BreathingCue.STEADY -> palette.gold
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF070B13))
            .border(1.dp, palette.borderNeutral.copy(alpha = 0.82f), RoundedCornerShape(18.dp))
            .testTag("exercise_live_motion_viewport")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val floorY = size.height * 0.84f
            drawBiomechanicsStudioStage(
                floorY = floorY,
                palette = palette,
                phase = effectiveProgress / 4f
            )

            // 1. Stationary immovable studio bench/box rendered BEFORE human (ZERO movement!)
            val bench = ExerciseChoreographyLibrary.stationaryBenchFor(exercise.id, size, floorY)
            if (bench != null) {
                drawStationaryPlyoBench(bench, floorY)
            }

            // 2. Solve 28-joint skeleton with exact analytical 2-bone IK + biomechanical physics
            val scaleMul = ExerciseChoreographyLibrary.scaleMultiplier(exercise.id)
            val ikLocks = ExerciseChoreographyLibrary.ikLocksFor(exercise.id, size, floorY, bench)
            val skel = solveFkSkeleton(
                pose = liveFkPose,
                canvasSize = size,
                floorY = floorY,
                isFemale = isFemale,
                scaleMultiplier = scaleMul,
                breathPhase = effectiveProgress / 4f,
                ikLocks = ikLocks,
                physics = bio
            )

            // 3. Render background equipment rigs (pull-up bar, resistance band anchors)
            drawBackgroundEquipmentRig(exercise = exercise, skel = skel, floorY = floorY, palette = palette)

            // 4. Render unified high-detail anatomical human with real muscle recruitment & physics shadow
            drawAnatomicalAthleticHuman(
                skel = skel,
                isFemale = isFemale,
                palette = palette,
                activeZone = exercise.activeZone,
                showMuscleFocus = showMuscleFocus,
                muscleActivation = muscleActivation,
                floorY = floorY,
                phase = effectiveProgress / 4f,
                physics = bio
            )

            // 5. Render foreground handheld equipment props (dumbbells, kettlebell, barbell, bands)
            drawHandheldEquipmentProps(exercise = exercise, skel = skel, floorY = floorY, palette = palette)
        }

        // Bottom live rep cadence progress bar
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .align(Alignment.BottomCenter)
        ) {
            val repProgress = (effectiveProgress / 4f).coerceIn(0f, 1f)
            val y = size.height - 4f
            val left = size.width * 0.05f
            val width = size.width * 0.90f
            drawLine(
                color = Color.White.copy(alpha = 0.22f),
                start = Offset(left, y),
                end = Offset(left + width, y),
                strokeWidth = 3.2f,
                cap = StrokeCap.Round
            )
            drawLine(
                brush = Brush.horizontalGradient(listOf(palette.accentSoft, palette.gold)),
                start = Offset(left, y),
                end = Offset(left + width * repProgress, y),
                strokeWidth = 3.8f,
                cap = StrokeCap.Round
            )
        }

        // Top-left step, active muscle & live biomechanical phase indicator
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .background(Color(0xCC070A12), RoundedCornerShape(10.dp))
                .border(0.7.dp, Color(0x55FFFFFF), RoundedCornerShape(10.dp))
                .padding(horizontal = 9.dp, vertical = 4.dp)
        ) {
            val zoneLabel = muscleZoneLabel(exercise.activeZone, isBn)
            val equipPrefix = if (exercise.equipmentRequired != "Bodyweight") {
                "${if (isBn) WorkoutEquipmentCatalog.equipmentBadgeBn(exercise.equipmentRequired) else exercise.equipmentRequired} • "
            } else ""
            val bioCue = if (isBn) bio.phaseLabelBn else bio.phaseLabelEn
            Text(
                text = "$equipPrefix${strings.movementStepLabel} ${phaseIndex + 1}/4 • $zoneLabel • $bioCue",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFEAEFF7),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Top-right breathing pill
        StatusPillBadge(
            label = breathText,
            accentColor = breathColor,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
        )
    }
}

private fun DrawScope.drawStationaryPlyoBench(bench: StationaryBenchSpec, floorY: Float) {
    // Ground contact shadow right under the immovable box
    drawOval(
        color = Color.Black.copy(alpha = 0.55f),
        topLeft = Offset(bench.left - 8f, floorY - 6f),
        size = Size(bench.width + 16f, 14f)
    )
    // Brushed metallic-slate plyometric box body
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(Color(0xFF2D3A4E), Color(0xFF1A2332), Color(0xFF0F1520)),
            startY = bench.top,
            endY = bench.top + bench.height
        ),
        topLeft = Offset(bench.left, bench.top),
        size = Size(bench.width, bench.height),
        cornerRadius = CornerRadius(8f, 8f)
    )
    // Textured anti-slip top pad strip
    drawRoundRect(
        brush = Brush.horizontalGradient(listOf(Color(0xFF3E4E66), Color(0xFF566B8A), Color(0xFF3E4E66))),
        topLeft = Offset(bench.left + 2f, bench.top),
        size = Size(bench.width - 4f, 9f),
        cornerRadius = CornerRadius(6f, 6f)
    )
    // Subtle structural rib lines on box front
    drawLine(
        color = Color(0x33D4E4F7),
        start = Offset(bench.left + 10f, bench.top + bench.height * 0.48f),
        end = Offset(bench.left + bench.width - 10f, bench.top + bench.height * 0.48f),
        strokeWidth = 1.4f
    )
    drawRoundRect(
        color = Color(0x88B8CEE8),
        topLeft = Offset(bench.left, bench.top),
        size = Size(bench.width, bench.height),
        cornerRadius = CornerRadius(8f, 8f),
        style = Stroke(width = 1.4f)
    )
}

private fun DrawScope.drawBackgroundEquipmentRig(
    exercise: ExerciseItem,
    skel: SolvedFkSkeleton,
    floorY: Float,
    palette: RuhZenaGlassPalette
) {
    val u = skel.unit
    when (exercise.equipmentRequired) {
        WorkoutEquipmentCatalog.PULL_UP_BAR -> {
            val barY = minOf(skel.nearHand.y, skel.farHand.y).coerceIn(size.height * 0.12f, size.height * 0.36f)
            val leftPostX = size.width * 0.24f
            val rightPostX = size.width * 0.76f
            // Vertical steel power-rack uprights
            drawLine(
                color = Color(0xFF334155),
                start = Offset(leftPostX, barY - u * 0.16f),
                end = Offset(leftPostX, floorY),
                strokeWidth = 6.5f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color(0xFF334155),
                start = Offset(rightPostX, barY - u * 0.16f),
                end = Offset(rightPostX, floorY),
                strokeWidth = 6.5f,
                cap = StrokeCap.Round
            )
            // Overhead metallic knurled pull-up bar
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color(0xFF94A3B8), Color(0xFFE2E8F0), Color(0xFF94A3B8)),
                    startX = leftPostX,
                    endX = rightPostX
                ),
                start = Offset(leftPostX - 8f, barY),
                end = Offset(rightPostX + 8f, barY),
                strokeWidth = 7.5f,
                cap = StrokeCap.Round
            )
        }
        WorkoutEquipmentCatalog.RESISTANCE_BANDS -> {
            val bandColor = palette.accentSoft
            val anchor = when (exercise.id) {
                "band_overhead_press" -> Offset(skel.nearFoot.x, floorY - 3f)
                "band_chest_press" -> Offset(size.width * 0.08f, skel.chest.y)
                else -> Offset(size.width * 0.92f, skel.chest.y)
            }
            // Wall / floor anchor mount
            drawCircle(
                color = Color(0xFF64748B),
                radius = 7f,
                center = anchor
            )
            drawCircle(
                color = bandColor,
                radius = 4f,
                center = anchor
            )
            // Dual elastic tension bands stretching smoothly to hands
            drawLine(
                color = bandColor.copy(alpha = 0.85f),
                start = anchor,
                end = skel.farHand,
                strokeWidth = 4.2f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = bandColor,
                start = anchor,
                end = skel.nearHand,
                strokeWidth = 4.8f,
                cap = StrokeCap.Round
            )
        }
    }
}

private fun DrawScope.drawHandheldEquipmentProps(
    exercise: ExerciseItem,
    skel: SolvedFkSkeleton,
    floorY: Float,
    palette: RuhZenaGlassPalette
) {
    val u = skel.unit
    when (exercise.equipmentRequired) {
        WorkoutEquipmentCatalog.DUMBBELLS -> {
            fun drawDumbbellAt(hand: Offset, alpha: Float) {
                val halfLen = u * 0.42f
                val plateR = u * 0.24f
                // Chrome knurled handle
                drawLine(
                    color = Color(0xFFCBD5E1).copy(alpha = alpha),
                    start = Offset(hand.x - halfLen, hand.y),
                    end = Offset(hand.x + halfLen, hand.y),
                    strokeWidth = 4.8f,
                    cap = StrokeCap.Round
                )
                // Left & right cast-iron hex weight heads
                for (dx in listOf(-halfLen, halfLen)) {
                    drawCircle(
                        color = Color(0xFF1E293B).copy(alpha = alpha),
                        radius = plateR,
                        center = Offset(hand.x + dx, hand.y)
                    )
                    drawCircle(
                        color = palette.gold.copy(alpha = 0.72f * alpha),
                        radius = plateR,
                        center = Offset(hand.x + dx, hand.y),
                        style = Stroke(width = 1.6f)
                    )
                }
            }
            if (exercise.id == "db_goblet_squat") {
                // Single vertical goblet dumbbell held at chest
                val mid = Offset((skel.nearHand.x + skel.farHand.x) * 0.5f, (skel.nearHand.y + skel.farHand.y) * 0.5f)
                val halfH = u * 0.38f
                drawLine(
                    color = Color(0xFFCBD5E1),
                    start = Offset(mid.x, mid.y - halfH),
                    end = Offset(mid.x, mid.y + halfH),
                    strokeWidth = 5.5f,
                    cap = StrokeCap.Round
                )
                for (dy in listOf(-halfH, halfH)) {
                    drawRoundRect(
                        color = Color(0xFF1E293B),
                        topLeft = Offset(mid.x - u * 0.28f, mid.y + dy - u * 0.14f),
                        size = Size(u * 0.56f, u * 0.28f),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                    drawRoundRect(
                        color = palette.gold.copy(alpha = 0.78f),
                        topLeft = Offset(mid.x - u * 0.28f, mid.y + dy - u * 0.14f),
                        size = Size(u * 0.56f, u * 0.28f),
                        cornerRadius = CornerRadius(6f, 6f),
                        style = Stroke(width = 1.5f)
                    )
                }
            } else {
                drawDumbbellAt(skel.farHand, 0.72f)
                drawDumbbellAt(skel.nearHand, 1f)
            }
        }
        WorkoutEquipmentCatalog.KETTLEBELL -> {
            val grip = Offset((skel.nearHand.x + skel.farHand.x) * 0.5f, (skel.nearHand.y + skel.farHand.y) * 0.5f)
            val bellCenter = Offset(grip.x + u * 0.04f, grip.y + u * 0.38f)
            // Cast-iron handle arc
            drawArc(
                color = Color(0xFFCBD5E1),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(grip.x - u * 0.22f, grip.y - u * 0.10f),
                size = Size(u * 0.44f, u * 0.40f),
                style = Stroke(width = 4.6f, cap = StrokeCap.Round)
            )
            // Cast-iron kettlebell body
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF475569), Color(0xFF0F172A)),
                    center = Offset(bellCenter.x - u * 0.08f, bellCenter.y - u * 0.08f),
                    radius = u * 0.38f
                ),
                radius = u * 0.34f,
                center = bellCenter
            )
            drawCircle(
                color = palette.gold.copy(alpha = 0.8f),
                radius = u * 0.34f,
                center = bellCenter,
                style = Stroke(width = 1.8f)
            )
        }
        WorkoutEquipmentCatalog.BARBELL_BENCH -> {
            val barCenter = if (exercise.id == "bb_back_squat") {
                Offset(skel.neckBase.x - u * 0.14f, skel.neckBase.y + u * 0.08f)
            } else {
                Offset((skel.nearHand.x + skel.farHand.x) * 0.5f, (skel.nearHand.y + skel.farHand.y) * 0.5f)
            }
            val plateR = u * 0.48f
            // Olympic bumper plate (side-profile circular disc centered on bar sleeve)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF334155), Color(0xFF0F172A)),
                    center = barCenter,
                    radius = plateR
                ),
                radius = plateR,
                center = barCenter
            )
            drawCircle(
                color = palette.accentSoft.copy(alpha = 0.85f),
                radius = plateR,
                center = barCenter,
                style = Stroke(width = 2.4f)
            )
            drawCircle(
                color = Color(0xFFCBD5E1),
                radius = u * 0.11f,
                center = barCenter
            )
            drawCircle(
                color = Color(0xFF1E293B),
                radius = u * 0.05f,
                center = barCenter
            )
        }
    }
}

private fun muscleZoneLabel(zone: MuscleZone, isBn: Boolean): String = when (zone) {
    MuscleZone.CHEST_ARMS -> if (isBn) "বুক ও বাহু" else "Chest & Arms"
    MuscleZone.CORE -> if (isBn) "কোর ও পেট" else "Core"
    MuscleZone.LEGS_GLUTES -> if (isBn) "পা ও গ্লুটস" else "Legs & Glutes"
    MuscleZone.SPINE_BACK -> if (isBn) "পিঠ ও মেরুদণ্ড" else "Back & Spine"
    MuscleZone.FULL_BODY -> if (isBn) "সম্পূর্ণ শরীর" else "Full Body"
}

private fun DrawScope.drawBiomechanicsStudioStage(
    floorY: Float,
    palette: RuhZenaGlassPalette,
    phase: Float
) {
    drawRect(
        brush = Brush.verticalGradient(
            listOf(Color(0xFF070B14), Color(0xFF10192A), Color(0xFF080C15))
        )
    )

    val lightCone = Path().apply {
        moveTo(size.width * 0.20f, 0f)
        lineTo(size.width * 0.56f, 0f)
        lineTo(size.width * 0.86f, floorY)
        lineTo(size.width * 0.14f, floorY)
        close()
    }
    drawPath(
        lightCone,
        brush = Brush.verticalGradient(
            listOf(Color(0x20A6C8F4), Color(0x09D5B77A), Color.Transparent),
            startY = 0f,
            endY = floorY
        )
    )

    val gridColor = Color(0x16B8CEE8)
    for (i in 1..4) {
        val y = floorY * (i / 5f)
        drawLine(gridColor, Offset(size.width * 0.06f, y), Offset(size.width * 0.94f, y), strokeWidth = 1f)
    }

    drawRect(
        brush = Brush.verticalGradient(
            listOf(Color(0xFF0D1422), Color(0xFF05080F)),
            startY = floorY,
            endY = size.height
        ),
        topLeft = Offset(0f, floorY),
        size = Size(size.width, size.height - floorY)
    )

    val matLeft = size.width * 0.08f
    val matW = size.width * 0.84f
    val matH = (size.height * 0.036f).coerceAtLeast(8f)
    drawRoundRect(
        brush = Brush.horizontalGradient(
            listOf(Color(0xFF142031), Color(0xFF21344D), Color(0xFF142031))
        ),
        topLeft = Offset(matLeft, floorY - matH * 0.25f),
        size = Size(matW, matH),
        cornerRadius = CornerRadius(4f, 4f)
    )
    drawLine(
        brush = Brush.horizontalGradient(
            listOf(Color.Transparent, palette.accentSoft.copy(alpha = 0.65f), palette.gold.copy(alpha = 0.65f), Color.Transparent)
        ),
        start = Offset(matLeft, floorY - matH * 0.25f),
        end = Offset(matLeft + matW, floorY - matH * 0.25f),
        strokeWidth = 1.6f
    )

    for (i in 0..5) {
        val drift = (phase + i * 0.17f) % 1f
        val x = size.width * (0.15f + i * 0.14f) + sin(drift * 6.28f) * 6f
        val y = floorY * (0.85f - drift * 0.65f)
        val a = sin(drift * PI).toFloat().coerceIn(0f, 1f) * 0.35f
        drawCircle(Color(0xFFD6E6FA).copy(alpha = a), radius = 1.4f, center = Offset(x, y))
    }
}

@Composable
fun ExerciseDemonstrationPlayer(
    exercise: ExerciseItem,
    characterGender: String = "MALE",
    onSelectGender: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    var isPlaying by remember(exercise.id) { mutableStateOf(true) }
    var speedMultiplier by remember(exercise.id) { mutableFloatStateOf(1.0f) }
    var repeatEnabled by remember(exercise.id) { mutableStateOf(true) }
    var showCaptions by remember(exercise.id) { mutableStateOf(true) }
    var showMuscleFocus by remember(exercise.id) { mutableStateOf(true) }
    var progress by remember(exercise.id) { mutableFloatStateOf(0f) }

    LaunchedEffect(exercise.id, isPlaying, speedMultiplier, repeatEnabled) {
        if (!isPlaying) return@LaunchedEffect
        var lastTimeNanos = 0L
        val cycleSpeed = 0.88f * speedMultiplier
        while (isPlaying) {
            withFrameNanos { frameNanos ->
                if (lastTimeNanos != 0L) {
                    val dt = ((frameNanos - lastTimeNanos) / 1_000_000_000f).coerceAtMost(0.06f)
                    val next = progress + dt * cycleSpeed
                    if (next >= 4f) {
                        if (repeatEnabled) {
                            progress = next % 4f
                        } else {
                            progress = 3.999f
                            isPlaying = false
                        }
                    } else {
                        progress = next
                    }
                }
                lastTimeNanos = frameNanos
            }
        }
    }

    val phaseIndex = floor(progress).toInt().coerceIn(0, 3)
    val currentPhase = exercise.phases[phaseIndex]

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(palette.cardElevatedBg, RoundedCornerShape(20.dp))
            .border(1.dp, palette.borderNeutral, RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (onSelectGender != null) {
                GlassFilterChip(
                    label = if (isBn) "পুরুষ" else "Male",
                    selected = !characterGender.equals("FEMALE", ignoreCase = true),
                    onClick = { onSelectGender("MALE") },
                    modifier = Modifier.weight(1f).testTag("demo_gender_male")
                )
                GlassFilterChip(
                    label = if (isBn) "নারী" else "Female",
                    selected = characterGender.equals("FEMALE", ignoreCase = true),
                    onClick = { onSelectGender("FEMALE") },
                    modifier = Modifier.weight(1f).testTag("demo_gender_female")
                )
            }
            GlassFilterChip(
                label = if (isBn) "পেশী ফোকাস" else "Muscle Focus",
                selected = showMuscleFocus,
                onClick = { showMuscleFocus = !showMuscleFocus },
                modifier = Modifier.weight(1.2f).testTag("demo_muscle_focus_toggle")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        SculptedExerciseViewport(
            exercise = exercise,
            isPlaying = isPlaying,
            playbackSpeedMultiplier = speedMultiplier,
            height = 282.dp,
            showMuscleFocus = showMuscleFocus,
            forcedProgress = progress,
            characterGender = characterGender
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            exercise.phases.forEachIndexed { idx, ph ->
                val isCurrent = idx == phaseIndex
                val chipBg by animateColorAsState(
                    targetValue = if (isCurrent) palette.accentContainer else palette.blockBg,
                    label = "stepBg$idx"
                )
                val borderC by animateColorAsState(
                    targetValue = if (isCurrent) palette.borderAccent else palette.borderNeutral.copy(alpha = 0.45f),
                    label = "stepBorder$idx"
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(chipBg)
                        .border(0.8.dp, borderC, RoundedCornerShape(10.dp))
                        .clickable {
                            isPlaying = false
                            progress = idx.toFloat()
                        }
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${idx + 1}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isCurrent) palette.accentSoft else palette.gold
                    )
                    Text(
                        text = (if (isBn) ph.captionBn else ph.captionEn).substringBefore("—").trim(),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isCurrent) palette.textPrimary else palette.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        AnimatedVisibility(visible = showCaptions) {
            Text(
                text = if (isBn) currentPhase.captionBn else currentPhase.captionEn,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textPrimary,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        Slider(
            value = progress,
            onValueChange = {
                isPlaying = false
                progress = it.coerceIn(0f, 3.99f)
            },
            valueRange = 0f..3.99f,
            colors = SliderDefaults.colors(
                thumbColor = palette.accentSoft,
                activeTrackColor = palette.accentPrimary,
                inactiveTrackColor = palette.textMuted.copy(alpha = 0.35f)
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    isPlaying = false
                    progress = (((phaseIndex - 1) + 4) % 4).toFloat()
                }
            ) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Previous step", tint = palette.textPrimary)
            }

            IconButton(
                onClick = { isPlaying = !isPlaying },
                modifier = Modifier
                    .size(48.dp)
                    .background(palette.accentPrimary, CircleShape)
                    .testTag("demo_play_pause_button")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) strings.pauseDemo else strings.playDemo,
                    tint = palette.onAccent
                )
            }

            IconButton(
                onClick = {
                    isPlaying = false
                    progress = ((phaseIndex + 1) % 4).toFloat()
                },
                modifier = Modifier.testTag("demo_next_step_button")
            ) {
                Icon(Icons.Default.SkipNext, contentDescription = "Next step", tint = palette.textPrimary)
            }

            IconButton(
                onClick = {
                    progress = 0f
                    isPlaying = true
                },
                modifier = Modifier.testTag("demo_replay_button")
            ) {
                Icon(Icons.Default.Replay, contentDescription = strings.replayDemo, tint = palette.textPrimary)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(0.5f to "0.5×", 1.0f to "1×", 1.5f to "1.5×").forEach { (spd, label) ->
                GlassFilterChip(
                    label = label,
                    selected = kotlin.math.abs(speedMultiplier - spd) < 0.05f,
                    onClick = { speedMultiplier = spd },
                    modifier = Modifier.weight(0.75f).testTag("demo_speed_$label")
                )
            }
            GlassFilterChip(
                label = strings.repeatLoop,
                selected = repeatEnabled,
                onClick = { repeatEnabled = !repeatEnabled },
                icon = Icons.Default.Repeat,
                modifier = Modifier.weight(1f)
            )
            GlassFilterChip(
                label = if (isBn) "টীকা" else "Cues",
                selected = showCaptions,
                onClick = { showCaptions = !showCaptions },
                icon = Icons.Default.Subtitles,
                modifier = Modifier.weight(1f).testTag("demo_captions_button")
            )
        }
    }
}
