package com.example.ruhzena.ui.exercises

import androidx.compose.ui.geometry.Offset

/**
 * Canonical Workout Equipment definitions shared across Onboarding, Fitness Profile, Settings,
 * Exercise Filtering, and Workout Program Recommendations.
 */
object WorkoutEquipmentCatalog {
    const val NONE = "No Equipment"
    const val DUMBBELLS = "Dumbbells"
    const val RESISTANCE_BANDS = "Resistance Bands"
    const val PULL_UP_BAR = "Pull-Up Bar"
    const val KETTLEBELL = "Kettlebell"
    const val BARBELL_BENCH = "Barbell & Bench"
    const val FULL_GYM = "Full Gym"

    data class EquipmentOption(
        val id: String,
        val labelEn: String,
        val labelBn: String,
        val subtitleEn: String,
        val subtitleBn: String
    )

    val selectableOptions: List<EquipmentOption> = listOf(
        EquipmentOption(
            id = NONE,
            labelEn = "No Equipment (Bodyweight)",
            labelBn = "কোনো সরঞ্জাম নেই (বডিওয়েট)",
            subtitleEn = "Zero-gear home calisthenics & mobility",
            subtitleBn = "কোনো যন্ত্রপাতি ছাড়াই ঘরে ব্যায়াম"
        ),
        EquipmentOption(
            id = DUMBBELLS,
            labelEn = "Dumbbells",
            labelBn = "ডাম্বেল",
            subtitleEn = "Fixed or adjustable dumbbells",
            subtitleBn = "ফিক্সড বা অ্যাডজাস্টেবল ডাম্বেল"
        ),
        EquipmentOption(
            id = RESISTANCE_BANDS,
            labelEn = "Resistance Bands",
            labelBn = "রেজিস্ট্যান্স ব্যান্ড",
            subtitleEn = "Loop bands or tube bands",
            subtitleBn = "লুপ বা টিউব রেজিস্ট্যান্স ব্যান্ড"
        ),
        EquipmentOption(
            id = PULL_UP_BAR,
            labelEn = "Pull-Up Bar",
            labelBn = "পুল-আপ বার",
            subtitleEn = "Doorway or wall-mounted bar",
            subtitleBn = "দরজা বা দেয়ালে লাগানো বার"
        ),
        EquipmentOption(
            id = KETTLEBELL,
            labelEn = "Kettlebell",
            labelBn = "কেটলবেল",
            subtitleEn = "Single or pair of kettlebells",
            subtitleBn = "একটি বা জোড়া কেটলবেল"
        ),
        EquipmentOption(
            id = BARBELL_BENCH,
            labelEn = "Barbell & Bench",
            labelBn = "বারবেল ও বেঞ্চ",
            subtitleEn = "Home rack, barbell & weight bench",
            subtitleBn = "বারবেল, প্লেট ও বেঞ্চ"
        ),
        EquipmentOption(
            id = FULL_GYM,
            labelEn = "Full Gym",
            labelBn = "সম্পূর্ণ জিম",
            subtitleEn = "All free weights, racks & cables",
            subtitleBn = "সকল জিম সরঞ্জাম ও মেশিন"
        )
    )

    fun parseSelected(raw: String): Set<String> {
        val clean = raw.trim()
        if (clean.isBlank() || clean.equals(NONE, ignoreCase = true) || clean.equals("Bodyweight", ignoreCase = true)) {
            return setOf(NONE)
        }
        val tokens = clean.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val mapped = tokens.mapNotNull { t ->
            when {
                t.contains("no equip", ignoreCase = true) || t.equals("bodyweight", ignoreCase = true) -> NONE
                t.contains("dumbbell", ignoreCase = true) -> DUMBBELLS
                t.contains("band", ignoreCase = true) -> RESISTANCE_BANDS
                t.contains("pull", ignoreCase = true) || t.contains("bar", ignoreCase = true) && !t.contains("barbell", ignoreCase = true) -> PULL_UP_BAR
                t.contains("kettle", ignoreCase = true) -> KETTLEBELL
                t.contains("barbell", ignoreCase = true) || t.contains("bench", ignoreCase = true) -> BARBELL_BENCH
                t.contains("gym", ignoreCase = true) -> FULL_GYM
                else -> null
            }
        }.toSet()
        return if (mapped.isEmpty()) setOf(NONE) else mapped
    }

    fun toggleOption(currentRaw: String, optionId: String): String {
        if (optionId == NONE) return NONE
        val current = parseSelected(currentRaw).toMutableSet()
        current.remove(NONE)
        if (current.contains(optionId)) {
            current.remove(optionId)
        } else {
            current.add(optionId)
        }
        if (current.isEmpty()) return NONE
        return selectableOptions.map { it.id }.filter { current.contains(it) }.joinToString(", ")
    }

    fun hasAnyEquipment(raw: String): Boolean {
        val sel = parseSelected(raw)
        return sel.any { it != NONE }
    }

    fun matchesUserEquipment(equipmentRequired: String, userRaw: String): Boolean {
        if (equipmentRequired.equals("Bodyweight", ignoreCase = true)) return true
        val sel = parseSelected(userRaw)
        if (sel.contains(FULL_GYM)) return true
        return when {
            equipmentRequired.equals(DUMBBELLS, ignoreCase = true) -> sel.contains(DUMBBELLS)
            equipmentRequired.equals(RESISTANCE_BANDS, ignoreCase = true) -> sel.contains(RESISTANCE_BANDS)
            equipmentRequired.equals(PULL_UP_BAR, ignoreCase = true) -> sel.contains(PULL_UP_BAR)
            equipmentRequired.equals(KETTLEBELL, ignoreCase = true) -> sel.contains(KETTLEBELL)
            equipmentRequired.contains("Barbell", ignoreCase = true) -> sel.contains(BARBELL_BENCH)
            else -> true
        }
    }

    fun equipmentBadgeBn(equip: String): String = when (equip) {
        "Bodyweight" -> "বডিওয়েট"
        DUMBBELLS -> "ডাম্বেল"
        RESISTANCE_BANDS -> "রেজিস্ট্যান্স ব্যান্ড"
        PULL_UP_BAR -> "পুল-আপ বার"
        KETTLEBELL -> "কেটলবেল"
        BARBELL_BENCH, "Barbell / Gym" -> "বারবেল / জিম"
        else -> equip
    }
}

/**
 * Authentic ACSM / NSCA / ExRx.net Biomechanics-Structured Equipment Exercise Library & Programs.
 * Organized systematically across all 6 foundational human movement patterns:
 * Squat, Hip Hinge, Horizontal Push, Vertical Push, Horizontal Pull, Vertical Pull, Core & Conditioning.
 */
object EquipmentExerciseCatalog {

    private fun placeholderPhases(
        c1En: String, c1Bn: String, b1: BreathingCue,
        c2En: String, c2Bn: String, b2: BreathingCue,
        c3En: String, c3Bn: String, b3: BreathingCue,
        c4En: String, c4Bn: String, b4: BreathingCue
    ): List<ExercisePhaseInfo> {
        val neutral = SkeletalPose(
            head = Offset(0.50f, 0.18f),
            shoulder = Offset(0.50f, 0.28f),
            elbow = Offset(0.46f, 0.42f),
            wrist = Offset(0.46f, 0.54f),
            hip = Offset(0.50f, 0.52f),
            knee = Offset(0.50f, 0.70f),
            ankle = Offset(0.50f, 0.86f)
        )
        return listOf(
            ExercisePhaseInfo(neutral, c1En, c1Bn, b1),
            ExercisePhaseInfo(neutral, c2En, c2Bn, b2),
            ExercisePhaseInfo(neutral, c3En, c3Bn, b3),
            ExercisePhaseInfo(neutral, c4En, c4Bn, b4)
        )
    }

    val equipmentExercises: List<ExerciseItem> = listOf(
        // ==================== DUMBBELLS (7 Authentic Compound & Isolation Lifts) ====================
        ExerciseItem(
            id = "db_goblet_squat",
            nameEn = "Dumbbell Goblet Squat",
            nameBn = "ডাম্বেল গবলেট স্কোয়াট",
            categoryEn = "Lower Body & Glutes",
            categoryBn = "পা ও গ্লুটস শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quadriceps, Gluteus Maximus, Adductors, Anterior Core",
            musclesBn = "উরু (কোয়াড্রিসেপস), গ্লুটস, অ্যাডাক্টর ও কোর",
            setsRepsEn = "3–4 sets × 10–12 reps",
            setsRepsBn = "৩–৪ সেট × ১০–১২ বার",
            restSeconds = 60,
            breathingEn = "Inhale and brace ribs before descending; exhale steadily as you drive vertically out of the bottom.",
            breathingBn = "নিচে নামার আগে বুক ভরে শ্বাস নিন; উপরে ওঠার সময় দৃঢ়ভাবে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Cup one dumbbell vertically tight against the sternum with elbows tucked down",
                "Feet shoulder-width apart, toes turned slightly out (10–20°)",
                "Sit hips down between heels keeping torso upright and entire foot planted"
            ),
            postureBn = listOf(
                "একটি ডাম্বেল বুকের কাছে সোজা ধরে কনুই নিচের দিকে রাখুন",
                "পা কাঁধের সমান প্রশস্ত ও পায়ের আঙুল সামান্য বাইরের দিকে রাখুন",
                "বুক উঁচু রেখে গোড়ালি মাটিতে চেপে কোমর নিচে নামান"
            ),
            mistakesEn = listOf("Letting knees cave inward (valgus)", "Heels lifting off the floor", "Holding dumbbell away from chest"),
            mistakesBn = listOf("হাঁটু ভেতরের দিকে ভেঙে যাওয়া", "গোড়ালি মাটি থেকে উঠে যাওয়া", "ডাম্বেল বুক থেকে দূরে ধরা"),
            easierAltEn = "Bodyweight Box Squat to a sturdy chair to groove hip depth.",
            easierAltBn = "চেয়ারের ওপর বডিওয়েট বক্স স্কোয়াট।",
            progressionEn = "3-second eccentric pause Goblet Squat or Double-Dumbbell Front Squat.",
            progressionBn = "৩ সেকেন্ড ধীরগতিতে নেমে বিরতিসহ গবলেট স্কোয়াট বা ডাবল-ডাম্বেল ফ্রন্ট স্কোয়াট।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Rack & Brace: Cup dumbbell tightly at chest, tall spine.", "১. প্রস্তুতি: বুকের কাছে ডাম্বেল শক্তভাবে ধরে মেরুদণ্ড সোজা রাখুন।", BreathingCue.INHALE,
                "2. Controlled Descent: Push knees smoothly over toes, hips drop straight down.", "২. নিচে নামা: হাঁটু পায়ের আঙুল বরাবর রেখে কোমর নিচে নামান।", BreathingCue.INHALE,
                "3. Full Depth: Thighs parallel or below, elbows graze inner knees.", "৩. গভীর অবস্থান: উরু মেঝের সমান্তরাল ও বুক সোজা রাখুন।", BreathingCue.STEADY,
                "4. Drive Tall: Push through mid-foot and lock glutes at the top.", "৪. উপরে ওঠা: পায়ের মাঝখান দিয়ে চাপ দিয়ে সোজা হয়ে দাঁড়ান।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.DUMBBELLS,
            movementPattern = "Squat"
        ),
        ExerciseItem(
            id = "db_romanian_deadlift",
            nameEn = "Dumbbell Romanian Deadlift (RDL)",
            nameBn = "ডাম্বেল রোমানিয়ান ডেডলিফট (RDL)",
            categoryEn = "Lower Body & Glutes",
            categoryBn = "পা ও হ্যামস্ট্রিং শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Hamstrings, Gluteus Maximus, Erector Spinae, Forearms",
            musclesBn = "হ্যামস্ট্রিং, গ্লুটস, নিচের পিঠ ও গ্রিপ",
            setsRepsEn = "3–4 sets × 8–12 reps",
            setsRepsBn = "৩–৪ সেট × ৮–১২ বার",
            restSeconds = 75,
            breathingEn = "Inhale to brace abdomen before hinging back; exhale strongly as hips drive forward to lockout.",
            breathingBn = "কোমর পেছনে নেওয়ার আগে শ্বাস নিন; সোজা হয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hold dumbbells flush against the front of thighs with lats engaged",
                "Keep a soft ~15° knee bend and push hips straight backward like closing a car door",
                "Stop at mid-shin when hamstring stretch peaks — keep lumbar spine completely neutral"
            ),
            postureBn = listOf(
                "ডাম্বেল দুটি উরুর গা ঘেঁষে ধরে কাঁধ পেছনে টানটান রাখুন",
                "হাঁটু সামান্য ভেঙে কোমর সোজা পেছনের দিকে ঠেলে দিন",
                "পিঠ গোল না করে হাঁটুর নিচ পর্যন্ত নামিয়ে হ্যামস্ট্রিংয়ে টান অনুভব করুন"
            ),
            mistakesEn = listOf("Rounding the lower back under load", "Squatting instead of hinging hips back", "Letting weights drift forward away from legs"),
            mistakesBn = listOf("নিচের পিঠ কুঁজো করে ফেলা", "হিপ হিঞ্জের বদলে স্কোয়াট করা", "ডাম্বেল পা থেকে সামনে ঝুলিয়ে দেওয়া"),
            easierAltEn = "Glute Bridge or Bodyweight Good Morning with hands behind head.",
            easierAltBn = "গ্লুট ব্রিজ বা বডিওয়েট হিপ হিঞ্জ।",
            progressionEn = "Single-Leg Dumbbell RDL for unilateral hamstring and hip stability.",
            progressionBn = "সিঙ্গেল-লেগ ডাম্বেল RDL।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Tall Hinge Setup: Shoulders packed, dumbbells touching front thighs.", "১. দাঁড়ানো অবস্থান: কাঁধ স্থির, ডাম্বেল উরুর সামনে।", BreathingCue.INHALE,
                "2. Hip Hinge Back: Slide dumbbells down thighs as hips travel straight back.", "২. হিপ হিঞ্জ: কোমর পেছনে ঠেলে ডাম্বেল উরু ঘেঁষে নিচে নামান।", BreathingCue.INHALE,
                "3. Mid-Shin Stretch: Flat neutral spine, deep hamstring tension.", "৩. পূর্ণ প্রসারণ: পিঠ সম্পূর্ণ সোজা, হ্যামস্ট্রিংয়ে টান।", BreathingCue.STEADY,
                "4. Glute Drive: Drive hips forward smoothly to tall standing without hyperextending.", "৪. সোজা হওয়া: গ্লুটস সংকুচিত করে সোজা দাঁড়িয়ে পড়ুন।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.DUMBBELLS,
            movementPattern = "Hip Hinge"
        ),
        ExerciseItem(
            id = "db_chest_press",
            nameEn = "Dumbbell Bench / Floor Press",
            nameBn = "ডাম্বেল চেস্ট প্রেস (বেঞ্চ বা ফ্লোর)",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Pectoralis Major, Anterior Deltoids, Triceps Brachii",
            musclesBn = "বুক (পেক্টোরালস), সামনের কাঁধ ও ট্রাইসেপস",
            setsRepsEn = "3–4 sets × 8–12 reps",
            setsRepsBn = "৩–৪ সেট × ৮–১২ বার",
            restSeconds = 60,
            breathingEn = "Inhale slowly as elbows lower under control; exhale decisively as you press weights over mid-chest.",
            breathingBn = "ধীরে নিচে নামার সময় শ্বাস নিন; উপরে চাপ দেওয়ার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Retract shoulder blades gently into the bench or floor and plant feet firmly",
                "Lower dumbbells with upper arms at a safe ~45° angle from torso (not 90° flared)",
                "Press smoothly up along a slight arc without clanking dumbbells together"
            ),
            postureBn = listOf(
                "বেঞ্চ বা মেঝেতে শুয়ে কাঁধের হাড় স্থির ও পা মাটিতে দৃঢ় রাখুন",
                "কনুই শরীর থেকে ৪৫ ডিগ্রি কোণে রেখে ডাম্বেল বুকের পাশে নামান",
                "ডাম্বেল ঠোকাঠুকি না করে সোজা উপরের দিকে প্রেস করুন"
            ),
            mistakesEn = listOf("Flaring elbows straight out at 90° stressing shoulder joints", "Bouncing elbows off the floor", "Over-arching wrists backward"),
            mistakesBn = listOf("কনুই ৯০ ডিগ্রি বাইরে ছড়িয়ে কাঁধে চাপ দেওয়া", "মেঝেতে কনুই ঠুকে বাউন্স করা", "কবজি পেছনে বাঁকিয়ে রাখা"),
            easierAltEn = "Floor Dumbbell Press with lighter weights (floor limits shoulder over-extension).",
            easierAltBn = "হালকা ডাম্বেল নিয়ে ফ্লোর প্রেস।",
            progressionEn = "Incline Dumbbell Press (30° bench) or Alternating Single-Arm Press.",
            progressionBn = "ইনক্লাইন ডাম্বেল প্রেস বা অল্টারনেটিং সিঙ্গেল-আর্ম প্রেস।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Locked Top: Dumbbells stacked vertically above shoulders, wrists neutral.", "১. উপরের অবস্থান: ডাম্বেল কাঁধ বরাবর সোজা, কবজি স্থির।", BreathingCue.INHALE,
                "2. Controlled Eccentric: Lower elbows at 45° angle for 2–3 seconds.", "২. নিয়ন্ত্রিত নামানো: ২–৩ সেকেন্ডে ৪৫° কোণে কনুই নামান।", BreathingCue.INHALE,
                "3. Chest Stretch: Forearms vertical, shoulder blades anchored down.", "৩. নিচের বিন্দু: কনুই বুক বরাবর, কাঁধের ব্লেড স্থির।", BreathingCue.STEADY,
                "4. Explosive Press: Exhale and press dumbbells back to full lockout.", "৪. শক্তিশালী প্রেস: শ্বাস ছেড়ে সোজা উপরে তুলে দিন।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.DUMBBELLS,
            movementPattern = "Horizontal Push"
        ),
        ExerciseItem(
            id = "db_overhead_press",
            nameEn = "Dumbbell Standing Overhead Press",
            nameBn = "ডাম্বেল ওভারহেড শোল্ডার প্রেস",
            categoryEn = "Upper Body Strength",
            categoryBn = "কাঁধ ও বাহুর শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Anterior & Lateral Deltoids, Triceps, Upper Traps, Core",
            musclesBn = "কাঁধ (ডেল্টয়েডস), ট্রাইসেপস ও কোর",
            setsRepsEn = "3 sets × 8–10 reps",
            setsRepsBn = "৩ সেট × ৮–১০ বার",
            restSeconds = 60,
            breathingEn = "Inhale and brace glutes and abs at shoulder height; exhale smoothly while pressing overhead.",
            breathingBn = "কাঁধের স্তরে শ্বাস নিয়ে কোর শক্ত করুন; উপরে তোলার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hold dumbbells at shoulder level in the scapular plane (elbows angled ~30° forward)",
                "Squeeze glutes and keep ribs stacked over pelvis so lower back never arches",
                "Press directly overhead until biceps align cleanly beside your ears"
            ),
            postureBn = listOf(
                "কাঁধ বরাবর ডাম্বেল ধরে কনুই সামান্য (৩০°) সামনের দিকে রাখুন",
                "কোমর পেছনে বাঁকা হওয়া ঠেকাতে পেট ও গ্লুটস শক্ত করে রাখুন",
                "মাথার ওপর সোজা তুলে বাহু কানের সমান্তরালে নিয়ে যান"
            ),
            mistakesEn = listOf("Hyperextending lower back to heave heavy weight", "Shrugging traps before pressing", "Flaring ribs upward"),
            mistakesBn = listOf("নিচের পিঠ অতিরিক্ত বাঁকিয়ে ফেলা", "কাঁধ কানের দিকে উঠিয়ে নেওয়া", "পাঁজর উপরের দিকে ছড়িয়ে দেওয়া"),
            easierAltEn = "Seated Dumbbell Overhead Press with back support.",
            easierAltBn = "বেঞ্চে বসে সিটেড ডাম্বেল শোল্ডার প্রেস।",
            progressionEn = "Arnold Press or Single-Arm Overhead Press for extra anti-lateral-flexion core demand.",
            progressionBn = "আর্নল্ড প্রেস বা এক হাতে ওভারহেড প্রেস।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Shoulder Rack: Elbows slightly forward, stacked ribs & braced core.", "১. শোল্ডার র‍্যাক: কনুই সামান্য সামনে, কোর টানটান।", BreathingCue.INHALE,
                "2. Vertical Drive: Press straight up keeping wrists directly over elbows.", "২. উপরে তোলা: কবজি কনুইয়ের ওপর রেখে সোজা উপরে চাপুন।", BreathingCue.EXHALE,
                "3. Full Lockout: Biceps beside ears, glutes tight, zero back lean.", "৩. পূর্ণ লকআউট: বাহু কানের পাশে সোজা, পিঠ নিরপেক্ষ।", BreathingCue.STEADY,
                "4. Controlled Lower: Descend smoothly back to shoulder height.", "৪. ধীর অবতরণ: নিয়ন্ত্রণ বজায় রেখে কাঁধের স্তরে নামিয়ে আনুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.DUMBBELLS,
            movementPattern = "Vertical Push"
        ),
        ExerciseItem(
            id = "db_single_arm_row",
            nameEn = "Single-Arm Dumbbell Bent-Over Row",
            nameBn = "সিঙ্গেল-আর্ম ডাম্বেল রো",
            categoryEn = "Back & Posture",
            categoryBn = "পিঠ ও মেরুদণ্ডের শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Latissimus Dorsi, Rhomboids, Mid-Trapezius, Posterior Delts, Biceps",
            musclesBn = "পিঠের ল্যাটস, রম্বয়েডস, মিড-ট্র্যাপ ও বাইসেপস",
            setsRepsEn = "3–4 sets × 10–12 reps/side",
            setsRepsBn = "৩–৪ সেট × ১০–১২ বার প্রতি পাশে",
            restSeconds = 60,
            breathingEn = "Inhale at full bottom stretch; exhale cleanly as you pull the dumbbell toward your hip pocket.",
            breathingBn = "নিচে প্রসারিত অবস্থায় শ্বাস নিন; কোমরের দিকে টানার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hinge hips to ~45° with flat neutral spine and non-working hand braced on knee or bench",
                "Pull elbow back toward your hip pocket — NOT straight up toward the shoulder",
                "Pause 1 second squeezing shoulder blade toward spine before lowering fully"
            ),
            postureBn = listOf(
                "মেরুদণ্ড সোজা রেখে কোমর ৪৫° ঝুঁকিয়ে অন্য হাত বেঞ্চ বা হাঁটুতে রাখুন",
                "কনুই কাঁধের দিকে নয় বরং কোমরের পকেটের দিকে পেছনে টানুন",
                "উপরে ১ সেকেন্ড পিঠের পেশী চেপে ধরে ধীরে নিচে নামান"
            ),
            mistakesEn = listOf("Twisting torso violently to swing weight up", "Rounding upper back", "Shrugging shoulder toward ear"),
            mistakesBn = listOf("শরীর ঘুরিয়ে ঝাঁকুনি দিয়ে ওজন তোলা", "উপরের পিঠ কুঁজো রাখা", "কাঁধ কানের দিকে টেনে তোলা"),
            easierAltEn = "Chest-Supported Incline Dumbbell Row to remove lower-back fatigue.",
            easierAltBn = "ইনক্লাইন বেঞ্চে বুক ঠেকিয়ে চেস্ট-সাপোর্টেড রো।",
            progressionEn = "Renegade Dumbbell Row in plank or Gorilla Alternating Dumbbell Rows.",
            progressionBn = "প্ল্যাঙ্ক রেনেগেড রো বা গরিলা ডাম্বেল রো।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Braced Hinge: Flat back, working arm extended fully toward floor.", "১. হিঞ্জ অবস্থান: পিঠ সোজা, হাত নিচের দিকে প্রসারিত।", BreathingCue.INHALE,
                "2. Drive to Hip: Pull elbow back smoothly sweeping toward hip pocket.", "২. টেনে তোলা: কনুই পেছনে কোমরের দিকে টেনে আনুন।", BreathingCue.EXHALE,
                "3. Scapular Squeeze: Hold 1s with shoulder blade retracted, chest open.", "৩. পিঠ সংকোচন: ১ সেকেন্ড পিঠের পেশী সংকুচিত রাখুন।", BreathingCue.STEADY,
                "4. Full Stretch: Lower under 2s control back to deep lat stretch.", "৪. ধীর প্রসারণ: ২ সেকেন্ডে ধীরে হাত নিচে নামান।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.DUMBBELLS,
            movementPattern = "Horizontal Pull"
        ),
        ExerciseItem(
            id = "db_bulgarian_split_squat",
            nameEn = "Dumbbell Bulgarian Split Squat",
            nameBn = "ডাম্বেল বুলগেরিয়ান স্প্লিট স্কোয়াট",
            categoryEn = "Lower Body & Glutes",
            categoryBn = "পা ও গ্লুটস শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quadriceps, Gluteus Maximus & Medius, Hamstrings, Core Stabilizers",
            musclesBn = "উরু, গ্লুটস, হ্যামস্ট্রিং ও ভারসাম্য পেশী",
            setsRepsEn = "3 sets × 8–10 reps/leg",
            setsRepsBn = "৩ সেট × ৮–১০ বার প্রতি পায়ে",
            restSeconds = 75,
            breathingEn = "Inhale smoothly descending straight down; exhale driving through front heel.",
            breathingBn = "নিচে নামার সময় শ্বাস নিন; সামনের পায়ে ভর দিয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Rest rear instep lightly on bench with dumbbells hanging cleanly by sides",
                "Lean torso forward ~15° to load front glute & quad evenly",
                "Drop rear knee straight toward the floor keeping front knee aligned over mid-foot"
            ),
            postureBn = listOf(
                "দুই হাতে ডাম্বেল নিয়ে পেছনের পায়ের পাতা বেঞ্চে রাখুন",
                "বুক সামান্য (১৫°) সামনে ঝুঁকিয়ে সামনের পায়ে ভারসাম্য রাখুন",
                "পেছনের হাঁটু মেঝের দিকে সোজা নামান, সামনের হাঁটু স্থির রাখুন"
            ),
            mistakesEn = listOf("Standing too close to bench cramming front knee", "Pushing off rear foot instead of front leg", "Allowing front knee to collapse inward"),
            mistakesBn = listOf("বেঞ্চের খুব কাছে দাঁড়ানো", "সামনের পায়ের বদলে পেছনের পা দিয়ে ঠেলা", "সামনের হাঁটু ভেতরে হেলে যাওয়া"),
            easierAltEn = "Bodyweight Bulgarian Split Squat or Dumbbell Reverse Lunge.",
            easierAltBn = "বডিওয়েট বুলগেরিয়ান স্প্লিট স্কোয়াট বা ডাম্বেল রিভার্স লাঞ্জ।",
            progressionEn = "Front-Foot Elevated Dumbbell Split Squat or 1.5-Rep Split Squats.",
            progressionBn = "ফ্রন্ট-ফুট এলিভেটেড স্প্লিট স্কোয়াট।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Split Setup: Rear foot resting on bench, dumbbells steady at sides.", "১. প্রস্তুতি: পেছনের পা বেঞ্চে, দুই পাশে ডাম্বেল স্থির।", BreathingCue.INHALE,
                "2. Vertical Drop: Lower rear knee smoothly toward the floor.", "২. নিচে নামা: পেছনের হাঁটু নিয়ন্ত্রিতভাবে মেঝের দিকে নামান।", BreathingCue.INHALE,
                "3. Deep Split: Front thigh parallel to floor, balanced alignment.", "৩. গভীর অবস্থান: সামনের উরু মেঝের সমান্তরাল।", BreathingCue.STEADY,
                "4. Front-Leg Drive: Push powerfully through front foot back to top.", "৪. উপরে ওঠা: সামনের পায়ের শক্তি দিয়ে সোজা উঠে দাঁড়ান।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.DUMBBELLS,
            movementPattern = "Squat"
        ),
        ExerciseItem(
            id = "db_hammer_curl",
            nameEn = "Dumbbell Hammer Curl",
            nameBn = "ডাম্বেল হ্যামার কার্ল",
            categoryEn = "Upper Body Strength",
            categoryBn = "বাহু ও ফোরআর্ম শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Brachialis, Biceps Brachii, Brachioradialis (Forearms)",
            musclesBn = "বাইসেপস, ব্র্যাকিয়ালিস ও ফোরআর্ম",
            setsRepsEn = "3 sets × 10–14 reps",
            setsRepsBn = "৩ সেট × ১০–১৪ বার",
            restSeconds = 45,
            breathingEn = "Exhale curling weights cleanly upward; inhale lowering slowly with zero swinging.",
            breathingBn = "ওজন উপরে তোলার সময় শ্বাস ছাড়ুন; ধীরে নিচে নামানোর সময় শ্বাস নিন।",
            postureEn = listOf(
                "Hold dumbbells with neutral palms-facing-in (thumb up) grip",
                "Pin upper arms quietly beside ribs so elbows stay stationary",
                "Curl cleanly to shoulder height and lower under a slow 2–3 second tempo"
            ),
            postureBn = listOf(
                "হাতের তালু ভেতরের দিকে ও বুড়ো আঙুল উপরে রেখে ডাম্বেল ধরুন",
                "কনুই শরীরের পাশে স্থির রেখে শুধু হাতের নিচের অংশ তুলুন",
                "ঝাঁকুনি ছাড়া ধীরে ২–৩ সেকেন্ডে নিচে নামিয়ে আনুন"
            ),
            mistakesEn = listOf("Swinging hips to use momentum", "Elbows drifting forward ahead of torso", "Dropping weights rapidly"),
            mistakesBn = listOf("কোমর দুলিয়ে ঝাঁকুনি দিয়ে তোলা", "কনুই সামনের দিকে এগিয়ে আনা", "ওজন হঠাৎ ছেড়ে দেওয়া"),
            easierAltEn = "Alternating Seated Hammer Curls with lighter dumbbells.",
            easierAltBn = "বসে এক হাত করে হালকা ডাম্বেল হ্যামার কার্ল।",
            progressionEn = "Incline Bench Dumbbell Curl or Slow Eccentric (4s down) Hammer Curls.",
            progressionBn = "ইনক্লাইন ডাম্বেল কার্ল বা ধীর ৪-সেকেন্ড অবতরণ কার্ল।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Neutral Hang: Palms facing thighs, elbows pinned to ribs.", "১. শুরুর অবস্থান: তালু ভেতরের দিকে, কনুই পাশে স্থির।", BreathingCue.INHALE,
                "2. Strict Curl: Flex elbows bringing thumbs smoothly toward shoulders.", "২. কার্ল: কনুই স্থির রেখে ডাম্বেল কাঁধের দিকে তুলুন।", BreathingCue.EXHALE,
                "3. Peak Contraction: Squeeze biceps & forearms firmly at top.", "৩. শীর্ষ সংকোচন: বাইসেপস ও ফোরআর্ম শক্তভাবে চেপে ধরুন।", BreathingCue.STEADY,
                "4. Slow Lower: Unwind under complete control to full extension.", "৪. ধীর অবতরণ: নিয়ন্ত্রিতভাবে সম্পূর্ণ নিচে নামান।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.DUMBBELLS,
            movementPattern = "Isolation Pull"
        ),

        // ==================== RESISTANCE BANDS (5 Authentic Joint-Friendly Exercises) ====================
        ExerciseItem(
            id = "band_chest_press",
            nameEn = "Banded Standing Chest Press",
            nameBn = "রেজিস্ট্যান্স ব্যান্ড চেস্ট প্রেস",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Pectorals, Anterior Shoulders, Triceps, Anti-Extension Core",
            musclesBn = "বুক, সামনের কাঁধ, ট্রাইসেপস ও কোর",
            setsRepsEn = "3 sets × 12–15 reps",
            setsRepsBn = "৩ সেট × ১২–১৫ বার",
            restSeconds = 45,
            breathingEn = "Inhale drawing hands back to chest; exhale forcefully pressing forward against peak band tension.",
            breathingBn = "হাত বুকের কাছে আনার সময় শ্বাস নিন; সামনে প্রেস করার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Anchor band securely behind you at chest height or loop across upper back",
                "Step into a staggered athletic stance for rock-solid stability",
                "Press hands straight forward keeping elbows at ~45° and shoulders packed down"
            ),
            postureBn = listOf(
                "ব্যান্ডটি বুক বরাবর পেছনে নিরাপদে বাঁধুন বা পিঠের ওপর দিয়ে নিন",
                "ভারসাম্যের জন্য এক পা সামান্য সামনে রেখে দাঁড়ান",
                "কাঁধ স্থির রেখে ৪৫° কনুইয়ে হাত সোজা সামনে প্রেস করুন"
            ),
            mistakesEn = listOf("Letting shoulders roll forward at lockout", "Arching lower back when tension peaks", "Snapping hands back uncontrolled"),
            mistakesBn = listOf("প্রেস শেষে কাঁধ সামনে ঝুঁকিয়ে ফেলা", "টান বাড়লে কোমর বাঁকিয়ে ফেলা", "হঠাৎ হাত পেছনে ছেড়ে দেওয়া"),
            easierAltEn = "Step closer to anchor point to reduce band resistance.",
            easierAltBn = "অ্যাঙ্কর পয়েন্টের কাছে দাঁড়িয়ে টান কমিয়ে চর্চা করুন।",
            progressionEn = "Single-Arm Banded Chest Press to challenge rotational core stability.",
            progressionBn = "এক হাতে ব্যান্ড চেস্ট প্রেস।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Split Stance Ready: Band anchored behind, elbows bent 45° at chest.", "১. প্রস্তুতি: স্ট্যাগার্ড স্ট্যান্সে হাত বুকের পাশে।", BreathingCue.INHALE,
                "2. Press Forward: Extend arms steadily against growing band tension.", "২. সামনে প্রেস: ব্যান্ডের টানের বিপরীতে হাত সোজা সামনে বাড়ান।", BreathingCue.EXHALE,
                "3. Peak Squeeze: Pause 1s squeezing chest together without shrugging.", "৩. শীর্ষ সংকোচন: কাঁধ না তুলে ১ সেকেন্ড বুক সংকুচিত রাখুন।", BreathingCue.STEADY,
                "4. Resist Return: Guide elbows slowly back to chest under tension.", "৪. নিয়ন্ত্রিত ফেরা: ধীরে হাত বুকের কাছে ফিরিয়ে আনুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.RESISTANCE_BANDS,
            movementPattern = "Horizontal Push"
        ),
        ExerciseItem(
            id = "band_seated_row",
            nameEn = "Banded Seated / Anchored Row",
            nameBn = "রেজিস্ট্যান্স ব্যান্ড সিটেড রো",
            categoryEn = "Back & Posture",
            categoryBn = "পিঠ ও ভঙ্গির শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Latissimus Dorsi, Rhomboids, Mid-Trapezius, Biceps",
            musclesBn = "পিঠের ল্যাটস, রম্বয়েডস, মিড-ট্র্যাপ ও বাইসেপস",
            setsRepsEn = "3–4 sets × 12–15 reps",
            setsRepsBn = "৩–৪ সেট × ১২–১৫ বার",
            restSeconds = 45,
            breathingEn = "Exhale pulling band handles toward lower ribs; inhale extending arms smoothly forward.",
            breathingBn = "ব্যান্ড পাঁজরের দিকে টানার সময় শ্বাস ছাড়ুন; হাত সামনে নেওয়ার সময় শ্বাস নিন।",
            postureEn = listOf(
                "Loop band firmly around mid-feet (or anchor in front) and sit tall with chest proud",
                "Lead the pull with elbows gliding close past your ribs",
                "Pinch shoulder blades together for 1 full second at peak tension"
            ),
            postureBn = listOf(
                "ব্যান্ড পায়ের মাঝখানে বা সামনের অ্যাঙ্করে লাগিয়ে মেরুদণ্ড সোজা করে বসুন",
                "কনুই শরীরের কাছ দিয়ে পেছনের দিকে টেনে আনুন",
                "পিঠের দুই কাঁধের হাড় ১ সেকেন্ড একসাথে চেপে ধরে রাখুন"
            ),
            mistakesEn = listOf("Slouching lower back while seated", "Pulling with wrists bent instead of elbows", "Shrugging shoulders upward"),
            mistakesBn = listOf("বসে নিচের পিঠ কুঁজো করে ফেলা", "কনুইয়ের বদলে শুধু কবজি টানা", "কাঁধ কানের দিকে উঠিয়ে নেওয়া"),
            easierAltEn = "Use lighter tension band or wider grip closer to handles.",
            easierAltBn = "হালকা ব্যান্ড ব্যবহার করুন।",
            progressionEn = "Double-band tension or 3-second isometric peak squeeze.",
            progressionBn = "মোটা ব্যান্ড বা ৩ সেকেন্ড হোল্ডসহ রো।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Tall Extension: Spine upright, arms extended forward with light band tension.", "১. প্রসারিত শুরু: মেরুদণ্ড সোজা, হাত সামনে ব্যান্ডে ধরা।", BreathingCue.INHALE,
                "2. Pull Back: Drive elbows cleanly past lower ribs.", "২. টেনে আনা: কনুই পাঁজরের পাশ দিয়ে পেছনে টানুন।", BreathingCue.EXHALE,
                "3. Back Squeeze: Chest proud, shoulder blades pinched together.", "৩. শীর্ষ সংকোচন: বুক উঁচু, কাঁধের ব্লেড সংকুচিত।", BreathingCue.STEADY,
                "4. Controlled Release: Extend smoothly back without rounding spine.", "৪. ধীর প্রসারণ: পিঠ সোজা রেখে হাত সামনে নিন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.RESISTANCE_BANDS,
            movementPattern = "Horizontal Pull"
        ),
        ExerciseItem(
            id = "band_face_pull",
            nameEn = "Banded Face Pull (Shoulder Armor)",
            nameBn = "রেজিস্ট্যান্স ব্যান্ড ফেস পুল",
            categoryEn = "Back & Posture",
            categoryBn = "কাঁধ ও সঠিক ভঙ্গি",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Rear Deltoids, External Rotators (Infraspinatus/Teres Minor), Mid-Traps",
            musclesBn = "পিছনের কাঁধ (রিয়ার ডেল্ট), রোটেটর কাফ ও উপরের পিঠ",
            setsRepsEn = "3 sets × 15 reps",
            setsRepsBn = "৩ সেট × ১৫ বার",
            restSeconds = 40,
            breathingEn = "Exhale pulling band toward forehead while rotating thumbs back; inhale slowly returning.",
            breathingBn = "কপালের দিকে টানার সময় শ্বাস ছাড়ুন; ধীরে ফেরার সময় শ্বাস নিন।",
            postureEn = listOf(
                "Anchor band at upper-chest to eye level and grip with thumbs pointing toward you",
                "Pull band directly toward forehead while externally rotating hands into a 'double-biceps' finish",
                "Keep ribs down and neck relaxed — this fixes rounded desk shoulders"
            ),
            postureBn = listOf(
                "ব্যান্ড চোখ বা বুকের সমান উচ্চতায় বেঁধে বুড়ো আঙুল নিজের দিকে রাখুন",
                "ব্যান্ড কপালের দিকে টেনে হাত বাইরের দিকে ঘোরান",
                "ঘাড় শিথিল রাখুন — এটি কুঁজো কাঁধ ঠিক করতে দারুণ কার্যকর"
            ),
            mistakesEn = listOf("Pulling elbows lower than wrists", "Leaning backward using body weight", "Using overly heavy band causing shoulder shrug"),
            mistakesBn = listOf("কনুই কবজির নিচে নামিয়ে রাখা", "শরীর পেছনে হেলিয়ে টানা", "খুব শক্ত ব্যান্ড নিয়ে কাঁধ তুলে ফেলা"),
            easierAltEn = "Banded Pull-Apart holding band at shoulder height.",
            easierAltBn = "ব্যান্ড পুল-অ্যাপার্ট (হাত সোজা রেখে ব্যান্ড দুপাশে টানা)।",
            progressionEn = "Face Pull with Overhead Y-Press at the end of every rep.",
            progressionBn = "ফেস পুল ও ওভারহেড Y-প্রেস কম্বো।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. High Anchor Hold: Arms straight forward at eye height.", "১. শুরুর অবস্থান: চোখ বরাবর হাত সামনে প্রসারিত।", BreathingCue.INHALE,
                "2. Pull & Rotate: Pull toward forehead, elbows high, thumbs rotating back.", "২. টানা ও ঘোরানো: কনুই উঁচু রেখে কপালের দিকে টানুন।", BreathingCue.EXHALE,
                "3. External Hold: Pause 1s in strong upright posture.", "৩. শীর্ষ হোল্ড: ১ সেকেন্ড পিঠ ও কাঁধের পেছনে টান ধরে রাখুন।", BreathingCue.STEADY,
                "4. Smooth Return: Extend arms back under steady tension.", "৪. নিয়ন্ত্রিত ফেরা: ধীরে হাত সামনে ফিরিয়ে নিন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.RESISTANCE_BANDS,
            movementPattern = "Horizontal Pull"
        ),
        ExerciseItem(
            id = "band_overhead_press",
            nameEn = "Banded Overhead Press",
            nameBn = "রেজিস্ট্যান্স ব্যান্ড ওভারহেড প্রেস",
            categoryEn = "Upper Body Strength",
            categoryBn = "কাঁধ ও বাহুর শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Deltoids, Triceps, Serratus Anterior, Core",
            musclesBn = "কাঁধ (ডেল্টয়েড), ট্রাইসেপস ও কোর",
            setsRepsEn = "3 sets × 10–12 reps",
            setsRepsBn = "৩ সেট × ১০–১২ বার",
            restSeconds = 50,
            breathingEn = "Inhale at shoulder rack; exhale pressing upward smoothly to full lockout.",
            breathingBn = "কাঁধের স্তরে শ্বাস নিন; উপরে চাপ দেওয়ার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Stand securely on center of loop band with both feet (narrower stance = lighter, wider = heavier)",
                "Bring band to front shoulder height with wrists straight and elbows slightly ahead",
                "Press straight overhead keeping glutes engaged and ribcage stacked"
            ),
            postureBn = listOf(
                "লুপ ব্যান্ডের মাঝখানে দুই পা দিয়ে দৃঢ়ভাবে দাঁড়ান",
                "ব্যান্ড কাঁধের সামনে রেখে কবজি সোজা রাখুন",
                "পেট শক্ত রেখে মাথার ওপর সোজা প্রেস করুন"
            ),
            mistakesEn = listOf("Letting band pull elbows too far behind ears", "Arching lower back", "Band slipping under foot — always anchor under mid-arch"),
            mistakesBn = listOf("কনুই অতিরিক্ত পেছনে চলে যাওয়া", "কোমর বাঁকিয়ে ফেলা", "পায়ের মাঝখানে ব্যান্ড ভালোভাবে না চাপা"),
            easierAltEn = "Single-foot anchor (stand on band with only one foot) for gentler tension.",
            easierAltBn = "শুধু এক পা ব্যান্ডের ওপর রেখে কম টানে প্রেস করুন।",
            progressionEn = "Single-Arm Banded Overhead Press or Tempo Pause Press.",
            progressionBn = "এক হাতে ব্যান্ড ওভারহেড প্রেস।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Anchored Rack: Feet firmly on band, hands stacked at shoulders.", "১. কাঁধে অবস্থান: পায়ে ব্যান্ড চাপা, হাত কাঁধ বরাবর।", BreathingCue.INHALE,
                "2. Press Overhead: Drive hands straight upward against band tension.", "২. উপরে প্রেস: ব্যান্ডের টানের বিপরীতে সোজা উপরে তুলুন।", BreathingCue.EXHALE,
                "3. Tall Lockout: Biceps beside ears, braced torso.", "৩. শীর্ষ অবস্থান: বাহু কানের পাশে সোজা, বুক স্থির।", BreathingCue.STEADY,
                "4. Controlled Descent: Resist the band pulling arms back to shoulders.", "৪. ধীর অবতরণ: ব্যান্ডের টান নিয়ন্ত্রণ করে কাঁধে নামান।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.RESISTANCE_BANDS,
            movementPattern = "Vertical Push"
        ),
        ExerciseItem(
            id = "band_pallof_press",
            nameEn = "Banded Pallof Press (Anti-Rotation Core)",
            nameBn = "ব্যান্ড প্যালফ প্রেস (অ্যান্টি-রোটেশন কোর)",
            categoryEn = "Core & Abs",
            categoryBn = "কোর ও মেরুদণ্ড স্থায়িত্ব",
            difficulty = "Beginner",
            activeZone = MuscleZone.CORE,
            musclesEn = "Obliques, Transverse Abdominis, Rectus Abdominis, Glute Medius",
            musclesBn = "অবলিকস, গভীর পেটের পেশী ও গ্লুটস",
            setsRepsEn = "3 sets × 10 reps/side (2s hold)",
            setsRepsBn = "৩ সেট × ১০ বার প্রতি পাশে (২ সেকেন্ড হোল্ড)",
            restSeconds = 40,
            breathingEn = "Inhale at chest; exhale slowly while pressing hands straight out and resisting sideways twist.",
            breathingBn = "বুকের কাছে শ্বাস নিন; হাত সামনে সোজা করে পাশের টান প্রতিরোধের সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Anchor band at sternum height to your side and step out until firm sideways tension pulls you",
                "Hold handle with both hands centered on sternum, knees softly bent",
                "Press hands straight forward and hold 2 full seconds without letting torso twist toward anchor"
            ),
            postureBn = listOf(
                "বুক বরাবর এক পাশে ব্যান্ড বেঁধে টান তৈরি করতে কয়েক কদম সরে দাঁড়ান",
                "দুই হাতে ব্যান্ড বুকের মাঝখানে ধরে হাঁটু সামান্য নমনীয় রাখুন",
                "শরীর মোচড় না খেয়ে হাত সোজা সামনে বাড়িয়ে ২ সেকেন্ড স্থির রাখুন"
            ),
            mistakesEn = listOf("Letting shoulders or hips rotate toward anchor", "Standing with locked knees", "Rushing reps without pause"),
            mistakesBn = listOf("কাঁধ বা কোমর ব্যান্ডের দিকে ঘুরে যাওয়া", "হাঁটু শক্ত করে লক রাখা", "বিরতি না দিয়ে তাড়াহুড়ো করা"),
            easierAltEn = "Step slightly closer to anchor or perform Half-Kneeling Pallof Press.",
            easierAltBn = "হাঁটু গেড়ে হাফ-নিলিং প্যালফ প্রেস।",
            progressionEn = "Overhead Pallof Press or Tall-Kneeling Extended Hold (5 seconds).",
            progressionBn = "ওভারহেড প্যালফ প্রেস বা ৫ সেকেন্ড হোল্ড।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Centered Brace: Both hands at sternum resisting sideways band pull.", "১. কেন্দ্রস্থলে স্থিরতা: দুই হাতে বুকের মাঝে ব্যান্ড ধরা।", BreathingCue.INHALE,
                "2. Press Straight: Extend arms directly forward keeping chest square.", "২. সামনে প্রেস: বুক সোজা রেখে হাত সামনে প্রসারিত করুন।", BreathingCue.EXHALE,
                "3. Anti-Rotation Hold: Lock core for 2 seconds — zero twist!", "৩. ২ সেকেন্ড হোল্ড: শরীর একটুও ঘুরতে দেবেন না।", BreathingCue.STEADY,
                "4. Controlled Draw: Bring hands cleanly back to sternum.", "৪. বুকে ফেরা: নিয়ন্ত্রিতভাবে হাত বুকের কাছে আনুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.RESISTANCE_BANDS,
            movementPattern = "Core Anti-Rotation"
        ),

        // ==================== PULL-UP BAR (4 Authentic Vertical Pull & Hanging Core) ====================
        ExerciseItem(
            id = "bar_pull_up",
            nameEn = "Pronated Pull-Up",
            nameBn = "পুল-আপ (ওভারহ্যান্ড গ্রিপ)",
            categoryEn = "Back & Posture",
            categoryBn = "পিঠ ও বাহুর শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Latissimus Dorsi, Teres Major, Rhomboids, Biceps, Forearms, Core",
            musclesBn = "পিঠের ল্যাটস, রম্বয়েডস, বাইসেপস, গ্রিপ ও কোর",
            setsRepsEn = "3–4 sets × 5–10 reps",
            setsRepsBn = "৩–৪ সেট × ৫–১০ বার",
            restSeconds = 90,
            breathingEn = "Inhale at the active hang; exhale strongly pulling chest toward the bar; inhale lowering slowly.",
            breathingBn = "ঝুলন্ত অবস্থায় শ্বাস নিন; উপরে ওঠার সময় শ্বাস ছাড়ুন এবং ধীরে নিচে নামুন।",
            postureEn = listOf(
                "Grip bar slightly wider than shoulders with palms facing away (pronated)",
                "Depress shoulder blades first (active hang), brace hollow core, then drive elbows down toward ribs",
                "Clear chin smoothly over bar and lower all the way down to straight arms — zero kipping"
            ),
            postureBn = listOf(
                "হাতের তালু সামনের দিকে রেখে কাঁধের চেয়ে সামান্য প্রশস্ত করে বার ধরুন",
                "প্রথমে কাঁধ নিচে টেনে কোর শক্ত করুন, তারপর কনুই পাঁজরের দিকে নামিয়ে উঠুন",
                "থুতনি বারের ওপর নিয়ে ধীরে সম্পূর্ণ হাত সোজা করে নিচে নামুন"
            ),
            mistakesEn = listOf("Half-reps not extending arms at bottom", "Swinging legs (kipping) for momentum", "Craning chin awkwardly while shoulders stay rounded"),
            mistakesBn = listOf("নিচে হাত পুরোপুরি সোজা না করা", "পা দুলিয়ে ঝাঁকুনি দিয়ে ওঠা", "কাঁধ সামনে ঝুঁকিয়ে শুধু থুতনি বাড়ানো"),
            easierAltEn = "Resistance-Band Assisted Pull-Up or 5-second Negative (Eccentric) Pull-Ups.",
            easierAltBn = "রেজিস্ট্যান্স ব্যান্ড সহায়তায় পুল-আপ বা ৫-সেকেন্ড স্লো নেগেটিভ পুল-আপ।",
            progressionEn = "Chest-to-Bar Pull-Up, L-Sit Pull-Up, or Weighted Pull-Up.",
            progressionBn = "চেস্ট-টু-বার পুল-আপ বা L-সিট পুল-আপ।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Active Dead Hang: Arms fully straight, shoulder blades gently engaged.", "১. অ্যাক্টিভ হ্যাং: হাত সম্পূর্ণ সোজা, কাঁধ স্থির।", BreathingCue.INHALE,
                "2. Vertical Pull: Drive elbows down and back toward ribs.", "২. উপরে টানা: কনুই নিচে ও পেছনে পাঁজরের দিকে টানুন।", BreathingCue.EXHALE,
                "3. Chin Over Bar: Chest lifted proud toward bar, zero swing.", "৩. শীর্ষ অবস্থান: বুক বারের কাছাকাছি, থুতনি বারের ওপরে।", BreathingCue.STEADY,
                "4. Full Eccentric: Lower slowly over 2–3s back to straight-arm hang.", "৪. ধীর অবতরণ: ২–৩ সেকেন্ডে ধীরে হাত সোজা করে নিচে নামুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.PULL_UP_BAR,
            movementPattern = "Vertical Pull"
        ),
        ExerciseItem(
            id = "bar_chin_up",
            nameEn = "Supinated Chin-Up",
            nameBn = "চিন-আপ (আন্ডারহ্যান্ড গ্রিপ)",
            categoryEn = "Upper Body Strength",
            categoryBn = "পিঠ ও বাইসেপস শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Latissimus Dorsi, Biceps Brachii, Lower Trapezius, Core",
            musclesBn = "পিঠের ল্যাটস, বাইসেপস ও কোর",
            setsRepsEn = "3–4 sets × 6–10 reps",
            setsRepsBn = "৩–৪ সেট × ৬–১০ বার",
            restSeconds = 90,
            breathingEn = "Exhale driving chest toward the bar; inhale under control descending to full extension.",
            breathingBn = "উপরে ওঠার সময় শ্বাস ছাড়ুন; ধীরে নিচে নামার সময় শ্বাস নিন।",
            postureEn = listOf(
                "Grip bar at shoulder width with palms facing toward you (supinated)",
                "Keep legs stacked smoothly slightly forward in a hollow body line",
                "Pull elbows cleanly down toward hips until upper chest nears bar"
            ),
            postureBn = listOf(
                "হাতের তালু নিজের দিকে রেখে কাঁধ সমান প্রশস্ততায় বার ধরুন",
                "পা সামান্য সামনে স্থির রেখে পেট টানটান রাখুন",
                "কনুই কোমরের দিকে টেনে বুক বারের কাছাকাছি নিয়ে যান"
            ),
            mistakesEn = listOf("Crossing ankles and flaring ribs", "Stopping halfway down", "Dropping suddenly into shoulder joints"),
            mistakesBn = listOf("পাঁজর ছড়িয়ে পিঠ বাঁকানো", "অর্ধেক নেমে আবার ওঠা", "কাঁধে হঠাৎ ঝাঁকুনি দিয়ে নিচে পড়া"),
            easierAltEn = "Band-Assisted Chin-Up or Isometric Top Hold (10–15 seconds).",
            easierAltBn = "ব্যান্ড-অ্যাসিস্টেড চিন-আপ বা শীর্ষে ১০ সেকেন্ড হোল্ড।",
            progressionEn = "Commando Chin-Up or Slow 3-1-3 Tempo Chin-Ups.",
            progressionBn = "স্লো টেম্পো চিন-আপ বা ওয়েটেড চিন-আপ।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Supinated Hang: Palms facing you, full arm stretch.", "১. ঝুলন্ত শুরু: তালু নিজের দিকে, হাত সম্পূর্ণ সোজা।", BreathingCue.INHALE,
                "2. Bicep & Lat Pull: Drive elbows down smoothly.", "২. উপরে ওঠা: বাইসেপস ও ল্যাটসের শক্তিতে শরীর উপরে তুলুন।", BreathingCue.EXHALE,
                "3. Top Lock: Chin clearly above bar, elbows tucked.", "৩. শীর্ষ সংকোচন: থুতনি বারের ওপর, বুক উঁচু।", BreathingCue.STEADY,
                "4. Controlled Lower: Descend smoothly to full hang.", "৪. ধীর অবতরণ: নিয়ন্ত্রণ রেখে সম্পূর্ণ নিচে নামুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.PULL_UP_BAR,
            movementPattern = "Vertical Pull"
        ),
        ExerciseItem(
            id = "bar_scapular_pull",
            nameEn = "Dead Hang Scapular Pull",
            nameBn = "ডেড হ্যাং ও স্ক্যাপুলার পুল",
            categoryEn = "Back & Posture",
            categoryBn = "কাঁধ ও গ্রিপ শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Lower Trapezius, Serratus Anterior, Lats, Forearm Grip",
            musclesBn = "লোয়ার ট্র্যাপ, স্ক্যাপুলা, ল্যাটস ও ফোরআর্ম গ্রিপ",
            setsRepsEn = "3 sets × 10–12 reps",
            setsRepsBn = "৩ সেট × ১০–১২ বার",
            restSeconds = 45,
            breathingEn = "Inhale relaxing shoulders slightly; exhale pulling shoulder blades down away from ears with straight elbows.",
            breathingBn = "ঝুলে শ্বাস নিন; কনুই সোজা রেখে কাঁধ নিচে টানার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hang from bar with completely straight elbows throughout the entire set",
                "Without bending arms, depress shoulder blades down and gently back — body rises 5–8 cm",
                "Hold the elevated active position 1–2 seconds; essential foundation for strict Pull-Ups"
            ),
            postureBn = listOf(
                "সম্পূর্ণ সেটে কনুই সোজা রেখে বারে ঝুলে থাকুন",
                "হাত না ভেঙে শুধু কাঁধের হাড় নিচের দিকে টেনে শরীর সামান্য উপরে তুলুন",
                "১–২ সেকেন্ড ধরে রাখুন — নিখুঁত পুল-আপ শেখার সেরা ভিত্তি"
            ),
            mistakesEn = listOf("Bending elbows instead of moving shoulder blades", "Swinging torso", "Holding breath"),
            mistakesBn = listOf("কাঁধের বদলে কনুই ভেঙে ফেলা", "শরীর দোলানো", "শ্বাস আটকে রাখা"),
            easierAltEn = "30-second Passive Dead Hang with feet lightly touching floor if needed.",
            easierAltBn = "৩০ সেকেন্ড সাধারণ ডেড হ্যাং (দরকার হলে পায়ের আঙুল মাটিতে ছুঁয়ে)।",
            progressionEn = "Active Hang to Strict Pull-Up transition.",
            progressionBn = "স্ক্যাপুলার পুল থেকে পূর্ণ পুল-আপ।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Passive Hang: Straight arms, shoulders elevated gently toward ears.", "১. প্যাসিভ হ্যাং: হাত সোজা, কাঁধ স্বাভাবিক।", BreathingCue.INHALE,
                "2. Scapular Depression: Pull shoulders firmly down away from ears.", "২. স্ক্যাপুলার পুল: কনুই না ভেঙে কাঁধ নিচে টেনে শরীর তুলুন।", BreathingCue.EXHALE,
                "3. Active Hold: Chest lifts slightly, spine long, 2s pause.", "৩. সক্রিয় হোল্ড: ২ সেকেন্ড স্থির রাখুন।", BreathingCue.STEADY,
                "4. Smooth Release: Lower gently back to stretched hang.", "৪. ধীর প্রসারণ: ধীরে শুরুর অবস্থানে ফিরুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.PULL_UP_BAR,
            movementPattern = "Vertical Pull"
        ),
        ExerciseItem(
            id = "bar_hanging_knee_raise",
            nameEn = "Hanging Knee / Leg Raise",
            nameBn = "হ্যাঙ্গিং নি / লেগ রেইজ",
            categoryEn = "Core & Abs",
            categoryBn = "কোর ও পেটের পেশী",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CORE,
            musclesEn = "Lower & Upper Rectus Abdominis, Obliques, Hip Flexors, Grip",
            musclesBn = "পেটের গভীর ও নিচের পেশী, হিপ ফ্লেক্সর ও গ্রিপ",
            setsRepsEn = "3 sets × 10–14 reps",
            setsRepsBn = "৩ সেট × ১০–১৪ বার",
            restSeconds = 60,
            breathingEn = "Exhale completely as you curl pelvis and knees upward; inhale lowering slowly without swinging.",
            breathingBn = "হাঁটু ও কোমর উপরে তোলার সময় শ্বাস ছাড়ুন; দোলন ছাড়া ধীরে নামানোর সময় শ্বাস নিন।",
            postureEn = listOf(
                "Hang in an active shoulder grip with zero body swing",
                "Curl pelvis upward (posterior pelvic tilt) as knees drive past hip height toward chest",
                "Lower legs slowly under 2-second control to stop momentum before the next rep"
            ),
            postureBn = listOf(
                "শরীর স্থির রেখে সক্রিয় কাঁধে বারে ঝুলে থাকুন",
                "শুধু পা নয়, কোমর সামান্য গোল করে হাঁটু বুকের দিকে তুলুন",
                "শরীর যেন না দোলে সেজন্য ২ সেকেন্ডে ধীরে পা নিচে নামান"
            ),
            mistakesEn = listOf("Swinging legs wildly using momentum", "Only lifting thighs without curling pelvis", "Shrugging into passive hang"),
            mistakesBn = listOf("পা ঝুলিয়ে দোলানো", "পেলভিস না ঘুরিয়ে শুধু হাঁটু ওঠানো", "কাঁধ ছেড়ে দিয়ে ঝোলা"),
            easierAltEn = "Lying Floor Leg Raises or Single-Knee Hanging March.",
            easierAltBn = "মেঝেতে শুয়ে লেগ রেইজ বা এক হাঁটু করে হ্যাঙ্গিং মার্চ।",
            progressionEn = "Straight-Leg Hanging Raise or Toes-to-Bar.",
            progressionBn = "সোজা পায়ে লেগ রেইজ বা টোজ-টু-বার।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Still Active Hang: Legs straight, zero momentum.", "১. স্থির ঝুলন্ত অবস্থান: পা সোজা, কোনো দোলন নেই।", BreathingCue.INHALE,
                "2. Pelvic Curl Up: Exhale and tuck knees high toward chest.", "২. হাঁটু ও কোমর তোলা: শ্বাস ছেড়ে হাঁটু বুকের দিকে আনুন।", BreathingCue.EXHALE,
                "3. Top Ab Crunch: Pause 1s with lower abs fully contracted.", "৩. শীর্ষ সংকোচন: ১ সেকেন্ড পেটের পেশী চেপে রাখুন।", BreathingCue.STEADY,
                "4. Anti-Swing Lower: Lower smoothly back to vertical hang.", "৪. ধীর অবতরণ: দোলন থামিয়ে ধীরে পা সোজা করুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.PULL_UP_BAR,
            movementPattern = "Core Flexion"
        ),

        // ==================== KETTLEBELL (4 Authentic Ballistic & Compound Exercises) ====================
        ExerciseItem(
            id = "kb_two_hand_swing",
            nameEn = "Two-Hand Kettlebell Swing",
            nameBn = "টু-হ্যান্ড কেটলবেল সুইং",
            categoryEn = "Cardio & Warm-Up",
            categoryBn = "কন্ডিশনিং ও পোস্টেরিয়র চেইন",
            difficulty = "Intermediate",
            activeZone = MuscleZone.FULL_BODY,
            musclesEn = "Glutes, Hamstrings, Lower Back Stabilizers, Core, Cardiovascular Power",
            musclesBn = "গ্লুটস, হ্যামস্ট্রিং, কোর ও হৃদযন্ত্রের সক্ষমতা",
            setsRepsEn = "4 sets × 15–20 swings",
            setsRepsBn = "৪ সেট × ১৫–২০ বার",
            restSeconds = 60,
            breathingEn = "Sharp inhale as bell hikes back between thighs; crisp power exhale at top plank lockout.",
            breathingBn = "কেটলবেল উরুর মাঝে যাওয়ার সময় শ্বাস নিন; কোমর সোজা করার সময় জোরে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "This is a dynamic HIP HINGE — NOT a squat and NOT an arm front-raise",
                "Hike kettlebell high between upper thighs keeping lats packed and back flat",
                "Snap hips forcefully forward to a standing plank so the bell floats weightlessly to chest height"
            ),
            postureBn = listOf(
                "এটি স্কোয়াট বা হাতের ব্যায়াম নয় — এটি দ্রুত হিপ হিঞ্জ ব্যায়াম",
                "পিঠ সোজা রেখে কেটলবেল উরুর উপরের মাঝখান দিয়ে পেছনে নিন",
                "কোমর ও গ্লুটস জোরে সামনে সোজা করুন যাতে কেটলবেল নিজে থেকেই বুক সমান উঠে আসে"
            ),
            mistakesEn = listOf("Lifting bell with shoulders/arms instead of hip snap", "Squatting deep with knees shooting forward", "Leaning back at the top"),
            mistakesBn = listOf("কোমরের বদলে হাতের জোরে তোলা", "হিপ হিঞ্জের বদলে স্কোয়াট করা", "শীর্ষে পৌঁছে পিঠ পেছনে হেলিয়ে দেওয়া"),
            easierAltEn = "Kettlebell Deadlift (touch-and-go hinge) to master flat-back hip drive.",
            easierAltBn = "কেটলবেল ডেডলিফট দিয়ে হিপ হিঞ্জ আয়ত্ত করুন।",
            progressionEn = "Single-Arm Kettlebell Swing (anti-rotation power).",
            progressionBn = "এক হাতে কেটলবেল সুইং।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Deep Backswing Hinge: Flat back, bell tucked high between thighs.", "১. হিপ হিঞ্জ: পিঠ সোজা, কেটলবেল উরুর মাঝে পেছনে।", BreathingCue.INHALE,
                "2. Explosive Hip Snap: Drive glutes forward powerfully, arms act like ropes.", "২. শক্তিশালী হিপ স্ন্যাপ: গ্লুটস সামনে ঠেলুন, হাত শিথিল।", BreathingCue.EXHALE,
                "3. Standing Plank Float: Bell floats to chest level, abs & glutes locked.", "৩. শীর্ষ ভাসমান বিন্দু: বুক বরাবর কেটলবেল, শরীর সোজা প্ল্যাঙ্ক।", BreathingCue.STEADY,
                "4. Wait & Hinge: Let bell fall close to body before hinging hips back.", "৪. পুনরায় হিঞ্জ: কেটলবেল কোমরের কাছে এলে আবার হিঞ্জ করুন।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.KETTLEBELL,
            movementPattern = "Hip Hinge"
        ),
        ExerciseItem(
            id = "kb_goblet_squat",
            nameEn = "Kettlebell Goblet Squat",
            nameBn = "কেটলবেল গবলেট স্কোয়াট",
            categoryEn = "Lower Body & Glutes",
            categoryBn = "পা ও গ্লুটস শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quadriceps, Glutes, Upper Back Posture, Core",
            musclesBn = "উরু, গ্লুটস, উপরের পিঠ ও কোর",
            setsRepsEn = "3–4 sets × 10–12 reps",
            setsRepsBn = "৩–৪ সেট × ১০–১২ বার",
            restSeconds = 60,
            breathingEn = "Inhale pulling yourself down cleanly; exhale pressing floor away to stand tall.",
            breathingBn = "নিচে নামার সময় শ্বাস নিন; উপরে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Grip kettlebell horns tightly right in front of sternum, elbows pointing down",
                "Keep tall chest and drop hips vertically between heels",
                "Pause 1 second at bottom gently prying knees outward with elbows"
            ),
            postureBn = listOf(
                "কেটলবেলের দুই পাশের হাতল বুকের সামনে শক্ত করে ধরুন",
                "বুক উঁচু রেখে গোড়ালির মাঝে কোমর সোজা নিচে নামান",
                "নিচে ১ সেকেন্ড বিরতি দিয়ে কনুই দিয়ে হাঁটু স্থির রাখুন"
            ),
            mistakesEn = listOf("Rounding upper spine under bell weight", "Collapsing arches of feet", "Cutting depth short"),
            mistakesBn = listOf("উপরের পিঠ সামনের দিকে ঝুঁকানো", "পায়ের পাতা ভেতরে হেলে পড়া", "খুব কম নিচে নামা"),
            easierAltEn = "Bodyweight Squat with arms extended forward for counterbalance.",
            easierAltBn = "বডিওয়েট স্কোয়াট।",
            progressionEn = "Double Kettlebell Front-Rack Squat.",
            progressionBn = "ডাবল কেটলবেল ফ্রন্ট-র‍্যাক স্কোয়াট।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Horn Grip Ready: Bell pinned at chest, tall proud posture.", "১. প্রস্তুতি: বুকের কাছে কেটলবেল শক্তভাবে ধরা।", BreathingCue.INHALE,
                "2. Pull Down: Actively sink hips between heels.", "২. নিচে নামা: নিয়ন্ত্রিতভাবে কোমর নিচে নামান।", BreathingCue.INHALE,
                "3. Bottom Pry: Deep upright squat, full foot planted.", "৩. গভীর স্কোয়াট: উরু সমান্তরাল, পিঠ সোজা।", BreathingCue.STEADY,
                "4. Stand Tall: Drive up cleanly squeezing quads and glutes.", "৪. সোজা ওঠা: পায়ে ভর দিয়ে সোজা দাঁড়ান।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.KETTLEBELL,
            movementPattern = "Squat"
        ),
        ExerciseItem(
            id = "kb_clean_and_press",
            nameEn = "Kettlebell Clean & Overhead Press",
            nameBn = "কেটলবেল ক্লিন ও ওভারহেড প্রেস",
            categoryEn = "Upper Body Strength",
            categoryBn = "সম্পূর্ণ শরীর ও কাঁধের শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.FULL_BODY,
            musclesEn = "Shoulders, Triceps, Glutes, Hamstrings, Core, Forearms",
            musclesBn = "কাঁধ, ট্রাইসেপস, গ্লুটস, কোর ও ফোরআর্ম",
            setsRepsEn = "3 sets × 6–8 reps/side",
            setsRepsBn = "৩ সেট × ৬–৮ বার প্রতি পাশে",
            restSeconds = 75,
            breathingEn = "Exhale gently into rack position; inhale bracing core, then exhale pressing strictly overhead.",
            breathingBn = "র‍্যাক পজিশনে এনে শ্বাস নিন; মাথার ওপর প্রেস করার সময় দৃঢ়ভাবে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Clean bell softly into front-rack (forearm vertical, wrist straight — bell rests cleanly on outer forearm)",
                "Brace glutes and abs firmly, then press straight overhead rotating palm forward",
                "Pull bell back down to rack with control before lowering to hinge"
            ),
            postureBn = listOf(
                "কেটলবেলটি কোমরের শক্তিতে কাঁধের সামনে র‍্যাক পজিশনে আনুন (কবজি সোজা রাখুন)",
                "পেট ও গ্লুটস শক্ত রেখে মাথার ওপর সোজা প্রেস করুন",
                "ধীরে র‍্যাকে নামিয়ে তারপর পরবর্তী রেপ শুরু করুন"
            ),
            mistakesEn = listOf("Banging bell painfully onto back of wrist", "Leaning torso sideways under load", "Bending wrist backward"),
            mistakesBn = listOf("কবজির পেছনে কেটলবেল জোরে লাগা", "একপাশে শরীর হেলে পড়া", "কবজি পেছনে বাঁকা রাখা"),
            easierAltEn = "Strict Kettlebell Floor/Standing Press starting directly from two-hand rack.",
            easierAltBn = "দুই হাতে কাঁধে তুলে শুধু ওভারহেড প্রেস।",
            progressionEn = "Double Kettlebell Clean & Press Complex.",
            progressionBn = "ডাবল কেটলবেল ক্লিন ও প্রেস।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Front Rack: Vertical forearm, wrist neutral, lats tight.", "১. ফ্রন্ট র‍্যাক: কবজি সোজা, কেটলবেল বুকের পাশে স্থির।", BreathingCue.INHALE,
                "2. Vertical Press: Drive kettlebell smoothly overhead.", "২. ওভারহেড প্রেস: কাঁধ ও কোরের শক্তিতে সোজা উপরে তুলুন।", BreathingCue.EXHALE,
                "3. Stacked Lockout: Arm vertical beside ear, core braced.", "৩. শীর্ষ লকআউট: বাহু কানের পাশে সোজা।", BreathingCue.STEADY,
                "4. Controlled Rack: Pull elbow cleanly back to ribcage.", "৪. র‍্যাকে ফেরা: নিয়ন্ত্রিতভাবে কনুই পাঁজরের পাশে নামান।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.KETTLEBELL,
            movementPattern = "Vertical Push"
        ),
        ExerciseItem(
            id = "kb_halo",
            nameEn = "Kettlebell Halo (Shoulder Mobility & Core)",
            nameBn = "কেটলবেল হ্যালো (কাঁধের সচলতা ও কোর)",
            categoryEn = "Mobility & Recovery",
            categoryBn = "সচলতা ও কোর স্থায়িত্ব",
            difficulty = "Beginner",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Rotator Cuff, Deltoids, Upper Back, Thoracic Mobility, Core",
            musclesBn = "রোটেটর কাফ, কাঁধ, উপরের পিঠ ও কোর",
            setsRepsEn = "3 sets × 8 halos/direction",
            setsRepsBn = "৩ সেট × ৮ বার প্রতি দিকে",
            restSeconds = 40,
            breathingEn = "Maintain calm steady nasal breathing while orbiting the kettlebell slowly around your head.",
            breathingBn = "মাথার চারপাশে ধীরে ঘোরানোর সময় স্বাভাবিক ও শান্ত শ্বাস-প্রশ্বাস রাখুন।",
            postureEn = listOf(
                "Hold kettlebell upside down (bottoms-up by the horns) right at chest level",
                "Keep head completely still and ribcage braced — orbit the bell closely around ears and nape",
                "Alternate clockwise and counter-clockwise smoothly with zero rib flare"
            ),
            postureBn = listOf(
                "কেটলবেল উল্টো করে দুই হাতল বুকের সামনে ধরুন",
                "মাথা ও কোমর স্থির রেখে কেটলবেলটি কানের কাছ দিয়ে মাথার চারপাশে ধীরে ঘোরান",
                "ডান ও বাম — উভয় দিকে সমান সংখ্যক বার সম্পন্ন করুন"
            ),
            mistakesEn = listOf("Bobbing head around the kettlebell", "Flaring ribs and arching lower back", "Moving too fast"),
            mistakesBn = listOf("মাথা ঘোরানো বা নড়ানো", "কোমর বাঁকিয়ে ফেলা", "অতিরিক্ত দ্রুত ঘোরানো"),
            easierAltEn = "Perform with a light dumbbell or water bottle.",
            easierAltBn = "হালকা ডাম্বেল দিয়ে হ্যালো করুন।",
            progressionEn = "Half-Kneeling Kettlebell Halo for heightened core engagement.",
            progressionBn = "হাঁটু গেড়ে হাফ-নিলিং কেটলবেল হ্যালো।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Chest Anchor: Inverted kettlebell held steady at chin level.", "১. শুরুর অবস্থান: উল্টো কেটলবেল থুতনির নিচে ধরা।", BreathingCue.INHALE,
                "2. Side Orbit: Sweep close past ear with elbows tucked.", "২. পাশ ঘোরানো: কানের কাছ দিয়ে ধীরে পেছনে নিন।", BreathingCue.STEADY,
                "3. Behind Nape: Drop bell smoothly behind neck keeping head tall.", "৩. মাথার পেছনে: মাথা সোজা রেখে ঘাড়ের পেছন দিয়ে ঘোরান।", BreathingCue.EXHALE,
                "4. Front Complete: Return cleanly to sternum, switch direction.", "৪. সামনে ফেরা: বুকের সামনে এনে বিপরীত দিকে ঘোরান।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.KETTLEBELL,
            movementPattern = "Mobility"
        ),

        // ==================== BARBELL & FULL GYM (4 Foundational Compound Lifts) ====================
        ExerciseItem(
            id = "bb_back_squat",
            nameEn = "Barbell Back Squat",
            nameBn = "বারবেল ব্যাক স্কোয়াট",
            categoryEn = "Lower Body & Glutes",
            categoryBn = "পা ও সম্পূর্ণ শরীরের শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quadriceps, Glutes, Adductors, Spinal Erectors, Core",
            musclesBn = "উরু, গ্লুটস, মেরুদণ্ডের পেশী ও কোর",
            setsRepsEn = "4 sets × 5–8 reps",
            setsRepsBn = "৪ সেট × ৫–৮ বার",
            restSeconds = 120,
            breathingEn = "Deep 360° diaphragmatic breath and core brace at top; exhale past the sticking point standing up.",
            breathingBn = "নামার আগে গভীর শ্বাস নিয়ে পেট শক্ত করুন; উপরে উঠে অর্ধেক পার হলে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Rest barbell snugly across upper trapezius shelf (never on neck bones) with tight upper back",
                "Keep bar path strictly vertical directly over mid-foot throughout descent and ascent",
                "Drive knees outward along toe line, reach parallel depth, and rise powerfully"
            ),
            postureBn = listOf(
                "ঘাড়ের হাড়ে নয়, বরং উপরের পিঠের মাংসপেশিতে বারবেল বসান",
                "নামা ও ওঠার পুরো সময় বারবেল পায়ের মাঝখান বরাবর সোজা রাখুন",
                "হাঁটু পায়ের আঙুল বরাবর রেখে সমান্তরাল গভীরতায় নেমে দৃঢ়ভাবে উঠুন"
            ),
            mistakesEn = listOf("Bar drifting forward over toes", "Knees caving inward", "Skipping safety pins in squat rack"),
            mistakesBn = listOf("বারবেল পায়ের আঙুলের সামনে চলে যাওয়া", "হাঁটু ভেতরে ভেঙে পড়া", "র‍্যাকে সেফটি পিন না লাগানো"),
            easierAltEn = "Dumbbell Goblet Squat or Empty-Bar Box Squat.",
            easierAltBn = "ডাম্বেল গবলেট স্কোয়াট বা খালি বার স্কোয়াট।",
            progressionEn = "Pause Barbell Squat (2s at bottom) or Front Barbell Squat.",
            progressionBn = "২ সেকেন্ড পজ ব্যাক স্কোয়াট বা ফ্রন্ট স্কোয়াট।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Tight Upper Back: Bar set on traps, deep 360° core brace.", "১. শক্ত অবস্থান: ট্র্যাপে বারবেল, গভীর শ্বাস ও কোর শক্ত।", BreathingCue.INHALE,
                "2. Controlled Descent: Break hips and knees together, bar over mid-foot.", "২. নিচে নামা: কোমর ও হাঁটু একসাথে ভেঙে নিয়ন্ত্রিত নামা।", BreathingCue.INHALE,
                "3. Parallel Depth: Hip crease aligned with knees, rigid neutral spine.", "৩. পূর্ণ গভীরতা: উরু সমান্তরাল, মেরুদণ্ড নিরপেক্ষ।", BreathingCue.STEADY,
                "4. Drive Vertical: Push floor down evenly, lock hips & knees tall.", "৪. শক্তিশালী ওঠা: পায়ের মাঝখান দিয়ে চাপ দিয়ে সোজা দাঁড়ান।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.BARBELL_BENCH,
            movementPattern = "Squat"
        ),
        ExerciseItem(
            id = "bb_romanian_deadlift",
            nameEn = "Barbell Romanian Deadlift",
            nameBn = "বারবেল রোমানিয়ান ডেডলিফট",
            categoryEn = "Lower Body & Glutes",
            categoryBn = "হ্যামস্ট্রিং ও পিঠের শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Hamstrings, Gluteus Maximus, Erector Spinae, Lats, Forearms",
            musclesBn = "হ্যামস্ট্রিং, গ্লুটস, ল্যাটস ও নিচের পিঠ",
            setsRepsEn = "3–4 sets × 6–10 reps",
            setsRepsBn = "৩–৪ সেট × ৬–১০ বার",
            restSeconds = 90,
            breathingEn = "Inhale and lock lats down before hinging hips backward; exhale cleanly driving hips through.",
            breathingBn = "হিপ হিঞ্জের আগে শ্বাস নিয়ে ল্যাটস শক্ত করুন; সোজা হওয়ার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Grip barbell just outside thighs with lats engaged pulling the bar gently against your legs",
                "Push hips straight backward with soft ~15° knees until hamstrings reach full stretch below knees",
                "Keep barbell scraping lightly along thighs/shins — never let it drift away"
            ),
            postureBn = listOf(
                "উরুর সামান্য বাইরে বারবেল ধরে ল্যাটস দিয়ে পায়ের গা ঘেঁষে রাখুন",
                "হাঁটু সামান্য নমনীয় রেখে কোমর পেছনে ঠেলে হাঁটুর নিচে নামান",
                "পিঠ সম্পূর্ণ সোজা রেখে গ্লুটসের শক্তিতে সোজা দাঁড়িয়ে পড়ুন"
            ),
            mistakesEn = listOf("Rounding lumbar spine to chase extra depth", "Bar drifting forward off legs", "Hyperextending back at top"),
            mistakesBn = listOf("অতিরিক্ত নিচে নামতে গিয়ে পিঠ গোল করা", "বার পা থেকে সামনে সরে যাওয়া", "উপরে উঠে পিঠ পেছনে বাঁকানো"),
            easierAltEn = "Dumbbell RDL with moderate load.",
            easierAltBn = "ডাম্বেল রোমানিয়ান ডেডলিফট।",
            progressionEn = "Conventional Barbell Deadlift from floor or Deficit RDL.",
            progressionBn = "ফ্লোর থেকে কনভেনশনাল বারবেল ডেডলিফট।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Top Brace: Lats locked, bar touching front of thighs.", "১. শুরুর অবস্থান: ল্যাটস টানটান, বার উরুর সাথে লাগানো।", BreathingCue.INHALE,
                "2. Hinge Back: Push hips backward keeping shins vertical.", "২. হিপ হিঞ্জ: কোমর পেছনে ঠেলে বার উরু বেয়ে নামান।", BreathingCue.INHALE,
                "3. Hamstring Peak: Flat spine, bar right below kneecaps.", "৩. পূর্ণ টান: পিঠ সমতল, হ্যামস্ট্রিং সম্পূর্ণ প্রসারিত।", BreathingCue.STEADY,
                "4. Hip Lockout: Drive glutes forward to tall neutral stance.", "৪. লকআউট: গ্লুটস চেপে সোজা দাঁড়িয়ে যান।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.BARBELL_BENCH,
            movementPattern = "Hip Hinge"
        ),
        ExerciseItem(
            id = "bb_bench_press",
            nameEn = "Barbell Flat Bench Press",
            nameBn = "বারবেল ফ্ল্যাট বেঞ্চ প্রেস",
            categoryEn = "Upper Body Strength",
            categoryBn = "বুক ও ট্রাইসেপস শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Pectoralis Major, Anterior Deltoids, Triceps Brachii",
            musclesBn = "বুক (পেক্টোরালস), সামনের কাঁধ ও ট্রাইসেপস",
            setsRepsEn = "4 sets × 6–8 reps",
            setsRepsBn = "৪ সেট × ৬–৮ বার",
            restSeconds = 120,
            breathingEn = "Inhale smoothly lowering bar to lower sternum; exhale firmly pressing up and slightly back.",
            breathingBn = "বুকের দিকে নামানোর সময় শ্বাস নিন; উপরে প্রেস করার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Set 5 points of contact: head, retracted shoulder blades, glutes on bench, and both feet planted",
                "Lower bar under control to lower chest line with elbows tucked ~45°",
                "Touch lightly without bouncing and press along a clean J-curve back over shoulders"
            ),
            postureBn = listOf(
                "মাথা, কাঁধের ব্লেড ও কোমর বেঞ্চে এবং দুই পা মেঝেতে দৃঢ়ভাবে স্থির রাখুন",
                "কনুই ৪৫° কোণে রেখে বারবেল নিয়ন্ত্রিতভাবে নিচের বুকে নামান",
                "বুকে বাউন্স না করে সোজা ও স্থির গতিতে উপরে প্রেস করুন"
            ),
            mistakesEn = listOf("Bouncing bar off ribcage", "Lifting glutes off the bench", "Flaring elbows 90° outward"),
            mistakesBn = listOf("বুকে বার ঠুকে বাউন্স করা", "বেঞ্চ থেকে কোমর তুলে ফেলা", "কনুই ৯০° বাইরে ছড়ানো"),
            easierAltEn = "Dumbbell Floor/Bench Press or Machine Chest Press.",
            easierAltBn = "ডাম্বেল বেঞ্চ প্রেস বা মেশিন চেস্ট প্রেস।",
            progressionEn = "Paused Bench Press (1s dead stop on chest) or Incline Barbell Press.",
            progressionBn = "১-সেকেন্ড পজ বেঞ্চ প্রেস বা ইনক্লাইন বারবেল প্রেস।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. Unrack & Set: Bar stacked over shoulders, shoulder blades retracted.", "১. সেটআপ: কাঁধ স্থির, বারবেল কাঁধের ওপর সোজা।", BreathingCue.INHALE,
                "2. Controlled Lower: Descend smoothly toward lower chest at 45° elbows.", "২. নিয়ন্ত্রিত অবতরণ: ৪৫° কনুইয়ে বুকের নিচের অংশে নামান।", BreathingCue.INHALE,
                "3. Soft Touch: Gentle contact on sternum, forearms vertical.", "৩. হালকা স্পর্শ: বাউন্স ছাড়া বুকে স্পর্শ, ফোরআর্ম সোজা।", BreathingCue.STEADY,
                "4. Strong Lockout: Drive feet down and press bar back over shoulders.", "৪. শক্তিশালী প্রেস: পায়ে চাপ রেখে বারবেল উপরে তুলুন।", BreathingCue.EXHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.BARBELL_BENCH,
            movementPattern = "Horizontal Push"
        ),
        ExerciseItem(
            id = "bb_bent_over_row",
            nameEn = "Barbell Bent-Over Row",
            nameBn = "বারবেল বেন্ট-ওভার রো",
            categoryEn = "Back & Posture",
            categoryBn = "পিঠ ও ল্যাটস শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Latissimus Dorsi, Rhomboids, Trapezius, Rear Delts, Erector Spinae",
            musclesBn = "ল্যাটস, রম্বয়েডস, ট্র্যাপ, রিয়ার ডেল্ট ও নিচের পিঠ",
            setsRepsEn = "4 sets × 8–10 reps",
            setsRepsBn = "৪ সেট × ৮–১০ বার",
            restSeconds = 90,
            breathingEn = "Inhale maintaining rigid hinged torso; exhale pulling barbell briskly to lower ribs/navel.",
            breathingBn = "ঝুঁকে থাকা অবস্থায় শ্বাস নিয়ে পিঠ শক্ত রাখুন; পেটের দিকে বার টানার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hinge hips cleanly to ~45° torso angle with flat neutral spine and soft knees",
                "Row barbell smoothly into lower ribcage / belly button line — elbows drive back",
                "Lower slowly with full scapular control without jerking torso upright"
            ),
            postureBn = listOf(
                "হাঁটু সামান্য নমনীয় রেখে পিঠ সোজা অবস্থায় ৪৫° কোণে ঝুঁকুন",
                "কনুই পেছনে টেনে বারবেল নিচের পাঁজর বা নাভি বরাবর আনুন",
                "শরীর ঝাঁকুনি না দিয়ে নিয়ন্ত্রিতভাবে নিচে নামিয়ে আনুন"
            ),
            mistakesEn = listOf("Standing nearly upright turning row into a shrug", "Rounding lower back", "Jerking weight with hip bounce"),
            mistakesBn = listOf("বেশি সোজা হয়ে দাঁড়িয়ে শ্রাগ করে ফেলা", "নিচের পিঠ কুঁজো রাখা", "কোমর ঝাঁকিয়ে ওজন তোলা"),
            easierAltEn = "Single-Arm Dumbbell Row with hand supported on bench.",
            easierAltBn = "বেঞ্চে হাত রেখে সিঙ্গেল-আর্ম ডাম্বেল রো।",
            progressionEn = "Strict Pendlay Row from floor dead-stop each rep.",
            progressionBn = "মেঝে থেকে স্ট্রিক্ট পেন্ডলে রো।",
            floorY = 0.84f,
            phases = placeholderPhases(
                "1. 45° Hinge Lock: Neutral flat spine, barbell hanging directly under shoulders.", "১. ৪৫° হিঞ্জ: পিঠ সম্পূর্ণ সোজা, বার কাঁধের নিচে।", BreathingCue.INHALE,
                "2. Pull to Ribs: Drive elbows back cleanly toward hip line.", "২. পাঁজরে টানা: কনুই পেছনে টেনে বারবেল পেটের কাছে আনুন।", BreathingCue.EXHALE,
                "3. Mid-Back Squeeze: Pause briefly touching lower ribs.", "৩. শীর্ষ সংকোচন: পিঠের মাঝখানে দৃঢ় টান অনুভব করুন।", BreathingCue.STEADY,
                "4. Controlled Extend: Lower smoothly without losing torso angle.", "৪. ধীর প্রসারণ: পিঠের কোণ স্থির রেখে বার নিচে নামান।", BreathingCue.INHALE
            ),
            equipmentRequired = WorkoutEquipmentCatalog.BARBELL_BENCH,
            movementPattern = "Horizontal Pull"
        )
    )

    // ==================== 6 AUTHENTIC EQUIPMENT-BASED GUIDED WORKOUT PROGRAMS ====================
    val equipmentPrograms: List<WorkoutProgram> = listOf(
        WorkoutProgram(
            id = "dumbbell_total_strength",
            titleEn = "Dumbbell Total-Body Strength",
            titleBn = "ডাম্বেল সম্পূর্ণ শরীর শক্তি রুটিন",
            subtitleEn = "All 6 ACSM movement patterns: Goblet Squat, RDL, Press, Row & Core",
            subtitleBn = "স্কোয়াট, RDL, চেস্ট প্রেস, রো, শোল্ডার প্রেস ও কোরের পূর্ণাঙ্গ ডাম্বেল সেশন",
            focusAreaEn = "Dumbbells • Full Body",
            focusAreaBn = "ডাম্বেল • সম্পূর্ণ শরীর",
            level = "Intermediate",
            durationMinutes = 24,
            estimatedKcal = 230,
            accentTag = "DUMBBELLS",
            equipmentTag = WorkoutEquipmentCatalog.DUMBBELLS,
            stations = listOf(
                WorkoutStation("cat_cow", targetReps = 8, restAfterSec = 15),
                WorkoutStation("db_goblet_squat", targetReps = 12, restAfterSec = 45),
                WorkoutStation("db_chest_press", targetReps = 12, restAfterSec = 45),
                WorkoutStation("db_single_arm_row", targetReps = 10, restAfterSec = 45),
                WorkoutStation("db_romanian_deadlift", targetReps = 10, restAfterSec = 50),
                WorkoutStation("db_overhead_press", targetReps = 10, restAfterSec = 45),
                WorkoutStation("db_hammer_curl", targetReps = 12, restAfterSec = 30),
                WorkoutStation("forearm_plank", durationSec = 40, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "dumbbell_lower_athletic",
            titleEn = "Dumbbell Lower & Glute Hypertrophy",
            titleBn = "ডাম্বেল লোয়ার বডি ও গ্লুটস",
            subtitleEn = "Balanced quads, hamstrings & unilateral split-squat power",
            subtitleBn = "গবলেট স্কোয়াট, RDL ও বুলগেরিয়ান স্প্লিট স্কোয়াটে পা ও গ্লুটসের শক্তি",
            focusAreaEn = "Dumbbells • Legs",
            focusAreaBn = "ডাম্বেল • পা ও গ্লুটস",
            level = "Advanced",
            durationMinutes = 22,
            estimatedKcal = 240,
            accentTag = "LEGS + DB",
            equipmentTag = WorkoutEquipmentCatalog.DUMBBELLS,
            stations = listOf(
                WorkoutStation("glute_bridge", targetReps = 12, restAfterSec = 20),
                WorkoutStation("db_goblet_squat", targetReps = 12, restAfterSec = 50),
                WorkoutStation("db_romanian_deadlift", targetReps = 10, restAfterSec = 55),
                WorkoutStation("db_bulgarian_split_squat", targetReps = 8, restAfterSec = 55),
                WorkoutStation("db_goblet_squat", targetReps = 10, restAfterSec = 40),
                WorkoutStation("childs_pose_stretch", durationSec = 35, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "resistance_band_sculpt",
            titleEn = "Resistance Band Strength & Posture",
            titleBn = "রেজিস্ট্যান্স ব্যান্ড শক্তি ও ভঙ্গি",
            subtitleEn = "Joint-friendly constant tension push, pull, shoulder armor & anti-rotation core",
            subtitleBn = "জয়েন্ট-বান্ধব ব্যান্ড চেস্ট প্রেস, রো, ফেস পুল, শোল্ডার প্রেস ও প্যালফ প্রেস",
            focusAreaEn = "Bands • Posture",
            focusAreaBn = "ব্যান্ড • শক্তি ও ভঙ্গি",
            level = "Beginner",
            durationMinutes = 18,
            estimatedKcal = 155,
            accentTag = "BANDS",
            equipmentTag = WorkoutEquipmentCatalog.RESISTANCE_BANDS,
            stations = listOf(
                WorkoutStation("cat_cow", targetReps = 8, restAfterSec = 15),
                WorkoutStation("band_chest_press", targetReps = 14, restAfterSec = 35),
                WorkoutStation("band_seated_row", targetReps = 14, restAfterSec = 35),
                WorkoutStation("band_overhead_press", targetReps = 12, restAfterSec = 35),
                WorkoutStation("band_face_pull", targetReps = 15, restAfterSec = 30),
                WorkoutStation("band_pallof_press", targetReps = 10, restAfterSec = 30),
                WorkoutStation("bodyweight_squat", targetReps = 15, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "pullup_bar_calisthenics",
            titleEn = "Pull-Up Bar & Calisthenics Power",
            titleBn = "পুল-আপ বার ও ক্যালিসথেনিক্স পাওয়ার",
            subtitleEn = "Complete upper pull, push & hanging core athlete session",
            subtitleBn = "স্ক্যাপুলার পুল, পুল-আপ, চিন-আপ, পুশ-আপ ও হ্যাঙ্গিং কোরের সমন্বিত রুটিন",
            focusAreaEn = "Pull-Up Bar",
            focusAreaBn = "পুল-আপ বার",
            level = "Advanced",
            durationMinutes = 22,
            estimatedKcal = 220,
            accentTag = "BAR POWER",
            equipmentTag = WorkoutEquipmentCatalog.PULL_UP_BAR,
            stations = listOf(
                WorkoutStation("bar_scapular_pull", targetReps = 10, restAfterSec = 30),
                WorkoutStation("bar_pull_up", targetReps = 6, restAfterSec = 60),
                WorkoutStation("push_up", targetReps = 12, restAfterSec = 45),
                WorkoutStation("bar_chin_up", targetReps = 6, restAfterSec = 60),
                WorkoutStation("pike_push_up", targetReps = 8, restAfterSec = 45),
                WorkoutStation("bar_hanging_knee_raise", targetReps = 12, restAfterSec = 40),
                WorkoutStation("childs_pose_stretch", durationSec = 35, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "kettlebell_conditioning",
            titleEn = "Kettlebell Power & Conditioning",
            titleBn = "কেটলবেল পাওয়ার ও কন্ডিশনিং",
            subtitleEn = "Ballistic hip-hinge swings, goblet squats, clean & press + shoulder halos",
            subtitleBn = "হ্যালো, গবলেট স্কোয়াট, কেটলবেল সুইং ও ক্লিন অ্যান্ড প্রেসের পূর্ণ সেশন",
            focusAreaEn = "Kettlebell",
            focusAreaBn = "কেটলবেল",
            level = "Intermediate",
            durationMinutes = 20,
            estimatedKcal = 250,
            accentTag = "KETTLEBELL",
            equipmentTag = WorkoutEquipmentCatalog.KETTLEBELL,
            stations = listOf(
                WorkoutStation("kb_halo", targetReps = 10, restAfterSec = 25),
                WorkoutStation("kb_goblet_squat", targetReps = 12, restAfterSec = 45),
                WorkoutStation("kb_two_hand_swing", targetReps = 16, restAfterSec = 45),
                WorkoutStation("kb_clean_and_press", targetReps = 8, restAfterSec = 50),
                WorkoutStation("kb_two_hand_swing", targetReps = 16, restAfterSec = 45),
                WorkoutStation("forearm_plank", durationSec = 40, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "barbell_gym_foundations",
            titleEn = "Barbell & Gym Foundational Compounds",
            titleBn = "বারবেল ও জিম ফাউন্ডেশন কম্পাউন্ড",
            subtitleEn = "Gold-standard NSCA Big-4 compound strength: Squat, Bench, RDL & Barbell Row",
            subtitleBn = "বারবেল ব্যাক স্কোয়াট, বেঞ্চ প্রেস, রোমানিয়ান ডেডলিফট ও বেন্ট-ওভার রো",
            focusAreaEn = "Barbell • Gym",
            focusAreaBn = "বারবেল ও জিম",
            level = "Intermediate",
            durationMinutes = 30,
            estimatedKcal = 285,
            accentTag = "BARBELL",
            equipmentTag = WorkoutEquipmentCatalog.BARBELL_BENCH,
            stations = listOf(
                WorkoutStation("cat_cow", targetReps = 8, restAfterSec = 15),
                WorkoutStation("bb_back_squat", targetReps = 8, restAfterSec = 90),
                WorkoutStation("bb_bench_press", targetReps = 8, restAfterSec = 90),
                WorkoutStation("bb_bent_over_row", targetReps = 10, restAfterSec = 75),
                WorkoutStation("bb_romanian_deadlift", targetReps = 8, restAfterSec = 90),
                WorkoutStation("bar_hanging_knee_raise", targetReps = 12, restAfterSec = 45),
                WorkoutStation("childs_pose_stretch", durationSec = 35, restAfterSec = 0)
            )
        )
    )
}
