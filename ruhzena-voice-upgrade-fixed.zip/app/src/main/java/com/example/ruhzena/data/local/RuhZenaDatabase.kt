package com.example.ruhzena.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        WaterLogEntity::class,
        MealLogEntity::class,
        SleepLogEntity::class,
        WorkoutLogEntity::class,
        HabitEntity::class,
        HabitCheckEntity::class,
        JournalEntryEntity::class,
        BookmarkEntity::class,
        AiMessageEntity::class,
        CachedSurahEntity::class,
        AiMemoryEntity::class,
        AiConversationSummaryEntity::class,
        AiTaskStateEntity::class,
        AiProviderHealthEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class RuhZenaDatabase : RoomDatabase() {
    abstract fun waterLogDao(): WaterLogDao
    abstract fun mealLogDao(): MealLogDao
    abstract fun sleepLogDao(): SleepLogDao
    abstract fun workoutLogDao(): WorkoutLogDao
    abstract fun habitDao(): HabitDao
    abstract fun journalDao(): JournalDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun aiMessageDao(): AiMessageDao
    abstract fun cachedSurahDao(): CachedSurahDao
    abstract fun aiMemoryDao(): AiMemoryDao
    abstract fun aiConversationSummaryDao(): AiConversationSummaryDao
    abstract fun aiTaskStateDao(): AiTaskStateDao
    abstract fun aiProviderHealthDao(): AiProviderHealthDao

    companion object {
        @Volatile
        private var INSTANCE: RuhZenaDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `ai_memories` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `category` TEXT NOT NULL,
                        `content` TEXT NOT NULL,
                        `sourcePrompt` TEXT NOT NULL,
                        `isApproved` INTEGER NOT NULL,
                        `isActive` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `ai_conversation_summaries` (
                        `sessionId` TEXT NOT NULL,
                        `summaryText` TEXT NOT NULL,
                        `coveredUpToMessageId` INTEGER NOT NULL,
                        `activeTopicsCsv` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`sessionId`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `ai_task_states` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `sessionId` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `objective` TEXT NOT NULL,
                        `constraints` TEXT NOT NULL,
                        `completedStepsJson` TEXT NOT NULL,
                        `remainingStepsJson` TEXT NOT NULL,
                        `findingsJson` TEXT NOT NULL,
                        `workingNotes` TEXT NOT NULL,
                        `nextAction` TEXT NOT NULL,
                        `unresolvedQuestionsJson` TEXT NOT NULL,
                        `status` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `ai_provider_health` (
                        `modelKey` TEXT NOT NULL,
                        `providerId` TEXT NOT NULL,
                        `modelId` TEXT NOT NULL,
                        `consecutiveFailures` INTEGER NOT NULL,
                        `cooldownUntilMillis` INTEGER NOT NULL,
                        `lastLatencyMs` INTEGER NOT NULL,
                        `lastErrorKind` TEXT NOT NULL,
                        `lastErrorSummary` TEXT NOT NULL,
                        `totalSuccesses` INTEGER NOT NULL,
                        `totalFailures` INTEGER NOT NULL,
                        `sessionDisabled` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`modelKey`)
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): RuhZenaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RuhZenaDatabase::class.java,
                    "ruhzena_local.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
