package com.example.ruhzena.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.SegmentedGlassTabRow
import com.example.ruhzena.core.ui.SegmentedTabItem
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.DailyPrayerSchedule
import com.example.ruhzena.data.islamic.NextPrayerInfo
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.local.HabitCheckEntity
import com.example.ruhzena.data.local.HabitEntity
import com.example.ruhzena.data.local.MealLogEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.data.local.WorkoutLogEntity
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.School
import com.example.ruhzena.data.islamic.IslamicAcademyCurriculum
import com.example.ruhzena.data.islamic.SurahCatalog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private enum class MyDayTab { MONTHLY, MY_DAY, MY_JOURNEY }

@Composable
fun MyDayAndJourneyDialog(
    prefs: UserPreferences,
    nextPrayer: NextPrayerInfo,
    prayerSchedule: DailyPrayerSchedule,
    waterMlToday: Int,
    mealsToday: List<MealLogEntity>,
    workoutsTodayCount: Int,
    habits: List<HabitEntity>,
    habitChecksToday: List<HabitCheckEntity>,
    waterLogsLast7Days: List<WaterLogEntity>,
    mealsLast7Days: List<MealLogEntity>,
    workoutsLast7Days: List<WorkoutLogEntity>,
    waterLogsLast30Days: List<WaterLogEntity> = waterLogsLast7Days,
    mealsLast30Days: List<MealLogEntity> = mealsLast7Days,
    workoutsLast30Days: List<WorkoutLogEntity> = workoutsLast7Days,
    habitChecksLast30Days: List<HabitCheckEntity> = habitChecksToday,
    bookmarksCount: Int = 0,
    journalEntriesCount: Int = 0,
    onToggleHabit: (HabitEntity, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val strings = LocalStrings.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    var selectedTab by rememberSaveable { mutableStateOf(MyDayTab.MONTHLY) }

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler { onDismiss() }

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("my_day_journey_dialog"),
            color = palette.voidBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isBn) "মাসিক ড্যাশবোর্ড ও অগ্রগতি" else "Monthly Progress Dashboard",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary
                        )
                        Text(
                            text = prefs.locationName,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.accentSoft
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_my_day_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textPrimary)
                    }
                }

                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    SegmentedGlassTabRow(
                        items = listOf(
                            SegmentedTabItem(MyDayTab.MONTHLY, if (isBn) "৩০ দিন" else "Monthly", "tab_monthly_records"),
                            SegmentedTabItem(MyDayTab.MY_DAY, if (isBn) "আজকের দিন" else "Today", "tab_my_day"),
                            SegmentedTabItem(MyDayTab.MY_JOURNEY, if (isBn) "৭ দিন" else "7-Day", "tab_my_journey")
                        ),
                        selected = selectedTab,
                        onSelect = { selectedTab = it },
                        scrollable = false
                    )
                }

                when (selectedTab) {
                    MyDayTab.MONTHLY -> MonthlyRecordsContent(
                        prefs = prefs,
                        habits = habits,
                        waterLogsLast30Days = waterLogsLast30Days,
                        mealsLast30Days = mealsLast30Days,
                        workoutsLast30Days = workoutsLast30Days,
                        habitChecksLast30Days = habitChecksLast30Days,
                        bookmarksCount = bookmarksCount,
                        journalEntriesCount = journalEntriesCount
                    )

                    MyDayTab.MY_DAY -> MyDayTimelineContent(
                        prefs = prefs,
                        nextPrayer = nextPrayer,
                        prayerSchedule = prayerSchedule,
                        waterMlToday = waterMlToday,
                        mealsToday = mealsToday,
                        workoutsTodayCount = workoutsTodayCount,
                        habits = habits,
                        habitChecksToday = habitChecksToday,
                        onToggleHabit = onToggleHabit
                    )

                    MyDayTab.MY_JOURNEY -> MyJourneyAnalyticsContent(
                        prefs = prefs,
                        habits = habits,
                        waterLogsLast7Days = waterLogsLast7Days,
                        mealsLast7Days = mealsLast7Days,
                        workoutsLast7Days = workoutsLast7Days
                    )
                }
            }
        }
    }
}

@Composable
private fun MonthlyRecordsContent(
    prefs: UserPreferences,
    habits: List<HabitEntity>,
    waterLogsLast30Days: List<WaterLogEntity>,
    mealsLast30Days: List<MealLogEntity>,
    workoutsLast30Days: List<WorkoutLogEntity>,
    habitChecksLast30Days: List<HabitCheckEntity>,
    bookmarksCount: Int,
    journalEntriesCount: Int
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    val dayActivityScores = remember(waterLogsLast30Days, mealsLast30Days, workoutsLast30Days, habitChecksLast30Days) {
        val waterDays = waterLogsLast30Days.groupBy { it.dateKey }.mapValues { (_, l) -> l.sumOf { it.amountMl } }
        val mealDays = mealsLast30Days.groupBy { it.dateKey }.keys
        val workoutDays = workoutsLast30Days.groupBy { it.dateKey }.keys
        val habitDays = habitChecksLast30Days.groupBy { it.dateKey }.keys
        val keyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dayNumFmt = SimpleDateFormat("d", Locale.US)
        (29 downTo 0).map { ago ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -ago)
            val key = keyFmt.format(cal.time)
            var score = 0
            if ((waterDays[key] ?: 0) > 0) score += 1
            if (mealDays.contains(key)) score += 1
            if (workoutDays.contains(key)) score += 1
            if (habitDays.contains(key)) score += 1
            Pair(dayNumFmt.format(cal.time), score)
        }
    }

    val activeDaysCount = remember(dayActivityScores) { dayActivityScores.count { it.second > 0 } }
    val totalWaterLiters = remember(waterLogsLast30Days) { waterLogsLast30Days.sumOf { it.amountMl } / 1000f }
    val waterGoalDaysMet = remember(waterLogsLast30Days, prefs.hydrationGoalMl) {
        waterLogsLast30Days.groupBy { it.dateKey }.count { (_, logs) -> logs.sumOf { it.amountMl } >= prefs.hydrationGoalMl }
    }
    val totalWorkouts = workoutsLast30Days.size
    val totalWorkoutMins = workoutsLast30Days.sumOf { it.durationMinutes }
    val totalWorkoutKcal = workoutsLast30Days.sumOf { it.estimatedCalories }
    val totalMeals = mealsLast30Days.size
    val avgDailyCalories = remember(mealsLast30Days) {
        val grouped = mealsLast30Days.groupBy { it.dateKey }
        if (grouped.isEmpty()) 0 else grouped.values.sumOf { day -> day.sumOf { it.calories } } / grouped.size
    }
    val totalHabitCheckins = habitChecksLast30Days.size
    val bestHabitStreak = habits.maxOfOrNull { it.bestStreak } ?: 0
    val completedModulesCount = remember(prefs.completedLearningStepsCsv) {
        prefs.completedLearningStepsCsv.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet().size
    }
    val masteredLettersCount = remember(prefs.arabicMasteredLettersCsv) {
        prefs.arabicMasteredLettersCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet().size
    }
    val lastSurah = SurahCatalog.getMeta(prefs.lastReadSurah)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("monthly_records_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 30-Day Activity Heatmap Calendar Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true, elevated = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBn) "গত ৩০ দিনের ধারাবাহিকতা" else "30-Day Activity Heatmap",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    StatusPillBadge(
                        label = "$activeDaysCount / 30 ${if (isBn) "দিন" else "days"}",
                        accentColor = palette.accentSoft
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    dayActivityScores.chunked(10).forEach { rowDays ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            rowDays.forEach { (dayNum, score) ->
                                val bg = when (score) {
                                    0 -> palette.blockBg
                                    1 -> palette.accentPrimary.copy(alpha = 0.30f)
                                    2 -> palette.accentPrimary.copy(alpha = 0.58f)
                                    3 -> palette.accentSoft.copy(alpha = 0.82f)
                                    else -> palette.gold
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(28.dp)
                                        .background(bg, RoundedCornerShape(7.dp))
                                        .border(0.6.dp, palette.borderNeutral.copy(alpha = 0.45f), RoundedCornerShape(7.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = dayNum,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = if (score > 0) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = if (score >= 3) palette.voidBg else palette.textSecondary
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isBn) "প্রতিটি বিভাগে কাজ করলে আজকের ঘরটি স্বয়ংক্রিয়ভাবে আপডেট হয়।" else "Updates automatically every time you log Quran, learning, water, meals, workouts, or habits.",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textMuted
                )
            }
        }

        // Section 1: Quran & Spirituality
        item {
            MonthlySectionRecordCard(
                icon = Icons.AutoMirrored.Filled.MenuBook,
                accent = palette.gold,
                title = if (isBn) "কুরআন ও ইবাদত" else "Quran & Spirituality",
                metrics = listOf(
                    (if (isBn) "সর্বশেষ সূরা" else "Last Read") to "${lastSurah.number}. ${if (isBn) lastSurah.banglaName else lastSurah.englishName} (${prefs.lastReadAyah})",
                    (if (isBn) "তাসবিহ মোট" else "Tasbih Count") to "${prefs.tasbihTotalCount} (${prefs.tasbihSessionsCompleted} ${if (isBn) "সেশন" else "sessions"})",
                    (if (isBn) "বুকমার্ক / হিফজ" else "Bookmarks / Hifz") to "$bookmarksCount saved • ${prefs.hifzRevisionStreak}d streak"
                )
            )
        }

        // Section 2: Islamic Learning Academy
        item {
            MonthlySectionRecordCard(
                icon = Icons.Default.School,
                accent = palette.accentSoft,
                title = if (isBn) "ইসলামিক শিক্ষা অগ্রগতি" else "Islamic Learning Progress",
                metrics = listOf(
                    (if (isBn) "ধাপ সম্পন্ন" else "Guided Steps") to "$completedModulesCount / ${IslamicAcademyCurriculum.guidedModules.size} ${if (isBn) "পাস" else "passed"}",
                    (if (isBn) "আরবি হরফ" else "Arabic Letters") to "$masteredLettersCount / 28 ${if (isBn) "আয়ত্ত" else "mastered"}"
                )
            )
        }

        // Section 3: Workouts & Physical Training
        item {
            MonthlySectionRecordCard(
                icon = Icons.Default.FitnessCenter,
                accent = palette.coral,
                title = if (isBn) "ব্যায়াম ও ফিটনেস (৩০ দিন)" else "Workouts & Fitness (30 Days)",
                metrics = listOf(
                    (if (isBn) "মোট সেশন" else "Sessions") to "$totalWorkouts",
                    (if (isBn) "মোট সময়" else "Active Time") to "$totalWorkoutMins min",
                    (if (isBn) "আনুমানিক বার্ন" else "Est. Burn") to "$totalWorkoutKcal kcal"
                )
            )
        }

        // Section 4: Hydration & Nutrition
        item {
            MonthlySectionRecordCard(
                icon = Icons.Default.WaterDrop,
                accent = palette.sky,
                title = if (isBn) "পানি পান ও পুষ্টি (৩০ দিন)" else "Hydration & Nutrition (30 Days)",
                metrics = listOf(
                    (if (isBn) "মোট পানি" else "Total Water") to String.format(Locale.US, "%.1f L (%d goal days)", totalWaterLiters, waterGoalDaysMet),
                    (if (isBn) "লগকৃত খাবার" else "Meals Logged") to "$totalMeals meals • avg $avgDailyCalories kcal/day"
                )
            )
        }

        // Section 5: Habits & Journal
        item {
            MonthlySectionRecordCard(
                icon = Icons.Default.EditNote,
                accent = palette.success,
                title = if (isBn) "অভ্যাস ও জার্নাল (৩০ দিন)" else "Habits & Reflections (30 Days)",
                metrics = listOf(
                    (if (isBn) "অভ্যাস চেক-ইন" else "Habit Check-ins") to "$totalHabitCheckins completed",
                    (if (isBn) "সর্বোচ্চ স্ট্রিক" else "Best Streak") to "$bestHabitStreak ${if (isBn) "দিন" else "days"}",
                    (if (isBn) "জার্নাল নোট" else "Journal Notes") to "$journalEntriesCount entries"
                )
            )
        }
    }
}

@Composable
private fun MonthlySectionRecordCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: androidx.compose.ui.graphics.Color,
    title: String,
    metrics: List<Pair<String, String>>
) {
    val palette = LocalRuhZenaPalette.current
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(accent.copy(alpha = 0.16f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            metrics.forEach { (label, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.blockBg, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(label, style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)
                    Text(
                        text = value,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = palette.textPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun MyDayTimelineContent(
    prefs: UserPreferences,
    nextPrayer: NextPrayerInfo,
    prayerSchedule: DailyPrayerSchedule,
    waterMlToday: Int,
    mealsToday: List<MealLogEntity>,
    workoutsTodayCount: Int,
    habits: List<HabitEntity>,
    habitChecksToday: List<HabitCheckEntity>,
    onToggleHabit: (HabitEntity, Boolean) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val strings = LocalStrings.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    val doneIds = remember(habitChecksToday) { habitChecksToday.map { it.habitId }.toSet() }
    val uncheckedHabits = remember(habits, doneIds) { habits.filterNot { doneIds.contains(it.id) } }
    val totalCalories = remember(mealsToday) { mealsToday.sumOf { it.calories } }

    val scheduleRows = remember(prayerSchedule, prefs.ramadanModeEnabled, isBn, strings) {
        val base = listOf(
            Triple("FAJR", if (prefs.ramadanModeEnabled) "${strings.fajr} (${if (isBn) "সেহরি শেষ" else "Suhoor Ends"})" else strings.fajr, prayerSchedule.fajrMinutes),
            Triple("DHUHR", strings.dhuhr, prayerSchedule.dhuhrMinutes),
            Triple("ASR", strings.asr, prayerSchedule.asrMinutes),
            Triple("MAGHRIB", if (prefs.ramadanModeEnabled) "${strings.maghrib} (${if (isBn) "ইফতার" else "Iftar"})" else strings.maghrib, prayerSchedule.maghribMinutes),
            Triple("ISHA", strings.isha, prayerSchedule.ishaMinutes)
        )
        base
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("my_day_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (prefs.ramadanModeEnabled) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true, elevated = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBn) "রমজান ফোকাস মোড সক্রিয়" else "Ramadan Rhythm Active",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.gold
                            )
                            Text(
                                text = if (isBn) {
                                    "সেহরি শেষ: ${PrayerCalculator.formatMinutes(prayerSchedule.fajrMinutes)} • ইফতার: ${PrayerCalculator.formatMinutes(prayerSchedule.maghribMinutes)}"
                                } else {
                                    "Suhoor ends: ${PrayerCalculator.formatMinutes(prayerSchedule.fajrMinutes)} • Iftar: ${PrayerCalculator.formatMinutes(prayerSchedule.maghribMinutes)}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                        StatusPillBadge(label = if (isBn) "রমজান" else "Ramadan", accentColor = palette.gold)
                    }
                }
            }
        }

        // Daily Wellness Snapshot
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (isBn) "আজকের স্বাস্থ্য সংক্ষেপ" else "Today's Wellness Snapshot",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SnapshotMiniBox(
                        icon = Icons.Default.WaterDrop,
                        label = strings.hydrationLabel,
                        value = "$waterMlToday / ${prefs.hydrationGoalMl} ml",
                        accent = palette.sky,
                        modifier = Modifier.weight(1f)
                    )
                    SnapshotMiniBox(
                        icon = Icons.Default.Restaurant,
                        label = strings.nutritionLabel,
                        value = "$totalCalories kcal",
                        accent = palette.amber,
                        modifier = Modifier.weight(1f)
                    )
                    SnapshotMiniBox(
                        icon = Icons.Default.FitnessCenter,
                        label = strings.workoutLabel,
                        value = "$workoutsTodayCount ${if (isBn) "টি" else "done"}",
                        accent = palette.accentSoft,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Chronological Prayer Timeline
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isBn) "নামাজের সময়সূচি" else "Daily Prayer Timeline",
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    scheduleRows.forEach { (key, title, mins) ->
                        val isNext = nextPrayer.prayerKey == key
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isNext) palette.accentContainer else palette.blockBg,
                                    RoundedCornerShape(10.dp)
                                )
                                .border(
                                    0.7.dp,
                                    if (isNext) palette.borderAccent else palette.borderNeutral.copy(alpha = 0.45f),
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isNext) palette.accentSoft else palette.textPrimary
                            )
                            Text(
                                text = PrayerCalculator.formatMinutes(mins),
                                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                                color = if (isNext) palette.gold else palette.textSecondary
                            )
                        }
                    }
                }
            }
        }

        // Remaining Habits Agenda
        item {
            Text(
                text = if (isBn) "আজকের বাকি অভ্যাস (${uncheckedHabits.size})" else "Remaining Habits Today (${uncheckedHabits.size})",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary
            )
        }

        if (uncheckedHabits.isEmpty()) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = palette.accentSoft)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isBn) "মাশাআল্লাহ! আজকের সব অভ্যাস সম্পন্ন হয়েছে।" else "MashaAllah! Every tracked habit for today is checked off.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textPrimary
                        )
                    }
                }
            }
        } else {
            items(uncheckedHabits, key = { it.id }) { habit ->
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("my_day_habit_${habit.id}"),
                    contentPadding = PaddingValues(12.dp),
                    onClick = { onToggleHabit(habit, false) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.RadioButtonUnchecked, contentDescription = habit.title, tint = palette.accentSoft)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(habit.title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                                Text(
                                    text = "${habit.category} • ${strings.streakLabel}: ${habit.currentStreak}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.gold
                                )
                            }
                        }
                        StatusPillBadge(label = if (isBn) "সম্পন্ন করুন" else "Tap Done", accentColor = palette.accentSoft)
                    }
                }
            }
        }
    }
}

@Composable
private fun SnapshotMiniBox(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    Column(
        modifier = modifier
            .background(palette.blockBg, RoundedCornerShape(12.dp))
            .border(0.7.dp, palette.borderNeutral.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = palette.textMuted, maxLines = 1)
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
            color = palette.textPrimary,
            maxLines = 1
        )
    }
}

private data class SevenDayMetric(
    val dayLabel: String,
    val waterMl: Int,
    val calories: Int
)

@Composable
private fun MyJourneyAnalyticsContent(
    prefs: UserPreferences,
    habits: List<HabitEntity>,
    waterLogsLast7Days: List<WaterLogEntity>,
    mealsLast7Days: List<MealLogEntity>,
    workoutsLast7Days: List<WorkoutLogEntity>
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    val daysData = remember(waterLogsLast7Days, mealsLast7Days) {
        val waterByDay = waterLogsLast7Days.groupBy { it.dateKey }.mapValues { (_, l) -> l.sumOf { it.amountMl } }
        val calByDay = mealsLast7Days.groupBy { it.dateKey }.mapValues { (_, l) -> l.sumOf { it.calories } }
        val keyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dayFmt = SimpleDateFormat("EEE", Locale.ENGLISH)
        (6 downTo 0).map { ago ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -ago)
            val key = keyFmt.format(cal.time)
            SevenDayMetric(
                dayLabel = dayFmt.format(cal.time).take(3),
                waterMl = waterByDay[key] ?: 0,
                calories = calByDay[key] ?: 0
            )
        }
    }

    val topHabit = remember(habits) { habits.maxByOrNull { it.bestStreak } }
    val weeklyWorkoutCount = workoutsLast7Days.size
    val weeklyWorkoutMinutes = workoutsLast7Days.sumOf { it.durationMinutes }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("my_journey_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 7-Day Dual Bar Chart (Hydration vs Nutrition Calories)
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                Text(
                    text = if (isBn) "৭ দিনের হাইড্রেশন ও পুষ্টি প্রবণতা" else "7-Day Hydration & Calorie Rhythm",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(palette.sky, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isBn) "পানি (ml)" else "Hydration", style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(palette.gold, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isBn) "ক্যালোরি (kcal)" else "Calories", style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                val maxWater = maxOf(prefs.hydrationGoalMl, daysData.maxOfOrNull { it.waterMl } ?: 2500, 1000).toFloat()
                val maxCal = maxOf(2200, daysData.maxOfOrNull { it.calories } ?: 2200, 1000).toFloat()

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(145.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val bottom = h - 8f
                    val top = 10f
                    val usableH = (bottom - top).coerceAtLeast(10f)
                    val slotW = w / daysData.size.coerceAtLeast(1)
                    val barW = (slotW * 0.28f).coerceIn(10f, 22f)

                    daysData.forEachIndexed { idx, stat ->
                        val cx = slotW * idx + slotW / 2f
                        // Hydration bar (left of slot center)
                        val wFrac = (stat.waterMl / maxWater).coerceIn(0f, 1f)
                        val wH = (wFrac * usableH).coerceAtLeast(if (stat.waterMl > 0) 6f else 4f)
                        drawRoundRect(
                            brush = Brush.verticalGradient(listOf(palette.sky, palette.accentPrimary)),
                            topLeft = Offset(cx - barW - 2f, bottom - wH),
                            size = Size(barW, wH),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                        // Calories bar (right of slot center)
                        val cFrac = (stat.calories / maxCal).coerceIn(0f, 1f)
                        val cH = (cFrac * usableH).coerceAtLeast(if (stat.calories > 0) 6f else 4f)
                        drawRoundRect(
                            brush = Brush.verticalGradient(listOf(palette.gold, palette.amber)),
                            topLeft = Offset(cx + 2f, bottom - cH),
                            size = Size(barW, cH),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    daysData.forEach { d ->
                        Text(d.dayLabel, style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                    }
                }
            }
        }

        // Workout Summary Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isBn) "সাপ্তাহিক ব্যায়াম ধারাবাহিকতা" else "7-Day Training Consistency",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary
                        )
                        Text(
                            text = if (isBn) {
                                "$weeklyWorkoutCount সেশন • মোট $weeklyWorkoutMinutes মিনিট"
                            } else {
                                "$weeklyWorkoutCount sessions • $weeklyWorkoutMinutes total active min"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.accentSoft
                        )
                    }
                    StatusPillBadge(label = "$weeklyWorkoutCount / 7", accentColor = palette.gold)
                }
            }
        }

        // Top Habit Streak Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (isBn) "সেরা ধারাবাহিকতা" else "Top Discipline Streak",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                if (topHabit != null) {
                    Text(topHabit.title, style = MaterialTheme.typography.titleSmall, color = palette.gold)
                    Text(
                        text = if (isBn) {
                            "বর্তমান স্ট্রিক: ${topHabit.currentStreak} • সর্বোচ্চ রেকর্ড: ${topHabit.bestStreak} দিন"
                        } else {
                            "Current streak: ${topHabit.currentStreak} • Best record: ${topHabit.bestStreak} days"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                } else {
                    Text(
                        text = if (isBn) "আপনার প্রথম অভ্যাস যোগ করুন।" else "Add your first daily habit to track long-term consistency.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textMuted
                    )
                }
            }
        }
    }
}
