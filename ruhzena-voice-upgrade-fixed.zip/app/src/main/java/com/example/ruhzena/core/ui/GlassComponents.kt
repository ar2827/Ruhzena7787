package com.example.ruhzena.core.ui

import android.graphics.drawable.ColorDrawable
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import com.example.ruhzena.media.LocalRuhZenaSound
import com.example.ui.theme.LocalReducedMotion
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Tactile spring press-scale animation for buttons, chips, and interactive cards.
 */
fun Modifier.pressBounceScale(
    interactionSource: MutableInteractionSource,
    pressedScale: Float = 0.965f
): Modifier = composed {
    val reducedMotion = LocalReducedMotion.current
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && !reducedMotion) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "pressBounceScale"
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/**
 * Crisp Brushed-Silver & Graphite Card with clean metallic borders (no foggy white glare).
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    elevated: Boolean = false,
    accentBorder: Boolean = false,
    cornerRadius: Dp = 18.dp,
    contentPadding: PaddingValues = PaddingValues(14.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val shape = RoundedCornerShape(cornerRadius)
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val topBorderColor by animateColorAsState(
        targetValue = when {
            accentBorder || isPressed -> palette.borderAccent
            else -> palette.highlightTop
        },
        label = "cardTopBorder"
    )
    val bottomBorderColor by animateColorAsState(
        targetValue = when {
            accentBorder -> palette.borderAccent.copy(alpha = 0.65f)
            isPressed -> palette.borderAccent
            else -> palette.borderNeutral
        },
        label = "cardBottomBorder"
    )

    val bgBrush = Brush.verticalGradient(
        colors = listOf(
            if (elevated) palette.cardElevatedBg else palette.cardBg,
            palette.surfaceBg.copy(alpha = 0.96f),
            if (elevated) palette.cardBg else palette.surfaceBg
        )
    )
    val specularSheen = Brush.horizontalGradient(
        colors = listOf(
            Color.Transparent,
            palette.highlightTop.copy(alpha = if (palette.isLight) 0.88f else 0.42f),
            Color.Transparent
        )
    )
    val borderBrush = Brush.verticalGradient(
        colors = listOf(topBorderColor, bottomBorderColor)
    )

    val cardModifier = if (onClick != null) {
        modifier
            .pressBounceScale(interactionSource, pressedScale = 0.985f)
            .clip(shape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = palette.accentPrimary.copy(alpha = 0.16f)),
                onClick = {
                    sound?.playClick()
                    onClick()
                }
            )
    } else {
        modifier.clip(shape)
    }

    Box(
        modifier = cardModifier
            .background(brush = bgBrush, shape = shape)
            .border(width = 1.dp, brush = borderBrush, shape = shape)
    ) {
        // Crisp liquid-glass top refraction edge
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.2.dp)
                .background(specularSheen)
                .align(Alignment.TopCenter)
        )
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}

data class SegmentedTabItem<T>(
    val value: T,
    val label: String,
    val testTag: String = ""
)

data class FoldedDropdownOption<T>(
    val value: T,
    val label: String,
    val subtitle: String = "",
    val icon: ImageVector? = null,
    val testTag: String = ""
)

/**
 * 3D Folded-Page Falling Dropdown Selector.
 * Replaces cluttered horizontal sliding tab strips with an origami/folded-page unfolding cascade:
 * each option swings down sequentially from its top crease (`rotationX = -86° -> 0°`) with spring physics.
 */
@Composable
fun <T> FoldedPageDropdown(
    options: List<FoldedDropdownOption<T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    sectionLabel: String = "",
    triggerTestTag: String = "folded_dropdown_trigger"
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val reducedMotion = LocalReducedMotion.current
    var expanded by remember { mutableStateOf(false) }

    val selectedOption = remember(options, selected) {
        options.firstOrNull { it.value == selected } ?: options.firstOrNull()
    }
    val chevronAngle by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "dropdownChevron"
    )
    val triggerShape = RoundedCornerShape(16.dp)

    Column(modifier = modifier.fillMaxWidth()) {
        // Closed / Anchor Trigger Bar
        Surface(
            onClick = {
                val next = !expanded
                expanded = next
                sound?.playFoldDropdown(opening = next)
            },
            shape = triggerShape,
            color = palette.cardElevatedBg,
            border = BorderStroke(
                width = if (expanded) 1.25.dp else 1.dp,
                color = if (expanded) palette.borderAccent else palette.borderNeutral
            ),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag(triggerTestTag)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (selectedOption?.icon != null) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.accentContainer)
                                .border(0.9.dp, palette.borderAccent, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = selectedOption.icon,
                                contentDescription = null,
                                tint = palette.accentSoft,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        if (sectionLabel.isNotBlank()) {
                            Text(
                                text = sectionLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = selectedOption?.label.orEmpty(),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = palette.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(palette.pillBg)
                            .border(0.8.dp, palette.borderNeutral, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = if (expanded) "Collapse menu" else "Expand menu",
                            tint = palette.accentSoft,
                            modifier = Modifier
                                .size(20.dp)
                                .graphicsLayer { rotationZ = chevronAngle }
                        )
                    }
                }
            }
        }

        // 3D Origami Folded-Page Unfolding Cascade
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(
                expandFrom = Alignment.Top,
                animationSpec = tween(durationMillis = if (reducedMotion) 80 else 220)
            ) + fadeIn(tween(150)),
            exit = shrinkVertically(
                shrinkTowards = Alignment.Top,
                animationSpec = tween(durationMillis = if (reducedMotion) 80 else 180)
            ) + fadeOut(tween(130))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                options.forEachIndexed { idx, opt ->
                    FoldedPageLeafItem(
                        option = opt,
                        index = idx,
                        total = options.size,
                        selected = opt.value == selected,
                        reducedMotion = reducedMotion,
                        onClick = {
                            sound?.playClick(pitch = 1.06f)
                            expanded = false
                            onSelect(opt.value)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun <T> FoldedPageLeafItem(
    option: FoldedDropdownOption<T>,
    index: Int,
    total: Int,
    selected: Boolean,
    reducedMotion: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val rotX = remember { Animatable(if (reducedMotion) 0f else -86f) }
    val leafAlpha = remember { Animatable(if (reducedMotion) 1f else 0f) }

    LaunchedEffect(Unit) {
        if (!reducedMotion) {
            delay(index * 42L)
            leafAlpha.snapTo(1f)
            rotX.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = 0.64f,
                    stiffness = 380f
                )
            )
        }
    }

    val shape = when {
        total == 1 -> RoundedCornerShape(14.dp)
        index == 0 -> RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp, bottomStart = 4.dp, bottomEnd = 4.dp)
        index == total - 1 -> RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomStart = 14.dp, bottomEnd = 14.dp)
        else -> RoundedCornerShape(4.dp)
    }

    val leafBg = if (selected) palette.accentContainer else palette.cardBg
    val leafBorder = if (selected) palette.borderAccent else palette.borderNeutral

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                rotationX = rotX.value
                alpha = leafAlpha.value
                transformOrigin = TransformOrigin(0.5f, 0f)
                cameraDistance = 14f * density
            }
            .clip(shape)
            .background(leafBg)
            .border(width = if (selected) 1.1.dp else 0.85.dp, color = leafBorder, shape = shape)
            .clickable(onClick = onClick)
            .then(if (option.testTag.isNotBlank()) Modifier.testTag(option.testTag) else Modifier)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (option.icon != null) {
                    Icon(
                        imageVector = option.icon,
                        contentDescription = null,
                        tint = if (selected) palette.gold else palette.textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = option.label,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        color = if (selected) palette.accentSoft else palette.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (option.subtitle.isNotBlank()) {
                        Text(
                            text = option.subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            if (selected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = palette.gold,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun <T> SegmentedGlassTabRow(
    items: List<SegmentedTabItem<T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    scrollable: Boolean = false
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val containerShape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(palette.surfaceBg, containerShape)
            .border(1.dp, palette.borderNeutral, containerShape)
            .padding(4.dp)
    ) {
        if (scrollable) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(items.size) { idx ->
                    val item = items[idx]
                    val isSel = item.value == selected
                    SegmentedPillButton(
                        label = item.label,
                        selected = isSel,
                        onClick = {
                            sound?.playClick()
                            onSelect(item.value)
                        },
                        modifier = if (item.testTag.isNotBlank()) Modifier.testTag(item.testTag) else Modifier
                    )
                }
            }
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items.forEach { item ->
                    val isSel = item.value == selected
                    SegmentedPillButton(
                        label = item.label,
                        selected = isSel,
                        onClick = {
                            sound?.playClick()
                            onSelect(item.value)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .then(if (item.testTag.isNotBlank()) Modifier.testTag(item.testTag) else Modifier)
                    )
                }
            }
        }
    }
}

@Composable
private fun SegmentedPillButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    val interactionSource = remember { MutableInteractionSource() }
    val bg by animateColorAsState(
        targetValue = if (selected) palette.accentContainer else Color.Transparent,
        label = "segBg"
    )
    val borderCol by animateColorAsState(
        targetValue = if (selected) palette.borderAccent else Color.Transparent,
        label = "segBorder"
    )
    val textCol by animateColorAsState(
        targetValue = if (selected) palette.accentSoft else palette.textSecondary,
        label = "segText"
    )
    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = modifier
            .pressBounceScale(interactionSource, pressedScale = 0.96f)
            .heightIn(min = 40.dp),
        shape = RoundedCornerShape(10.dp),
        color = bg,
        border = if (selected) BorderStroke(1.dp, borderCol) else null
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                color = textCol,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun EmeraldActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val interactionSource = remember { MutableInteractionSource() }
    Button(
        onClick = {
            sound?.playClick(pitch = 1.04f)
            onClick()
        },
        enabled = enabled,
        interactionSource = interactionSource,
        modifier = modifier
            .pressBounceScale(interactionSource, pressedScale = 0.965f)
            .minimumInteractiveComponentSize()
            .heightIn(min = 50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = palette.accentPrimary,
            contentColor = palette.onAccent,
            disabledContainerColor = palette.pillBg,
            disabledContentColor = palette.textMuted
        ),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp)
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun GlassFilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val interactionSource = remember { MutableInteractionSource() }
    val bgColor by animateColorAsState(
        targetValue = if (selected) palette.accentContainer else palette.pillBg,
        label = "chipBg"
    )
    val borderColor by animateColorAsState(
        targetValue = if (selected) palette.borderAccent else palette.borderNeutral,
        label = "chipBorder"
    )
    val contentColor by animateColorAsState(
        targetValue = if (selected) palette.accentSoft else palette.textSecondary,
        label = "chipText"
    )

    Surface(
        onClick = {
            sound?.playClick()
            onClick()
        },
        interactionSource = interactionSource,
        modifier = modifier
            .pressBounceScale(interactionSource, pressedScale = 0.95f)
            .minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(50),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val palette = LocalRuhZenaPalette.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {},
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailing != null) {
            Spacer(modifier = Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun StatusPillBadge(
    label: String,
    accentColor: Color? = null,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null
) {
    val palette = LocalRuhZenaPalette.current
    val resolvedAccent = accentColor ?: palette.accentSoft
    Row(
        modifier = modifier
            .background(
                color = palette.pillBg,
                shape = RoundedCornerShape(50)
            )
            .border(
                width = 0.9.dp,
                color = resolvedAccent.copy(alpha = 0.55f),
                shape = RoundedCornerShape(50)
            )
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = resolvedAccent,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
        } else {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(resolvedAccent, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = resolvedAccent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun GoldSourceTag(
    sourceText: String,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    Row(
        modifier = modifier
            .background(palette.pillBg, RoundedCornerShape(8.dp))
            .border(0.9.dp, palette.gold.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = sourceText,
            style = MaterialTheme.typography.labelSmall,
            color = palette.gold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Universal phone-safe full-screen Dialog wrapper.
 * Uses decorFitsSystemWindows = true + MATCH_PARENT + safeDrawing + imePadding so bottom buttons
 * are NEVER pushed behind 3-button nav bars, gesture pills, or curved display edges on ANY Android
 * OEM or OS version (Android 9 through Android 16), while providing a smooth spring entrance.
 */
@Composable
fun SafeFullScreenDialog(
    onDismissRequest: () -> Unit,
    centerContent: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val reducedMotion = LocalReducedMotion.current
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = true
        )
    ) {
        val dialogView = LocalView.current
        SideEffect {
            (dialogView.parent as? DialogWindowProvider)?.window?.let { win ->
                WindowCompat.setDecorFitsSystemWindows(win, true)
                win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                win.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
                @Suppress("DEPRECATION")
                win.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
        }

        val alphaAnim = remember { Animatable(if (reducedMotion) 1f else 0f) }
        val scaleAnim = remember { Animatable(if (reducedMotion) 1f else 0.95f) }
        val offsetYAnim = remember { Animatable(if (reducedMotion) 0f else 28f) }
        LaunchedEffect(reducedMotion) {
            if (!reducedMotion) {
                launch { alphaAnim.animateTo(1f, tween(210, easing = FastOutSlowInEasing)) }
                launch {
                    scaleAnim.animateTo(
                        1f,
                        spring(dampingRatio = 0.84f, stiffness = Spring.StiffnessMediumLow)
                    )
                }
                launch {
                    offsetYAnim.animateTo(
                        0f,
                        spring(dampingRatio = 0.86f, stiffness = Spring.StiffnessMediumLow)
                    )
                }
            } else {
                alphaAnim.snapTo(1f)
                scaleAnim.snapTo(1f)
                offsetYAnim.snapTo(0f)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
                .graphicsLayer {
                    alpha = alphaAnim.value
                    scaleX = scaleAnim.value
                    scaleY = scaleAnim.value
                    translationY = offsetYAnim.value
                },
            contentAlignment = if (centerContent) Alignment.Center else Alignment.TopStart,
            content = content
        )
    }
}
