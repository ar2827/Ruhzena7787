package com.example.ruhzena.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ruhzena.ui.exercises.MuscleZone
import com.example.ui.theme.RuhZenaGlassPalette
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Unified 28-Joint Anatomical Human Rig Engine (Flexible Multi-Segment Spine + Analytical 2-Bone IK
 * + Volumetric Muscle/Skin/Fabric Shading).
 *
 * Used identically across Workouts (Halal athletic attire), Salah (Prayer attire), and Wudu
 * (Prayer attire with rolled sleeves & wet-skin water physics) so both Male & Female figures
 * maintain lifelike human proportions, flexible vertebral movement, realistic muscle/cloth detail,
 * and zero detached limbs or bouncing props.
 */

enum class GroundContactMode {
    FEET_ONLY,
    FEET_AND_HANDS,
    KNEELING_SUJUD,
    SUPINE_BACK,
    PRONE_FLOOR,
    ALL_EXTREMITIES,
    MANUAL_WORLD_ANCHOR // Skips vertical auto-shift when root/feet are pinned to exact world coordinates
}

enum class HumanOutfitStyle {
    HALAL_ATHLETIC,
    PRAYER_ROBE
}

enum class HandStyle {
    OPEN_RELAXED,
    FLAT_PRESS,
    FIST,
    CUPPED_WUDU,
    TASHAHHUD_INDEX
}

enum class WuduWetZone {
    NONE,
    HANDS,
    FACE,
    ARMS,
    HEAD,
    FEET
}

/**
 * Optional world-space Inverse Kinematics target locks for hands and feet.
 * Whenever a target is non-null, exact analytical 2-bone IK solves the elbow or knee joint
 * so the hand or foot stays 100% glued to stationary floors, benches, knees, or faucet streams.
 */
data class IkTargetLocks(
    val nearHand: Offset? = null,
    val farHand: Offset? = null,
    val nearFoot: Offset? = null,
    val farFoot: Offset? = null,
    val nearElbowBendSign: Float = -1f, // -1f bends elbow back/down in standard push-up/reach facing right
    val farElbowBendSign: Float = -1f,
    val nearKneeBendSign: Float = 1f,   // +1f bends knee forward when facing right
    val farKneeBendSign: Float = 1f,
    val pinNearToeToWorld: Offset? = null, // Translates entire skeleton so nearToe sits at exact world point!
    val pinFarToeToWorld: Offset? = null
)

data class FkPose(
    val rootXNorm: Float = 0.50f,
    val rootYBias: Float = 0f,           // Vertical offset in head units (negative = up, e.g. jump height)
    val pelvisTiltDeg: Float = -90f,     // Angle pelvis -> lumbar (-90° = upright, 0° = horizontal facing right)
    val spineFlexDeg: Float = 0f,        // Total spine flex split naturally across lumbar (45%) & thoracic (55%)
    val lumbarFlexBias: Float = 0f,      // Extra independent lumbar curve (e.g. Cobra / Cat-Cow / Hollow)
    val thoracicFlexBias: Float = 0f,    // Extra independent thoracic curve
    val neckBendDeg: Float = 0f,         // Relative bend from chest -> neck -> head
    val nearShoulderDeg: Float = 92f,    // World angle of near upper arm
    val nearElbowFlexDeg: Float = -12f,  // Relative elbow bend
    val nearWristBendDeg: Float = 0f,    // Relative wrist bend
    val farShoulderDeg: Float = 88f,     // World angle of far upper arm
    val farElbowFlexDeg: Float = -10f,
    val farWristBendDeg: Float = 0f,
    val nearHipDeg: Float = 90f,         // World angle of near thigh
    val nearKneeFlexDeg: Float = 2f,     // Relative knee bend (+ bends shin backward when facing right)
    val nearAnkleDeg: Float = 0f,        // World angle of near foot (0° = flat pointing right)
    val nearHeelLift: Float = 0f,        // 0f = flat foot, 1f = up on toes/ball of foot
    val farHipDeg: Float = 92f,
    val farKneeFlexDeg: Float = 2f,
    val farAnkleDeg: Float = 0f,
    val farHeelLift: Float = 0f,
    val isFrontalView: Boolean = false,
    val contactMode: GroundContactMode = GroundContactMode.FEET_ONLY,
    val facingRight: Boolean = true,
    val shoulderSpanBias: Float = 1f,
    val handStyle: HandStyle = HandStyle.OPEN_RELAXED
)

/**
 * Full 28-joint solved anatomical skeleton in canvas pixel space.
 */
data class SolvedFkSkeleton(
    // 7-joint flexible spine & cranium
    val pelvis: Offset,
    val lumbar: Offset,
    val thoracic: Offset,
    val waist: Offset,       // Mid-torso convenience alias (= lumbar)
    val chest: Offset,
    val neckBase: Offset,
    val neck: Offset,        // Neck top
    val head: Offset,
    // 10 arm & hand joints
    val nearClavicle: Offset,
    val nearShoulder: Offset,
    val nearElbow: Offset,
    val nearWrist: Offset,
    val nearHand: Offset,
    val farClavicle: Offset,
    val farShoulder: Offset,
    val farElbow: Offset,
    val farWrist: Offset,
    val farHand: Offset,
    // 11 leg & articulated foot joints
    val nearHip: Offset,
    val nearKnee: Offset,
    val nearAnkle: Offset,
    val nearHeel: Offset,
    val nearBall: Offset,
    val nearFoot: Offset,    // Toe tip
    val farHip: Offset,
    val farKnee: Offset,
    val farAnkle: Offset,
    val farHeel: Offset,
    val farBall: Offset,
    val farFoot: Offset,
    // Anatomical metrics & state
    val unit: Float,
    val headAngleDeg: Float,
    val nearElbowFlexDeg: Float,
    val farElbowFlexDeg: Float,
    val nearKneeFlexDeg: Float,
    val farKneeFlexDeg: Float,
    val nearHeelLift: Float,
    val farHeelLift: Float,
    val isFrontalView: Boolean,
    val facingRight: Boolean,
    val handStyle: HandStyle
)

fun lerpAngleDeg(a: Float, b: Float, t: Float): Float {
    var diff = (b - a) % 360f
    if (diff > 180f) diff -= 360f
    if (diff < -180f) diff += 360f
    return a + diff * t
}

fun lerpFkPose(a: FkPose, b: FkPose, t: Float): FkPose = FkPose(
    rootXNorm = lerpFloat(a.rootXNorm, b.rootXNorm, t),
    rootYBias = lerpFloat(a.rootYBias, b.rootYBias, t),
    pelvisTiltDeg = lerpAngleDeg(a.pelvisTiltDeg, b.pelvisTiltDeg, t),
    spineFlexDeg = lerpFloat(a.spineFlexDeg, b.spineFlexDeg, t),
    lumbarFlexBias = lerpFloat(a.lumbarFlexBias, b.lumbarFlexBias, t),
    thoracicFlexBias = lerpFloat(a.thoracicFlexBias, b.thoracicFlexBias, t),
    neckBendDeg = lerpFloat(a.neckBendDeg, b.neckBendDeg, t),
    nearShoulderDeg = lerpAngleDeg(a.nearShoulderDeg, b.nearShoulderDeg, t),
    nearElbowFlexDeg = lerpFloat(a.nearElbowFlexDeg, b.nearElbowFlexDeg, t),
    nearWristBendDeg = lerpFloat(a.nearWristBendDeg, b.nearWristBendDeg, t),
    farShoulderDeg = lerpAngleDeg(a.farShoulderDeg, b.farShoulderDeg, t),
    farElbowFlexDeg = lerpFloat(a.farElbowFlexDeg, b.farElbowFlexDeg, t),
    farWristBendDeg = lerpFloat(a.farWristBendDeg, b.farWristBendDeg, t),
    nearHipDeg = lerpAngleDeg(a.nearHipDeg, b.nearHipDeg, t),
    nearKneeFlexDeg = lerpFloat(a.nearKneeFlexDeg, b.nearKneeFlexDeg, t),
    nearAnkleDeg = lerpAngleDeg(a.nearAnkleDeg, b.nearAnkleDeg, t),
    nearHeelLift = lerpFloat(a.nearHeelLift, b.nearHeelLift, t),
    farHipDeg = lerpAngleDeg(a.farHipDeg, b.farHipDeg, t),
    farKneeFlexDeg = lerpFloat(a.farKneeFlexDeg, b.farKneeFlexDeg, t),
    farAnkleDeg = lerpAngleDeg(a.farAnkleDeg, b.farAnkleDeg, t),
    farHeelLift = lerpFloat(a.farHeelLift, b.farHeelLift, t),
    isFrontalView = if (t < 0.5f) a.isFrontalView else b.isFrontalView,
    contactMode = if (t < 0.5f) a.contactMode else b.contactMode,
    facingRight = if (t < 0.5f) a.facingRight else b.facingRight,
    shoulderSpanBias = lerpFloat(a.shoulderSpanBias, b.shoulderSpanBias, t),
    handStyle = if (t < 0.5f) a.handStyle else b.handStyle
)

private fun rad(deg: Float): Float = (deg * PI / 180.0).toFloat()
private fun deg(rad: Float): Float = (rad * 180.0 / PI).toFloat()

private fun stepJoint(origin: Offset, length: Float, angleDeg: Float): Offset {
    val r = rad(angleDeg)
    return Offset(origin.x + cos(r) * length, origin.y + sin(r) * length)
}

/**
 * Exact Analytical 2-Bone Inverse Kinematics Solver (Law of Cosines).
 * Guarantees exact bone lengths `len1` and `len2` while locking the end effector onto `target`.
 */
fun solveTwoBoneIk(
    root: Offset,
    target: Offset,
    len1: Float,
    len2: Float,
    bendSign: Float
): Pair<Offset, Offset> {
    val dx = target.x - root.x
    val dy = target.y - root.y
    val rawDist = hypot(dx, dy).coerceAtLeast(0.001f)
    val minReach = abs(len1 - len2) + 2.0f
    val maxReach = (len1 + len2) * 0.996f
    val d = rawDist.coerceIn(minReach, maxReach)

    val baseAngle = atan2(dy, dx)
    val cosAlpha = ((len1 * len1 + d * d - len2 * len2) / (2f * len1 * d)).coerceIn(-1f, 1f)
    val alpha = acos(cosAlpha)
    val jointAngle = baseAngle + bendSign * alpha

    val mid = Offset(
        root.x + cos(jointAngle) * len1,
        root.y + sin(jointAngle) * len1
    )
    val clampedEnd = Offset(
        root.x + (dx / rawDist) * d,
        root.y + (dy / rawDist) * d
    )
    return mid to clampedEnd
}

/**
 * Computes articulated foot landmarks (heel, ball of foot, toe tip) from an ankle joint.
 */
private fun solveArticulatedFoot(
    ankle: Offset,
    footAngleDeg: Float,
    heelLift: Float,
    u: Float
): Triple<Offset, Offset, Offset> {
    val dir = Offset(cos(rad(footAngleDeg)), sin(rad(footAngleDeg)))
    val perp = Offset(-dir.y, dir.x)
    val heel = Offset(
        ankle.x - dir.x * u * 0.20f + perp.x * u * (0.14f - heelLift * 0.08f),
        ankle.y - dir.y * u * 0.20f + perp.y * u * (0.14f - heelLift * 0.08f)
    )
    val ballAngle = footAngleDeg + heelLift * 24f
    val ball = stepJoint(ankle, u * 0.48f, ballAngle)
    val toeAngle = footAngleDeg - heelLift * 14f
    val toe = stepJoint(ball, u * 0.28f, toeAngle)
    return Triple(heel, ball, toe)
}

/**
 * Solves exact 28-joint anatomical human skeleton with multi-segment flexible spine,
 * automatic floor contact (or exact world pin), and optional analytical 2-bone IK locks.
 */
fun solveFkSkeleton(
    pose: FkPose,
    canvasSize: Size,
    floorY: Float,
    isFemale: Boolean,
    scaleMultiplier: Float = 1.0f,
    breathPhase: Float = 0f,
    ikLocks: IkTargetLocks? = null,
    physics: BiomechanicalTelemetry = BiomechanicalTelemetry()
): SolvedFkSkeleton {
    // Master anatomical head-height unit (~1/7.8 of standing human height)
    val u = (canvasSize.minDimension * 0.106f * scaleMultiplier).coerceAtLeast(18f)

    // Vitruvian proportional bone lengths (strictly immutable across frames!)
    val lumbarLen = u * (if (isFemale) 0.80f else 0.85f)
    val thoracicLen = u * (if (isFemale) 0.86f else 0.92f)
    val upperChestLen = u * (if (isFemale) 0.66f else 0.72f)
    val neckBaseLen = u * 0.24f
    val neckTopLen = u * 0.30f
    val headCenterLen = u * 0.62f

    val upperArmLen = u * (if (isFemale) 1.48f else 1.56f)
    val forearmLen = u * (if (isFemale) 1.32f else 1.40f)
    val handLen = u * 0.50f

    val thighLen = u * (if (isFemale) 2.02f else 2.10f)
    val shinLen = u * (if (isFemale) 1.94f else 2.04f)

    // Real diaphragmatic breathing lift + subtle isometric neuromuscular stabilization
    val breathSignal = if (abs(physics.breathExpansion) > 0.001f) physics.breathExpansion else sin(breathPhase * 2f * PI.toFloat())
    val breathLift = breathSignal * u * 0.036f
    val jitterY = physics.isometricMicroJitterU * u
    val facingSign = if (pose.facingRight) 1f else -1f

    // Landing shock absorption flexes knees & hips dynamically on foot strike (only when grounded/standing)
    val canAbsorbKnee = pose.contactMode == GroundContactMode.FEET_ONLY || pose.contactMode == GroundContactMode.ALL_EXTREMITIES
    val absorbDeg = if (canAbsorbKnee) physics.landingCompression * 18f else 0f
    val dynamicSpineLean = if (canAbsorbKnee) physics.landingCompression * 6f * facingSign else 0f

    // 1. Multi-segment flexible spine chain with real CoM horizontal counter-shift
    val rawPelvis = Offset(
        canvasSize.width * pose.rootXNorm + physics.comShiftXU * u * facingSign,
        floorY - u * 4.0f + jitterY
    )
    val lumbarAngle = pose.pelvisTiltDeg + pose.spineFlexDeg * 0.35f + pose.lumbarFlexBias + dynamicSpineLean * 0.45f
    val rawLumbar = stepJoint(rawPelvis, lumbarLen, lumbarAngle)
    val thoracicAngle = lumbarAngle + pose.spineFlexDeg * 0.40f + pose.thoracicFlexBias + dynamicSpineLean * 0.55f
    val rawThoracic = stepJoint(rawLumbar, thoracicLen + breathLift * 0.55f, thoracicAngle)
    val chestAngle = thoracicAngle + pose.spineFlexDeg * 0.25f
    val rawChest = stepJoint(rawThoracic, upperChestLen + breathLift * 0.65f, chestAngle)
    val neckAngle = chestAngle + pose.neckBendDeg * 0.55f - dynamicSpineLean * 0.35f
    val rawNeckBase = stepJoint(rawChest, neckBaseLen, neckAngle)
    val rawNeckTop = stepJoint(rawNeckBase, neckTopLen, neckAngle + pose.neckBendDeg * 0.20f)
    val headAngle = chestAngle + pose.neckBendDeg - dynamicSpineLean * 0.45f
    val rawHead = stepJoint(rawNeckTop, headCenterLen, headAngle)

    // 2. Clavicle, Shoulder & Hip anatomical sockets
    val shoulderSpan = if (pose.isFrontalView) {
        u * (if (isFemale) 0.76f else 0.94f)
    } else {
        u * 0.16f * pose.shoulderSpanBias
    }
    val hipSpan = if (pose.isFrontalView) {
        u * (if (isFemale) 0.58f else 0.50f)
    } else {
        u * 0.12f * pose.shoulderSpanBias
    }

    val chestDir = Offset(cos(rad(chestAngle)), sin(rad(chestAngle)))
    val shoulderDrop = Offset(-chestDir.x * u * 0.10f, -chestDir.y * u * 0.10f)

    val rawNearClavicle = if (pose.isFrontalView) {
        Offset(rawChest.x + shoulderSpan * 0.45f, rawChest.y + u * 0.04f)
    } else {
        Offset(rawChest.x + shoulderSpan * 0.28f + shoulderDrop.x * 0.5f, rawChest.y + shoulderDrop.y * 0.5f)
    }
    val rawFarClavicle = if (pose.isFrontalView) {
        Offset(rawChest.x - shoulderSpan * 0.45f, rawChest.y + u * 0.04f)
    } else {
        Offset(rawChest.x - shoulderSpan * 0.30f + shoulderDrop.x * 0.5f, rawChest.y + shoulderDrop.y * 0.5f)
    }

    val rawNearShoulder = if (pose.isFrontalView) {
        Offset(rawChest.x + shoulderSpan, rawChest.y + u * 0.08f)
    } else {
        Offset(rawChest.x + shoulderSpan * 0.55f + shoulderDrop.x, rawChest.y + shoulderDrop.y + u * 0.05f)
    }
    val rawFarShoulder = if (pose.isFrontalView) {
        Offset(rawChest.x - shoulderSpan, rawChest.y + u * 0.08f)
    } else {
        Offset(rawChest.x - shoulderSpan * 0.65f + shoulderDrop.x, rawChest.y + shoulderDrop.y - u * 0.04f)
    }

    val rawNearHip = if (pose.isFrontalView) {
        Offset(rawPelvis.x + hipSpan, rawPelvis.y + u * 0.08f)
    } else {
        Offset(rawPelvis.x + hipSpan * 0.50f, rawPelvis.y + u * 0.05f)
    }
    val rawFarHip = if (pose.isFrontalView) {
        Offset(rawPelvis.x - hipSpan, rawPelvis.y + u * 0.08f)
    } else {
        Offset(rawPelvis.x - hipSpan * 0.60f, rawPelvis.y - u * 0.04f)
    }

    // 3. Initial FK chains for arms & legs
    var rawNearElbow = stepJoint(rawNearShoulder, upperArmLen, pose.nearShoulderDeg)
    val nearForearmAngle = pose.nearShoulderDeg + pose.nearElbowFlexDeg
    var rawNearWrist = stepJoint(rawNearElbow, forearmLen, nearForearmAngle)
    var rawNearHand = stepJoint(rawNearWrist, handLen, nearForearmAngle + pose.nearWristBendDeg)

    var rawFarElbow = stepJoint(rawFarShoulder, upperArmLen, pose.farShoulderDeg)
    val farForearmAngle = pose.farShoulderDeg + pose.farElbowFlexDeg
    var rawFarWrist = stepJoint(rawFarElbow, forearmLen, farForearmAngle)
    var rawFarHand = stepJoint(rawFarWrist, handLen, farForearmAngle + pose.farWristBendDeg)

    val effNearHipDeg = pose.nearHipDeg - absorbDeg * 0.55f * facingSign
    val effNearKneeFlex = pose.nearKneeFlexDeg + absorbDeg * 1.15f * facingSign
    val effFarHipDeg = pose.farHipDeg - absorbDeg * 0.55f * facingSign
    val effFarKneeFlex = pose.farKneeFlexDeg + absorbDeg * 1.15f * facingSign
    val effNearHeelLift = (pose.nearHeelLift + physics.footRollPhase * 0.22f).coerceIn(0f, 1f)
    val effFarHeelLift = (pose.farHeelLift + physics.footRollPhase * 0.14f).coerceIn(0f, 1f)

    var rawNearKnee = stepJoint(rawNearHip, thighLen, effNearHipDeg)
    val nearShinAngle = effNearHipDeg + effNearKneeFlex
    var rawNearAnkle = stepJoint(rawNearKnee, shinLen, nearShinAngle)
    var (rawNearHeel, rawNearBall, rawNearFoot) = solveArticulatedFoot(rawNearAnkle, pose.nearAnkleDeg, effNearHeelLift, u)

    var rawFarKnee = stepJoint(rawFarHip, thighLen, effFarHipDeg)
    val farShinAngle = effFarHipDeg + effFarKneeFlex
    var rawFarAnkle = stepJoint(rawFarKnee, shinLen, farShinAngle)
    var (rawFarHeel, rawFarBall, rawFarFoot) = solveArticulatedFoot(rawFarAnkle, pose.farAnkleDeg, effFarHeelLift, u)

    // 4. Whole-body Grounding / World-Pin Translation
    val shiftVec: Offset = when {
        ikLocks?.pinNearToeToWorld != null -> {
            val target = ikLocks.pinNearToeToWorld
            Offset(target.x - rawNearFoot.x, target.y - rawNearFoot.y + pose.rootYBias * u)
        }
        ikLocks?.pinFarToeToWorld != null -> {
            val target = ikLocks.pinFarToeToWorld
            Offset(target.x - rawFarFoot.x, target.y - rawFarFoot.y + pose.rootYBias * u)
        }
        pose.contactMode == GroundContactMode.MANUAL_WORLD_ANCHOR -> {
            Offset(0f, pose.rootYBias * u)
        }
        else -> {
            val contactPoints: List<Float> = when (pose.contactMode) {
                GroundContactMode.FEET_ONLY -> listOf(
                    rawNearHeel.y + u * 0.08f, rawNearBall.y + u * 0.12f, rawNearFoot.y + u * 0.10f,
                    rawFarHeel.y + u * 0.08f, rawFarBall.y + u * 0.12f, rawFarFoot.y + u * 0.10f
                )
                GroundContactMode.FEET_AND_HANDS -> listOf(
                    rawNearBall.y + u * 0.12f, rawNearFoot.y + u * 0.10f,
                    rawFarBall.y + u * 0.12f, rawFarFoot.y + u * 0.10f,
                    rawNearWrist.y + u * 0.14f, rawNearHand.y + u * 0.11f, rawNearElbow.y + u * 0.15f,
                    rawNearKnee.y + u * 0.22f
                )
                GroundContactMode.KNEELING_SUJUD -> listOf(
                    rawNearKnee.y + u * 0.22f, rawFarKnee.y + u * 0.22f,
                    rawNearAnkle.y + u * 0.16f, rawNearFoot.y + u * 0.12f,
                    rawNearWrist.y + u * 0.12f, rawNearHand.y + u * 0.10f,
                    rawHead.y + u * 0.56f
                )
                GroundContactMode.SUPINE_BACK -> listOf(
                    rawPelvis.y + u * 0.42f, rawThoracic.y + u * 0.42f, rawChest.y + u * 0.42f,
                    rawNearHeel.y + u * 0.12f, rawNearFoot.y + u * 0.12f,
                    rawFarHeel.y + u * 0.12f, rawHead.y + u * 0.54f
                )
                GroundContactMode.PRONE_FLOOR -> listOf(
                    rawPelvis.y + u * 0.34f, rawLumbar.y + u * 0.32f, rawThoracic.y + u * 0.34f,
                    rawNearKnee.y + u * 0.22f, rawNearAnkle.y + u * 0.18f, rawNearFoot.y + u * 0.12f
                )
                else -> listOf(
                    rawNearAnkle.y + u * 0.20f, rawNearFoot.y + u * 0.12f,
                    rawFarAnkle.y + u * 0.20f, rawFarFoot.y + u * 0.12f,
                    rawNearKnee.y + u * 0.22f, rawNearWrist.y + u * 0.14f, rawNearHand.y + u * 0.12f,
                    rawPelvis.y + u * 0.36f
                )
            }
            val lowestContactY = contactPoints.maxOrNull() ?: rawNearAnkle.y
            // True ballistic parabolic flight lift (-gravityFlightLiftU * u) raises figure cleanly off floor!
            val ballisticLiftY = -physics.gravityFlightLiftU * u
            Offset(0f, (floorY - lowestContactY) + pose.rootYBias * u + ballisticLiftY)
        }
    }

    fun shift(p: Offset) = Offset(p.x + shiftVec.x, p.y + shiftVec.y)

    val pelvis = shift(rawPelvis)
    val lumbar = shift(rawLumbar)
    val thoracic = shift(rawThoracic)
    val chest = shift(rawChest)
    val neckBase = shift(rawNeckBase)
    val neck = shift(rawNeckTop)
    val head = shift(rawHead)

    val nearClavicle = shift(rawNearClavicle)
    val farClavicle = shift(rawFarClavicle)
    val nearShoulder = shift(rawNearShoulder)
    val farShoulder = shift(rawFarShoulder)
    val nearHip = shift(rawNearHip)
    val farHip = shift(rawFarHip)

    var nearElbow = shift(rawNearElbow)
    var nearWrist = shift(rawNearWrist)
    var nearHand = shift(rawNearHand)
    var farElbow = shift(rawFarElbow)
    var farWrist = shift(rawFarWrist)
    var farHand = shift(rawFarHand)

    var nearKnee = shift(rawNearKnee)
    var nearAnkle = shift(rawNearAnkle)
    var nearHeel = shift(rawNearHeel)
    var nearBall = shift(rawNearBall)
    var nearFoot = shift(rawNearFoot)

    var farKnee = shift(rawFarKnee)
    var farAnkle = shift(rawFarAnkle)
    var farHeel = shift(rawFarHeel)
    var farBall = shift(rawFarBall)
    var farFoot = shift(rawFarFoot)

    var finalNearElbowFlex = pose.nearElbowFlexDeg
    var finalFarElbowFlex = pose.farElbowFlexDeg
    var finalNearKneeFlex = pose.nearKneeFlexDeg
    var finalFarKneeFlex = pose.farKneeFlexDeg

    // 5. Analytical 2-Bone IK Post-Pass (locks wrists/ankles solidly onto stationary surfaces!)
    if (ikLocks != null) {
        ikLocks.nearHand?.let { target ->
            val (ikElbow, ikWrist) = solveTwoBoneIk(nearShoulder, target, upperArmLen, forearmLen, ikLocks.nearElbowBendSign)
            nearElbow = ikElbow
            nearWrist = ikWrist
            val handAngle = if (pose.handStyle == HandStyle.FLAT_PRESS) 0f
            else deg(atan2(ikWrist.y - ikElbow.y, ikWrist.x - ikElbow.x)) + pose.nearWristBendDeg
            nearHand = stepJoint(nearWrist, handLen, handAngle)
            val upperA = deg(atan2(nearElbow.y - nearShoulder.y, nearElbow.x - nearShoulder.x))
            val lowerA = deg(atan2(nearWrist.y - nearElbow.y, nearWrist.x - nearElbow.x))
            finalNearElbowFlex = lerpAngleDeg(0f, lowerA - upperA, 1f)
        }
        ikLocks.farHand?.let { target ->
            val (ikElbow, ikWrist) = solveTwoBoneIk(farShoulder, target, upperArmLen, forearmLen, ikLocks.farElbowBendSign)
            farElbow = ikElbow
            farWrist = ikWrist
            val handAngle = if (pose.handStyle == HandStyle.FLAT_PRESS) 0f
            else deg(atan2(ikWrist.y - ikElbow.y, ikWrist.x - ikElbow.x)) + pose.farWristBendDeg
            farHand = stepJoint(farWrist, handLen, handAngle)
            val upperA = deg(atan2(farElbow.y - farShoulder.y, farElbow.x - farShoulder.x))
            val lowerA = deg(atan2(farWrist.y - farElbow.y, farWrist.x - farElbow.x))
            finalFarElbowFlex = lerpAngleDeg(0f, lowerA - upperA, 1f)
        }
        ikLocks.nearFoot?.let { target ->
            val (ikKnee, ikAnkle) = solveTwoBoneIk(nearHip, target, thighLen, shinLen, ikLocks.nearKneeBendSign)
            nearKnee = ikKnee
            nearAnkle = ikAnkle
            val footSolved = solveArticulatedFoot(nearAnkle, pose.nearAnkleDeg, pose.nearHeelLift, u)
            nearHeel = footSolved.first
            nearBall = footSolved.second
            nearFoot = footSolved.third
            val thighA = deg(atan2(nearKnee.y - nearHip.y, nearKnee.x - nearHip.x))
            val shinA = deg(atan2(nearAnkle.y - nearKnee.y, nearAnkle.x - nearKnee.x))
            finalNearKneeFlex = lerpAngleDeg(0f, shinA - thighA, 1f)
        }
        ikLocks.farFoot?.let { target ->
            val (ikKnee, ikAnkle) = solveTwoBoneIk(farHip, target, thighLen, shinLen, ikLocks.farKneeBendSign)
            farKnee = ikKnee
            farAnkle = ikAnkle
            val footSolved = solveArticulatedFoot(farAnkle, pose.farAnkleDeg, pose.farHeelLift, u)
            farHeel = footSolved.first
            farBall = footSolved.second
            farFoot = footSolved.third
            val thighA = deg(atan2(farKnee.y - farHip.y, farKnee.x - farHip.x))
            val shinA = deg(atan2(farAnkle.y - farKnee.y, farAnkle.x - farKnee.x))
            finalFarKneeFlex = lerpAngleDeg(0f, shinA - thighA, 1f)
        }
    }

    return SolvedFkSkeleton(
        pelvis = pelvis,
        lumbar = lumbar,
        thoracic = thoracic,
        waist = lumbar,
        chest = chest,
        neckBase = neckBase,
        neck = neck,
        head = head,
        nearClavicle = nearClavicle,
        nearShoulder = nearShoulder,
        nearElbow = nearElbow,
        nearWrist = nearWrist,
        nearHand = nearHand,
        farClavicle = farClavicle,
        farShoulder = farShoulder,
        farElbow = farElbow,
        farWrist = farWrist,
        farHand = farHand,
        nearHip = nearHip,
        nearKnee = nearKnee,
        nearAnkle = nearAnkle,
        nearHeel = nearHeel,
        nearBall = nearBall,
        nearFoot = nearFoot,
        farHip = farHip,
        farKnee = farKnee,
        farAnkle = farAnkle,
        farHeel = farHeel,
        farBall = farBall,
        farFoot = farFoot,
        unit = u,
        headAngleDeg = headAngle,
        nearElbowFlexDeg = finalNearElbowFlex,
        farElbowFlexDeg = finalFarElbowFlex,
        nearKneeFlexDeg = finalNearKneeFlex,
        farKneeFlexDeg = finalFarKneeFlex,
        nearHeelLift = pose.nearHeelLift,
        farHeelLift = pose.farHeelLift,
        isFrontalView = pose.isFrontalView,
        facingRight = pose.facingRight,
        handStyle = pose.handStyle
    )
}

/**
 * Draws a sculpted volumetric muscle segment with 4-stop studio lighting, anatomical groove contour,
 * subtle woven cloth/skin specular sheen, and active muscle engagement striations.
 */
fun DrawScope.drawSculptedMuscleSegment(
    start: Offset,
    end: Offset,
    rStart: Float,
    rEnd: Float,
    anteriorBulge: Float,
    posteriorBulge: Float,
    bulgePosition: Float = 0.42f,
    baseColor: Color,
    shadowColor: Color,
    highlightColor: Color,
    inkColor: Color,
    rimColor: Color = Color.Transparent,
    activeGlowColor: Color = Color.Transparent,
    activeGlowAlpha: Float = 0f,
    drawFabricWeave: Boolean = false,
    drawMuscleGroove: Boolean = false,
    wetSheenAlpha: Float = 0f
) {
    val dx = end.x - start.x
    val dy = end.y - start.y
    val len = hypot(dx, dy).coerceAtLeast(1f)
    val ux = dx / len
    val uy = dy / len
    val nx = -uy
    val ny = ux

    val sA = Offset(start.x + nx * rStart, start.y + ny * rStart)
    val sP = Offset(start.x - nx * rStart, start.y - ny * rStart)
    val eA = Offset(end.x + nx * rEnd, end.y + ny * rEnd)
    val eP = Offset(end.x - nx * rEnd, end.y - ny * rEnd)

    val peakT = bulgePosition.coerceIn(0.22f, 0.72f)
    val peakCenter = Offset(start.x + dx * peakT, start.y + dy * peakT)
    val peakR = lerpFloat(rStart, rEnd, peakT)

    val c1A = Offset(
        start.x + dx * (peakT * 0.54f) + nx * (peakR + anteriorBulge * 1.18f),
        start.y + dy * (peakT * 0.54f) + ny * (peakR + anteriorBulge * 1.18f)
    )
    val c2A = Offset(
        start.x + dx * (peakT + (1f - peakT) * 0.42f) + nx * (peakR * 0.90f + anteriorBulge * 0.54f),
        start.y + dy * (peakT + (1f - peakT) * 0.42f) + ny * (peakR * 0.90f + anteriorBulge * 0.54f)
    )
    val c2P = Offset(
        start.x + dx * (peakT + (1f - peakT) * 0.45f) - nx * (peakR * 0.90f + posteriorBulge * 0.54f),
        start.y + dy * (peakT + (1f - peakT) * 0.45f) - ny * (peakR * 0.90f + posteriorBulge * 0.54f)
    )
    val c1P = Offset(
        start.x + dx * (peakT * 0.52f) - nx * (peakR + posteriorBulge * 1.12f),
        start.y + dy * (peakT * 0.52f) - ny * (peakR + posteriorBulge * 1.12f)
    )

    val musclePath = Path().apply {
        moveTo(sA.x, sA.y)
        cubicTo(c1A.x, c1A.y, c2A.x, c2A.y, eA.x, eA.y)
        quadraticTo(end.x + ux * rEnd * 0.84f, end.y + uy * rEnd * 0.84f, eP.x, eP.y)
        cubicTo(c2P.x, c2P.y, c1P.x, c1P.y, sP.x, sP.y)
        quadraticTo(start.x - ux * rStart * 0.84f, start.y - uy * rStart * 0.84f, sA.x, sA.y)
        close()
    }

    // 4-stop volumetric cylindrical lighting (specular key -> highlight -> midtone -> core shadow -> subtle cool bounce)
    val bounceTint = Color(
        red = ((shadowColor.red + 0.08f).coerceAtMost(1f)),
        green = ((shadowColor.green + 0.11f).coerceAtMost(1f)),
        blue = ((shadowColor.blue + 0.17f).coerceAtMost(1f)),
        alpha = 1f
    )
    val gradStart = Offset(peakCenter.x + nx * (peakR + anteriorBulge), peakCenter.y + ny * (peakR + anteriorBulge))
    val gradEnd = Offset(peakCenter.x - nx * (peakR + posteriorBulge), peakCenter.y - ny * (peakR + posteriorBulge))
    drawPath(
        path = musclePath,
        brush = Brush.linearGradient(
            colors = listOf(highlightColor, baseColor, shadowColor, bounceTint),
            start = gradStart,
            end = gradEnd
        )
    )

    // Subtle specular volume strip along muscle peak
    val specStart = Offset(start.x + dx * 0.16f + nx * peakR * 0.42f, start.y + dy * 0.16f + ny * peakR * 0.42f)
    val specEnd = Offset(start.x + dx * 0.72f + nx * peakR * 0.30f, start.y + dy * 0.72f + ny * peakR * 0.30f)
    drawLine(
        color = Color.White.copy(alpha = if (wetSheenAlpha > 0.1f) 0.42f * wetSheenAlpha else 0.12f),
        start = specStart,
        end = specEnd,
        strokeWidth = (peakR * 0.36f).coerceIn(1.5f, 5.5f),
        cap = StrokeCap.Round
    )

    // Anatomical muscle separation groove (e.g., bicep/tricep sulcus, quad/hamstring lateral sweep)
    if (drawMuscleGroove && len > 16f) {
        val grooveStart = Offset(start.x + dx * 0.22f - nx * peakR * 0.10f, start.y + dy * 0.22f - ny * peakR * 0.10f)
        val grooveMid = Offset(start.x + dx * peakT - nx * peakR * 0.16f, start.y + dy * peakT - ny * peakR * 0.16f)
        val grooveEnd = Offset(start.x + dx * 0.80f - nx * peakR * 0.06f, start.y + dy * 0.80f - ny * peakR * 0.06f)
        val groove = Path().apply {
            moveTo(grooveStart.x, grooveStart.y)
            quadraticTo(grooveMid.x, grooveMid.y, grooveEnd.x, grooveEnd.y)
        }
        drawPath(groove, color = shadowColor.copy(alpha = 0.55f), style = Stroke(width = 1.45f, cap = StrokeCap.Round))
        drawPath(
            groove,
            color = highlightColor.copy(alpha = 0.22f),
            style = Stroke(width = 0.9f, cap = StrokeCap.Round)
        )
    }

    // Subtle woven textile crease lines on clothing segments for realistic texture
    if (drawFabricWeave && len > 20f) {
        val creaseCount = 3
        for (i in 1..creaseCount) {
            val frac = i / (creaseCount + 1f)
            val cx = start.x + dx * frac
            val cy = start.y + dy * frac
            val w = lerpFloat(rStart, rEnd, frac) * 0.62f
            drawLine(
                color = shadowColor.copy(alpha = 0.28f),
                start = Offset(cx - nx * w * 0.8f - ux * 2.5f, cy - ny * w * 0.8f - uy * 2.5f),
                end = Offset(cx + nx * w * 0.45f + ux * 2.5f, cy + ny * w * 0.45f + uy * 2.5f),
                strokeWidth = 1.15f,
                cap = StrokeCap.Round
            )
        }
    }

    // Active muscle fiber engagement sheen
    if (activeGlowAlpha > 0.04f && activeGlowColor.alpha > 0.01f) {
        drawPath(
            path = musclePath,
            brush = Brush.radialGradient(
                colors = listOf(
                    activeGlowColor.copy(alpha = (0.45f * activeGlowAlpha).coerceIn(0f, 0.62f)),
                    activeGlowColor.copy(alpha = (0.14f * activeGlowAlpha).coerceIn(0f, 0.24f)),
                    Color.Transparent
                ),
                center = peakCenter,
                radius = max(len * 0.52f, peakR * 2.2f)
            )
        )
        for (k in -1..1) {
            val offsetFrac = k * 0.34f
            val fStart = Offset(start.x + dx * 0.18f + nx * peakR * offsetFrac, start.y + dy * 0.18f + ny * peakR * offsetFrac)
            val fEnd = Offset(start.x + dx * 0.78f + nx * peakR * offsetFrac * 0.68f, start.y + dy * 0.78f + ny * peakR * offsetFrac * 0.68f)
            drawLine(
                color = activeGlowColor.copy(alpha = 0.26f * activeGlowAlpha),
                start = fStart,
                end = fEnd,
                strokeWidth = 1.35f,
                cap = StrokeCap.Round
            )
        }
    }

    // Glistening wet-water sheen & clinging droplets for Wudu washing
    if (wetSheenAlpha > 0.05f) {
        drawPath(
            path = musclePath,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF8BE2FF).copy(alpha = 0.42f * wetSheenAlpha),
                    Color(0xFF47B8F5).copy(alpha = 0.16f * wetSheenAlpha),
                    Color.Transparent
                ),
                start = gradStart,
                end = gradEnd
            )
        )
    }

    // Crisp rim light along key edge
    if (rimColor.alpha > 0.05f) {
        val rimPath = Path().apply {
            moveTo(sA.x, sA.y)
            cubicTo(c1A.x, c1A.y, c2A.x, c2A.y, eA.x, eA.y)
        }
        drawPath(rimPath, color = rimColor, style = Stroke(width = 1.85f, cap = StrokeCap.Round))
    }

    // Precision anatomical contour outline
    drawPath(musclePath, color = inkColor, style = Stroke(width = 1.75f, join = StrokeJoin.Round))
}

/**
 * Convenience wrapper for athletic exercises (preserves call signature).
 */
fun DrawScope.drawAnatomicalAthleticHuman(
    skel: SolvedFkSkeleton,
    isFemale: Boolean,
    palette: RuhZenaGlassPalette,
    activeZone: MuscleZone,
    showMuscleFocus: Boolean,
    muscleActivation: Float,
    floorY: Float,
    phase: Float,
    physics: BiomechanicalTelemetry = BiomechanicalTelemetry()
) {
    drawUnifiedAnatomicalHuman(
        skel = skel,
        isFemale = isFemale,
        outfitStyle = HumanOutfitStyle.HALAL_ATHLETIC,
        palette = palette,
        activeZone = activeZone,
        showMuscleFocus = showMuscleFocus,
        muscleActivation = muscleActivation,
        floorY = floorY,
        phase = phase,
        physics = physics
    )
}

/**
 * Unified Lifelike Anatomical Human Renderer used for:
 * - Workouts (`HumanOutfitStyle.HALAL_ATHLETIC`)
 * - Salah (`HumanOutfitStyle.PRAYER_ROBE`)
 * - Wudu (`HumanOutfitStyle.PRAYER_ROBE` + `isWudu = true` + `wetZone`)
 */
fun DrawScope.drawUnifiedAnatomicalHuman(
    skel: SolvedFkSkeleton,
    isFemale: Boolean,
    outfitStyle: HumanOutfitStyle,
    palette: RuhZenaGlassPalette,
    activeZone: MuscleZone = MuscleZone.FULL_BODY,
    showMuscleFocus: Boolean = false,
    muscleActivation: Float = 0f,
    floorY: Float,
    phase: Float,
    isWudu: Boolean = false,
    wetZone: WuduWetZone = WuduWetZone.NONE,
    clothDrag: Float = 0f,
    taslimYaw: Float = 0f,
    physics: BiomechanicalTelemetry = BiomechanicalTelemetry()
) {
    val u = skel.unit
    val ink = Color(0xFF0A0E17)
    val rim = if (isWudu) Color(0xFFA6E6FF) else if (outfitStyle == HumanOutfitStyle.PRAYER_ROBE) Color(0xFFF3DFAF) else Color(0xFFD2E5FF)

    // Realistic skin tones with warm subsurface midtone & natural occlusion shadow
    val skinHi = if (isFemale) Color(0xFFFDE4CF) else Color(0xFFF4CEB1)
    val skinBase = if (isFemale) Color(0xFFEDC6AA) else Color(0xFFDFAD89)
    val skinSh = if (isFemale) Color(0xFFBA866B) else Color(0xFFA06C4E)
    val farSkinBase = if (isFemale) Color(0xFFC59377) else Color(0xFFB37D5E)
    val farSkinSh = if (isFemale) Color(0xFF8C5D47) else Color(0xFF7A4D36)

    // Outfit palettes
    val isPrayer = outfitStyle == HumanOutfitStyle.PRAYER_ROBE
    val topHi = when {
        isPrayer && !isFemale -> Color(0xFFF6F9FD)
        isPrayer && isFemale -> Color(0xFF425673)
        !isFemale -> Color(0xFFE0E7F1)
        else -> Color(0xFF4A5F7D)
    }
    val topBase = when {
        isPrayer && !isFemale -> Color(0xFFE0E7F0)
        isPrayer && isFemale -> Color(0xFF28374D)
        !isFemale -> Color(0xFFB3C1D4)
        else -> Color(0xFF2D3E57)
    }
    val topSh = when {
        isPrayer && !isFemale -> Color(0xFF8C9BB0)
        isPrayer && isFemale -> Color(0xFF131B29)
        !isFemale -> Color(0xFF66768C)
        else -> Color(0xFF162132)
    }
    val farTopHi = topBase.copy(alpha = 0.88f)
    val farTopBase = topSh
    val farTopSh = if (isFemale) Color(0xFF0B101A) else Color(0xFF455266)

    val pantHi = if (isPrayer) topHi else Color(0xFF3A475C)
    val pantBase = if (isPrayer) topBase else Color(0xFF232C3D)
    val pantSh = if (isPrayer) topSh else Color(0xFF101520)
    val farPantHi = if (isPrayer) farTopHi else Color(0xFF242D3E)
    val farPantBase = if (isPrayer) farTopBase else Color(0xFF161D29)
    val farPantSh = if (isPrayer) farTopSh else Color(0xFF0A0E16)

    val shoeHi = Color(0xFFEBF0F7)
    val shoeBase = Color(0xFF9AA8BC)
    val shoeSh = Color(0xFF495466)
    val goldTrim = Color(0xFFE5C47E)

    // Individual physiological muscle activation driven by real BiomechanicalTelemetry
    val glowColor = if (showMuscleFocus && !isPrayer) palette.gold else Color.Transparent
    val focusScale = if (showMuscleFocus && !isPrayer) 1f else 0f
    val pecGlow = (physics.pecTension * focusScale).coerceIn(0f, 1f)
    val deltGlow = (physics.deltTension * focusScale).coerceIn(0f, 1f)
    val armGlow = (max(physics.bicepTension, physics.tricepTension) * focusScale).coerceIn(0f, 1f)
    val forearmGlow = (physics.forearmTension * focusScale).coerceIn(0f, 1f)
    val coreGlow = (physics.coreTension * focusScale).coerceIn(0f, 1f)
    val quadGlow = (max(physics.quadTension, physics.hamTension) * focusScale).coerceIn(0f, 1f)
    val calfGlow = (physics.calfTension * focusScale).coerceIn(0f, 1f)

    val wetHands = if (wetZone == WuduWetZone.HANDS || wetZone == WuduWetZone.ARMS || wetZone == WuduWetZone.FACE) 1f else 0f
    val wetArms = if (wetZone == WuduWetZone.ARMS) 1f else 0f
    val wetFace = if (wetZone == WuduWetZone.FACE) 1f else 0f
    val wetFeet = if (wetZone == WuduWetZone.FEET) 1f else 0f

    // 0. Weighted Anatomical Center-of-Mass (CoM) Altitude-Scaled Ground Shadow & Impact Shockwave
    val comX = skel.pelvis.x * 0.36f + skel.thoracic.x * 0.28f + skel.head.x * 0.08f +
        skel.nearKnee.x * 0.10f + skel.farKnee.x * 0.08f + skel.nearElbow.x * 0.05f + skel.farElbow.x * 0.05f
    val lowestFootY = max(max(skel.nearFoot.y, skel.farFoot.y), max(skel.nearHeel.y, skel.farHeel.y))
    val altitudeNorm = ((floorY - lowestFootY) / (u * 1.4f)).coerceIn(0f, 1f)
    val shadowScale = 1f - altitudeNorm * 0.28f
    val shadowAlpha = (0.68f - altitudeNorm * 0.34f).coerceIn(0.22f, 0.72f)
    val bodySpread = max(abs(skel.head.x - skel.nearFoot.x), u * 2.2f) * shadowScale

    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color.Black.copy(alpha = shadowAlpha), Color.Black.copy(alpha = shadowAlpha * 0.35f), Color.Transparent),
            center = Offset(comX, floorY + u * 0.04f),
            radius = bodySpread * 0.74f
        ),
        topLeft = Offset(comX - bodySpread * 0.66f, floorY - u * 0.14f),
        size = Size(bodySpread * 1.32f, u * 0.34f * shadowScale)
    )

    // Tight dark contact-occlusion shadows directly under planted feet/hands
    if (altitudeNorm < 0.12f) {
        val contactAlpha = (0.48f * (1f - altitudeNorm / 0.12f)).coerceIn(0f, 0.50f)
        drawOval(
            color = Color.Black.copy(alpha = contactAlpha),
            topLeft = Offset(skel.nearBall.x - u * 0.42f, floorY - u * 0.05f),
            size = Size(u * 0.84f, u * 0.13f)
        )
        drawOval(
            color = Color.Black.copy(alpha = contactAlpha * 0.85f),
            topLeft = Offset(skel.farBall.x - u * 0.38f, floorY - u * 0.05f),
            size = Size(u * 0.76f, u * 0.12f)
        )
    }

    // Ground-reaction landing impact ripple ring on plyo/stride touchdown
    if (physics.landingImpactRipple > 0.02f && physics.landingImpactRipple < 0.98f) {
        val rProg = physics.landingImpactRipple
        val rippleRx = u * (0.75f + rProg * 2.15f)
        val rippleRy = u * (0.14f + rProg * 0.24f)
        drawOval(
            color = palette.accentSoft.copy(alpha = (1f - rProg) * 0.52f),
            topLeft = Offset(comX - rippleRx, floorY - rippleRy * 0.5f),
            size = Size(rippleRx * 2f, rippleRy),
            style = Stroke(width = 2.2f * (1f - rProg * 0.6f))
        )
    }

    // Subtle grounded CoM balance anchor cue during athletic exercises
    if (physics.showComBalanceGuide && !isPrayer) {
        drawCircle(
            color = palette.gold.copy(alpha = 0.45f),
            radius = 3.2f,
            center = Offset(comX, floorY + 2f)
        )
    }

    // Dynamic muscle flexion bulges respond directly to real joint angles + neuromuscular tension!
    val nearBicepFlex = ((abs(skel.nearElbowFlexDeg) / 108f) * 0.72f + physics.bicepTension * 0.38f).coerceIn(0f, 1.15f)
    val farBicepFlex = ((abs(skel.farElbowFlexDeg) / 108f) * 0.72f + physics.bicepTension * 0.32f).coerceIn(0f, 1.10f)
    val nearTricepExt = ((1f - (abs(skel.nearElbowFlexDeg) / 115f).coerceIn(0f, 1f)) * 0.55f + physics.tricepTension * 0.55f).coerceIn(0f, 1.15f)
    val nearQuadFlex = ((abs(skel.nearKneeFlexDeg) / 105f) * 0.62f + physics.quadTension * 0.48f).coerceIn(0f, 1.15f)
    val nearCalfLoad = (skel.nearHeelLift * 0.55f + physics.calfTension * 0.55f).coerceIn(0f, 1.15f)

    val thighW = u * (if (isFemale) 0.44f else 0.49f)
    val kneeW = u * 0.28f
    val ankleW = u * 0.165f
    val upperArmW = u * (if (isFemale) 0.28f else 0.34f)
    val elbowW = u * (if (isFemale) 0.21f else 0.245f)
    val wristW = u * 0.14f

    // 1. FAR LEG (Quad -> Calf -> Articulated Foot / Shoe)
    drawSculptedMuscleSegment(
        start = skel.farHip, end = skel.farKnee,
        rStart = thighW * 0.94f, rEnd = kneeW * 0.94f,
        anteriorBulge = u * (0.15f + physics.quadTension * 0.05f),
        posteriorBulge = u * (0.10f + physics.hamTension * 0.04f),
        bulgePosition = 0.42f,
        baseColor = farPantBase, shadowColor = farPantSh, highlightColor = farPantHi,
        inkColor = ink, activeGlowColor = glowColor, activeGlowAlpha = quadGlow * 0.60f,
        drawFabricWeave = true
    )
    val farLowerBare = isWudu && wetZone == WuduWetZone.FEET && !isFemale
    drawSculptedMuscleSegment(
        start = skel.farKnee, end = skel.farAnkle,
        rStart = kneeW * 0.92f, rEnd = ankleW * 0.94f,
        anteriorBulge = u * 0.025f,
        posteriorBulge = u * (0.15f + physics.calfTension * 0.06f),
        bulgePosition = 0.31f,
        baseColor = if (farLowerBare) farSkinBase else farPantBase,
        shadowColor = if (farLowerBare) farSkinSh else farPantSh,
        highlightColor = if (farLowerBare) skinBase else farPantHi,
        inkColor = ink, activeGlowColor = glowColor, activeGlowAlpha = calfGlow * 0.52f,
        wetSheenAlpha = wetFeet * 0.7f
    )
    if (isPrayer) {
        drawBareArticulatedFoot(skel.farAnkle, skel.farHeel, skel.farBall, skel.farFoot, u, farSkinBase, farSkinSh, skinBase, ink, wetFeet * 0.7f)
    } else {
        drawArticulatedAthleticShoe(skel.farAnkle, skel.farHeel, skel.farBall, skel.farFoot, u, shoeBase, shoeSh, shoeHi, ink)
    }

    // 2. FAR ARM (Deltoid/Bicep/Tricep -> Forearm -> Hand)
    drawSculptedMuscleSegment(
        start = skel.farShoulder, end = skel.farElbow,
        rStart = upperArmW * 0.94f, rEnd = elbowW * 0.94f,
        anteriorBulge = u * (0.07f + farBicepFlex * 0.10f),
        posteriorBulge = u * (0.08f + physics.tricepTension * 0.06f),
        bulgePosition = 0.44f,
        baseColor = farTopBase, shadowColor = farTopSh, highlightColor = farTopHi,
        inkColor = ink, activeGlowColor = glowColor, activeGlowAlpha = armGlow * 0.55f,
        drawFabricWeave = true
    )
    val farForearmSkin = (!isFemale && (!isPrayer || isWudu))
    drawSculptedMuscleSegment(
        start = skel.farElbow, end = skel.farWrist,
        rStart = elbowW * 0.92f, rEnd = wristW * 0.94f,
        anteriorBulge = u * (0.08f + physics.forearmTension * 0.03f),
        posteriorBulge = u * 0.05f,
        bulgePosition = 0.28f,
        baseColor = if (farForearmSkin) farSkinBase else farTopBase,
        shadowColor = if (farForearmSkin) farSkinSh else farTopSh,
        highlightColor = if (farForearmSkin) skinBase else farTopHi,
        inkColor = ink,
        drawMuscleGroove = farForearmSkin,
        wetSheenAlpha = if (farForearmSkin) wetArms else 0f
    )
    drawDetailedSculptedHand(skel.farWrist, skel.farHand, u, farSkinBase, farSkinSh, skinBase, ink, skel.handStyle, wetHands * 0.8f)

    // 3. CONTINUOUS MULTI-SEGMENT FLEXIBLE TORSO (Pelvis -> Lumbar -> Thoracic -> Chest)
    val effectiveClothDrag = clothDrag + physics.clothInertia * 0.45f
    if (isPrayer) {
        drawUnifiedPrayerRobeTorso(
            skel = skel,
            isFemale = isFemale,
            robeHi = topHi,
            robeBase = topBase,
            robeSh = topSh,
            robeDeep = farTopSh,
            goldTrim = goldTrim,
            ink = ink,
            rim = rim,
            floorY = floorY,
            phase = phase,
            clothDrag = effectiveClothDrag
        )
    } else {
        drawFlexibleAthleticTorso(
            skel = skel,
            isFemale = isFemale,
            topHi = topHi,
            topBase = topBase,
            topSh = topSh,
            pantBase = pantBase,
            pantSh = pantSh,
            ink = ink,
            rim = rim,
            glowColor = glowColor,
            coreGlow = coreGlow,
            chestGlow = pecGlow,
            physics = physics
        )
    }

    // 4. NECK (with Trapezius & Sternocleidomastoid tendons) & SCULPTED LIFELIKE HEAD
    val neckCovered = isFemale
    drawSculptedMuscleSegment(
        start = skel.chest, end = skel.neck,
        rStart = u * 0.28f, rEnd = u * 0.21f,
        anteriorBulge = u * 0.035f, posteriorBulge = u * 0.045f,
        baseColor = if (neckCovered) Color(0xFFDCE4F0) else skinBase,
        shadowColor = if (neckCovered) Color(0xFF8393AA) else skinSh,
        highlightColor = if (neckCovered) Color(0xFFF4F7FC) else skinHi,
        inkColor = ink,
        drawMuscleGroove = !neckCovered
    )
    // Sternocleidomastoid (SCM) diagonal tendon definition on exposed neck
    if (!neckCovered) {
        val neckDir = unitVec(skel.chest, skel.neck)
        val neckPerp = Offset(-neckDir.y, neckDir.x)
        drawLine(
            color = skinSh.copy(alpha = 0.56f),
            start = skel.neck - neckPerp * (u * 0.08f),
            end = skel.chest + neckPerp * (u * 0.14f),
            strokeWidth = 1.45f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = skinHi.copy(alpha = 0.42f),
            start = skel.neck - neckPerp * (u * 0.04f),
            end = skel.chest + neckPerp * (u * 0.17f),
            strokeWidth = 1.0f,
            cap = StrokeCap.Round
        )
    }
    drawUnifiedLifelikeHead(
        skel = skel,
        isFemale = isFemale,
        outfitStyle = outfitStyle,
        skinHi = skinHi,
        skinBase = skinBase,
        skinSh = skinSh,
        goldTrim = goldTrim,
        ink = ink,
        rim = rim,
        clothDrag = effectiveClothDrag,
        taslimYaw = taslimYaw,
        wetFaceAlpha = wetFace,
        wetHeadAlpha = if (wetZone == WuduWetZone.HEAD) 1f else 0f
    )

    // 5. NEAR LEG (Sculpted Quad Teardrop / Hamstring / IT-Band -> Patella Knee Cap -> Twin-Head Gastrocnemius Calf -> Achilles -> Foot/Shoe)
    drawSculptedMuscleSegment(
        start = skel.nearHip, end = skel.nearKnee,
        rStart = thighW, rEnd = kneeW,
        anteriorBulge = u * (0.17f + nearQuadFlex * 0.08f),
        posteriorBulge = u * (0.12f + physics.hamTension * 0.06f),
        bulgePosition = 0.39f,
        baseColor = pantBase, shadowColor = pantSh, highlightColor = pantHi,
        inkColor = ink, rimColor = rim.copy(alpha = 0.50f),
        activeGlowColor = glowColor, activeGlowAlpha = quadGlow,
        drawFabricWeave = true,
        drawMuscleGroove = !isPrayer
    )
    // Anatomical Quadriceps Vastus Lateralis teardrop & IT-Band highlight contour
    if (!isPrayer) {
        val thighDir = unitVec(skel.nearHip, skel.nearKnee)
        val thighPerp = Offset(-thighDir.y, thighDir.x)
        val quadTearCenter = lerpOffset(skel.nearHip, skel.nearKnee, 0.70f) + thighPerp * (thighW * 0.36f)
        drawLine(
            color = pantHi.copy(alpha = 0.38f + physics.quadTension * 0.25f),
            start = lerpOffset(skel.nearHip, skel.nearKnee, 0.24f) + thighPerp * (thighW * 0.32f),
            end = quadTearCenter,
            strokeWidth = (u * 0.11f).coerceIn(2.2f, 4.8f),
            cap = StrokeCap.Round
        )
        // Hamstring separation contour along posterior thigh
        drawLine(
            color = pantSh.copy(alpha = 0.62f),
            start = lerpOffset(skel.nearHip, skel.nearKnee, 0.18f) - thighPerp * (thighW * 0.14f),
            end = lerpOffset(skel.nearHip, skel.nearKnee, 0.84f) - thighPerp * (kneeW * 0.18f),
            strokeWidth = 1.6f,
            cap = StrokeCap.Round
        )
    }
    // Sculpted anatomical Patella (kneecap) bone landmark
    val kneeDir = unitVec(skel.nearHip, skel.nearKnee)
    val kneePerp = Offset(-kneeDir.y, kneeDir.x)
    val patellaCenter = skel.nearKnee + kneePerp * (kneeW * 0.36f)
    drawCircle(
        brush = Brush.radialGradient(
            listOf(pantHi.copy(alpha = 0.56f), pantBase.copy(alpha = 0.18f), Color.Transparent),
            center = patellaCenter,
            radius = kneeW * 0.72f
        ),
        radius = kneeW * 0.65f,
        center = patellaCenter
    )
    val nearLowerBare = isWudu && wetZone == WuduWetZone.FEET && !isFemale
    drawSculptedMuscleSegment(
        start = skel.nearKnee, end = skel.nearAnkle,
        rStart = kneeW * 0.96f, rEnd = ankleW,
        anteriorBulge = u * 0.035f,
        posteriorBulge = u * (0.18f + nearCalfLoad * 0.08f),
        bulgePosition = 0.30f,
        baseColor = if (nearLowerBare) skinBase else pantBase,
        shadowColor = if (nearLowerBare) skinSh else pantSh,
        highlightColor = if (nearLowerBare) skinHi else pantHi,
        inkColor = ink, rimColor = rim.copy(alpha = 0.42f),
        activeGlowColor = glowColor, activeGlowAlpha = calfGlow,
        drawFabricWeave = !nearLowerBare,
        drawMuscleGroove = !isPrayer || nearLowerBare,
        wetSheenAlpha = wetFeet
    )
    // Twin-Head Gastrocnemius diamond & tapered Achilles tendon definition
    if (!isPrayer || nearLowerBare) {
        val shinDir = unitVec(skel.nearKnee, skel.nearAnkle)
        val shinPerp = Offset(-shinDir.y, shinDir.x)
        val calfPeak = lerpOffset(skel.nearKnee, skel.nearAnkle, 0.32f) - shinPerp * (kneeW * 0.48f)
        val achillesTop = lerpOffset(skel.nearKnee, skel.nearAnkle, 0.56f) - shinPerp * (ankleW * 0.52f)
        val achillesBot = skel.nearHeel
        val calfShadow = if (nearLowerBare) skinSh else pantSh
        val calfHi = if (nearLowerBare) skinHi else pantHi
        drawLine(
            color = calfShadow.copy(alpha = 0.60f),
            start = calfPeak,
            end = achillesTop,
            strokeWidth = 1.55f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = calfHi.copy(alpha = 0.36f + physics.calfTension * 0.25f),
            start = achillesTop,
            end = achillesBot,
            strokeWidth = 1.65f,
            cap = StrokeCap.Round
        )
    }
    if (isPrayer) {
        drawBareArticulatedFoot(skel.nearAnkle, skel.nearHeel, skel.nearBall, skel.nearFoot, u, skinBase, skinSh, skinHi, ink, wetFeet)
    } else {
        drawArticulatedAthleticShoe(skel.nearAnkle, skel.nearHeel, skel.nearBall, skel.nearFoot, u, shoeBase, shoeSh, shoeHi, ink)
    }

    // 6. NEAR ARM (3-Head Deltoid Cap -> Flexing Biceps Peak & Triceps Horseshoe -> Brachioradialis Forearm -> Articulated Hand)
    drawSculptedMuscleSegment(
        start = skel.nearShoulder, end = skel.nearElbow,
        rStart = upperArmW, rEnd = elbowW,
        anteriorBulge = u * (0.09f + nearBicepFlex * 0.14f),
        posteriorBulge = u * (0.09f + nearTricepExt * 0.11f),
        bulgePosition = 0.44f,
        baseColor = topBase, shadowColor = topSh, highlightColor = topHi,
        inkColor = ink, rimColor = rim.copy(alpha = 0.68f),
        activeGlowColor = glowColor, activeGlowAlpha = armGlow,
        drawFabricWeave = true,
        drawMuscleGroove = !isPrayer
    )
    // Triceps lateral-head horseshoe & biceps brachialis separation on athletic upper arm
    if (!isPrayer) {
        val armDir = unitVec(skel.nearShoulder, skel.nearElbow)
        val armPerp = Offset(-armDir.y, armDir.x)
        val tricepHookStart = lerpOffset(skel.nearShoulder, skel.nearElbow, 0.30f) - armPerp * (upperArmW * 0.36f)
        val tricepHookEnd = lerpOffset(skel.nearShoulder, skel.nearElbow, 0.64f) - armPerp * (elbowW * 0.24f)
        drawLine(
            color = topSh.copy(alpha = 0.52f + physics.tricepTension * 0.25f),
            start = tricepHookStart,
            end = tricepHookEnd,
            strokeWidth = 1.6f,
            cap = StrokeCap.Round
        )
        // Biceps peak specular highlight
        val bicepPeak = lerpOffset(skel.nearShoulder, skel.nearElbow, 0.48f) + armPerp * (upperArmW * (0.34f + nearBicepFlex * 0.15f))
        drawCircle(
            brush = Brush.radialGradient(
                listOf(topHi.copy(alpha = 0.42f + nearBicepFlex * 0.25f), Color.Transparent),
                center = bicepPeak,
                radius = upperArmW * 0.72f
            ),
            radius = upperArmW * 0.65f,
            center = bicepPeak
        )
    }

    // Sculpted 3-Head Deltoid Shoulder Cap (anatomical teardrop inserting into deltoid tuberosity!)
    val armDirForDelt = unitVec(skel.nearShoulder, skel.nearElbow)
    val armPerpForDelt = Offset(-armDirForDelt.y, armDirForDelt.x)
    val deltInsert = lerpOffset(skel.nearShoulder, skel.nearElbow, 0.36f)
    val deltTop = skel.nearShoulder - armDirForDelt * (upperArmW * 0.62f)
    val deltAnt = skel.nearShoulder + armPerpForDelt * (upperArmW * 1.06f) + armDirForDelt * (upperArmW * 0.14f)
    val deltPost = skel.nearShoulder - armPerpForDelt * (upperArmW * 1.02f) + armDirForDelt * (upperArmW * 0.10f)
    val deltoidPath = Path().apply {
        moveTo(deltTop.x, deltTop.y)
        quadraticTo(deltAnt.x, deltAnt.y, deltInsert.x + armPerpForDelt.x * upperArmW * 0.30f, deltInsert.y + armPerpForDelt.y * upperArmW * 0.30f)
        quadraticTo(deltInsert.x, deltInsert.y + armDirForDelt.y * u * 0.08f, deltInsert.x - armPerpForDelt.x * upperArmW * 0.28f, deltInsert.y - armPerpForDelt.y * upperArmW * 0.28f)
        quadraticTo(deltPost.x, deltPost.y, deltTop.x, deltTop.y)
        close()
    }
    drawPath(
        path = deltoidPath,
        brush = Brush.radialGradient(
            colors = listOf(topHi, topBase, topSh),
            center = Offset(skel.nearShoulder.x + u * 0.08f, skel.nearShoulder.y - u * 0.08f),
            radius = upperArmW * 1.32f
        )
    )
    if (deltGlow > 0.08f) {
        drawPath(
            path = deltoidPath,
            brush = Brush.radialGradient(
                colors = listOf(glowColor.copy(alpha = 0.52f * deltGlow), Color.Transparent),
                center = skel.nearShoulder,
                radius = upperArmW * 1.28f
            )
        )
    }
    // Anterior / lateral deltoid head separation ridge
    drawLine(
        color = topSh.copy(alpha = 0.45f),
        start = skel.nearShoulder + armPerpForDelt * (upperArmW * 0.26f),
        end = deltInsert + armPerpForDelt * (upperArmW * 0.12f),
        strokeWidth = 1.25f,
        cap = StrokeCap.Round
    )
    drawPath(deltoidPath, color = ink.copy(alpha = 0.85f), style = Stroke(width = 1.45f, join = StrokeJoin.Round))

    // Rolled cuff ring during Wudu for Male
    val nearForearmSkin = (!isFemale && (!isPrayer || isWudu))
    if (isWudu && !isFemale) {
        drawCircle(
            color = topHi,
            radius = elbowW * 1.06f,
            center = skel.nearElbow
        )
        drawCircle(
            color = ink,
            radius = elbowW * 1.06f,
            center = skel.nearElbow,
            style = Stroke(width = 1.5f)
        )
    }
    drawSculptedMuscleSegment(
        start = skel.nearElbow, end = skel.nearWrist,
        rStart = elbowW * 0.96f, rEnd = wristW,
        anteriorBulge = u * (0.09f + physics.forearmTension * 0.045f),
        posteriorBulge = u * (0.055f + physics.forearmTension * 0.03f),
        bulgePosition = 0.28f,
        baseColor = if (nearForearmSkin) skinBase else topBase,
        shadowColor = if (nearForearmSkin) skinSh else topSh,
        highlightColor = if (nearForearmSkin) skinHi else topHi,
        inkColor = ink, rimColor = rim.copy(alpha = 0.56f),
        activeGlowColor = glowColor, activeGlowAlpha = forearmGlow * 0.72f,
        drawFabricWeave = !nearForearmSkin,
        drawMuscleGroove = nearForearmSkin,
        wetSheenAlpha = if (nearForearmSkin) wetArms else 0f
    )
    drawDetailedSculptedHand(skel.nearWrist, skel.nearHand, u, skinBase, skinSh, skinHi, ink, skel.handStyle, wetHands)
}

/**
 * Multi-segment flexible athletic torso following pelvis -> lumbar -> thoracic -> chest curvature!
 */
private fun DrawScope.drawFlexibleAthleticTorso(
    skel: SolvedFkSkeleton,
    isFemale: Boolean,
    topHi: Color,
    topBase: Color,
    topSh: Color,
    pantBase: Color,
    pantSh: Color,
    ink: Color,
    rim: Color,
    glowColor: Color,
    coreGlow: Float,
    chestGlow: Float,
    physics: BiomechanicalTelemetry = BiomechanicalTelemetry()
) {
    val u = skel.unit
    val lowerDir = unitVec(skel.pelvis, skel.lumbar)
    val midDir = unitVec(skel.lumbar, skel.thoracic)
    val upperDir = unitVec(skel.thoracic, skel.chest)

    val lowerPerp = Offset(-lowerDir.y, lowerDir.x)
    val midPerp = Offset(-midDir.y, midDir.x)
    val upperPerp = Offset(-upperDir.y, upperDir.x)
    val breathExpand = physics.breathExpansion * u * 0.045f

    if (skel.isFrontalView) {
        val shW = u * (if (isFemale) 0.78f else 1.00f)
        val chestW = u * (if (isFemale) 0.68f else 0.88f) + breathExpand
        val waistW = u * (if (isFemale) 0.56f else 0.64f)
        val hipW = u * (if (isFemale) 0.78f else 0.68f)

        val torsoPath = Path().apply {
            moveTo(skel.chest.x - shW, skel.chest.y)
            quadraticTo(skel.chest.x, skel.chest.y - u * 0.30f, skel.chest.x + shW, skel.chest.y)
            cubicTo(
                skel.thoracic.x + chestW, skel.thoracic.y,
                skel.lumbar.x + waistW, skel.lumbar.y,
                skel.pelvis.x + hipW * 0.90f, skel.pelvis.y + u * 0.34f
            )
            lineTo(skel.pelvis.x - hipW * 0.90f, skel.pelvis.y + u * 0.34f)
            cubicTo(
                skel.lumbar.x - waistW, skel.lumbar.y,
                skel.thoracic.x - chestW, skel.thoracic.y,
                skel.chest.x - shW, skel.chest.y
            )
            close()
        }
        drawPath(
            torsoPath,
            brush = Brush.horizontalGradient(
                listOf(topSh, topBase, topHi, topBase, topSh),
                startX = skel.chest.x - shW,
                endX = skel.chest.x + shW
            )
        )
        if (coreGlow > 0.05f || chestGlow > 0.05f) {
            drawPath(
                torsoPath,
                brush = Brush.radialGradient(
                    listOf(glowColor.copy(alpha = 0.45f * max(coreGlow, chestGlow)), Color.Transparent),
                    center = skel.lumbar,
                    radius = u * 1.55f
                )
            )
        }
        // Sculpted Pectoralis Major, Clavicle, Obliques & Rectus Abdominis anatomical shading
        if (!isFemale) {
            // Left & right pectoral lower sweep arcs
            val pecY = skel.thoracic.y - u * 0.05f
            val pecL = Path().apply {
                moveTo(skel.chest.x - u * 0.06f, pecY - u * 0.04f)
                quadraticTo(skel.chest.x - chestW * 0.45f, pecY + u * 0.08f, skel.chest.x - chestW * 0.78f, pecY - u * 0.14f)
            }
            val pecR = Path().apply {
                moveTo(skel.chest.x + u * 0.06f, pecY - u * 0.04f)
                quadraticTo(skel.chest.x + chestW * 0.45f, pecY + u * 0.08f, skel.chest.x + chestW * 0.78f, pecY - u * 0.14f)
            }
            drawPath(pecL, color = topSh.copy(alpha = 0.58f + physics.pecTension * 0.22f), style = Stroke(width = 1.75f, cap = StrokeCap.Round))
            drawPath(pecR, color = topSh.copy(alpha = 0.58f + physics.pecTension * 0.22f), style = Stroke(width = 1.75f, cap = StrokeCap.Round))

            // Linea alba + rectus abdominis tendinous intersections
            drawLine(
                color = topSh.copy(alpha = 0.42f + physics.coreTension * 0.20f),
                start = Offset(skel.chest.x, skel.chest.y + u * 0.24f),
                end = Offset(skel.lumbar.x, skel.lumbar.y + u * 0.28f),
                strokeWidth = 1.45f,
                cap = StrokeCap.Round
            )
            for (row in 0..2) {
                val frac = 0.28f + row * 0.26f
                val abY = lerpFloat(skel.thoracic.y, skel.pelvis.y, frac)
                val abSpan = waistW * (0.44f - row * 0.04f)
                drawLine(
                    color = topSh.copy(alpha = 0.30f + physics.coreTension * 0.22f),
                    start = Offset(skel.lumbar.x - abSpan, abY),
                    end = Offset(skel.lumbar.x + abSpan, abY),
                    strokeWidth = 1.25f,
                    cap = StrokeCap.Round
                )
            }
        }
        drawPath(torsoPath, color = ink, style = Stroke(width = 1.85f, join = StrokeJoin.Round))
        return
    }

    // Profile / 3/4 Multi-Segment Flexible Spine Torso (bends naturally along lumbar + thoracic joints!)
    val chestFront = u * (if (isFemale) 0.54f else 0.62f) + breathExpand
    val chestBack = u * (if (isFemale) 0.46f else 0.55f)
    val thorFront = u * (if (isFemale) 0.50f else 0.56f) + breathExpand * 0.85f
    val thorBack = u * (if (isFemale) 0.44f else 0.51f)
    val waistFront = u * (if (isFemale) 0.37f else 0.41f)
    val waistBack = u * (if (isFemale) 0.36f else 0.39f)
    val hipFront = u * (if (isFemale) 0.44f else 0.42f)
    val hipBack = u * (if (isFemale) 0.56f else 0.51f) + physics.gluteTension * u * 0.04f

    // Pelvis / Gluteus Maximus anchor fused cleanly to hips
    val pelvisPath = Path().apply {
        moveTo(skel.lumbar.x + lowerPerp.x * waistFront, skel.lumbar.y + lowerPerp.y * waistFront)
        quadraticTo(
            skel.pelvis.x + lowerPerp.x * hipFront, skel.pelvis.y + lowerPerp.y * hipFront,
            skel.pelvis.x - lowerDir.x * u * 0.38f + lowerPerp.x * u * 0.16f,
            skel.pelvis.y - lowerDir.y * u * 0.38f + lowerPerp.y * u * 0.16f
        )
        quadraticTo(
            skel.pelvis.x - lowerDir.x * u * 0.42f - lowerPerp.x * hipBack * 0.78f,
            skel.pelvis.y - lowerDir.y * u * 0.42f - lowerPerp.y * hipBack * 0.78f,
            skel.pelvis.x - lowerPerp.x * hipBack, skel.pelvis.y - lowerPerp.y * hipBack
        )
        lineTo(skel.lumbar.x - lowerPerp.x * waistBack, skel.lumbar.y - lowerPerp.y * waistBack)
        close()
    }
    drawPath(pelvisPath, brush = Brush.linearGradient(listOf(pantBase, pantSh), start = skel.pelvis + lowerPerp * hipFront, end = skel.pelvis - lowerPerp * hipBack))
    if (physics.gluteTension > 0.35f && glowColor.alpha > 0.01f) {
        drawPath(
            pelvisPath,
            brush = Brush.radialGradient(
                listOf(glowColor.copy(alpha = 0.40f * physics.gluteTension), Color.Transparent),
                center = skel.pelvis - lowerPerp * (hipBack * 0.55f),
                radius = u * 0.75f
            )
        )
    }
    drawPath(pelvisPath, color = ink, style = Stroke(width = 1.75f, join = StrokeJoin.Round))

    // Upper & Mid Torso tracing the real curved spine (chest -> thoracic -> lumbar -> hem)
    val tunicExtend = if (isFemale) u * 0.62f else u * 0.22f
    val hemBase = Offset(skel.pelvis.x - lowerDir.x * tunicExtend, skel.pelvis.y - lowerDir.y * tunicExtend)
    val hemFrontW = if (isFemale) u * 0.60f else hipFront * 0.96f
    val hemBackW = if (isFemale) u * 0.68f else hipBack * 0.96f

    val collarTopBack = skel.chest + upperDir * (u * 0.26f) - upperPerp * (u * 0.36f)
    val collarTopFront = skel.chest + upperDir * (u * 0.24f) + upperPerp * (u * 0.24f)
    val pChestF = skel.chest + upperPerp * chestFront
    val pThorF = skel.thoracic + midPerp * thorFront
    val pLumbarF = skel.lumbar + lowerPerp * waistFront
    val pHemF = hemBase + lowerPerp * hemFrontW
    val pHemB = hemBase - lowerPerp * hemBackW
    val pLumbarB = skel.lumbar - lowerPerp * waistBack
    val pThorB = skel.thoracic - midPerp * thorBack
    val pChestB = skel.chest - upperPerp * chestBack

    val torsoPath = Path().apply {
        moveTo(collarTopBack.x, collarTopBack.y)
        quadraticTo(collarTopFront.x, collarTopFront.y, pChestF.x, pChestF.y)
        quadraticTo(pThorF.x, pThorF.y, pLumbarF.x, pLumbarF.y)
        lineTo(pHemF.x, pHemF.y)
        quadraticTo(hemBase.x - lowerDir.x * u * 0.14f, hemBase.y - lowerDir.y * u * 0.14f, pHemB.x, pHemB.y)
        lineTo(pLumbarB.x, pLumbarB.y)
        quadraticTo(pThorB.x, pThorB.y, pChestB.x, pChestB.y)
        lineTo(collarTopBack.x, collarTopBack.y)
        close()
    }

    drawPath(
        path = torsoPath,
        brush = Brush.linearGradient(
            colors = listOf(topHi, topBase, topSh),
            start = pThorF,
            end = pThorB
        )
    )

    // Core & Chest physiological muscle highlight overlays
    if (coreGlow > 0.05f) {
        drawPath(
            path = torsoPath,
            brush = Brush.radialGradient(
                colors = listOf(glowColor.copy(alpha = 0.50f * coreGlow), Color.Transparent),
                center = skel.lumbar + lowerPerp * (u * 0.12f),
                radius = u * 1.42f
            )
        )
    }
    if (chestGlow > 0.05f) {
        drawPath(
            path = torsoPath,
            brush = Brush.radialGradient(
                colors = listOf(glowColor.copy(alpha = 0.52f * chestGlow), Color.Transparent),
                center = skel.thoracic + midPerp * (u * 0.28f),
                radius = u * 1.22f
            )
        )
    }

    // Anatomical Trapezius, Latissimus Dorsi V-taper, Serratus Anterior & Oblique contours
    val latSeam = Path().apply {
        moveTo(skel.chest.x - upperPerp.x * u * 0.06f, skel.chest.y - upperPerp.y * u * 0.06f)
        quadraticTo(
            skel.thoracic.x - midPerp.x * u * 0.15f, skel.thoracic.y - midPerp.y * u * 0.15f,
            skel.lumbar.x - lowerPerp.x * u * 0.08f, skel.lumbar.y - lowerPerp.y * u * 0.08f
        )
    }
    drawPath(latSeam, color = topSh.copy(alpha = 0.56f), style = Stroke(width = 1.75f, cap = StrokeCap.Round))

    if (!isFemale) {
        // Sculpted Pectoralis Major lower sweep & clavicular highlight
        val pecSweep = Path().apply {
            val ps = skel.thoracic + midPerp * (thorFront * 0.14f) + midDir * (u * 0.10f)
            val pm = skel.thoracic + midPerp * (thorFront * 0.58f) - midDir * (u * 0.04f)
            val pe = skel.thoracic + midPerp * (thorFront * 0.92f) + midDir * (u * 0.08f)
            moveTo(ps.x, ps.y)
            quadraticTo(pm.x, pm.y, pe.x, pe.y)
        }
        drawPath(pecSweep, color = topSh.copy(alpha = 0.48f + physics.pecTension * 0.25f), style = Stroke(width = 1.65f, cap = StrokeCap.Round))

        // Serratus Anterior ribcage digitations along lateral ribcage
        for (i in 0..2) {
            val basePt = lerpOffset(skel.thoracic, skel.lumbar, 0.28f + i * 0.20f)
            drawLine(
                color = topSh.copy(alpha = 0.34f + physics.coreTension * 0.20f),
                start = basePt + midPerp * (thorFront * 0.04f),
                end = basePt + midPerp * (thorFront * 0.34f) - midDir * (u * 0.06f),
                strokeWidth = 1.2f,
                cap = StrokeCap.Round
            )
        }

        // External Oblique & Rectus Abdominis contour line
        drawLine(
            color = topSh.copy(alpha = 0.36f + physics.coreTension * 0.22f),
            start = skel.lumbar + lowerPerp * (waistFront * 0.24f),
            end = skel.lumbar + lowerPerp * (waistFront * 0.84f),
            strokeWidth = 1.4f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = topSh.copy(alpha = 0.32f + physics.coreTension * 0.18f),
            start = lerpOffset(skel.lumbar, skel.pelvis, 0.42f) + lowerPerp * (waistFront * 0.16f),
            end = lerpOffset(skel.lumbar, skel.pelvis, 0.55f) + lowerPerp * (waistFront * 0.72f),
            strokeWidth = 1.25f,
            cap = StrokeCap.Round
        )
    }

    // Illuminated leading rim highlight
    val rimCurve = Path().apply {
        moveTo(pChestF.x, pChestF.y)
        quadraticTo(pThorF.x, pThorF.y, pLumbarF.x, pLumbarF.y)
    }
    drawPath(rimCurve, color = rim.copy(alpha = 0.65f), style = Stroke(width = 2.0f, cap = StrokeCap.Round))
    drawPath(torsoPath, color = ink, style = Stroke(width = 1.85f, join = StrokeJoin.Round))
}

/**
 * Unified Lifelike Prayer Robe (Male Thobe / Female Modest Abaya) draped onto the exact same
 * multi-segment flexible human spine with realistic woven fabric folds & gold collar embroidery.
 */
private fun DrawScope.drawUnifiedPrayerRobeTorso(
    skel: SolvedFkSkeleton,
    isFemale: Boolean,
    robeHi: Color,
    robeBase: Color,
    robeSh: Color,
    robeDeep: Color,
    goldTrim: Color,
    ink: Color,
    rim: Color,
    floorY: Float,
    phase: Float,
    clothDrag: Float
) {
    val u = skel.unit
    val lowerDir = unitVec(skel.pelvis, skel.lumbar)
    val midDir = unitVec(skel.lumbar, skel.thoracic)
    val upperDir = unitVec(skel.thoracic, skel.chest)

    val lowerPerp = Offset(-lowerDir.y, lowerDir.x)
    val midPerp = Offset(-midDir.y, midDir.x)
    val upperPerp = Offset(-upperDir.y, upperDir.x)

    val torsoW = u * (if (isFemale) 0.72f else 0.64f)
    val sway = sin(phase * 2f * PI.toFloat()) * u * 0.05f - clothDrag * u * 0.26f

    val shBack = skel.chest - upperPerp * (torsoW * 0.72f)
    val shFront = skel.chest + upperPerp * (torsoW * 0.74f)
    val thorFront = skel.thoracic + midPerp * (torsoW * 0.72f)
    val thorBack = skel.thoracic - midPerp * (torsoW * 0.76f)
    val waistFront = skel.lumbar + lowerPerp * (torsoW * 0.70f)
    val waistBack = skel.lumbar - lowerPerp * (torsoW * 0.78f)
    val pelvisFront = skel.pelvis + lowerPerp * (torsoW * 0.80f)
    val pelvisBack = skel.pelvis - lowerPerp * (torsoW * 0.88f)

    // Skirt/Hem follows leg geometry smoothly during standing, Ruku, Sujud, Jalsa & Wudu
    val skirtBack = lerpOffset(skel.pelvis, skel.nearAnkle, 0.76f) - lowerPerp * (torsoW * (if (isFemale) 1.04f else 0.84f)) + Offset(sway, 0f)
    val skirtFront = lerpOffset(skel.pelvis, skel.nearKnee, 0.84f) + lowerPerp * (torsoW * (if (isFemale) 0.90f else 0.74f)) + Offset(sway * 0.45f, 0f)
    val skirtMid = Offset(
        (skirtBack.x + skirtFront.x) * 0.50f + sway * 0.30f,
        max(skirtBack.y, skirtFront.y).coerceAtMost(floorY - u * 0.06f)
    )

    val robePath = Path().apply {
        moveTo(shBack.x, shBack.y)
        quadraticTo(skel.neckBase.x, skel.neckBase.y + u * 0.06f, shFront.x, shFront.y)
        quadraticTo(thorFront.x, thorFront.y, waistFront.x, waistFront.y)
        quadraticTo(pelvisFront.x, pelvisFront.y, skirtFront.x, skirtFront.y)
        quadraticTo(skirtMid.x, skirtMid.y + u * 0.10f, skirtBack.x, skirtBack.y)
        quadraticTo(pelvisBack.x + sway * 0.25f, pelvisBack.y, waistBack.x + sway * 0.18f, waistBack.y)
        quadraticTo(thorBack.x, thorBack.y, shBack.x, shBack.y)
        close()
    }
    drawPath(robePath, brush = Brush.linearGradient(listOf(robeHi, robeBase, robeSh), start = thorFront, end = thorBack))

    // Volumetric cloth shadow plane along posterior half
    val shadowPlane = Path().apply {
        moveTo(shBack.x, shBack.y)
        lineTo(skel.chest.x - upperPerp.x * torsoW * 0.08f, skel.chest.y - upperPerp.y * torsoW * 0.08f)
        lineTo(skel.lumbar.x - lowerPerp.x * torsoW * 0.14f, skel.lumbar.y - lowerPerp.y * torsoW * 0.14f)
        lineTo(skirtMid.x, skirtMid.y + u * 0.06f)
        lineTo(skirtBack.x, skirtBack.y)
        lineTo(waistBack.x + sway * 0.18f, waistBack.y)
        close()
    }
    drawPath(shadowPlane, color = robeSh.copy(alpha = 0.56f))

    // Realistic vertical drape folds & fabric highlight ridges
    drawLine(robeDeep.copy(alpha = 0.72f), waistBack + lowerPerp * (torsoW * 0.34f), skirtBack + Offset(u * 0.24f, -u * 0.10f), strokeWidth = 1.9f, cap = StrokeCap.Round)
    drawLine(robeDeep.copy(alpha = 0.52f), skel.lumbar + lowerPerp * (torsoW * 0.10f), skirtMid, strokeWidth = 1.5f, cap = StrokeCap.Round)
    drawLine(robeHi.copy(alpha = 0.45f), thorFront - midPerp * (torsoW * 0.24f), skirtFront - lowerPerp * (torsoW * 0.18f), strokeWidth = 1.4f, cap = StrokeCap.Round)

    // Illuminated leading rim light
    drawLine(rim.copy(alpha = 0.72f), shFront, waistFront, strokeWidth = 2.0f, cap = StrokeCap.Round)
    drawLine(rim.copy(alpha = 0.48f), waistFront, skirtFront, strokeWidth = 1.7f, cap = StrokeCap.Round)

    // Gold collar & placket embroidery
    drawLine(
        color = goldTrim,
        start = skel.neckBase + upperPerp * (torsoW * 0.18f),
        end = skel.thoracic + midPerp * (torsoW * 0.34f),
        strokeWidth = 2.5f,
        cap = StrokeCap.Round
    )
    drawPath(robePath, color = ink, style = Stroke(width = 1.95f, join = StrokeJoin.Round))
}

private fun DrawScope.drawArticulatedAthleticShoe(
    ankle: Offset,
    heel: Offset,
    ball: Offset,
    toe: Offset,
    u: Float,
    base: Color,
    shadow: Color,
    hi: Color,
    ink: Color
) {
    val dir = unitVec(heel, toe)
    val perp = Offset(-dir.y, dir.x)
    val shoePath = Path().apply {
        moveTo(heel.x - perp.x * u * 0.10f, heel.y - perp.y * u * 0.10f)
        lineTo(ankle.x + perp.x * u * 0.15f, ankle.y + perp.y * u * 0.15f)
        quadraticTo(
            ball.x + perp.x * u * 0.18f, ball.y + perp.y * u * 0.18f,
            toe.x + dir.x * u * 0.08f, toe.y + dir.y * u * 0.08f
        )
        quadraticTo(
            ball.x - perp.x * u * 0.14f, ball.y - perp.y * u * 0.14f,
            heel.x - perp.x * u * 0.14f, heel.y - perp.y * u * 0.14f
        )
        close()
    }
    drawPath(shoePath, brush = Brush.linearGradient(listOf(hi, base, shadow), start = ankle, end = toe))
    // Crisp white midsole cushion line
    drawLine(
        color = Color(0xFFEFF4FA).copy(alpha = 0.85f),
        start = Offset(heel.x - perp.x * u * 0.11f, heel.y - perp.y * u * 0.11f),
        end = Offset(toe.x - perp.x * u * 0.07f, toe.y - perp.y * u * 0.07f),
        strokeWidth = 2.2f,
        cap = StrokeCap.Round
    )
    drawPath(shoePath, color = ink, style = Stroke(width = 1.55f, join = StrokeJoin.Round))
}

private fun DrawScope.drawBareArticulatedFoot(
    ankle: Offset,
    heel: Offset,
    ball: Offset,
    toe: Offset,
    u: Float,
    base: Color,
    shadow: Color,
    hi: Color,
    ink: Color,
    wetAlpha: Float
) {
    val dir = unitVec(heel, toe)
    val perp = Offset(-dir.y, dir.x)
    val footPath = Path().apply {
        moveTo(heel.x - perp.x * u * 0.08f, heel.y - perp.y * u * 0.08f)
        lineTo(ankle.x + perp.x * u * 0.13f, ankle.y + perp.y * u * 0.13f)
        quadraticTo(ball.x + perp.x * u * 0.13f, ball.y + perp.y * u * 0.13f, toe.x, toe.y)
        quadraticTo(ball.x - perp.x * u * 0.11f, ball.y - perp.y * u * 0.11f, heel.x - perp.x * u * 0.11f, heel.y - perp.y * u * 0.11f)
        close()
    }
    drawPath(footPath, brush = Brush.linearGradient(listOf(hi, base, shadow), start = ankle, end = toe))
    if (wetAlpha > 0.05f) {
        drawPath(footPath, color = Color(0xFF7AD8FF).copy(alpha = 0.38f * wetAlpha))
    }
    drawPath(footPath, color = ink, style = Stroke(width = 1.45f, join = StrokeJoin.Round))
}

private fun DrawScope.drawDetailedSculptedHand(
    wrist: Offset,
    handTip: Offset,
    u: Float,
    base: Color,
    shadow: Color,
    hi: Color,
    ink: Color,
    style: HandStyle,
    wetAlpha: Float
) {
    val dir = unitVec(wrist, handTip)
    val perp = Offset(-dir.y, dir.x)
    when (style) {
        HandStyle.FIST -> {
            val fistCenter = lerpOffset(wrist, handTip, 0.50f)
            drawCircle(
                brush = Brush.radialGradient(listOf(hi, base, shadow), center = fistCenter, radius = u * 0.22f),
                radius = u * 0.18f,
                center = fistCenter
            )
            drawCircle(color = ink, radius = u * 0.18f, center = fistCenter, style = Stroke(width = 1.5f))
        }
        HandStyle.CUPPED_WUDU -> {
            val palm = lerpOffset(wrist, handTip, 0.56f)
            val cupPath = Path().apply {
                moveTo(wrist.x - perp.x * u * 0.12f, wrist.y - perp.y * u * 0.12f)
                quadraticTo(palm.x - perp.x * u * 0.20f, palm.y - perp.y * u * 0.20f, handTip.x + perp.x * u * 0.06f, handTip.y + perp.y * u * 0.06f)
                quadraticTo(palm.x + perp.x * u * 0.16f, palm.y + perp.y * u * 0.16f, wrist.x + perp.x * u * 0.12f, wrist.y + perp.y * u * 0.12f)
                close()
            }
            drawPath(cupPath, brush = Brush.linearGradient(listOf(hi, base, shadow), start = wrist, end = handTip))
            if (wetAlpha > 0.05f) {
                drawPath(cupPath, color = Color(0xFF7CE0FF).copy(alpha = 0.42f * wetAlpha))
            }
            drawPath(cupPath, color = ink, style = Stroke(width = 1.5f, join = StrokeJoin.Round))
        }
        else -> {
            // Sculpted palm + thumb + articulated fingers (replaces plain tapered blob)
            val palmEnd = lerpOffset(wrist, handTip, 0.56f)
            drawSculptedMuscleSegment(
                start = wrist,
                end = palmEnd,
                rStart = u * 0.125f,
                rEnd = u * 0.115f,
                anteriorBulge = u * 0.03f,
                posteriorBulge = u * 0.02f,
                bulgePosition = 0.45f,
                baseColor = base,
                shadowColor = shadow,
                highlightColor = hi,
                inkColor = ink,
                wetSheenAlpha = wetAlpha
            )
            // Articulated thumb opposing palm
            val thumbBase = lerpOffset(wrist, palmEnd, 0.42f) + perp * (u * 0.08f)
            val thumbTip = palmEnd + perp * (u * 0.17f) + dir * (u * 0.06f)
            drawLine(base, thumbBase, thumbTip, strokeWidth = (u * 0.095f).coerceIn(2.2f, 4.4f), cap = StrokeCap.Round)
            drawLine(ink.copy(alpha = 0.72f), thumbBase, thumbTip, strokeWidth = 1.0f, cap = StrokeCap.Round)

            // Articulated fingers extending cleanly to fingertip
            val fingerSpread = if (style == HandStyle.FLAT_PRESS) 0.06f else 0.045f
            for (f in -1..1) {
                val fStart = palmEnd + perp * (u * f * fingerSpread)
                val fLenScale = if (f == 0) 1.05f else 0.90f
                val fEnd = palmEnd + dir * (u * 0.24f * fLenScale) + perp * (u * f * (fingerSpread * 1.15f))
                drawLine(base, fStart, fEnd, strokeWidth = (u * 0.078f).coerceIn(1.9f, 3.6f), cap = StrokeCap.Round)
                drawLine(shadow.copy(alpha = 0.55f), fStart, fEnd, strokeWidth = 0.9f, cap = StrokeCap.Round)
            }
            if (style == HandStyle.TASHAHHUD_INDEX) {
                val indexTip = handTip + Offset(u * 0.32f, -u * 0.14f)
                drawLine(base, handTip, indexTip, strokeWidth = 3.8f, cap = StrokeCap.Round)
                drawLine(ink, handTip, indexTip, strokeWidth = 1.4f, cap = StrokeCap.Round)
                drawCircle(Color(0xFFE5C47E).copy(alpha = 0.38f), radius = 7.5f, center = indexTip)
                drawCircle(Color.White.copy(alpha = 0.85f), radius = 2.6f, center = indexTip)
            }
        }
    }
}

/**
 * Unified Lifelike Sculpted Head (clean respectful anatomy with realistic jawline, nose-bridge/brow
 * contour, ear detail, natural lighting, Sports/Prayer Hijab for Female, Groomed hair / Kufi for Male).
 */
private fun DrawScope.drawUnifiedLifelikeHead(
    skel: SolvedFkSkeleton,
    isFemale: Boolean,
    outfitStyle: HumanOutfitStyle,
    skinHi: Color,
    skinBase: Color,
    skinSh: Color,
    goldTrim: Color,
    ink: Color,
    rim: Color,
    clothDrag: Float,
    taslimYaw: Float,
    wetFaceAlpha: Float,
    wetHeadAlpha: Float
) {
    val u = skel.unit
    val head = skel.head
    val hr = u * 0.58f
    val headDir = Offset(cos(rad(skel.headAngleDeg)), sin(rad(skel.headAngleDeg)))
    val faceFwd = if (skel.isFrontalView) Offset(0f, 0f) else Offset(-headDir.y, headDir.x)
    val isPrayer = outfitStyle == HumanOutfitStyle.PRAYER_ROBE
    val veilDrift = -clothDrag * hr * 0.45f

    if (isFemale) {
        // Layered flowing Hijab (modest chest drape for Prayer, streamlined sports hijab for Workouts)
        val hijabHi = Color(0xFFF3F7FC)
        val hijabBase = Color(0xFFD5DFEC)
        val hijabSh = Color(0xFF7D8FA8)
        val hijabPath = Path().apply {
            if (isPrayer) {
                val topBack = head - faceFwd * (hr * 1.12f) + headDir * (hr * 0.15f)
                val crownBack = head - faceFwd * (hr * 1.06f) + headDir * (hr * 1.32f)
                val crownFront = head + faceFwd * (hr * 1.04f) + headDir * (hr * 1.32f)
                val frontEdge = head + faceFwd * (hr * 0.96f) - headDir * (hr * 0.08f)
                val chestDrape = skel.chest + faceFwd * (hr * 0.94f) + Offset(veilDrift * 0.25f, hr * 0.48f)
                val backDrape = skel.chest - faceFwd * (hr * 1.14f) + Offset(veilDrift * 0.75f, hr * 0.54f)
                moveTo(topBack.x, topBack.y)
                cubicTo(crownBack.x, crownBack.y, crownFront.x, crownFront.y, frontEdge.x, frontEdge.y)
                lineTo(chestDrape.x, chestDrape.y)
                quadraticTo(skel.neck.x + veilDrift * 0.4f, skel.chest.y + hr * 0.76f, backDrape.x, backDrape.y)
                close()
            } else {
                moveTo(head.x - hr * 1.08f, head.y)
                cubicTo(
                    head.x - hr * 1.12f, head.y - hr * 1.24f,
                    head.x + hr * 1.06f, head.y - hr * 1.24f,
                    head.x + hr * 0.96f, head.y - hr * 0.10f
                )
                lineTo(skel.neck.x + faceFwd.x * hr * 0.85f, skel.neck.y + hr * 0.72f)
                lineTo(skel.neck.x - faceFwd.x * hr * 1.05f, skel.neck.y + hr * 0.76f)
                close()
            }
        }
        drawPath(
            hijabPath,
            brush = Brush.linearGradient(listOf(hijabHi, hijabBase, hijabSh), start = head + faceFwd * hr, end = head - faceFwd * hr)
        )
        // Subtle woven drape fold on hijab
        drawLine(
            color = hijabSh.copy(alpha = 0.55f),
            start = head - faceFwd * (hr * 0.42f) - headDir * (hr * 0.30f),
            end = skel.neck - faceFwd * (hr * 0.50f) + headDir * (hr * 0.05f),
            strokeWidth = 1.5f,
            cap = StrokeCap.Round
        )
        drawPath(hijabPath, color = ink, style = Stroke(width = 1.85f, join = StrokeJoin.Round))
    }

    // Sculpted anatomical cranium & natural jawline (clean, serene, non-cartoonish)
    val yawShift = faceFwd * (hr * (0.16f + taslimYaw * 0.16f))
    val faceCenter = head + yawShift
    val fw = hr * (if (isFemale) 0.78f else 0.92f)
    val fh = hr * (if (isFemale) 0.86f else 0.96f)

    if (skel.isFrontalView) {
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(skinHi, skinBase, skinSh),
                center = Offset(faceCenter.x + fw * 0.2f, faceCenter.y - fh * 0.2f),
                radius = fw * 1.45f
            ),
            topLeft = Offset(faceCenter.x - fw, faceCenter.y - fh),
            size = Size(fw * 2f, fh * 2f)
        )
        // Subtle realistic facial anatomy (dignified calm brow, eye & eyelid crease, nose shadow, lips)
        val browY = faceCenter.y - fh * 0.14f
        drawLine(
            color = Color(0xFF1D1A18).copy(alpha = 0.72f),
            start = Offset(faceCenter.x - fw * 0.48f, browY),
            end = Offset(faceCenter.x - fw * 0.14f, browY - fh * 0.04f),
            strokeWidth = 1.55f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF1D1A18).copy(alpha = 0.72f),
            start = Offset(faceCenter.x + fw * 0.14f, browY - fh * 0.04f),
            end = Offset(faceCenter.x + fw * 0.48f, browY),
            strokeWidth = 1.55f,
            cap = StrokeCap.Round
        )
        val eyeY = faceCenter.y - fh * 0.01f
        drawCircle(color = Color(0xFF1A1E28), radius = (u * 0.048f).coerceIn(1.3f, 2.5f), center = Offset(faceCenter.x - fw * 0.30f, eyeY))
        drawCircle(color = Color(0xFF1A1E28), radius = (u * 0.048f).coerceIn(1.3f, 2.5f), center = Offset(faceCenter.x + fw * 0.30f, eyeY))
        // Subtle nose shadow & serene mouth contour
        drawLine(
            color = skinSh.copy(alpha = 0.62f),
            start = Offset(faceCenter.x, faceCenter.y + fh * 0.04f),
            end = Offset(faceCenter.x + fw * 0.05f, faceCenter.y + fh * 0.25f),
            strokeWidth = 1.25f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = skinSh.copy(alpha = 0.78f),
            start = Offset(faceCenter.x - fw * 0.22f, faceCenter.y + fh * 0.46f),
            end = Offset(faceCenter.x + fw * 0.22f, faceCenter.y + fh * 0.46f),
            strokeWidth = 1.45f,
            cap = StrokeCap.Round
        )
        drawOval(
            color = ink,
            topLeft = Offset(faceCenter.x - fw, faceCenter.y - fh),
            size = Size(fw * 2f, fh * 2f),
            style = Stroke(width = 1.8f)
        )
    } else {
        // Lifelike 3/4 sculpted head silhouette with brow, nose bridge & chin taper
        val headPath = Path().apply {
            val backOcciput = faceCenter - faceFwd * (fw * 0.96f) + headDir * (fh * 0.14f)
            val crownB = faceCenter - faceFwd * (fw * 0.88f) + headDir * (fh * 1.06f)
            val crownF = faceCenter + faceFwd * (fw * 0.84f) + headDir * (fh * 1.06f)
            val brow = faceCenter + faceFwd * (fw * 0.96f) + headDir * (fh * 0.24f)
            val noseTip = faceCenter + faceFwd * (fw * 1.08f) - headDir * (fh * 0.12f)
            val chin = faceCenter + faceFwd * (fw * 0.56f) - headDir * (fh * 0.94f)
            val jawAngle = faceCenter - faceFwd * (fw * 0.42f) - headDir * (fh * 0.66f)
            moveTo(backOcciput.x, backOcciput.y)
            cubicTo(crownB.x, crownB.y, crownF.x, crownF.y, brow.x, brow.y)
            quadraticTo(noseTip.x, noseTip.y, faceCenter.x + faceFwd.x * fw * 0.84f - headDir.x * fh * 0.48f, faceCenter.y + faceFwd.y * fw * 0.84f - headDir.y * fh * 0.48f)
            quadraticTo(chin.x + faceFwd.x * fw * 0.12f, chin.y, chin.x, chin.y)
            quadraticTo(jawAngle.x, jawAngle.y, backOcciput.x, backOcciput.y)
            close()
        }
        drawPath(
            headPath,
            brush = Brush.radialGradient(
                colors = listOf(skinHi, skinBase, skinSh),
                center = faceCenter + faceFwd * (fw * 0.35f) + headDir * (fh * 0.25f),
                radius = fw * 1.55f
            )
        )
        // Lifelike 3/4 brow ridge, serene eye, cheekbone & lip contour
        val browStart = faceCenter + faceFwd * (fw * 0.46f) + headDir * (fh * 0.24f)
        val browEnd = faceCenter + faceFwd * (fw * 0.86f) + headDir * (fh * 0.19f)
        drawLine(color = Color(0xFF1D1A18).copy(alpha = 0.78f), start = browStart, end = browEnd, strokeWidth = 1.65f, cap = StrokeCap.Round)

        val eyePos = faceCenter + faceFwd * (fw * 0.64f) + headDir * (fh * 0.06f)
        drawLine(
            color = Color(0xFF181C24),
            start = eyePos - faceFwd * (fw * 0.14f),
            end = eyePos + faceFwd * (fw * 0.12f),
            strokeWidth = 1.75f,
            cap = StrokeCap.Round
        )
        drawCircle(color = Color(0xFF181C24), radius = (u * 0.045f).coerceIn(1.2f, 2.3f), center = eyePos + faceFwd * (fw * 0.03f) - headDir * (fh * 0.02f))

        // Natural lip contour & cheekbone/jawline shadow depth
        val lipPos = faceCenter + faceFwd * (fw * 0.74f) - headDir * (fh * 0.50f)
        drawLine(
            color = skinSh.copy(alpha = 0.82f),
            start = lipPos - faceFwd * (fw * 0.16f),
            end = lipPos + faceFwd * (fw * 0.10f),
            strokeWidth = 1.5f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = skinSh.copy(alpha = 0.54f),
            start = faceCenter + faceFwd * (fw * 0.42f) - headDir * (fh * 0.72f),
            end = faceCenter - faceFwd * (fw * 0.34f) - headDir * (fh * 0.54f),
            strokeWidth = 1.6f,
            cap = StrokeCap.Round
        )
        if (wetFaceAlpha > 0.05f) {
            drawPath(headPath, color = Color(0xFF7FDFFF).copy(alpha = 0.30f * wetFaceAlpha))
        }
        drawPath(headPath, color = ink, style = Stroke(width = 1.85f, join = StrokeJoin.Round))

        // Sculpted ear contour with inner helix shadow for Male
        if (!isFemale) {
            val earPos = faceCenter - faceFwd * (fw * 0.28f) - headDir * (fh * 0.08f)
            drawCircle(color = skinBase, radius = u * 0.11f, center = earPos)
            drawCircle(color = skinSh.copy(alpha = 0.65f), radius = u * 0.055f, center = earPos)
            drawCircle(color = skinSh, radius = u * 0.11f, center = earPos, style = Stroke(width = 1.2f))
        }
    }

    // Male groomed hair + Prayer Kufi (when in Prayer/Wudu mode)
    if (!isFemale) {
        val hairPath = Path().apply {
            if (skel.isFrontalView) {
                moveTo(faceCenter.x - fw * 0.98f, faceCenter.y - fh * 0.08f)
                cubicTo(
                    faceCenter.x - fw * 1.02f, faceCenter.y - fh * 1.24f,
                    faceCenter.x + fw * 1.02f, faceCenter.y - fh * 1.24f,
                    faceCenter.x + fw * 0.98f, faceCenter.y - fh * 0.08f
                )
                quadraticTo(faceCenter.x, faceCenter.y - fh * 0.40f, faceCenter.x - fw * 0.98f, faceCenter.y - fh * 0.08f)
            } else {
                val back = Offset(-faceFwd.x, -faceFwd.y)
                val up = headDir
                val p1 = faceCenter + back * (fw * 0.98f) - up * (fh * 0.20f)
                val p2 = faceCenter + back * (fw * 0.78f) + up * (fh * 1.08f)
                val p3 = faceCenter + faceFwd * (fw * 0.80f) + up * (fh * 0.76f)
                val p4 = faceCenter + back * (fw * 0.04f) + up * (fh * 0.30f)
                val p5 = faceCenter + back * (fw * 0.44f) - up * (fh * 0.24f)
                moveTo(p1.x, p1.y)
                quadraticTo(p2.x, p2.y, p3.x, p3.y)
                lineTo(p4.x, p4.y)
                lineTo(p5.x, p5.y)
                close()
            }
        }
        drawPath(hairPath, color = Color(0xFF151A24))
        drawPath(hairPath, color = ink, style = Stroke(width = 1.5f, join = StrokeJoin.Round))

        if (isPrayer && !skel.isFrontalView) {
            // Crisp Sunnah Kufi with subtle gold trim band
            val kufiPath = Path().apply {
                val kL = faceCenter - faceFwd * (fw * 0.92f) + headDir * (fh * 0.40f)
                val kC1 = faceCenter - faceFwd * (fw * 0.86f) + headDir * (fh * 1.26f)
                val kC2 = faceCenter + faceFwd * (fw * 0.86f) + headDir * (fh * 1.26f)
                val kR = faceCenter + faceFwd * (fw * 0.90f) + headDir * (fh * 0.40f)
                moveTo(kL.x, kL.y)
                cubicTo(kC1.x, kC1.y, kC2.x, kC2.y, kR.x, kR.y)
                close()
            }
            drawPath(
                kufiPath,
                brush = Brush.linearGradient(
                    listOf(Color(0xFFF7FAFE), Color(0xFFDCE4F0), Color(0xFFA0B0C6)),
                    start = faceCenter + faceFwd * fw + headDir * fh,
                    end = faceCenter - faceFwd * fw
                )
            )
            drawLine(
                color = goldTrim,
                start = faceCenter - faceFwd * (fw * 0.86f) + headDir * (fh * 0.46f),
                end = faceCenter + faceFwd * (fw * 0.84f) + headDir * (fh * 0.46f),
                strokeWidth = 2.1f
            )
            drawPath(kufiPath, color = ink, style = Stroke(width = 1.75f, join = StrokeJoin.Round))
        }
    }

    // Wet sheen on head crown during Wudu head-wipe
    if (wetHeadAlpha > 0.05f) {
        drawArc(
            color = Color(0xFF7BE2FF).copy(alpha = 0.65f * wetHeadAlpha),
            startAngle = 195f,
            sweepAngle = 145f,
            useCenter = false,
            topLeft = Offset(head.x - hr * 1.05f, head.y - hr * 1.10f),
            size = Size(hr * 2.10f, hr * 2.10f),
            style = Stroke(width = 3.2f, cap = StrokeCap.Round)
        )
    }

    // Studio rim light along crown
    drawArc(
        color = rim.copy(alpha = 0.72f),
        startAngle = 212f,
        sweepAngle = 82f,
        useCenter = false,
        topLeft = Offset(faceCenter.x - fw, faceCenter.y - fh),
        size = Size(fw * 2f, fh * 2f),
        style = Stroke(width = 1.85f, cap = StrokeCap.Round)
    )
}

private fun unitVec(a: Offset, b: Offset): Offset {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val l = hypot(dx, dy).coerceAtLeast(0.0001f)
    return Offset(dx / l, dy / l)
}
