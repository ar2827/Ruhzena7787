package com.example.ruhzena.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.FoldedDropdownOption
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.FoldedPageDropdown
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.GuidedLearningModule
import com.example.ruhzena.data.islamic.IslamicAcademyCatalog
import com.example.ruhzena.data.islamic.IslamicAcademyCurriculum
import com.example.ruhzena.data.islamic.IslamicLearningCatalog
import com.example.ruhzena.data.islamic.NarratedIslamicStory
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.LocalRuhZenaPalette

enum class LearningHubTab {
    GUIDED_PATH, HOW_TO_PRAY, ARABIC_STUDIO, STORIES, ENCYCLOPEDIA, HAJJ_UMRAH
}

@Composable
fun IslamicLearningHubScreen(
    prefs: UserPreferences,
    initialTab: LearningHubTab? = null,
    speakingItemId: String? = null,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit = { _, _, _ -> },
    onSpeakLocalized: (itemId: String, text: String) -> Unit = { _, _ -> },
    onStopSpeech: () -> Unit = {},
    onCompleteLearningStep: (Int) -> Unit = {},
    onSetLearningAllAccess: (Boolean) -> Unit = {},
    onSelectLearningExperience: (isExperienced: Boolean) -> Unit = { onSetLearningAllAccess(it) },
    onToggleArabicLetterMastered: (String) -> Unit = {},
    onActiveTabChanged: (LearningHubTab) -> Unit = {},
    onBack: () -> Unit,
    onAskRuhZebaAi: (String, String) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current

    BackHandler(onBack = {
        onStopSpeech()
        onBack()
    })

    DisposableEffect(Unit) {
        onDispose { onStopSpeech() }
    }

    var selectedTab by rememberSaveable(initialTab) {
        mutableStateOf(initialTab ?: LearningHubTab.GUIDED_PATH)
    }
    androidx.compose.runtime.LaunchedEffect(selectedTab, prefs.learningTrackChosen) {
        if (prefs.learningTrackChosen || initialTab != null) {
            onActiveTabChanged(selectedTab)
        }
    }
    var activeModuleId by rememberSaveable { mutableStateOf<String?>(null) }

    val completedSteps = remember(prefs.completedLearningStepsCsv) {
        prefs.completedLearningStepsCsv
            .split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .toSet()
    }
    val masteredLetters = remember(prefs.arabicMasteredLettersCsv) {
        prefs.arabicMasteredLettersCsv
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    val openSourceUrl: (String) -> Unit = remember(context) {
        { url ->
            runCatching {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        }
    }

    val isExperiencedLibrary = prefs.learningAllAccess || prefs.learningMode.equals("EXPERIENCED", ignoreCase = true)

    val learningDropdownOptions = remember(isBn, isExperiencedLibrary) {
        listOf(
            FoldedDropdownOption(
                value = LearningHubTab.GUIDED_PATH,
                label = if (isExperiencedLibrary) (if (isBn) "পাঠসমূহ" else "Lessons") else (if (isBn) "ধাপে ধাপে পাঠ" else "Guided Path"),
                subtitle = if (isBn) "ভিত্তিমূলক ইসলামিক পাঠ ও কুইজ" else "Structured foundations & quick checks",
                testTag = "learning_tab_path"
            ),
            FoldedDropdownOption(
                value = LearningHubTab.HOW_TO_PRAY,
                label = if (isBn) "সালাত ও অজু গাইড" else "How to Pray & Wudu",
                subtitle = if (isBn) "৩ডি মডেল সহ নামাজের প্রতিটি ধাপ" else "Articulated step-by-step Salah & Wudu",
                testTag = "learning_tab_pray"
            ),
            FoldedDropdownOption(
                value = LearningHubTab.ARABIC_STUDIO,
                label = if (isBn) "আরবি লেখা ও উচ্চারণ" else "Arabic Writing Studio",
                subtitle = if (isBn) "২৮ হরফ লেখা ও মাখরাজ শোনা" else "Trace 28 letters & listen to Makharij",
                testTag = "learning_tab_arabic_studio"
            ),
            FoldedDropdownOption(
                value = LearningHubTab.STORIES,
                label = if (isBn) "নবী ও সাহাবাদের গল্প" else "Prophet & Sahaba Stories",
                subtitle = if (isBn) "অডিও বর্ণনাসহ শিক্ষণীয় কাহিনি" else "Narrated authentic biographies",
                testTag = "learning_tab_stories"
            ),
            FoldedDropdownOption(
                value = LearningHubTab.ENCYCLOPEDIA,
                label = if (isBn) "ইসলামিক রেফারেন্স" else "Reference & Encyclopedia",
                subtitle = if (isBn) "আকিদাহ, ফিকহ ও প্রামাণ্য উত্তর" else "Aqeedah, Fiqh & verified rulings",
                testTag = "learning_tab_encyclopedia"
            ),
            FoldedDropdownOption(
                value = LearningHubTab.HAJJ_UMRAH,
                label = if (isBn) "হজ ও উমরাহ গাইড" else "Hajj & Umrah",
                subtitle = if (isBn) "প্রতিটি রুকন ও মাসনুন দুআ" else "Rites checklist & Talbiyah Duas",
                testTag = "learning_tab_hajj"
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("islamic_learning_hub_screen")
    ) {
        // Clean Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconButton(
                    onClick = {
                        onStopSpeech()
                        onBack()
                    },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("learning_hub_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = if (isBn) "ফিরে যান" else "Back",
                        tint = palette.textPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = if (isBn) "ইসলামিক শিক্ষা" else "Islamic Learning",
                        style = MaterialTheme.typography.titleLarge,
                        color = palette.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (!prefs.learningTrackChosen && initialTab == null) {
                            if (isBn) "আপনার শেখার ধরন নির্বাচন করুন" else "Choose your learning style to begin"
                        } else if (isExperiencedLibrary) {
                            if (isBn) "ওপেন লাইব্রেরি • সব বিভাগ উন্মুক্ত" else "Open Library • All categories unlocked"
                        } else {
                            if (isBn) "ধাপে ধাপে শিক্ষা • কুইজ দিয়ে আনলক" else "Beginner Path • Step-by-step with quizzes"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (prefs.learningTrackChosen || initialTab != null) {
                GlassFilterChip(
                    label = if (isExperiencedLibrary) {
                        if (isBn) "লাইব্রেরি" else "Library"
                    } else {
                        if (isBn) "বিগিনার" else "Beginner"
                    },
                    selected = isExperiencedLibrary,
                    icon = if (isExperiencedLibrary) Icons.Default.LockOpen else Icons.Default.School,
                    onClick = { onSelectLearningExperience(!isExperiencedLibrary) },
                    modifier = Modifier
                        .tutorialTarget(TutorialTargetKeys.LEARN_MODE_CHIP)
                        .testTag("learning_mode_switcher_chip")
                )
            } else {
                StatusPillBadge(
                    label = "${completedSteps.size}/${IslamicAcademyCurriculum.guidedModules.size}",
                    accentColor = palette.gold,
                    icon = Icons.Default.School
                )
            }
        }

        // Phase 1: Mandatory Beginner vs. Experienced Selection Gate
        if (!prefs.learningTrackChosen && initialTab == null) {
            LearningExperienceGateContent(
                isBn = isBn,
                onChooseBeginner = {
                    onSelectLearningExperience(false)
                    selectedTab = LearningHubTab.GUIDED_PATH
                },
                onChooseExperienced = {
                    onSelectLearningExperience(true)
                    selectedTab = LearningHubTab.GUIDED_PATH
                }
            )
            return
        }

        Spacer(modifier = Modifier.height(4.dp))

        Box(
            modifier = Modifier
                .padding(horizontal = 14.dp)
                .tutorialTarget(TutorialTargetKeys.LEARN_SECTION_DROPDOWN)
        ) {
            FoldedPageDropdown(
                options = learningDropdownOptions,
                selected = selectedTab,
                onSelect = {
                    onStopSpeech()
                    selectedTab = it
                },
                sectionLabel = if (isBn) "শিক্ষার বিভাগ" else "Learning Section",
                triggerTestTag = "learning_section_dropdown"
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = {
                (fadeIn(tween(220, easing = FastOutSlowInEasing)) +
                    slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { it / 14 } +
                    scaleIn(initialScale = 0.98f, animationSpec = tween(220))) togetherWith
                    (fadeOut(tween(150)) + slideOutHorizontally(tween(160)) { -it / 16 })
            },
            modifier = Modifier.weight(1f),
            label = "learningTabTransition"
        ) { activeLearningTab ->
        when (activeLearningTab) {
            LearningHubTab.GUIDED_PATH -> GuidedPathTabContent(
                isBn = isBn,
                completedSteps = completedSteps,
                allAccess = isExperiencedLibrary,
                onToggleAllAccess = onSelectLearningExperience,
                onOpenModule = { activeModuleId = it.id }
            )

            LearningHubTab.HOW_TO_PRAY -> PhotorealisticPrayerCoachTab(
                isBn = isBn,
                defaultGender = prefs.characterGender,
                speakingItemId = speakingItemId,
                onSpeakArabic = onSpeakArabic,
                onSpeakLocalized = onSpeakLocalized,
                onOpenUrl = openSourceUrl,
                onAskRuhZenaAi = { prompt -> onAskRuhZebaAi("ISLAMIC", prompt) }
            )

            LearningHubTab.ARABIC_STUDIO -> ArabicWritingStudioTab(
                isBn = isBn,
                masteredLetterKeys = masteredLetters,
                speakingItemId = speakingItemId,
                onSpeakArabic = onSpeakArabic,
                onToggleMastered = onToggleArabicLetterMastered,
                onAskRuhZenaAi = { prompt -> onAskRuhZebaAi("ISLAMIC", prompt) }
            )

            LearningHubTab.STORIES -> StoriesTabContent(
                isBn = isBn,
                isExperiencedMode = isExperiencedLibrary,
                speakingItemId = speakingItemId,
                onSpeakArabic = onSpeakArabic,
                onSpeakLocalized = onSpeakLocalized,
                onOpenUrl = openSourceUrl
            )

            LearningHubTab.ENCYCLOPEDIA -> EncyclopediaTabContent(
                isBn = isBn,
                speakingItemId = speakingItemId,
                onSpeakArabic = onSpeakArabic,
                onSpeakLocalized = onSpeakLocalized,
                onOpenUrl = openSourceUrl,
                onAskRuhZenaAi = { prompt -> onAskRuhZebaAi("ISLAMIC", prompt) }
            )

            LearningHubTab.HAJJ_UMRAH -> HajjUmrahTabContent(
                isBn = isBn,
                speakingItemId = speakingItemId,
                onSpeakArabic = onSpeakArabic,
                onSpeakLocalized = onSpeakLocalized
            )
        }
        }
    }

    val openedModule = remember(activeModuleId) {
        IslamicAcademyCurriculum.guidedModules.firstOrNull { it.id == activeModuleId }
    }
    if (openedModule != null) {
        GuidedModuleLessonDialog(
            module = openedModule,
            isBn = isBn,
            isExperiencedMode = isExperiencedLibrary,
            alreadyCompleted = completedSteps.contains(openedModule.stepNumber),
            speakingItemId = speakingItemId,
            onSpeakArabic = onSpeakArabic,
            onSpeakLocalized = onSpeakLocalized,
            onStopSpeech = onStopSpeech,
            onOpenUrl = openSourceUrl,
            onJumpRelated = { tag ->
                onStopSpeech()
                activeModuleId = null
                if (tag == "PRAYER_GUIDE") selectedTab = LearningHubTab.HOW_TO_PRAY
                if (tag == "ARABIC_STUDIO") selectedTab = LearningHubTab.ARABIC_STUDIO
            },
            onPassedQuiz = {
                onCompleteLearningStep(openedModule.stepNumber)
            },
            onAskAi = { prompt ->
                onStopSpeech()
                activeModuleId = null
                onAskRuhZebaAi("ISLAMIC", prompt)
            },
            onDismiss = {
                onStopSpeech()
                activeModuleId = null
            }
        )
    }
}

@Composable
private fun GuidedPathTabContent(
    isBn: Boolean,
    completedSteps: Set<Int>,
    allAccess: Boolean,
    onToggleAllAccess: (Boolean) -> Unit,
    onOpenModule: (GuidedLearningModule) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val modules = IslamicAcademyCurriculum.guidedModules
    val ratio = (completedSteps.size.toFloat() / modules.size.toFloat()).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("learning_guided_path_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Mastery Progress & Step-Lock Info Card
        item {
            GlassCard(accentBorder = true, elevated = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (allAccess) {
                                if (isBn) "ইসলামিক ওপেন লাইব্রেরি" else "Islamic Knowledge Library"
                            } else {
                                if (isBn) "ধাপে ধাপে ইসলামিক শিক্ষা" else "Step-by-Step Guided Path"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (allAccess) {
                                if (isBn) {
                                    "সব বিষয় সরাসরি পড়ুন, শুনুন এবং প্রামাণ্য দলিলসহ জানুন — কোনো লক বা সময়সীমা নেই।"
                                } else {
                                    "Explore any Islamic topic freely with authentic Quran & Sahih Hadith references."
                                }
                            } else if (isBn) {
                                "প্রতিটি ধাপ শেষ করে ছোট ৩ প্রশ্নের কুইজ পাস করলে পরবর্তী ধাপ খুলে যাবে।"
                            } else {
                                "Finish one lesson at a time and pass a quick 3-question check to unlock the next step."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    if (!allAccess) {
                        StatusPillBadge(
                            label = "${(ratio * 100).toInt()}%",
                            accentColor = palette.accentSoft
                        )
                    }
                }
                if (!allAccess) {
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { ratio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = palette.accentSoft,
                        trackColor = palette.blockBg
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = if (allAccess) Icons.Default.LockOpen else Icons.Default.Lock,
                            contentDescription = null,
                            tint = palette.gold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBn) "অভিজ্ঞ শিক্ষার্থী (ওপেন লাইব্রেরি)" else "Experienced learner (Open Library)",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textSecondary
                        )
                    }
                    Switch(
                        checked = allAccess,
                        onCheckedChange = onToggleAllAccess,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = palette.onAccent,
                            checkedTrackColor = palette.accentPrimary
                        ),
                        modifier = Modifier.testTag("learning_all_access_switch")
                    )
                }
            }
        }

        // Sequential Module Cards
        items(modules, key = { it.id }) { module ->
            val isCompleted = completedSteps.contains(module.stepNumber)
            val isUnlocked = allAccess || module.stepNumber == 1 || completedSteps.contains(module.stepNumber - 1)

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("learning_module_step_${module.stepNumber}"),
                accentBorder = isUnlocked && !isCompleted,
                elevated = isUnlocked && !isCompleted,
                onClick = if (isUnlocked) ({ onOpenModule(module) }) else null
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(
                                    when {
                                        isCompleted -> palette.success.copy(alpha = 0.18f)
                                        isUnlocked -> palette.accentContainer
                                        else -> palette.blockBg
                                    },
                                    CircleShape
                                )
                                .border(
                                    1.dp,
                                    when {
                                        isCompleted -> palette.success
                                        isUnlocked -> palette.borderAccent
                                        else -> palette.borderNeutral
                                    },
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            when {
                                isCompleted -> Icon(Icons.Default.CheckCircle, contentDescription = null, tint = palette.success, modifier = Modifier.size(20.dp))
                                allAccess -> Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(19.dp))
                                isUnlocked -> Text(
                                    text = "${module.stepNumber}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.accentSoft,
                                    fontWeight = FontWeight.Bold
                                )
                                else -> Icon(Icons.Default.Lock, contentDescription = "Locked", tint = palette.textMuted, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBn) module.titleBn else module.titleEn,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isUnlocked) palette.textPrimary else palette.textMuted,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (isUnlocked) {
                                    if (isBn) module.subtitleBn else module.subtitleEn
                                } else {
                                    if (isBn) "ধাপ ${module.stepNumber - 1} এর কুইজ সম্পন্ন করলে খুলবে" else "Pass Step ${module.stepNumber - 1} quiz to unlock"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                    }
                    if (!allAccess || isCompleted) {
                        Spacer(modifier = Modifier.width(8.dp))
                        StatusPillBadge(
                            label = when {
                                isCompleted -> if (isBn) "সম্পন্ন" else "Passed"
                                isUnlocked -> "${module.durationMinutes} min"
                                else -> if (isBn) "লকড" else "Locked"
                            },
                            accentColor = when {
                                isCompleted -> palette.success
                                isUnlocked -> palette.gold
                                else -> palette.textMuted
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GuidedModuleLessonDialog(
    module: GuidedLearningModule,
    isBn: Boolean,
    isExperiencedMode: Boolean,
    alreadyCompleted: Boolean,
    speakingItemId: String?,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit,
    onSpeakLocalized: (itemId: String, text: String) -> Unit,
    onStopSpeech: () -> Unit,
    onOpenUrl: (String) -> Unit,
    onJumpRelated: (String) -> Unit,
    onPassedQuiz: () -> Unit,
    onAskAi: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    var showQuiz by rememberSaveable(module.id) { mutableStateOf(false) }
    val selectedAnswers = remember(module.id) { mutableStateMapOf<Int, Int>() }
    var quizSubmitted by rememberSaveable(module.id) { mutableStateOf(false) }
    var lastScore by rememberSaveable(module.id) { mutableIntStateOf(0) }

    val lessonAudioId = "module_audio_${module.id}"
    val isListening = speakingItemId == lessonAudioId

    val fullLessonSpeech = remember(module.id, isBn) {
        buildString {
            append(if (isBn) module.titleBn else module.titleEn)
            append(". ")
            module.points.forEach { p ->
                append(if (isBn) p.headingBn else p.headingEn)
                append(". ")
                append(if (isBn) p.bodyBn else p.bodyEn)
                append(" ")
            }
        }
    }

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler {
            if (showQuiz) showQuiz = false else onDismiss()
        }
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("guided_module_dialog_${module.stepNumber}"),
            color = palette.voidBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 12.dp)
            ) {
                // Dialog Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        StatusPillBadge(
                            label = if (isExperiencedMode) {
                                if (isBn) "ইসলামিক পাঠাগার" else "Knowledge Reference"
                            } else {
                                "${if (isBn) "ধাপ" else "Step"} ${module.stepNumber} • ${module.durationMinutes} min"
                            },
                            accentColor = palette.gold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isBn) module.titleBn else module.titleEn,
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_module_dialog")) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textPrimary)
                    }
                }

                if (!showQuiz) {
                    // Lesson Study View
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            GlassCard(accentBorder = true) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = module.arabicTitle,
                                        style = MaterialTheme.typography.headlineSmall.copy(
                                            fontFamily = ArabicFontFamily,
                                            textDirection = TextDirection.Rtl
                                        ),
                                        color = palette.gold
                                    )
                                    GlassFilterChip(
                                        label = if (isListening) {
                                            if (isBn) "থামান" else "Stop Audio"
                                        } else {
                                            if (isBn) "পাঠ শুনুন" else "Listen Lesson"
                                        },
                                        selected = isListening,
                                        icon = if (isListening) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                        onClick = { onSpeakLocalized(lessonAudioId, fullLessonSpeech) },
                                        modifier = Modifier.testTag("module_listen_button")
                                    )
                                }
                            }
                        }

                        items(module.points) { pt ->
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (isBn) pt.headingBn else pt.headingEn,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.accentSoft,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (pt.arabicSnippet.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val arSpeechId = "mod_ar_${module.id}_${pt.headingEn.hashCode()}"
                                    val arPlaying = speakingItemId == arSpeechId
                                    val pronText = pt.arabicTransliteration.ifBlank {
                                        resolveArabicPronunciation(pt.arabicSnippet)
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        IconButton(
                                            onClick = { onSpeakArabic(arSpeechId, pt.arabicSnippet, pronText.ifBlank { pt.headingEn }) },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (arPlaying) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                                contentDescription = "Listen Arabic",
                                                tint = if (arPlaying) palette.gold else palette.accentSoft
                                            )
                                        }
                                        Text(
                                            text = pt.arabicSnippet,
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontFamily = ArabicFontFamily,
                                                fontSize = 21.sp,
                                                lineHeight = 34.sp,
                                                textDirection = TextDirection.Rtl
                                            ),
                                            color = palette.gold,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (pronText.isNotBlank()) {
                                        Text(
                                            text = "${if (isBn) "উচ্চারণ:" else "Pronunciation:"} $pronText",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = palette.accentSoft,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isBn) pt.bodyBn else pt.bodyEn,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = palette.textPrimary
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                GoldSourceTag(
                                    sourceText = "${pt.sourceRef} ↗",
                                    modifier = Modifier.clickable { onOpenUrl(pt.sourceUrl) }
                                )
                            }
                        }

                        if (module.relatedActionTag != null) {
                            item {
                                GlassCard(accentBorder = true) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (module.relatedActionTag == "PRAYER_GUIDE") {
                                                if (isBn) "ভিজ্যুয়াল সালাত ও অজু কোচ দেখুন" else "Practice in Visual Salah & Wudu Coach"
                                            } else {
                                                if (isBn) "আরবি হরফ লেখার স্টুডিও খুলুন" else "Practice in Arabic Writing Studio"
                                            },
                                            style = MaterialTheme.typography.labelLarge,
                                            color = palette.textPrimary,
                                            modifier = Modifier.weight(1f)
                                        )
                                        GlassFilterChip(
                                            label = if (isBn) "খুলুন" else "Open",
                                            selected = true,
                                            icon = Icons.Default.PlayArrow,
                                            onClick = { onJumpRelated(module.relatedActionTag) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassFilterChip(
                            label = if (isBn) "AI-কে প্রশ্ন" else "Ask AI",
                            selected = false,
                            icon = Icons.Default.AutoAwesome,
                            onClick = {
                                val q = if (isBn) "${module.titleBn} সহজ উদাহরণসহ আরও বিস্তারিত বুঝিয়ে বলুন।"
                                else "Help me understand '${module.titleEn}' more deeply with practical daily examples."
                                onAskAi(q)
                            }
                        )
                        EmeraldActionButton(
                            text = if (alreadyCompleted) {
                                if (isBn) "কুইজ পুনরায় দিন" else "Retake Quick Check"
                            } else {
                                if (isBn) "৩ প্রশ্নের কুইজ দিয়ে পরের ধাপ খুলুন" else "Take 3-Question Check"
                            },
                            icon = Icons.Default.Quiz,
                            onClick = {
                                onStopSpeech()
                                showQuiz = true
                            },
                            modifier = Modifier.weight(1f).testTag("module_start_quiz_button")
                        )
                    }
                } else {
                    // Verification Quiz View
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            GlassCard(accentBorder = true) {
                                Text(
                                    text = if (isBn) "সংক্ষিপ্ত যাচাই কুইজ (পাস করতে কমপক্ষে ২/৩)" else "Quick Understanding Check (2/3 to unlock next step)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.gold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        module.quiz.forEachIndexed { qIdx, question ->
                            item(key = "q_$qIdx") {
                                val chosen = selectedAnswers[qIdx]
                                GlassCard(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "${qIdx + 1}. ${if (isBn) question.questionBn else question.questionEn}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = palette.textPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    val opts = if (isBn) question.optionsBn else question.optionsEn
                                    opts.forEachIndexed { optIdx, label ->
                                        val isSelected = chosen == optIdx
                                        val isCorrect = optIdx == question.correctIndex
                                        val bg = when {
                                            quizSubmitted && isCorrect -> palette.success.copy(alpha = 0.22f)
                                            quizSubmitted && isSelected && !isCorrect -> palette.coral.copy(alpha = 0.22f)
                                            isSelected -> palette.accentContainer
                                            else -> palette.blockBg
                                        }
                                        val borderC = when {
                                            quizSubmitted && isCorrect -> palette.success
                                            quizSubmitted && isSelected && !isCorrect -> palette.coral
                                            isSelected -> palette.borderAccent
                                            else -> palette.borderNeutral
                                        }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 3.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(bg)
                                                .border(0.9.dp, borderC, RoundedCornerShape(12.dp))
                                                .clickable(enabled = !quizSubmitted) {
                                                    selectedAnswers[qIdx] = optIdx
                                                }
                                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                                .testTag("quiz_q${qIdx}_opt${optIdx}"),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = label,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = palette.textPrimary
                                            )
                                        }
                                    }

                                    if (quizSubmitted) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = if (isBn) question.explanationBn else question.explanationEn,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.gold
                                        )
                                    }
                                }
                            }
                        }

                        if (quizSubmitted) {
                            item {
                                val passed = lastScore >= 2
                                GlassCard(accentBorder = true, elevated = true) {
                                    Text(
                                        text = if (passed) {
                                            if (isBn) "মাশাআল্লাহ! আপনি $lastScore / ${module.quiz.size} পেয়েছেন — পরবর্তী ধাপ খুলে গেছে!"
                                            else "MashaAllah! You scored $lastScore / ${module.quiz.size} — Next step unlocked!"
                                        } else {
                                            if (isBn) "আপনার স্কোর $lastScore / ${module.quiz.size}। পাঠটি আরেকবার দেখে আবার চেষ্টা করুন।"
                                            else "You scored $lastScore / ${module.quiz.size}. Review the lesson and try again!"
                                        },
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (passed) palette.success else palette.coral,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassFilterChip(
                            label = if (isBn) "পাঠে ফিরুন" else "Back to Lesson",
                            selected = false,
                            onClick = {
                                showQuiz = false
                                quizSubmitted = false
                            }
                        )
                        if (!quizSubmitted) {
                            EmeraldActionButton(
                                text = if (isBn) "উত্তর যাচাই করুন" else "Submit Answers",
                                enabled = selectedAnswers.size == module.quiz.size,
                                onClick = {
                                    val score = module.quiz.indices.count { i ->
                                        selectedAnswers[i] == module.quiz[i].correctIndex
                                    }
                                    lastScore = score
                                    quizSubmitted = true
                                    if (score >= 2) {
                                        onPassedQuiz()
                                    }
                                },
                                modifier = Modifier.weight(1f).testTag("module_submit_quiz_button")
                            )
                        } else if (lastScore >= 2) {
                            EmeraldActionButton(
                                text = if (isBn) "সম্পন্ন" else "Continue Path",
                                icon = Icons.Default.CheckCircle,
                                onClick = onDismiss,
                                modifier = Modifier.weight(1f).testTag("module_quiz_continue_button")
                            )
                        } else {
                            EmeraldActionButton(
                                text = if (isBn) "আবার চেষ্টা করুন" else "Try Again",
                                icon = Icons.Default.Refresh,
                                onClick = {
                                    selectedAnswers.clear()
                                    quizSubmitted = false
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LearningExperienceGateContent(
    isBn: Boolean,
    onChooseBeginner: () -> Unit,
    onChooseExperienced: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("learning_experience_gate"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard(accentBorder = true, elevated = true) {
                Text(
                    text = if (isBn) "আপনার ইসলামিক শিক্ষার স্তর বেছে নিন" else "Choose Your Learning Experience",
                    style = MaterialTheme.typography.headlineSmall,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBn) {
                        "নতুন শিক্ষার্থী হলে ধাপে ধাপে কুইজভিত্তিক পদ্ধতি স্বয়ংক্রিয়ভাবে চালু হবে। আর অভিজ্ঞ হলে সম্পূর্ণ ওপেন লাইব্রেরি হিসেবে প্রতিটি আলাদা বিভাগে সরাসরি প্রবেশ করতে পারবেন।"
                    } else {
                        "Pick how you want to learn. Beginners get a calm step-by-step progression with quick quizzes; experienced learners unlock the full open library with dedicated tabs for every topic."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
            }
        }

        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.LEARN_GATE_BEGINNER)
                    .testTag("learning_choose_beginner"),
                accentBorder = true,
                elevated = true,
                onClick = onChooseBeginner
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(palette.accentContainer, CircleShape)
                            .border(1.dp, palette.borderAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.School, contentDescription = null, tint = palette.accentSoft)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "নতুন শিক্ষার্থী (ধাপে ধাপে)" else "Beginner — Guided Path",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isBn) "একটি ধাপ শেষ করে ছোট কুইজ দিয়ে পরের ধাপ খুলুন" else "Learn one foundation at a time; pass quick checks to unlock next steps",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                EmeraldActionButton(
                    text = if (isBn) "ধাপে ধাপে শুরু করুন" else "Start Step-by-Step Path",
                    onClick = onChooseBeginner,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.LEARN_GATE_EXPERIENCED)
                    .testTag("learning_choose_experienced"),
                elevated = true,
                onClick = onChooseExperienced
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(palette.gold.copy(alpha = 0.16f), CircleShape)
                            .border(1.dp, palette.gold.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.LockOpen, contentDescription = null, tint = palette.gold)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "অভিজ্ঞ শিক্ষার্থী (ওপেন লাইব্রেরি)" else "Experienced — Open Library",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isBn) "সব পাঠ, সালাত, আরবি লেখা, গল্প, রেফারেন্স ও হজ আলাদা ট্যাবে উন্মুক্ত" else "Instant access to all lessons, Salah, Arabic Writing, Stories, Reference & Hajj tabs",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                GlassFilterChip(
                    label = if (isBn) "ওপেন লাইব্রেরি খুলুন" else "Open Full Library",
                    selected = true,
                    icon = Icons.Default.LockOpen,
                    onClick = onChooseExperienced,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun StoriesTabContent(
    isBn: Boolean,
    isExperiencedMode: Boolean,
    speakingItemId: String?,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit,
    onSpeakLocalized: (itemId: String, text: String) -> Unit,
    onOpenUrl: (String) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    var query by rememberSaveable { mutableStateOf("") }

    var activeReaderStory by remember { mutableStateOf<NarratedIslamicStory?>(null) }

    val filteredStories = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) IslamicAcademyCurriculum.narratedStories
        else IslamicAcademyCurriculum.narratedStories.filter {
            it.titleEn.lowercase().contains(q) || it.titleBn.contains(q) ||
                it.storyEn.lowercase().contains(q) || it.explanationEn.lowercase().contains(q) ||
                it.categoryEn.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("learning_stories_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassCard(accentBorder = true) {
                Text(
                    text = if (isBn) "ইসলামের পূর্ণাঙ্গ কালানুক্রমিক গল্প ও প্রামাণ্য ব্যাখ্যা" else "Full Chronological Islamic Stories & Explanations",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = if (isBn) "সৃষ্টির সূচনা → আদম (আ.) → নবীগণ → নবী মুহাম্মদ ﷺ → সাহাবায়ে কেরাম (রা.) • তাফসীর ও হাদীসের ব্যাখ্যাসহ" else "Creation → Adam (AS) → Prophets → Muhammad ﷺ → Companions (RA) • Full Narrative & Tafsir Commentary",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.gold
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = {
                        Text(if (isBn) "এখানে লিখুন" else "Type here", color = palette.textMuted)
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accentSoft) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.borderAccent,
                        unfocusedBorderColor = palette.borderNeutral,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    )
                )
            }
        }

        items(filteredStories, key = { it.id }) { story ->
            val speechId = "story_${story.id}"
            val playing = speakingItemId == speechId
            val eraBadge = if (isBn) {
                story.eraLabelBn.ifBlank { story.categoryBn }
            } else {
                story.eraLabelEn.ifBlank { story.categoryEn }
            }
            val storyBody = if (isBn) story.storyBn else story.storyEn
            val previewText = remember(storyBody) {
                storyBody.replace("\n\n", " ").take(420).let { if (storyBody.length > 420) "$it…" else it }
            }
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { activeReaderStory = story }
                    .testTag("story_card_${story.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(
                        label = if (isExperiencedMode) eraBadge else "$eraBadge • ${story.estimatedReadMinutes}m",
                        accentColor = palette.accentSoft
                    )
                    GlassFilterChip(
                        label = if (playing) {
                            if (isBn) "থামান" else "Stop"
                        } else {
                            if (isBn) "শুনুন" else "Listen"
                        },
                        selected = playing,
                        icon = if (playing) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                        onClick = {
                            val spoken = buildString {
                                if (isBn) {
                                    append("${story.titleBn}. ${story.storyBn}. ")
                                    if (story.explanationBn.isNotBlank()) append("বিস্তারিত ব্যাখ্যা: ${story.explanationBn}. ")
                                    append("মূল শিক্ষা: ${story.lessonBn}")
                                } else {
                                    append("${story.titleEn}. ${story.storyEn} ")
                                    if (story.explanationEn.isNotBlank()) append("Authentic explanation: ${story.explanationEn} ")
                                    append("Key reflection: ${story.lessonEn}")
                                }
                            }
                            onSpeakLocalized(speechId, spoken)
                        },
                        modifier = Modifier.testTag("listen_story_${story.id}")
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isBn) story.titleBn else story.titleEn,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = story.arabicName,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontFamily = ArabicFontFamily,
                        textDirection = TextDirection.Rtl
                    ),
                    color = palette.gold
                )
                val storyPron = story.arabicNameTransliteration.ifBlank { resolveArabicPronunciation(story.arabicName) }
                if (storyPron.isNotBlank()) {
                    Text(
                        text = "${if (isBn) "উচ্চারণ:" else "Pronunciation:"} $storyPron",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.accentSoft
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = previewText,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GoldSourceTag(
                        sourceText = "${story.sourceRef} ↗",
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .clickable { onOpenUrl(story.sourceUrl) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    GlassFilterChip(
                        label = if (isBn) "পূর্ণ গল্প ও ব্যাখ্যা পড়ুন" else "Read Full Story & Explanation",
                        selected = true,
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        onClick = { activeReaderStory = story },
                        modifier = Modifier.testTag("open_full_story_${story.id}")
                    )
                }
            }
        }
    }

    activeReaderStory?.let { story ->
        DetailedStoryReaderDialog(
            story = story,
            isBn = isBn,
            isExperiencedMode = isExperiencedMode,
            isPlaying = speakingItemId == "story_${story.id}",
            onToggleListen = {
                val spoken = buildString {
                    if (isBn) {
                        append("${story.titleBn}. ${story.storyBn}. ")
                        if (story.explanationBn.isNotBlank()) append("তাফসীর ও প্রামাণ্য ব্যাখ্যা: ${story.explanationBn}. ")
                        append("মূল শিক্ষা: ${story.lessonBn}")
                    } else {
                        append("${story.titleEn}. ${story.storyEn} ")
                        if (story.explanationEn.isNotBlank()) append("Scholarly explanation: ${story.explanationEn} ")
                        append("Key reflection: ${story.lessonEn}")
                    }
                }
                onSpeakLocalized("story_${story.id}", spoken)
            },
            onOpenUrl = onOpenUrl,
            onDismiss = { activeReaderStory = null }
        )
    }
}

@Composable
private fun DetailedStoryReaderDialog(
    story: NarratedIslamicStory,
    isBn: Boolean,
    isExperiencedMode: Boolean,
    isPlaying: Boolean,
    onToggleListen: () -> Unit,
    onOpenUrl: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val storyParagraphs = remember(story, isBn) {
        (if (isBn) story.storyBn else story.storyEn)
            .split("\n\n")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }
    val explanationText = if (isBn) story.explanationBn else story.explanationEn
    val quoteText = if (isBn) story.keyVerseOrHadithBn else story.keyVerseOrHadithEn

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = palette.surfaceBg
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(bottom = 10.dp)) {
                // Header bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.cardElevatedBg)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(
                        label = if (isBn) story.eraLabelBn.ifBlank { story.categoryBn } else story.eraLabelEn.ifBlank { story.categoryEn },
                        accentColor = palette.gold
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GlassFilterChip(
                            label = if (isPlaying) {
                                if (isBn) "থামান" else "Stop Audio"
                            } else {
                                if (isBn) "পূর্ণ গল্প শুনুন" else "Listen Full Story"
                            },
                            selected = isPlaying,
                            icon = if (isPlaying) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            onClick = onToggleListen,
                            modifier = Modifier.testTag("dialog_listen_story_${story.id}")
                        )
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_story_reader_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = if (isBn) "বন্ধ করুন" else "Close story",
                                tint = palette.textPrimary
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (isBn) story.titleBn else story.titleEn,
                        style = MaterialTheme.typography.headlineSmall,
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = story.arabicName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = ArabicFontFamily,
                            textDirection = TextDirection.Rtl
                        ),
                        color = palette.gold
                    )
                    val pron = story.arabicNameTransliteration.ifBlank { resolveArabicPronunciation(story.arabicName) }
                    if (pron.isNotBlank()) {
                        Text(
                            text = if (isExperiencedMode) {
                                "${if (isBn) "উচ্চারণ:" else "Pronunciation:"} $pron"
                            } else {
                                "${if (isBn) "উচ্চারণ:" else "Pronunciation:"} $pron • ${story.estimatedReadMinutes} min"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.accentSoft
                        )
                    }

                    if (quoteText.isNotBlank()) {
                        GlassCard(accentBorder = true, elevated = true) {
                            Text(
                                text = if (isBn) "কুরআন ও হাদীসের প্রামাণ্য বাণী" else "Quran & Authentic Hadith Anchor",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.gold,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = quoteText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textPrimary,
                                lineHeight = 22.sp
                            )
                        }
                    }

                    // Full Multi-Paragraph Narrative
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = if (isBn) "পূর্ণাঙ্গ ঐতিহাসিক বিবরণ" else "Complete Authentic Narrative",
                            style = MaterialTheme.typography.titleSmall,
                            color = palette.accentSoft,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        storyParagraphs.forEachIndexed { idx, para ->
                            Text(
                                text = para,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textPrimary,
                                lineHeight = 24.sp
                            )
                            if (idx < storyParagraphs.lastIndex) {
                                Spacer(modifier = Modifier.height(10.dp))
                            }
                        }
                    }

                    // Dedicated Scholarly Explanation & Tafsir Commentary Card
                    if (explanationText.isNotBlank()) {
                        GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true, elevated = true) {
                            Text(
                                text = if (isBn) "গভীর তাফসীর ও প্রামাণ্য ব্যাখ্যা" else "Detailed Explanation & Scholarly Commentary",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.gold,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = explanationText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textSecondary,
                                lineHeight = 23.sp
                            )
                        }
                    }

                    // Key Life Reflection
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.blockBg)
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (isBn) "জীবনের জন্য মূল শিক্ষা" else "Practical Spiritual Takeaway",
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.gold,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isBn) story.lessonBn else story.lessonEn,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textPrimary,
                                lineHeight = 22.sp
                            )
                        }
                    }

                    GoldSourceTag(
                        sourceText = "${story.sourceRef} ↗",
                        modifier = Modifier
                            .clickable { onOpenUrl(story.sourceUrl) }
                            .testTag("story_reader_source_link")
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun EncyclopediaTabContent(
    isBn: Boolean,
    speakingItemId: String?,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit,
    onSpeakLocalized: (itemId: String, text: String) -> Unit,
    onOpenUrl: (String) -> Unit,
    onAskRuhZenaAi: (String) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    var query by rememberSaveable { mutableStateOf("") }

    val filteredEntries = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) IslamicAcademyCatalog.encyclopediaEntries
        else IslamicAcademyCatalog.encyclopediaEntries.filter {
            it.titleEn.lowercase().contains(q) || it.titleBn.contains(q) ||
                it.summaryEn.lowercase().contains(q) || it.arabicTerm.contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("learning_encyclopedia_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassCard(accentBorder = true) {
                Text(
                    text = if (isBn) "ইসলামিক এনসাইক্লোপিডিয়া ও রেফারেন্স" else "Islamic Reference & Encyclopedia",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = {
                        Text(if (isBn) "এখানে লিখুন" else "Type here", color = palette.textMuted)
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accentSoft) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.borderAccent,
                        unfocusedBorderColor = palette.borderNeutral,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    )
                )
            }
        }

        items(filteredEntries, key = { it.id }) { entry ->
            val speechId = "enc_${entry.id}"
            val playing = speakingItemId == speechId
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBn) entry.titleBn else entry.titleEn,
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            val spoken = if (isBn) "${entry.titleBn}. ${entry.summaryBn}" else "${entry.titleEn}. ${entry.summaryEn}"
                            onSpeakLocalized(speechId, spoken)
                        }
                    ) {
                        Icon(
                            imageVector = if (playing) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen",
                            tint = if (playing) palette.gold else palette.accentSoft
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val arId = "enc_ar_${entry.id}"
                    val arPlaying = speakingItemId == arId
                    Text(
                        text = entry.arabicTerm,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = ArabicFontFamily,
                            textDirection = TextDirection.Rtl
                        ),
                        color = palette.gold
                    )
                    IconButton(
                        onClick = { onSpeakArabic(arId, entry.arabicTerm, entry.titleEn) },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = if (arPlaying) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen Arabic Term",
                            tint = if (arPlaying) palette.gold else palette.textSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                val encPron = resolveArabicPronunciation(entry.arabicTerm, entry.titleEn)
                if (encPron.isNotBlank()) {
                    Text(
                        text = "${if (isBn) "উচ্চারণ:" else "Pronunciation:"} $encPron",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.accentSoft
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBn) entry.summaryBn else entry.summaryEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                GoldSourceTag(
                    sourceText = "${entry.evidenceRef} ↗",
                    modifier = Modifier.clickable { onOpenUrl(entry.sourceUrl) }
                )
                Spacer(modifier = Modifier.height(8.dp))
                GlassFilterChip(
                    label = if (isBn) "AI-কে প্রশ্ন" else "Ask RuhZena AI",
                    selected = false,
                    icon = Icons.Default.AutoAwesome,
                    onClick = {
                        onAskRuhZenaAi("Explain '${entry.titleEn}' with authentic Quran and Hadith context (${entry.evidenceRef}).")
                    }
                )
            }
        }
    }
}

@Composable
private fun HajjUmrahTabContent(
    isBn: Boolean,
    speakingItemId: String?,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit,
    onSpeakLocalized: (itemId: String, text: String) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    var checkedHajjIds by rememberSaveable { mutableStateOf(setOf<String>()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("learning_hajj_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassCard(accentBorder = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "হজ ও উমরাহ ধাপে ধাপে গাইড" else "Hajj & Umrah Step-by-Step Guide",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isBn) "প্রতিটি রুকন ও দুআ শুনুন এবং সম্পন্ন হলে টিক দিন" else "Listen to each rite & Arabic Dua, then check off steps",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    StatusPillBadge(
                        label = "${checkedHajjIds.size}/${IslamicLearningCatalog.hajjUmrahSteps.size}",
                        accentColor = palette.gold
                    )
                }
            }
        }

        itemsIndexed(IslamicLearningCatalog.hajjUmrahSteps, key = { _, step -> step.id }) { idx, step ->
            val checked = checkedHajjIds.contains(step.id)
            val speechId = "hajj_${step.id}"
            val arSpeechId = "hajj_ar_${step.id}"
            val playing = speakingItemId == speechId
            val playingAr = speakingItemId == arSpeechId
            val toggleStep = {
                checkedHajjIds = if (checked) checkedHajjIds - step.id else checkedHajjIds + step.id
            }
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hajj_step_card_${step.id}"),
                accentBorder = checked,
                elevated = checked,
                onClick = toggleStep
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        // Modern Liquid-Glass Step Milestone Emblem (replaces primitive checkbox)
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (checked) palette.gold.copy(alpha = 0.22f)
                                    else palette.accentContainer
                                )
                                .border(
                                    width = if (checked) 1.4.dp else 0.9.dp,
                                    color = if (checked) palette.gold else palette.borderAccent,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (checked) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Step completed",
                                    tint = palette.gold,
                                    modifier = Modifier.size(22.dp)
                                )
                            } else {
                                Text(
                                    text = "%02d".format(idx + 1),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.accentSoft
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusPillBadge(
                                    label = "${step.kind} • ${if (isBn) step.dayOrPhaseBn else step.dayOrPhaseEn}",
                                    accentColor = palette.gold
                                )
                                if (checked) {
                                    StatusPillBadge(
                                        label = if (isBn) "সম্পন্ন" else "Done",
                                        accentColor = palette.success
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = if (isBn) step.titleBn else step.titleEn,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = palette.textPrimary
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            val spoken = if (isBn) "${step.titleBn}. ${step.detailBn}" else "${step.titleEn}. ${step.detailEn}"
                            onSpeakLocalized(speechId, spoken)
                        }
                    ) {
                        Icon(
                            imageVector = if (playing) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen",
                            tint = if (playing) palette.gold else palette.accentSoft
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { onSpeakArabic(arSpeechId, step.arabicDua, step.transliteration) },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = if (playingAr) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen Arabic Dua",
                            tint = if (playingAr) palette.gold else palette.accentSoft
                        )
                    }
                    Text(
                        text = step.arabicDua,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = ArabicFontFamily,
                            textDirection = TextDirection.Rtl
                        ),
                        color = palette.gold,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    text = "${if (isBn) "উচ্চারণ:" else "Pronunciation:"} ${step.transliteration}",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.accentSoft
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isBn) step.detailBn else step.detailEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            }
        }
    }
}

/**
 * Provides clear phonetic transliteration / pronunciation for Arabic learning snippets & Islamic terms
 * across Guided Modules, Stories, and Encyclopedia entries so learners always know how to pronounce Arabic.
 */
private fun resolveArabicPronunciation(arabic: String, englishHint: String = ""): String {
    val clean = arabic.trim()
    if (clean.isBlank()) return ""
    // Curated exact transliterations for key Quranic verses & module snippets
    val knownPhrases = listOf(
        "قُلْ هُوَ اللَّهُ أَحَدٌ" to "Qul Huwallahu Ahad, Allahus-Samad",
        "وَإِذَا سَأَلَكَ عِبَادِي" to "Wa idha sa'alaka 'ibadi 'anni fa-inni qarib",
        "بِسْمِ اللَّهِ" to "Bismillah",
        "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ" to "Ashhadu an la ilaha illallah, wa ashhadu anna Muhammadan rasulullah",
        "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ" to "Innamal-a'malu bin-niyyat",
        "سُبْحَانَ اللَّهِ" to "SubhanAllah",
        "الْحَمْدُ لِلَّهِ" to "Alhamdulillah",
        "اللَّهُ أَكْبَرُ" to "Allahu Akbar",
        "لَا إِلَهَ إِلَّا اللَّهُ" to "La ilaha illallah",
        "أَسْتَغْفِرُ اللَّهَ" to "Astaghfirullah",
        "حَسْبُنَا اللَّهُ" to "Hasbunallahu wa ni'mal Wakil",
        "إِنَّ مَعَ الْعُسْرِ يُسْرًا" to "Inna ma'al-'usri yusra",
        "رَبِّ زِدْنِي عِلْمًا" to "Rabbi zidni 'ilma",
        "وَأَقِيمُوا الصَّلَاةَ" to "Wa aqimus-salah wa atuz-zakah",
        "يَا أَيُّهَا الَّذِينَ آمَنُوا" to "Ya ayyuhalladhina amanu...",
        "فَاذْكُرُونِي أَذْكُرْكُمْ" to "Fadhkuruni adhkurkum",
        "لَئِن شَكَرْتُمْ" to "La-in shakartum la-azidannakum",
        "وَقُولُوا لِلنَّاسِ حُسْنًا" to "Wa qulu lin-nasi husna",
        "الصَّلَاةُ" to "As-Salah",
        "الزَّكَاةُ" to "Az-Zakah",
        "الصَّوْمُ" to "As-Sawm",
        "الْحَجُّ" to "Al-Hajj",
        "التَّوْحِيدُ" to "At-Tawhid",
        "الْإِحْسَانُ" to "Al-Ihsan",
        "التَّقْوَى" to "At-Taqwa",
        "التَّوَكُّلُ" to "At-Tawakkul",
        "الصَّبْرُ" to "As-Sabr",
        "الشُّكْرُ" to "Ash-Shukr"
    )
    knownPhrases.firstOrNull { (k, _) -> clean.contains(k) }?.let { return it.second }

    // Clean phonetic letter-by-letter transliteration fallback for any remaining Arabic term
    val sb = StringBuilder()
    var prevWasSpace = true
    for (ch in clean) {
        val mapped = when (ch) {
            'ا', 'أ', 'إ', 'آ', 'ٱ' -> "a"
            'ب' -> "b"
            'ت' -> "t"
            'ث' -> "th"
            'ج' -> "j"
            'ح' -> "h"
            'خ' -> "kh"
            'د' -> "d"
            'ذ' -> "dh"
            'ر' -> "r"
            'ز' -> "z"
            'س' -> "s"
            'ش' -> "sh"
            'ص' -> "s"
            'ض' -> "d"
            'ط' -> "t"
            'ظ' -> "z"
            'ع' -> "'"
            'غ' -> "gh"
            'ف' -> "f"
            'ق' -> "q"
            'ك' -> "k"
            'ل' -> "l"
            'م' -> "m"
            'ن' -> "n"
            'ه', 'ة' -> "h"
            'و' -> "w"
            'ي', 'ى' -> "y"
            'ء' -> "'"
            '\u064E' -> "a" // fatha
            '\u064F' -> "u" // damma
            '\u0650' -> "i" // kasra
            '\u064B' -> "an"
            '\u064C' -> "un"
            '\u064D' -> "in"
            ' ' -> " "
            else -> ""
        }
        if (mapped.isNotEmpty()) {
            if (prevWasSpace && mapped[0].isLetter()) {
                sb.append(mapped.replaceFirstChar { it.uppercase() })
            } else {
                sb.append(mapped)
            }
            prevWasSpace = (mapped == " ")
        }
    }
    val derived = sb.toString().replace(Regex("\\s+"), " ").trim()
    return derived.ifBlank { englishHint }
}
