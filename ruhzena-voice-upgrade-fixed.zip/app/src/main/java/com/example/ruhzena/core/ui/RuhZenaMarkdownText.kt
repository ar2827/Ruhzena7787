package com.example.ruhzena.core.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalRuhZenaPalette

/**
 * Rich Markdown text renderer for RuhZena AI responses (both final and live-streaming).
 * Supports:
 *  - Headings: #, ##, ###
 *  - Blockquotes: > quote
 *  - Bold: **text** (with high-contrast emphasis)
 *  - Italic: *text* and _text_
 *  - Bold + Italic: ***text***
 *  - Underline: __text__ and <u>text</u>
 *  - Highlight: ==text==
 *  - Inline code: `code`
 *  - Clickable inline links: [label](https://...) and bare https://... URLs
 *  - Nested inline formatting (e.g. **bold with *italic*** or **__bold underline__**)
 *  - Bullet points (-, *, •) & numbered lists (1., 2.)
 *  - Horizontal dividers (---)
 */
@Composable
fun RuhZenaMarkdownText(
    markdown: String,
    modifier: Modifier = Modifier,
    baseColor: Color = LocalRuhZenaPalette.current.textPrimary,
    baseStyle: TextStyle = MaterialTheme.typography.bodyMedium
) {
    val palette = LocalRuhZenaPalette.current
    val uriHandler = LocalUriHandler.current
    val highlightBg = palette.gold.copy(alpha = if (palette.isLight) 0.28f else 0.25f)
    val highlightText = if (palette.isLight) Color(0xFF1A1405) else Color(0xFFFFF2CC)
    val boldColor = if (palette.isLight) Color(0xFF0A0E17) else Color(0xFFFFFFFF)
    val underlineColor = palette.accentSoft
    val linkColor = palette.gold
    val codeBg = palette.blockBg
    val codeText = palette.sky
    val accentHeading = palette.gold

    val blocks = remember(markdown) { parseMarkdownBlocks(markdown) }

    val inlineStyleConfig = remember(
        baseColor, boldColor, underlineColor, highlightBg, highlightText, codeBg, codeText, linkColor
    ) {
        InlineStyleConfig(
            baseColor = baseColor,
            boldColor = boldColor,
            underlineColor = underlineColor,
            highlightBg = highlightBg,
            highlightText = highlightText,
            codeBg = codeBg,
            codeText = codeText,
            linkColor = linkColor
        )
    }

    val openUrl: (String) -> Unit = remember(uriHandler) {
        { url -> runCatching { uriHandler.openUri(url) } }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        blocks.forEach { block ->
            when (block) {
                is MdBlock.Heading -> {
                    val hStyle = when (block.level) {
                        1 -> MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
                        2 -> MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        else -> MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    }
                    val hColor = if (block.level <= 2) boldColor else accentHeading
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = buildInlineAnnotated(
                            raw = block.text,
                            cfg = inlineStyleConfig.copy(baseColor = hColor),
                            onOpenUrl = openUrl
                        ),
                        style = hStyle,
                        color = hColor
                    )
                }

                is MdBlock.Blockquote -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min)
                            .clip(RoundedCornerShape(10.dp))
                            .background(palette.gold.copy(alpha = if (palette.isLight) 0.08f else 0.10f))
                            .padding(end = 10.dp, top = 7.dp, bottom = 7.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.5.dp)
                                .fillMaxHeight()
                                .background(palette.gold, RoundedCornerShape(4.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = buildInlineAnnotated(
                                raw = block.text,
                                cfg = inlineStyleConfig.copy(baseColor = palette.textPrimary),
                                onOpenUrl = openUrl
                            ),
                            style = baseStyle.copy(
                                fontStyle = FontStyle.Italic,
                                lineHeight = (baseStyle.lineHeight.value.takeIf { it > 0 } ?: 21f).sp
                            ),
                            color = palette.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                is MdBlock.Bullet -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = block.marker,
                            style = baseStyle.copy(fontWeight = FontWeight.ExtraBold),
                            color = palette.gold,
                            modifier = Modifier.padding(top = 0.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = buildInlineAnnotated(
                                raw = block.text,
                                cfg = inlineStyleConfig,
                                onOpenUrl = openUrl
                            ),
                            style = baseStyle.copy(
                                lineHeight = (baseStyle.lineHeight.value.takeIf { it > 0 } ?: 21f).sp
                            ),
                            color = baseColor,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                MdBlock.Divider -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .height(1.dp)
                            .background(palette.borderNeutral)
                    )
                }

                is MdBlock.Paragraph -> {
                    Text(
                        text = buildInlineAnnotated(
                            raw = block.text,
                            cfg = inlineStyleConfig,
                            onOpenUrl = openUrl
                        ),
                        style = baseStyle.copy(
                            lineHeight = (baseStyle.lineHeight.value.takeIf { it > 0 } ?: 21f).sp
                        ),
                        color = baseColor
                    )
                }
            }
        }
    }
}

private data class InlineStyleConfig(
    val baseColor: Color,
    val boldColor: Color,
    val underlineColor: Color,
    val highlightBg: Color,
    val highlightText: Color,
    val codeBg: Color,
    val codeText: Color,
    val linkColor: Color
)

private sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Blockquote(val text: String) : MdBlock
    data class Bullet(val marker: String, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data object Divider : MdBlock
}

private val numberedListRegex = Regex("^(\\d+\\.)\\s+(.*)$")
private val bulletListRegex = Regex("^[-*•]\\s+(.*)$")
private val headingRegex = Regex("^(#{1,4})\\s+(.*)$")
private val quoteRegex = Regex("^>\\s?(.*)$")
private val dividerRegex = Regex("^[-*_]{3,}$")

private fun parseMarkdownBlocks(raw: String): List<MdBlock> {
    val lines = raw.replace("\r\n", "\n").split("\n")
    val out = mutableListOf<MdBlock>()
    val paraBuffer = mutableListOf<String>()
    val quoteBuffer = mutableListOf<String>()

    fun flushPara() {
        if (paraBuffer.isNotEmpty()) {
            out.add(MdBlock.Paragraph(paraBuffer.joinToString("\n")))
            paraBuffer.clear()
        }
    }

    fun flushQuote() {
        if (quoteBuffer.isNotEmpty()) {
            out.add(MdBlock.Blockquote(quoteBuffer.joinToString("\n")))
            quoteBuffer.clear()
        }
    }

    for (line in lines) {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) {
            flushPara()
            flushQuote()
            continue
        }
        val qMatch = quoteRegex.matchEntire(trimmed)
        if (qMatch != null) {
            flushPara()
            quoteBuffer.add(qMatch.groupValues[1].trim())
            continue
        } else {
            flushQuote()
        }
        if (dividerRegex.matches(trimmed)) {
            flushPara()
            out.add(MdBlock.Divider)
            continue
        }
        val hMatch = headingRegex.matchEntire(trimmed)
        if (hMatch != null) {
            flushPara()
            val level = hMatch.groupValues[1].length.coerceIn(1, 3)
            out.add(MdBlock.Heading(level, hMatch.groupValues[2].trim()))
            continue
        }
        val bMatch = bulletListRegex.matchEntire(trimmed)
        if (bMatch != null) {
            flushPara()
            out.add(MdBlock.Bullet("•", bMatch.groupValues[1].trim()))
            continue
        }
        val nMatch = numberedListRegex.matchEntire(trimmed)
        if (nMatch != null) {
            flushPara()
            out.add(MdBlock.Bullet(nMatch.groupValues[1], nMatch.groupValues[2].trim()))
            continue
        }
        paraBuffer.add(line)
    }
    flushPara()
    flushQuote()
    return out
}

private fun buildInlineAnnotated(
    raw: String,
    cfg: InlineStyleConfig,
    onOpenUrl: (String) -> Unit
): AnnotatedString = buildAnnotatedString {
    appendInlineRecursive(raw, cfg, onOpenUrl, depth = 0)
}

private fun AnnotatedString.Builder.appendInlineRecursive(
    raw: String,
    cfg: InlineStyleConfig,
    onOpenUrl: (String) -> Unit,
    depth: Int
) {
    if (depth > 4) {
        append(raw)
        return
    }
    var i = 0
    val len = raw.length
    while (i < len) {
        // Markdown clickable link: [label](https://...)
        if (raw[i] == '[') {
            val closeBracket = raw.indexOf(']', i + 1)
            if (closeBracket > i + 1 && closeBracket + 1 < len && raw[closeBracket + 1] == '(') {
                val closeParen = raw.indexOf(')', closeBracket + 2)
                if (closeParen > closeBracket + 2) {
                    val label = raw.substring(i + 1, closeBracket)
                    val url = raw.substring(closeBracket + 2, closeParen).trim()
                    if (url.startsWith("http://") || url.startsWith("https://")) {
                        val linkStyle = TextLinkStyles(
                            style = SpanStyle(
                                color = cfg.linkColor,
                                fontWeight = FontWeight.SemiBold,
                                textDecoration = TextDecoration.Underline
                            )
                        )
                        val annotation = LinkAnnotation.Url(
                            url = url,
                            styles = linkStyle,
                            linkInteractionListener = { onOpenUrl(url) }
                        )
                        pushLink(annotation)
                        append("$label ↗")
                        pop()
                        i = closeParen + 1
                        continue
                    }
                }
            }
        }

        // Bare URL: https://... or http://...
        if (raw.startsWith("https://", i) || raw.startsWith("http://", i)) {
            var end = i
            while (end < len && !raw[end].isWhitespace() && raw[end] !in listOf(')', ']', ',', ';', '"', '\'')) {
                end++
            }
            while (end > i && raw[end - 1] in listOf('.', '!', '?')) end--
            val url = raw.substring(i, end)
            if (url.length > 10) {
                val cleanDisplay = url.removePrefix("https://").removePrefix("http://").removeSuffix("/")
                val annotation = LinkAnnotation.Url(
                    url = url,
                    styles = TextLinkStyles(
                        style = SpanStyle(
                            color = cfg.linkColor,
                            fontWeight = FontWeight.SemiBold,
                            textDecoration = TextDecoration.Underline
                        )
                    ),
                    linkInteractionListener = { onOpenUrl(url) }
                )
                pushLink(annotation)
                append("$cleanDisplay ↗")
                pop()
                i = end
                continue
            }
        }

        // HTML underline: <u>text</u>
        if (raw.startsWith("<u>", i, ignoreCase = true)) {
            val end = raw.indexOf("</u>", i + 3, ignoreCase = true)
            if (end > i + 3) {
                withStyle(
                    SpanStyle(
                        textDecoration = TextDecoration.Underline,
                        fontWeight = FontWeight.Medium,
                        color = cfg.underlineColor
                    )
                ) {
                    appendInlineRecursive(raw.substring(i + 3, end), cfg, onOpenUrl, depth + 1)
                }
                i = end + 4
                continue
            }
        }

        // Bold + Italic: ***text***
        if (raw.startsWith("***", i)) {
            val end = raw.indexOf("***", i + 3)
            if (end > i + 3) {
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.ExtraBold,
                        fontStyle = FontStyle.Italic,
                        color = cfg.boldColor
                    )
                ) {
                    appendInlineRecursive(raw.substring(i + 3, end), cfg, onOpenUrl, depth + 1)
                }
                i = end + 3
                continue
            }
        }

        // Bold: **text**
        if (raw.startsWith("**", i)) {
            val end = raw.indexOf("**", i + 2)
            if (end > i + 2) {
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.ExtraBold,
                        color = cfg.boldColor
                    )
                ) {
                    appendInlineRecursive(raw.substring(i + 2, end), cfg, onOpenUrl, depth + 1)
                }
                i = end + 2
                continue
            }
        }

        // Highlight: ==text==
        if (raw.startsWith("==", i)) {
            val end = raw.indexOf("==", i + 2)
            if (end > i + 2) {
                withStyle(
                    SpanStyle(
                        background = cfg.highlightBg,
                        color = cfg.highlightText,
                        fontWeight = FontWeight.Bold
                    )
                ) {
                    append(" ")
                    appendInlineRecursive(raw.substring(i + 2, end), cfg, onOpenUrl, depth + 1)
                    append(" ")
                }
                i = end + 2
                continue
            }
        }

        // Underline: __text__
        if (raw.startsWith("__", i)) {
            val end = raw.indexOf("__", i + 2)
            if (end > i + 2) {
                withStyle(
                    SpanStyle(
                        textDecoration = TextDecoration.Underline,
                        fontWeight = FontWeight.SemiBold,
                        color = cfg.underlineColor
                    )
                ) {
                    appendInlineRecursive(raw.substring(i + 2, end), cfg, onOpenUrl, depth + 1)
                }
                i = end + 2
                continue
            }
        }

        // Inline Code: `code`
        if (raw[i] == '`') {
            val end = raw.indexOf('`', i + 1)
            if (end > i + 1) {
                withStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        background = cfg.codeBg,
                        color = cfg.codeText
                    )
                ) {
                    append(" ${raw.substring(i + 1, end)} ")
                }
                i = end + 1
                continue
            }
        }

        // Italic: *text* (only if not followed by space so math/bullets aren't eaten)
        if (raw[i] == '*' && i + 1 < len && raw[i + 1] != ' ' && raw[i + 1] != '*') {
            val end = raw.indexOf('*', i + 1)
            if (end > i + 1 && raw[end - 1] != ' ') {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = cfg.baseColor)) {
                    appendInlineRecursive(raw.substring(i + 1, end), cfg, onOpenUrl, depth + 1)
                }
                i = end + 1
                continue
            }
        }

        // Italic: _text_ (bounded by non-alphanumeric so snake_case isn't affected)
        if (raw[i] == '_' && (i == 0 || !raw[i - 1].isLetterOrDigit()) && i + 1 < len && raw[i + 1] != ' ' && raw[i + 1] != '_') {
            val end = raw.indexOf('_', i + 1)
            if (end > i + 1 && raw[end - 1] != ' ' && (end + 1 == len || !raw[end + 1].isLetterOrDigit())) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = cfg.baseColor)) {
                    appendInlineRecursive(raw.substring(i + 1, end), cfg, onOpenUrl, depth + 1)
                }
                i = end + 1
                continue
            }
        }

        append(raw[i])
        i++
    }
}

/**
 * Strips markdown symbols cleanly so expressive voice TTS reads natural prose without saying "asterisk".
 */
fun stripMarkdownForSpeech(markdown: String): String = markdown
    .replace(Regex("```[\\s\\S]*?```"), " ")
    .replace(Regex("\\[([^\\]]+)\\]\\((https?://[^)]+)\\)"), "$1")
    .replace(Regex("https?://\\S+"), "")
    .replace(Regex("</?u>", RegexOption.IGNORE_CASE), "")
    .replace(Regex("^#{1,6}\\s*", RegexOption.MULTILINE), "")
    .replace(Regex("^>\\s*", RegexOption.MULTILINE), "")
    .replace(Regex("\\*\\*\\*(.*?)\\*\\*\\*"), "$1")
    .replace(Regex("\\*\\*(.*?)\\*\\*"), "$1")
    .replace(Regex("__(.*?)__"), "$1")
    .replace(Regex("==(.*?)=="), "$1")
    .replace(Regex("\\*(.*?)\\*"), "$1")
    .replace(Regex("(?<![A-Za-z0-9])_([^_]+)_(?![A-Za-z0-9])"), "$1")
    .replace(Regex("`([^`]*)`"), "$1")
    .replace(Regex("^[-*•]\\s+", RegexOption.MULTILINE), "")
    .replace(Regex("\\s+"), " ")
    .trim()
