package com.example.ruhzena.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.local.MealLogEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.ui.MealScanUiState
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

private data class BeveragePreset(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val hydrationMultiplier: Float
)

private val beveragePresets = listOf(
    BeveragePreset("water", "Pure Water (1.0x)", "বিশুদ্ধ পানি (১.০x)", 1.0f),
    BeveragePreset("milk", "Milk / Smoothie (1.1x)", "দুধ / স্মুদি (১.১x)", 1.1f),
    BeveragePreset("electrolyte", "Lemon / Electrolytes (1.1x)", "লেবু ও ইলেক্ট্রোলাইট (১.১x)", 1.1f),
    BeveragePreset("tea_coffee", "Tea / Coffee (0.8x)", "চা / কফি (০.৮x)", 0.8f)
)

private data class HydrationDayStat(
    val dateKey: String,
    val dayLabel: String,
    val totalMl: Int
)

private data class MealPresetItem(
    val category: String,
    val nameEn: String,
    val nameBn: String,
    val calories: Int,
    val protein: Int,
    val carbs: Int,
    val fat: Int,
    val source: String,
    val sourceUrl: String = "https://fdc.nal.usda.gov/",
    val countryCodes: List<String> = emptyList()
)

private val curatedMealPresets = listOf(
    MealPresetItem("Sunnah Recipes", "Talbinah (Barley Porridge, Milk & Honey)", "তালবিনা (যবের জাউ, দুধ ও মধু)", 295, 9, 51, 6, "Sahih al-Bukhari 5417", "https://sunnah.com/bukhari:5417"),
    MealPresetItem("Sunnah Recipes", "3 Medjool Dates + Warm Milk (250ml)", "৩টি খেজুর ও ১ গ্লাস দুধ", 320, 10, 65, 5, "Sahih Muslim 2049", "https://sunnah.com/muslim:2049"),
    MealPresetItem("Sunnah Recipes", "Red Lentil Shorba + Olive Oil & Whole Bread", "মসুর ডালের শোরবা ও অলিভ অয়েল", 340, 17, 48, 9, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("Sunnah Recipes", "Raw Honey (1 tbsp) + Black Seed & Almonds", "খাঁটি মধু, কালিজিরা ও বাদাম", 145, 3, 20, 7, "Sahih al-Bukhari 5688", "https://sunnah.com/bukhari:5688"),
    MealPresetItem("High Protein", "Grilled Chicken Breast (140g) + Salad", "গ্রিলড চিকেন ব্রেস্ট (১৪০ গ্রাম) ও সালাদ", 265, 42, 6, 7, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("High Protein", "2 Boiled Eggs + 2 Whole Wheat Toast", "২টি সেদ্ধ ডিম ও ২ পিস লাল আটার রুটি/টোস্ট", 310, 19, 30, 12, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("High Protein", "Greek Yogurt Bowl + Chia & Berries", "টক দই/গ্রিক ইয়োগার্ট ও চিয়া-ফল", 220, 18, 22, 6, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("High Protein", "Grilled Fish Fillet (150g) + Veggies", "ভাজা/গ্রিলড মাছ (১৫০ গ্রাম) ও সবজি", 280, 34, 8, 12, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("Suhoor & Iftar", "3 Medjool Dates (~72g) + Water", "৩টি মেদজুল খেজুর ও পানি", 200, 2, 54, 0, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("Suhoor & Iftar", "Suhoor Power Bowl (Oats, Milk, Banana, Almonds)", "সেহরি ওটস, দুধ, কলা ও বাদাম", 410, 16, 62, 11, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("Suhoor & Iftar", "Chickpea Chana Chaat (1 Bowl)", "ছোলা ও শসা-পেঁয়াজের চাট (১ বাটি)", 245, 11, 38, 6, "FAO Food Comp", "https://www.fao.org/infoods/infoods/en/", listOf("BD", "PK", "IN")),
    MealPresetItem("Worldwide", "Kabsa Grilled Chicken & Basmati Rice (Moderate)", "সৌদি কাবসা চিকেন ও বাসমতি ভাত", 540, 34, 64, 15, "FAO Regional Comp", "https://www.fao.org/infoods/infoods/en/", listOf("SA", "AE", "EG")),
    MealPresetItem("Worldwide", "Hummus (120g) + Whole Pita + Cucumber", "হুমুস, পিটা রুটি ও শসা", 360, 13, 46, 14, "USDA Reference", "https://fdc.nal.usda.gov/", listOf("SA", "AE", "EG", "TR", "GB", "US")),
    MealPresetItem("Worldwide", "Turkish Mercimek Soup + Grilled Kofta & Salad", "তুর্কি মসুর স্যুপ ও কোফতা সালাদ", 450, 29, 36, 20, "FAO Food Comp", "https://www.fao.org/infoods/infoods/en/", listOf("TR")),
    MealPresetItem("Worldwide", "Gado-Gado Peanut Salad + Steamed Tempeh", "ইন্দোনেশিয়ান গাদো-গাদো ও টেম্পে", 410, 21, 38, 19, "FAO Food Comp", "https://www.fao.org/infoods/infoods/en/", listOf("ID", "MY")),
    MealPresetItem("Worldwide", "Mediterranean Salmon + Quinoa & Roasted Greens", "সালমন মাছ, কিনোয়া ও সবজি", 485, 36, 39, 19, "USDA Reference", "https://fdc.nal.usda.gov/", listOf("GB", "US")),
    MealPresetItem("Desi / Everyday", "Rice (1 cup) + Masoor Dal + Mixed Veg", "ভাত (১ কাপ), মসুর ডাল ও সবজি", 440, 14, 78, 7, "FAO South Asia", "https://www.fao.org/infoods/infoods/en/", listOf("BD", "PK", "IN")),
    MealPresetItem("Desi / Everyday", "2 Whole Wheat Roti + Chicken Curry", "২টি আটার রুটি ও মুরগির তরকারি", 460, 28, 48, 16, "FAO South Asia", "https://www.fao.org/infoods/infoods/en/", listOf("BD", "PK", "IN")),
    MealPresetItem("Desi / Everyday", "Fish Curry + Steamed Rice (Modest Bowl)", "মাছের ঝোল ও পরিমিত ভাত", 420, 29, 52, 10, "FAO South Asia", "https://www.fao.org/infoods/infoods/en/", listOf("BD", "MY", "ID")),
    MealPresetItem("Desi / Everyday", "Beef Biryani / Tehari (Moderate Plate)", "গরুর তেহারি/বিরিয়ানি (মাঝারি প্লেট)", 640, 26, 72, 26, "FAO South Asia", "https://www.fao.org/infoods/infoods/en/", listOf("BD", "PK", "SA")),
    MealPresetItem("Desi / Everyday", "Egg Bhuna + 2 Parathas", "ডিম ভুনা ও ২টি পরোটা", 550, 17, 54, 28, "FAO South Asia", "https://www.fao.org/infoods/infoods/en/", listOf("BD", "PK")),
    MealPresetItem("Snacks & Fruit", "1 Medium Banana + 10 Almonds", "১টি কলা ও ১০টি কাঠবাদাম", 175, 4, 29, 6, "USDA Reference", "https://fdc.nal.usda.gov/"),
    MealPresetItem("Snacks & Fruit", "Roasted Peanuts / Chana (35g)", "ভাজা বাদাম বা ছোলা (৩৫ গ্রাম)", 195, 8, 10, 14, "USDA Reference", "https://fdc.nal.usda.gov/")
)

@Composable
private fun glassFieldColors(focusColor: Color = LocalRuhZenaPalette.current.accentPrimary) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = focusColor,
    unfocusedBorderColor = LocalRuhZenaPalette.current.borderNeutral,
    focusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    unfocusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    focusedLabelColor = focusColor,
    unfocusedLabelColor = LocalRuhZenaPalette.current.textMuted,
    focusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted,
    unfocusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted
)

fun calculateRecommendedHydrationMl(
    weightKg: Int,
    ageYears: Int,
    activityLevel: Int // 0 = Sedentary, 1 = Moderate, 2 = Active
): Int {
    val w = weightKg.coerceIn(25, 220)
    val basePerKg = when {
        ageYears < 14 -> 40
        ageYears > 60 -> 30
        else -> 35
    }
    val activityBonus = when (activityLevel) {
        1 -> 350
        2 -> 700
        else -> 0
    }
    val raw = (w * basePerKg) + activityBonus
    return ((raw + 50) / 100 * 100).coerceIn(1400, 4800)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HydrationTab(
    goalMl: Int,
    waterMlToday: Int,
    logs: List<WaterLogEntity>,
    weeklyLogs: List<WaterLogEntity> = emptyList(),
    prefs: UserPreferences = UserPreferences(),
    onAddWater: (Int) -> Unit,
    onDeleteWater: (Long) -> Unit,
    onSetGoal: (Int) -> Unit,
    formatTime: (Long) -> String,
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> }
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val context = LocalContext.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    var customMlText by remember { mutableStateOf("") }
    var selectedBeverageIdx by rememberSaveable { mutableIntStateOf(0) }
    var showWhyExpanded by rememberSaveable { mutableStateOf(true) }
    var showCalcExpanded by rememberSaveable { mutableStateOf(false) }

    var calcWeight by remember(prefs.weightKg) { mutableStateOf(prefs.weightKg.toString()) }
    var calcAge by remember(prefs.ageYears) { mutableStateOf(prefs.ageYears.toString()) }
    var calcActivity by rememberSaveable { mutableIntStateOf(1) }

    val selectedBeverage = beveragePresets[selectedBeverageIdx]
    val pct = (waterMlToday.toFloat() / goalMl.coerceAtLeast(1)).coerceIn(0f, 1f)
    val animatedPct by animateFloatAsState(
        targetValue = pct,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
        label = "hydrationWavePct"
    )
    val remainingMl = (goalMl - waterMlToday).coerceAtLeast(0)
    val percentInt = (pct * 100f).roundToInt()

    val weeklySeries = remember(weeklyLogs, logs) {
        val combined = if (weeklyLogs.isNotEmpty()) weeklyLogs else logs
        val grouped = combined.groupBy { it.dateKey }.mapValues { (_, list) -> list.sumOf { it.amountMl } }
        val keyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dayFmt = SimpleDateFormat("EEE", Locale.ENGLISH)
        (6 downTo 0).map { daysAgo ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
            val key = keyFmt.format(cal.time)
            val label = dayFmt.format(cal.time).take(3)
            HydrationDayStat(
                dateKey = key,
                dayLabel = label,
                totalMl = grouped[key] ?: 0
            )
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("hydration_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 52.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Animated Liquid Vessel Gauge & Smart Drink Logger
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.HYDRATION_GAUGE_CARD),
                elevated = true,
                accentBorder = true
            ) {
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.hydrationGoalTitle, style = MaterialTheme.typography.titleLarge, color = palette.textPrimary)
                        StatusPillBadge(
                            label = if (remainingMl == 0) {
                                if (isBn) "লক্ষ্য পূর্ণ ($percentInt%)" else "Goal Met ($percentInt%)"
                            } else {
                                if (isBn) "$remainingMl ml বাকি" else "$remainingMl ml left"
                            },
                            accentColor = if (remainingMl == 0) palette.accentSoft else palette.sky
                        )
                    }

                    if (prefs.ramadanModeEnabled) {
                        Spacer(modifier = Modifier.height(6.dp))
                        StatusPillBadge(
                            label = if (isBn) "রমজান মোড: মাগরিব থেকে ফজর পর্যন্ত পানির সতর্কতা" else "Ramadan Mode: hydration alerts paused during daytime fast",
                            accentColor = palette.gold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    HydrationWaveVessel(
                        fillFraction = animatedPct,
                        waterMlToday = waterMlToday,
                        goalMl = goalMl,
                        percentInt = percentInt
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Beverage Hydration Quality Selector
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(beveragePresets.indices.toList()) { idx ->
                            val bev = beveragePresets[idx]
                            GlassFilterChip(
                                label = if (isBn) bev.nameBn else bev.nameEn,
                                selected = selectedBeverageIdx == idx,
                                onClick = { selectedBeverageIdx = idx }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .tutorialTarget(TutorialTargetKeys.HYDRATION_QUICK_ADD_ROW)
                    ) {
                        EmeraldActionButton(
                            text = "+250 ml",
                            icon = Icons.Default.WaterDrop,
                            onClick = {
                                val eff = (250f * selectedBeverage.hydrationMultiplier).roundToInt()
                                onAddWater(eff)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("add_water_250")
                        )
                        EmeraldActionButton(
                            text = "+500 ml",
                            icon = Icons.Default.LocalDrink,
                            onClick = {
                                val eff = (500f * selectedBeverage.hydrationMultiplier).roundToInt()
                                onAddWater(eff)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("add_water_500")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    GlassFilterChip(
                        label = if (isBn) "হাইড্রেশন নিয়ে রূহযেনা AI" else "Ask RuhZena AI",
                        selected = false,
                        icon = Icons.Default.AutoAwesome,
                        onClick = {
                            val q = if (isBn) {
                                "আজ আমি $waterMlToday/$goalMl মি.লি. পানি পান করেছি—দৈনিক লক্ষ্য পূরণ ও হাইড্রেশনের সেরা সময়সূচি বলুন।"
                            } else {
                                "I've had $waterMlToday/$goalMl ml today. Suggest a hydration rhythm around my prayers and fitness goal."
                            }
                            onAskRuhZebaAi("WELLNESS", q)
                        },
                        modifier = Modifier.testTag("hydration_ask_ai_button")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = customMlText,
                            onValueChange = { customMlText = it.filter(Char::isDigit) },
                            placeholder = { Text(strings.addWaterCustom, color = palette.textMuted) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = glassFieldColors(palette.sky),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                val raw = customMlText.toIntOrNull() ?: 0
                                if (raw in 10..2000) {
                                    val eff = (raw * selectedBeverage.hydrationMultiplier).roundToInt()
                                    onAddWater(eff)
                                    customMlText = ""
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(palette.sky.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add custom ml", tint = palette.sky)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(2000, 2500, 3000, 3500).forEach { g ->
                            GlassFilterChip(label = "${g / 1000.0}L", selected = goalMl == g, onClick = { onSetGoal(g) })
                        }
                    }
                }
            }
        }

        // 2. Interactive Hydration Goal Calculator
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hydration_calculator_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCalcExpanded = !showCalcExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(palette.accentContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isBn) "স্মার্ট হাইড্রেশন লক্ষ্য ক্যালকুলেটর" else "Smart Daily Hydration Calculator",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                            Text(
                                text = if (isBn) "ওজন, বয়স ও পরিশ্রমের ভিত্তিতে" else "Tailored by weight, age & daily activity",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary
                            )
                        }
                    }
                    Icon(
                        imageVector = if (showCalcExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = palette.textSecondary
                    )
                }

                AnimatedVisibility(visible = showCalcExpanded) {
                    val w = calcWeight.toIntOrNull() ?: prefs.weightKg
                    val a = calcAge.toIntOrNull() ?: prefs.ageYears
                    val recommended = calculateRecommendedHydrationMl(w, a, calcActivity)

                    Column(modifier = Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = calcWeight,
                                onValueChange = { calcWeight = it.filter(Char::isDigit).take(3) },
                                label = { Text(strings.weightKgLabel) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = glassFieldColors(palette.sky),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = calcAge,
                                onValueChange = { calcAge = it.filter(Char::isDigit).take(3) },
                                label = { Text(strings.ageLabel) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = glassFieldColors(palette.sky),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                0 to (if (isBn) "হালকা" else "Light"),
                                1 to (if (isBn) "মাঝারি" else "Moderate"),
                                2 to (if (isBn) "সক্রিয়" else "Active")
                            ).forEach { (idx, label) ->
                                GlassFilterChip(
                                    label = label,
                                    selected = calcActivity == idx,
                                    onClick = { calcActivity = idx },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isBn) "প্রস্তাবিত লক্ষ্য" else "Recommended Target",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.textMuted
                                )
                                Text(
                                    text = "$recommended ml / day",
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                                    color = palette.sky
                                )
                            }
                            EmeraldActionButton(
                                text = if (isBn) "লক্ষ্য সেট করুন" else "Apply Goal",
                                onClick = { onSetGoal(recommended) },
                                modifier = Modifier.testTag("apply_hydration_goal_button")
                            )
                        }
                    }
                }
            }
        }

        // 3. Weekly 7-Day Glass Hydration Bar Chart
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("weekly_hydration_chart")
            ) {
                val weekAvg = (weeklySeries.sumOf { it.totalMl } / 7)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBn) "সাপ্তাহিক পানি পানের গ্রাফ (৭ দিন)" else "Weekly Hydration Consistency (7 Days)",
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                    Text(
                        text = "${weekAvg} ml avg",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = palette.sky
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                WeeklyHydrationBarChart(
                    series = weeklySeries,
                    goalMl = goalMl
                )
            }
        }

        // 4. Engaging Educational Guide: Why Hydration Matters + Functional Clickable Sources
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hydration_why_card"),
                accentBorder = false
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showWhyExpanded = !showWhyExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(palette.sky.copy(alpha = 0.16f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.WaterDrop, contentDescription = null, tint = palette.sky, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(strings.whyHydrationMatters, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(
                                text = if (isBn) "মস্তিষ্ক, এনার্জি, কিডনি ও সুন্নাহ আদব" else "Brain focus, cellular energy, joints & Sunnah etiquette",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary
                            )
                        }
                    }
                    Icon(
                        imageVector = if (showWhyExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = palette.textSecondary
                    )
                }

                AnimatedVisibility(visible = showWhyExpanded) {
                    Column(
                        modifier = Modifier.padding(top = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        HydrationFactRow(
                            icon = Icons.Default.Psychology,
                            accent = palette.sky,
                            title = if (isBn) "মনোযোগ ও মস্তিষ্কের সতেজতা" else "Focus, Memory & Khushu'",
                            body = if (isBn) {
                                "মস্তিষ্কের প্রায় ৭৫% পানি। মাত্র ১–২% পানিশূন্যতাও মাথাব্যথা, অবসাদ এবং নামাজ ও কাজে মনোযোগ কমিয়ে দেয়।"
                            } else {
                                "Your brain is ~75% water. Even mild 1–2% dehydration reduces alertness, increases fatigue, and clouds focus during prayer and work."
                            }
                        )
                        HydrationFactRow(
                            icon = Icons.Default.Bolt,
                            accent = palette.accentSoft,
                            title = if (isBn) "বিপাক, হজম ও জয়েন্ট সুরক্ষা" else "Metabolism, Digestion & Joint Cushion",
                            body = if (isBn) {
                                "পর্যাপ্ত পানি শরীরে পুষ্টি পরিবহন করে, জয়েন্টের তরল সচল রাখে এবং পেশীর ক্র্যাম্প ও ক্লান্তি কমাতে সাহায্য করে।"
                            } else {
                                "Water carries nutrients to cells, lubricates joint cartilage during workouts, regulates temperature, and supports kidney filtration."
                            }
                        )
                        HydrationFactRow(
                            icon = Icons.Default.Spa,
                            accent = palette.gold,
                            title = if (isBn) "পানি পানের সুন্নাহ আদব" else "Sunnah Etiquette & Rhythm",
                            body = if (isBn) {
                                "বিসমিল্লাহ বলে বসে তিন শ্বাসে ধীরে পানি পান করুন এবং শেষে আলহামদুলিল্লাহ বলুন (সহীহ মুসলিম ২০২৪, ২০২৮) — এটি হজমের জন্যও অত্যন্ত উপকারী।"
                            } else {
                                "Sit calmly, say Bismillah, sip slowly in 3 gentle breaths rather than gulping, and say Alhamdulillah afterward (Sahih Muslim 2024, 2028) — aiding gentle digestion."
                            }
                        )

                        Spacer(modifier = Modifier.height(2.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            GoldSourceTag(
                                sourceText = "WHO Hydration Guide ↗",
                                modifier = Modifier
                                    .clickable {
                                        runCatching {
                                            context.startActivity(
                                                Intent(
                                                    Intent.ACTION_VIEW,
                                                    Uri.parse("https://www.who.int/news-room/fact-sheets/detail/drinking-water")
                                                )
                                            )
                                        }
                                    }
                                    .testTag("hydration_source_who")
                            )
                            GoldSourceTag(
                                sourceText = "Sahih Muslim 2024 ↗",
                                modifier = Modifier
                                    .clickable {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Intent.ACTION_VIEW, Uri.parse("https://sunnah.com/muslim:2024"))
                                            )
                                        }
                                    }
                                    .testTag("hydration_source_muslim_2024")
                            )
                            GoldSourceTag(
                                sourceText = "Sahih Muslim 2028 ↗",
                                modifier = Modifier
                                    .clickable {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Intent.ACTION_VIEW, Uri.parse("https://sunnah.com/muslim:2028"))
                                            )
                                        }
                                    }
                                    .testTag("hydration_source_muslim_2028")
                            )
                        }
                    }
                }
            }
        }

        // 5. Today's Water Timeline
        if (logs.isNotEmpty()) {
            item {
                Text(
                    text = if (isBn) "আজকের পানি পানের তালিকা" else "Today's Hydration Log",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
            }
        }
        items(logs, key = { it.id }) { log ->
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(palette.sky.copy(alpha = 0.14f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.WaterDrop, contentDescription = null, tint = palette.sky, modifier = Modifier.size(17.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("+${log.amountMl} ml", style = MaterialTheme.typography.titleMedium, color = palette.sky)
                            Text(formatTime(log.timestamp), style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        }
                    }
                    IconButton(onClick = { onDeleteWater(log.id) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = palette.textSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun WeeklyHydrationBarChart(
    series: List<HydrationDayStat>,
    goalMl: Int
) {
    val palette = LocalRuhZenaPalette.current
    val maxVal = maxOf(goalMl, series.maxOfOrNull { it.totalMl } ?: goalMl, 1000).toFloat()

    Column(modifier = Modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(124.dp)
        ) {
            val w = size.width
            val h = size.height
            val chartBottom = h - 8f
            val chartTop = 10f
            val chartHeight = (chartBottom - chartTop).coerceAtLeast(10f)

            // Dashed target line
            val goalY = chartBottom - ((goalMl.toFloat() / maxVal).coerceIn(0f, 1f) * chartHeight)
            drawLine(
                color = palette.gold.copy(alpha = 0.55f),
                start = Offset(0f, goalY),
                end = Offset(w, goalY),
                strokeWidth = 2.2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
            )

            val slotW = w / series.size.coerceAtLeast(1)
            val barW = (slotW * 0.48f).coerceIn(14f, 36f)

            series.forEachIndexed { idx, day ->
                val cx = slotW * idx + slotW / 2f
                val left = cx - barW / 2f
                // Background slot track
                drawRoundRect(
                    color = palette.blockBg,
                    topLeft = Offset(left, chartTop),
                    size = Size(barW, chartHeight),
                    cornerRadius = CornerRadius(8f, 8f)
                )
                val frac = (day.totalMl.toFloat() / maxVal).coerceIn(0f, 1f)
                val fillH = (frac * chartHeight).coerceAtLeast(if (day.totalMl > 0) 6f else 0f)
                if (fillH > 0f) {
                    val met = day.totalMl >= goalMl
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            colors = if (met) listOf(palette.accentSoft, palette.accentPrimary)
                            else listOf(palette.sky, palette.accentPrimary.copy(alpha = 0.72f))
                        ),
                        topLeft = Offset(left, chartBottom - fillH),
                        size = Size(barW, fillH),
                        cornerRadius = CornerRadius(8f, 8f)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            series.forEach { day ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = day.dayLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (day.totalMl >= goalMl) palette.accentSoft else palette.textMuted
                    )
                    Text(
                        text = if (day.totalMl >= 1000) String.format(Locale.US, "%.1fL", day.totalMl / 1000f)
                        else "${day.totalMl}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = palette.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun HydrationWaveVessel(
    fillFraction: Float,
    waterMlToday: Int,
    goalMl: Int,
    percentInt: Int
) {
    val palette = LocalRuhZenaPalette.current
    val infiniteTransition = rememberInfiniteTransition(label = "waterWave")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(168.dp)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f
            val r = (size.minDimension / 2f) - 8f

            drawCircle(
                color = palette.blockBg,
                radius = r,
                center = Offset(cx, cy)
            )

            val clipCircle = Path().apply {
                addOval(
                    androidx.compose.ui.geometry.Rect(
                        left = cx - r + 4f,
                        top = cy - r + 4f,
                        right = cx + r - 4f,
                        bottom = cy + r - 4f
                    )
                )
            }

            clipPath(clipCircle) {
                val clamped = fillFraction.coerceIn(0.02f, 1f)
                val waterTopY = (cy + r) - (2f * r * clamped)
                val amp = if (clamped >= 0.99f || clamped <= 0.03f) 3f else 8f

                val backPath = Path().apply {
                    moveTo(cx - r, cy + r)
                    var x = cx - r
                    while (x <= cx + r + 4f) {
                        val normX = (x - (cx - r)) / (2f * r)
                        val y = waterTopY + sin((normX * 2f * PI).toFloat() + wavePhase + 1.4f) * amp
                        lineTo(x, y)
                        x += 6f
                    }
                    lineTo(cx + r, cy + r)
                    close()
                }
                drawPath(path = backPath, color = palette.accentPrimary.copy(alpha = 0.34f))

                val frontPath = Path().apply {
                    moveTo(cx - r, cy + r)
                    var x = cx - r
                    while (x <= cx + r + 4f) {
                        val normX = (x - (cx - r)) / (2f * r)
                        val y = waterTopY + sin((normX * 2f * PI).toFloat() - wavePhase) * amp
                        lineTo(x, y)
                        x += 6f
                    }
                    lineTo(cx + r, cy + r)
                    close()
                }
                drawPath(
                    path = frontPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(palette.sky.copy(alpha = 0.72f), palette.accentPrimary.copy(alpha = 0.56f)),
                        startY = waterTopY,
                        endY = cy + r
                    )
                )
            }

            drawCircle(
                color = palette.sky.copy(alpha = 0.55f),
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(width = 3.5f)
            )
            drawArc(
                color = Color.White.copy(alpha = 0.25f),
                startAngle = 205f,
                sweepAngle = 70f,
                useCenter = false,
                topLeft = Offset(cx - r + 10f, cy - r + 10f),
                size = Size((r - 10f) * 2f, (r - 10f) * 2f),
                style = Stroke(width = 3f)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$percentInt%",
                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = palette.gold
            )
            Text(
                text = "$waterMlToday ml",
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = palette.textPrimary
            )
            Text("/ $goalMl ml", style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)
        }
    }
}

@Composable
private fun HydrationFactRow(
    icon: ImageVector,
    accent: Color,
    title: String,
    body: String
) {
    val palette = LocalRuhZenaPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.blockBg, RoundedCornerShape(12.dp))
            .border(0.7.dp, palette.borderNeutral.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(11.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(title, style = MaterialTheme.typography.labelLarge, color = accent)
            Spacer(modifier = Modifier.height(2.dp))
            Text(body, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NutritionTab(
    meals: List<MealLogEntity>,
    mealScanState: MealScanUiState,
    hasPreviousScan: Boolean = false,
    prefs: UserPreferences = UserPreferences(),
    onAddMeal: (String, String, Int, Int, Int, Int, Boolean, String) -> Unit,
    onDeleteMeal: (Long) -> Unit,
    onAnalyzeMealPhoto: (Bitmap, String) -> Unit,
    onReanalyzeMealPhoto: (String) -> Unit = {},
    onRestorePreviousScan: () -> Unit = {},
    onClearMealScan: () -> Unit,
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> }
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mealName by remember { mutableStateOf("") }
    var mealType by remember { mutableStateOf("Lunch") }
    var calories by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    var presetCategory by remember { mutableStateOf("All") }
    var presetQuery by remember { mutableStateOf("") }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            scope.launch {
                decodeUriToBitmap(context, uri)?.let { bmp ->
                    onAnalyzeMealPhoto(bmp, mealType)
                }
            }
        }
    }

    val pickPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                decodeUriToBitmap(context, uri)?.let { bmp ->
                    onAnalyzeMealPhoto(bmp, mealType)
                }
            }
        }
    }

    val filteredPresets = remember(presetCategory, presetQuery, prefs.countryCode) {
        val code = prefs.countryCode.uppercase()
        curatedMealPresets.filter { item ->
            val catOk = presetCategory == "All" || item.category == presetCategory
            val q = presetQuery.trim().lowercase()
            val qOk = q.isEmpty() ||
                item.nameEn.lowercase().contains(q) ||
                item.nameBn.contains(q) ||
                item.category.lowercase().contains(q)
            catOk && qOk
        }.sortedByDescending { item ->
            if (code.isNotEmpty() && item.countryCodes.contains(code)) 1 else 0
        }
    }

    val totalCal = meals.sumOf { it.calories }
    val totalPro = meals.sumOf { it.proteinGrams }
    val totalCarbs = meals.sumOf { it.carbsGrams }
    val totalFat = meals.sumOf { it.fatGrams }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("nutrition_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 52.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.NUTRITION_SUMMARY_CARD),
                elevated = true,
                accentBorder = true
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "আজকের পুষ্টি ও ক্যালোরি" else "Today's Nutrition Balance",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "$totalCal kcal  •  P: ${totalPro}g  C: ${totalCarbs}g  F: ${totalFat}g",
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                            color = palette.gold
                        )
                    }
                    GlassFilterChip(
                        label = if (isBn) "রূহযেনা AI" else "Ask RuhZena AI",
                        selected = false,
                        icon = Icons.Default.AutoAwesome,
                        onClick = {
                            val q = if (isBn) {
                                "আজ আমি $totalCal kcal (প্রোটিন ${totalPro}g, কার্ব ${totalCarbs}g, ফ্যাট ${totalFat}g) খেয়েছি। পরের খাবারে কী ভারসাম্য রাখা ভালো?"
                            } else {
                                "My intake today is $totalCal kcal (P:${totalPro}g C:${totalCarbs}g F:${totalFat}g). What should my next balanced meal focus on?"
                            }
                            onAskRuhZebaAi("WELLNESS", q)
                        },
                        modifier = Modifier.testTag("nutrition_ask_ai_button")
                    )
                }
            }
        }

        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.NUTRITION_SCANNER_CARD)
                    .testTag("meal_photo_scanner_card"),
                accentBorder = true
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.scanMealPhotoTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isBn) {
                        "খাবারের ছবি তুলুন বা আপলোড করুন — AI ক্যালোরি, প্রোটিন-শর্করা এবং এটি আপনার লক্ষ্যের জন্য ভালো কিনা বলে দেবে।"
                    } else {
                        "Snap or pick a meal photo — AI estimates calories, macros, and tells you whether it fits your fitness goal."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EmeraldActionButton(
                        text = strings.takeMealPhoto,
                        icon = Icons.Default.CameraAlt,
                        onClick = {
                            val dir = File(context.cacheDir, "meal_photos").apply { mkdirs() }
                            val file = File(dir, "meal_${System.currentTimeMillis()}.jpg")
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            pendingCameraUri = uri
                            takePictureLauncher.launch(uri)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("take_meal_photo_button")
                    )
                    OutlinedButton(
                        onClick = {
                            pickPhotoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("choose_meal_photo_button")
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = palette.gold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.chooseMealPhoto, color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                when (mealScanState) {
                    MealScanUiState.Idle -> {
                        if (hasPreviousScan) {
                            Spacer(modifier = Modifier.height(10.dp))
                            GlassFilterChip(
                                label = if (isBn) "আগের স্ক্যান পুনরায় দেখুন" else "Use Previous Scan",
                                selected = false,
                                icon = Icons.Default.AutoAwesome,
                                onClick = onRestorePreviousScan,
                                modifier = Modifier.testTag("nutrition_use_previous_scan")
                            )
                        }
                    }
                    MealScanUiState.Analyzing -> {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = palette.accentSoft, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(strings.analyzingMealPhoto, style = MaterialTheme.typography.bodySmall, color = palette.accentSoft)
                        }
                    }
                    is MealScanUiState.Error -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(palette.coral.copy(alpha = 0.14f), RoundedCornerShape(10.dp))
                                .border(0.7.dp, palette.coral.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(mealScanState.message, style = MaterialTheme.typography.bodySmall, color = palette.coral, modifier = Modifier.weight(1f))
                            IconButton(onClick = onClearMealScan, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                    is MealScanUiState.Success -> {
                        val analysis = mealScanState.analysis
                        var editedDishName by remember(analysis) { mutableStateOf(analysis.dishName) }
                        var editedCalories by remember(analysis) { mutableStateOf(analysis.calories.toString()) }
                        var editedProtein by remember(analysis) { mutableStateOf(analysis.proteinGrams.toString()) }
                        var editedCarbs by remember(analysis) { mutableStateOf(analysis.carbsGrams.toString()) }
                        var editedFat by remember(analysis) { mutableStateOf(analysis.fatGrams.toString()) }

                        val verdictColor = when (analysis.healthVerdict) {
                            "GOOD_CHOICE" -> palette.accentSoft
                            "LIMIT" -> palette.coral
                            else -> palette.amber
                        }
                        val verdictText = when (analysis.healthVerdict) {
                            "GOOD_CHOICE" -> if (isBn) "খুবই স্বাস্থ্যকর" else "Good Choice"
                            "LIMIT" -> if (isBn) "কম পরিমাণে নিন" else "Limit Portion"
                            else -> if (isBn) "মাঝারি পছন্দ" else "Moderate Choice"
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(palette.blockBg, RoundedCornerShape(14.dp))
                                .border(0.8.dp, palette.borderAccent, RoundedCornerShape(14.dp))
                                .padding(12.dp)
                                .testTag("meal_ai_review_card"),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    bitmap = mealScanState.previewBitmap.asImageBitmap(),
                                    contentDescription = analysis.dishName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(62.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        StatusPillBadge(label = "AI Estimate", accentColor = palette.gold)
                                        StatusPillBadge(label = verdictText, accentColor = verdictColor)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (isBn) "লগ করার আগে পরিমাণ ও নাম সংশোধন করতে পারেন" else "Review & adjust calories or macros before saving",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.textSecondary
                                    )
                                }
                                IconButton(onClick = onClearMealScan) {
                                    Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textSecondary)
                                }
                            }

                            OutlinedTextField(
                                value = editedDishName,
                                onValueChange = { editedDishName = it },
                                label = { Text(if (isBn) "খাবারের নাম" else "Dish Name") },
                                singleLine = true,
                                colors = glassFieldColors(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("meal_review_name_input")
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    value = editedCalories,
                                    onValueChange = { editedCalories = it.filter(Char::isDigit) },
                                    label = { Text("kcal") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    colors = glassFieldColors(palette.gold),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .testTag("meal_review_cal_input")
                                )
                                OutlinedTextField(
                                    value = editedProtein,
                                    onValueChange = { editedProtein = it.filter(Char::isDigit) },
                                    label = { Text("P(g)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    colors = glassFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("meal_review_pro_input")
                                )
                                OutlinedTextField(
                                    value = editedCarbs,
                                    onValueChange = { editedCarbs = it.filter(Char::isDigit) },
                                    label = { Text("C(g)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    colors = glassFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("meal_review_carb_input")
                                )
                                OutlinedTextField(
                                    value = editedFat,
                                    onValueChange = { editedFat = it.filter(Char::isDigit) },
                                    label = { Text("F(g)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    colors = glassFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("meal_review_fat_input")
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                GlassFilterChip(
                                    label = if (isBn) "ক্যালোরি পুনর্গণনা" else "Recalculate",
                                    selected = false,
                                    icon = Icons.Default.Calculate,
                                    onClick = {
                                        val p = editedProtein.toIntOrNull() ?: 0
                                        val c = editedCarbs.toIntOrNull() ?: 0
                                        val f = editedFat.toIntOrNull() ?: 0
                                        editedCalories = (p * 4 + c * 4 + f * 9).toString()
                                    },
                                    modifier = Modifier.testTag("meal_recalculate_button")
                                )
                                GlassFilterChip(
                                    label = if (isBn) "পুনরায় AI বিশ্লেষণ" else "Re-run AI",
                                    selected = false,
                                    icon = Icons.Default.AutoAwesome,
                                    onClick = { onReanalyzeMealPhoto(mealType) },
                                    modifier = Modifier.testTag("meal_rerun_ai_button")
                                )
                            }

                            if (analysis.detectedItems.isNotEmpty()) {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    analysis.detectedItems.forEach { item ->
                                        StatusPillBadge(label = item, accentColor = palette.sky)
                                    }
                                }
                            }

                            if (analysis.recommendationReason.isNotBlank()) {
                                Text(analysis.recommendationReason, style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                            }
                            if (analysis.improvementTip.isNotBlank()) {
                                Text(
                                    text = "${if (isBn) "পরামর্শ" else "Tip"}: ${analysis.improvementTip}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = palette.accentSoft
                                )
                            }

                            EmeraldActionButton(
                                text = strings.logAnalyzedMeal,
                                onClick = {
                                    onAddMeal(
                                        editedDishName.trim().ifBlank { analysis.dishName },
                                        mealType,
                                        editedCalories.toIntOrNull() ?: analysis.calories,
                                        editedProtein.toIntOrNull() ?: analysis.proteinGrams,
                                        editedCarbs.toIntOrNull() ?: analysis.carbsGrams,
                                        editedFat.toIntOrNull() ?: analysis.fatGrams,
                                        false,
                                        "AI Estimate"
                                    )
                                    onClearMealScan()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("log_scanned_meal_button")
                            )
                        }
                    }
                }
            }
        }

        // 3. Searchable 1-Tap Worldwide & Sunnah Meal Presets
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("meal_presets_card")
            ) {
                Text(
                    text = if (isBn) "১-ট্যাপ বিশ্বব্যাপী ও সুন্নাহ খাবার" else "Worldwide & Sunnah Quick Presets",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Text(
                    text = if (isBn) "যেকোনো খাবারে '+ যোগ' ট্যাপ করে সরাসরি লগ করুন অথবা নাম-ক্যালোরি ভরুন।" else "Tap '+ Add' to log instantly, or tap a row to prefill & customize.",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = presetQuery,
                    onValueChange = { presetQuery = it },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accentSoft) },
                    placeholder = { Text(if (isBn) "এখানে লিখুন" else "Type here", color = palette.textMuted) },
                    singleLine = true,
                    colors = glassFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("All", "Sunnah Recipes", "Worldwide", "High Protein", "Suhoor & Iftar", "Desi / Everyday", "Snacks & Fruit")) { cat ->
                        GlassFilterChip(label = cat, selected = presetCategory == cat, onClick = { presetCategory = cat })
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    filteredPresets.forEach { food ->
                        val foodTitle = if (isBn) food.nameBn else food.nameEn
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(palette.blockBg, RoundedCornerShape(12.dp))
                                .border(0.7.dp, palette.borderNeutral.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                                .clickable {
                                    mealName = foodTitle
                                    calories = food.calories.toString()
                                    protein = food.protein.toString()
                                    carbs = food.carbs.toString()
                                    fat = food.fat.toString()
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(foodTitle, style = MaterialTheme.typography.labelLarge, color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    text = "${food.calories} kcal • P:${food.protein}g C:${food.carbs}g F:${food.fat}g",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                    color = palette.gold
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                GoldSourceTag(
                                    sourceText = "${food.source} ↗",
                                    modifier = Modifier.clickable {
                                        runCatching {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(food.sourceUrl)))
                                        }
                                    }
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            GlassFilterChip(
                                label = if (isBn) "+ যোগ" else "+ Add",
                                selected = true,
                                onClick = {
                                    onAddMeal(
                                        foodTitle,
                                        mealType,
                                        food.calories,
                                        food.protein,
                                        food.carbs,
                                        food.fat,
                                        true,
                                        food.source
                                    )
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GoldSourceTag(
                        sourceText = "USDA FoodData Central ↗",
                        modifier = Modifier
                            .clickable {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://fdc.nal.usda.gov/")))
                                }
                            }
                            .testTag("nutrition_source_usda")
                    )
                    GoldSourceTag(
                        sourceText = "FAO INFOODS ↗",
                        modifier = Modifier
                            .clickable {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.fao.org/infoods/infoods/en/")))
                                }
                            }
                            .testTag("nutrition_source_fao")
                    )
                    GoldSourceTag(
                        sourceText = "Sahih al-Bukhari 5417 ↗",
                        modifier = Modifier
                            .clickable {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://sunnah.com/bukhari:5417")))
                                }
                            }
                            .testTag("nutrition_source_bukhari")
                    )
                }
            }
        }

        // 4. Editable Custom Meal Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(strings.logMealTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("Suhoor", "Breakfast", "Lunch", "Iftar", "Dinner", "Snack")) { type ->
                        GlassFilterChip(label = type, selected = mealType == type, onClick = { mealType = type })
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = mealName,
                    onValueChange = { mealName = it },
                    placeholder = { Text(strings.mealNameHint, color = palette.textMuted) },
                    singleLine = true,
                    colors = glassFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = calories,
                        onValueChange = { calories = it.filter(Char::isDigit) },
                        placeholder = { Text("kcal") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = glassFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = protein,
                        onValueChange = { protein = it.filter(Char::isDigit) },
                        placeholder = { Text("P(g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = glassFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = carbs,
                        onValueChange = { carbs = it.filter(Char::isDigit) },
                        placeholder = { Text("C(g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = glassFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fat,
                        onValueChange = { fat = it.filter(Char::isDigit) },
                        placeholder = { Text("F(g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = glassFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                EmeraldActionButton(
                    text = strings.logMealTitle,
                    onClick = {
                        if (mealName.isNotBlank()) {
                            onAddMeal(
                                mealName.trim(),
                                mealType,
                                calories.toIntOrNull() ?: 0,
                                protein.toIntOrNull() ?: 0,
                                carbs.toIntOrNull() ?: 0,
                                fat.toIntOrNull() ?: 0,
                                false,
                                strings.estimatedDataTag
                            )
                            mealName = ""
                            calories = ""
                            protein = ""
                            carbs = ""
                            fat = ""
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_meal_button")
                )
            }
        }

        // 5. Logged Meals Today
        items(meals, key = { it.id }) { meal ->
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${meal.mealType}: ${meal.name}", style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                        Text(
                            "${meal.calories} kcal • P:${meal.proteinGrams}g C:${meal.carbsGrams}g F:${meal.fatGrams}g",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        StatusPillBadge(
                            label = if (meal.isVerifiedReference) "${strings.verifiedDataTag} (${meal.sourceAttribution})" else meal.sourceAttribution,
                            accentColor = if (meal.isVerifiedReference) palette.accentSoft else palette.amber
                        )
                    }
                    IconButton(onClick = { onDeleteMeal(meal.id) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = palette.textSecondary)
                    }
                }
            }
        }
    }
}

private suspend fun decodeUriToBitmap(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
    runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val src = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.isMutableRequired = false
                val maxSide = maxOf(info.size.width, info.size.height)
                if (maxSide > 1024) {
                    val sample = (maxSide / 1024).coerceAtLeast(1)
                    decoder.setTargetSampleSize(sample)
                }
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    }.getOrNull()
}
