package com.example.ruhzena.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.example.ruhzena.data.local.RuhZenaDatabase
import com.example.ruhzena.data.local.UserPreferencesRepository
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.media.RuhZenaMediaNotificationManager
import com.example.ruhzena.widgets.RuhZenaWidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val notificationId = intent.getIntExtra(EXTRA_NOTIFICATION_ID, -1)
        val reminderType = intent.getStringExtra(EXTRA_REMINDER_TYPE).orEmpty()
        val isBn = intent.getBooleanExtra(EXTRA_IS_BN, false)

        when (action) {
            ACTION_MEDIA_PLAY_PAUSE,
            ACTION_MEDIA_PREV,
            ACTION_MEDIA_NEXT,
            ACTION_MEDIA_STOP -> {
                RuhZenaMediaNotificationManager.handleAction(context, action)
            }

            ACTION_DONE, ACTION_CANCEL -> {
                RuhZenaNotificationHelper.stopActiveAlertSound(context)
                if (notificationId >= 0) {
                    NotificationManagerCompat.from(context).cancel(notificationId)
                }
            }

            ACTION_SNOOZE_5, ACTION_SNOOZE_15 -> {
                RuhZenaNotificationHelper.stopActiveAlertSound(context)
                if (notificationId >= 0) {
                    NotificationManagerCompat.from(context).cancel(notificationId)
                }
                val delayMin = if (action == ACTION_SNOOZE_15) 15L else 5L
                if (reminderType.isNotBlank()) {
                    val request = OneTimeWorkRequestBuilder<RuhZenaReminderWorker>()
                        .addTag("ruhzena_reminder")
                        .setInitialDelay(delayMin, TimeUnit.MINUTES)
                        .setInputData(workDataOf(RuhZenaReminderWorker.KEY_TYPE to reminderType))
                        .build()
                    runCatching {
                        WorkManager.getInstance(context).enqueueUniqueWork(
                            "ruhzena_snooze_$reminderType",
                            ExistingWorkPolicy.REPLACE,
                            request
                        )
                    }
                    RuhZenaNotificationHelper.showSilentConfirmation(
                        context = context,
                        notificationId = if (notificationId >= 0) notificationId else 1090,
                        title = if (isBn) "${delayMin} মিনিটের জন্য স্নুজ করা হয়েছে" else "Snoozed for $delayMin min",
                        body = if (isBn) "${delayMin} মিনিট পর আবার মনে করিয়ে দেওয়া হবে।" else "RuhZena will remind you again in $delayMin minutes.",
                        isBn = isBn
                    )
                }
            }

            ACTION_SHOW_MUTE_OPTIONS -> {
                RuhZenaNotificationHelper.stopActiveAlertSound(context)
                val id = if (notificationId >= 0) notificationId else 1091
                RuhZenaNotificationHelper.showMuteDurationChooserNotification(
                    context = context,
                    notificationId = id,
                    reminderType = reminderType,
                    isBn = isBn
                )
            }

            ACTION_MUTE_HOURS -> {
                RuhZenaNotificationHelper.stopActiveAlertSound(context)
                val hours = intent.getIntExtra(EXTRA_MUTE_HOURS, 1).coerceIn(1, 24)
                val untilMs = System.currentTimeMillis() + hours * 3_600_000L
                val untilTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(untilMs))
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        UserPreferencesRepository(context).setMutedUntil(untilMs)
                        if (notificationId >= 0) {
                            NotificationManagerCompat.from(context).cancel(notificationId)
                        }
                        RuhZenaNotificationHelper.showSilentConfirmation(
                            context = context,
                            notificationId = 1095,
                            title = if (isBn) "$hours ঘণ্টার জন্য মিউট করা হয়েছে" else "Notifications muted for ${hours}h",
                            body = if (isBn) "$untilTime পর্যন্ত কোনো রিমাইন্ডার আসবে না।" else "All alerts silenced until $untilTime.",
                            showUnmuteAction = true,
                            isBn = isBn
                        )
                    } finally {
                        pendingResult.finish()
                    }
                }
            }

            ACTION_UNMUTE -> {
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        UserPreferencesRepository(context).setMutedUntil(0L)
                        NotificationManagerCompat.from(context).cancel(1095)
                        if (notificationId >= 0) {
                            NotificationManagerCompat.from(context).cancel(notificationId)
                        }
                    } finally {
                        pendingResult.finish()
                    }
                }
            }

            ACTION_WATER_CUSTOM_INPUT -> {
                RuhZenaNotificationHelper.stopActiveAlertSound(context)
                val rawText = RemoteInput.getResultsFromIntent(intent)
                    ?.getCharSequence(RuhZenaNotificationHelper.KEY_WATER_ML_INPUT)
                    ?.toString()
                    .orEmpty()
                val parsedMl = Regex("\\d+").find(rawText)?.value?.toIntOrNull()?.coerceIn(10, 5000) ?: 250
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        val dao = RuhZenaDatabase.getInstance(context).waterLogDao()
                        dao.insert(WaterLogEntity(amountMl = parsedMl, dateKey = todayKey))
                        val newTotal = dao.getTotalMlForDateSnapshot(todayKey)
                        val goal = UserPreferencesRepository(context).preferencesFlow.first().hydrationGoalMl
                        RuhZenaWidgetUpdater.updateAll(context)
                        val notifId = if (notificationId >= 0) notificationId else 1001
                        RuhZenaNotificationHelper.showSilentConfirmation(
                            context = context,
                            notificationId = notifId,
                            title = if (isBn) "+${parsedMl} মি.লি. পানি যোগ হয়েছে" else "Logged +${parsedMl} ml water",
                            body = if (isBn) "আজকের মোট: $newTotal / $goal মি.লি.। মাশাআল্লাহ!" else "Today's total: $newTotal / $goal ml. Well done!",
                            isBn = isBn
                        )
                    } finally {
                        pendingResult.finish()
                    }
                }
            }

            ACTION_WATER_250, ACTION_WIDGET_WATER_250 -> {
                RuhZenaNotificationHelper.stopActiveAlertSound(context)
                if (notificationId >= 0) {
                    NotificationManagerCompat.from(context).cancel(notificationId)
                }
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        val dao = RuhZenaDatabase.getInstance(context).waterLogDao()
                        dao.insert(WaterLogEntity(amountMl = 250, dateKey = todayKey))
                        val newTotal = dao.getTotalMlForDateSnapshot(todayKey)
                        val goal = UserPreferencesRepository(context).preferencesFlow.first().hydrationGoalMl
                        RuhZenaWidgetUpdater.updateAll(context)
                        if (action == ACTION_WATER_250) {
                            RuhZenaNotificationHelper.showSilentConfirmation(
                                context = context,
                                notificationId = if (notificationId >= 0) notificationId else 1001,
                                title = if (isBn) "+২৫০ মি.লি. পানি যোগ হয়েছে" else "Logged +250 ml water",
                                body = if (isBn) "আজকের মোট: $newTotal / $goal মি.লি.।" else "Today's total: $newTotal / $goal ml.",
                                isBn = isBn
                            )
                        }
                    } finally {
                        pendingResult.finish()
                    }
                }
            }

            ACTION_WIDGET_TASBIH_TAP -> {
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        UserPreferencesRepository(context).recordTasbihTap(completedSession = false)
                        RuhZenaWidgetUpdater.updateAll(context)
                    } finally {
                        pendingResult.finish()
                    }
                }
            }
        }
    }

    companion object {
        const val ACTION_DONE = "com.example.ruhzena.action.NOTIFICATION_DONE"
        const val ACTION_CANCEL = "com.example.ruhzena.action.NOTIFICATION_CANCEL"
        const val ACTION_SNOOZE_5 = "com.example.ruhzena.action.NOTIFICATION_SNOOZE_5"
        const val ACTION_SNOOZE_15 = "com.example.ruhzena.action.NOTIFICATION_SNOOZE_15"
        const val ACTION_SHOW_MUTE_OPTIONS = "com.example.ruhzena.action.NOTIFICATION_SHOW_MUTE_OPTIONS"
        const val ACTION_MUTE_HOURS = "com.example.ruhzena.action.NOTIFICATION_MUTE_HOURS"
        const val ACTION_UNMUTE = "com.example.ruhzena.action.NOTIFICATION_UNMUTE"
        const val ACTION_WATER_CUSTOM_INPUT = "com.example.ruhzena.action.NOTIFICATION_WATER_CUSTOM_INPUT"
        const val ACTION_WATER_250 = "com.example.ruhzena.action.NOTIFICATION_WATER_250"
        const val ACTION_WIDGET_WATER_250 = "com.example.ruhzena.action.WIDGET_WATER_250"
        const val ACTION_WIDGET_TASBIH_TAP = "com.example.ruhzena.action.WIDGET_TASBIH_TAP"

        // Futuristic Background Media Bar Controls
        const val ACTION_MEDIA_PLAY_PAUSE = "com.example.ruhzena.action.MEDIA_PLAY_PAUSE"
        const val ACTION_MEDIA_PREV = "com.example.ruhzena.action.MEDIA_PREV"
        const val ACTION_MEDIA_NEXT = "com.example.ruhzena.action.MEDIA_NEXT"
        const val ACTION_MEDIA_STOP = "com.example.ruhzena.action.MEDIA_STOP"

        const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
        const val EXTRA_REMINDER_TYPE = "extra_reminder_type"
        const val EXTRA_IS_BN = "extra_is_bn"
        const val EXTRA_MUTE_HOURS = "extra_mute_hours"
    }
}
