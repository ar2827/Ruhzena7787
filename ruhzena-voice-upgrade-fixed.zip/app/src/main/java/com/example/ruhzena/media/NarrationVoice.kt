package com.example.ruhzena.media

import java.security.MessageDigest
import java.util.Locale

/**
 * Voice model for RuhZena's AI NARRATION (stories, AI replies, lessons, context, duas, Arabic letters).
 *
 * This file is deliberately free of Android classes so it can be unit-tested on the JVM.
 * It is NOT used by QuranAudioController / Quran reciters, which stay a completely separate system.
 *
 * Single source of truth: the gender chosen in onboarding/profile (`UserPreferences.characterGender`).
 * The legacy `speechVoiceStyle` setting is now only a TONE variant *inside* that gender.
 */
enum class NarrationGender { MALE, FEMALE }

enum class NarrationType { STORY, AI_REPLY, EDUCATIONAL, ARABIC }

data class NarrationVoiceConfig(
    val gender: NarrationGender,
    /** Canonical legacy style id (WARM_HUMAN / CALM_SCHOLAR / GENTLE_FEMALE) consistent with [gender]. */
    val styleId: String,
    /** Gemini prebuilt voice name sent as a real voice configuration (not just prose). */
    val geminiVoice: String
) {
    /** Changes whenever anything affecting the generated audio's speaker changes. */
    val cacheSignature: String get() = "${gender.name}:$geminiVoice"
}

object NarrationVoiceResolver {
    const val STYLE_WARM_MALE = "WARM_HUMAN"
    const val STYLE_CALM_MALE = "CALM_SCHOLAR"
    const val STYLE_GENTLE_FEMALE = "GENTLE_FEMALE"

    /** Gemini TTS prebuilt voices. One fixed speaker per style => no random switching. */
    private val GEMINI_VOICE_BY_STYLE = mapOf(
        STYLE_WARM_MALE to "Algieba",     // smooth, warm male
        STYLE_CALM_MALE to "Charon",      // calm, informative male
        STYLE_GENTLE_FEMALE to "Sulafat"  // warm female
    )

    fun genderOfStyle(styleId: String): NarrationGender =
        if (styleId.equals(STYLE_GENTLE_FEMALE, ignoreCase = true)) NarrationGender.FEMALE
        else NarrationGender.MALE

    /** Styles the settings picker may offer for [gender]. */
    fun stylesFor(gender: NarrationGender): List<String> = when (gender) {
        NarrationGender.MALE -> listOf(STYLE_WARM_MALE, STYLE_CALM_MALE)
        NarrationGender.FEMALE -> listOf(STYLE_GENTLE_FEMALE)
    }

    /** Parses "MALE"/"FEMALE" (any case); anything else (blank, junk) => null. */
    fun parseGender(characterGender: String?): NarrationGender? = when (characterGender?.trim()?.uppercase(Locale.US)) {
        "MALE" -> NarrationGender.MALE
        "FEMALE" -> NarrationGender.FEMALE
        else -> null
    }

    /**
     * Gender rules:
     *  1. A valid onboarding/profile gender always wins.
     *  2. If none was ever saved (very old accounts), honour the legacy voice style the user picked.
     *  3. Otherwise default to MALE.
     */
    fun resolveGender(characterGender: String?, legacyStyle: String?): NarrationGender =
        parseGender(characterGender) ?: genderOfStyle(legacyStyle.orEmpty())

    fun resolve(characterGender: String?, legacyStyle: String?): NarrationVoiceConfig {
        val gender = resolveGender(characterGender, legacyStyle)
        val requested = legacyStyle.orEmpty().uppercase(Locale.US)
        val style = if (requested in GEMINI_VOICE_BY_STYLE && genderOfStyle(requested) == gender) {
            requested
        } else {
            stylesFor(gender).first()
        }
        return NarrationVoiceConfig(gender, style, GEMINI_VOICE_BY_STYLE.getValue(style))
    }
}

object NarrationPrompts {
    const val PROMPT_VERSION = "p5"

    fun languageName(isBangla: Boolean, type: NarrationType): String = when {
        type == NarrationType.ARABIC -> "Arabic"
        isBangla -> "Bengali"
        else -> "English"
    }

    /**
     * Compact "Say ...:" directive. Voice gender/timbre is NOT described here — it comes from the real
     * prebuilt-voice configuration. Short on purpose: long preambles get read aloud and add latency.
     */
    fun directive(type: NarrationType, language: String): String = when (type) {
        NarrationType.STORY ->
            "Narrate this in $language like a calm, warm audiobook storyteller: unhurried, natural breaths between sentences, " +
                "softer and gently expressive for dialogue, subtle emphasis on important moments, respectful and reverent when " +
                "Prophets are mentioned, never theatrical"
        NarrationType.AI_REPLY ->
            "Say this in $language as a warm, intelligent companion explaining something clearly, with natural conversational " +
                "rhythm and friendly intonation"
        NarrationType.EDUCATIONAL ->
            "Say this in $language as a clear, friendly, professional teacher: steady unhurried pace, precise pronunciation, " +
                "calm natural intonation"
        NarrationType.ARABIC ->
            "Recite this in Arabic slowly and clearly with precise pronunciation, calm and steady, pausal endings at phrase ends"
    }

    fun build(type: NarrationType, language: String, chunk: String): String =
        "${directive(type, language)}:\n$chunk"
}

object NarrationCacheKeys {
    /** Includes everything that changes the audio: type, language, gender+voice, prompt version, text. */
    fun build(type: NarrationType, language: String, voice: NarrationVoiceConfig, text: String): String {
        val raw = "v5|${type.name}|${language.lowercase(Locale.US)}|${voice.cacheSignature}|${NarrationPrompts.PROMPT_VERSION}|$text"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.take(40)
    }
}

/** One synthesis unit. [paragraphBreakAfter] => a longer natural pause is inserted after it. */
data class SpeechChunk(val text: String, val paragraphBreakAfter: Boolean)

object NarrationChunker {
    private val SENTENCE_SPLIT = Regex("(?<=[.!?।؟…])\\s+")
    private val PARAGRAPH_SPLIT = Regex("\\s*\\n+\\s*")

    /**
     * Splits narration into chunks that never cross a paragraph boundary.
     * The first chunk is a complete first sentence/clause group (short enough to start fast but long
     * enough that Gemini can give it natural intonation); later chunks are larger so prosody stays
     * continuous and fewer seams exist.
     */
    fun split(text: String, firstMax: Int = 130, nextMax: Int = 380): List<SpeechChunk> {
        val clean = text.trim()
        if (clean.isEmpty()) return emptyList()
        val paragraphs = clean.split(PARAGRAPH_SPLIT).map { it.trim() }.filter { it.isNotEmpty() }
        val out = mutableListOf<SpeechChunk>()

        fun limit() = if (out.isEmpty()) firstMax else nextMax
        fun add(t: String, para: Boolean) { if (t.isNotBlank()) out.add(SpeechChunk(t.trim(), para)) }

        for ((pIdx, paragraph) in paragraphs.withIndex()) {
            val sentences = paragraph.split(SENTENCE_SPLIT).map { it.trim() }.filter { it.isNotEmpty() }
            val current = StringBuilder()
            for (sentence in sentences) {
                if (sentence.length > limit()) {
                    if (current.isNotEmpty()) { add(current.toString(), false); current.clear() }
                    for (piece in breakLongSentence(sentence, limit(), nextMax)) add(piece, false)
                } else if (current.isNotEmpty() && current.length + 1 + sentence.length > limit()) {
                    add(current.toString(), false)
                    current.clear()
                    current.append(sentence)
                } else {
                    if (current.isNotEmpty()) current.append(' ')
                    current.append(sentence)
                }
            }
            if (current.isNotEmpty()) add(current.toString(), false)
            // mark the last chunk of this paragraph (if any chunk exists and more paragraphs follow)
            if (pIdx < paragraphs.lastIndex && out.isNotEmpty()) {
                val last = out.removeAt(out.lastIndex)
                out.add(last.copy(paragraphBreakAfter = true))
            }
        }
        return out
    }

    /** Breaks an over-long sentence at commas/semicolons first, then at spaces. First piece may use a tighter limit. */
    private fun breakLongSentence(sentence: String, firstLimit: Int, nextLimit: Int): List<String> {
        val pieces = mutableListOf<String>()
        val buf = StringBuilder()
        fun lim() = if (pieces.isEmpty()) firstLimit else nextLimit
        val tokens = sentence.split(Regex("(?<=[,;:،؛])\\s+|\\s+")).filter { it.isNotEmpty() }
        for (t in tokens) {
            if (buf.isNotEmpty() && buf.length + 1 + t.length > lim()) {
                pieces.add(buf.toString()); buf.clear()
            }
            if (buf.isNotEmpty()) buf.append(' ')
            buf.append(t)
        }
        if (buf.isNotEmpty()) pieces.add(buf.toString())
        return pieces
    }
}

/**
 * Best-effort gender classification of Android TextToSpeech voices. Android's Voice API exposes no
 * gender field, so this relies on explicit "male"/"female" words and well-known Google voice codes
 * (e.g. en-us-x-iom-network). Unknown => null, which the player treats as "unknown gender" and
 * compensates for with pitch instead of ever picking a voice known to be the opposite gender.
 */
object DeviceVoiceGender {
    private val FEMALE_TOKENS = listOf(
        "female", "-f-", "_f_", "x-sfg", "x-tpf", "x-iob", "x-iog", "x-gba", "x-gbc",
        "x-bnf", "x-bna", "x-arf", "x-ara", "x-inf", "x-auf", "x-tpc"
    )
    private val MALE_TOKENS = listOf(
        "male", "-m-", "_m_", "x-tpd", "x-iom", "x-iol", "x-gbb", "x-gbd",
        "x-bnd", "x-bnm", "x-ard", "x-arm", "x-sfb", "x-sfm", "x-aud", "x-inm"
    )

    fun classify(voiceName: String, features: String = ""): NarrationGender? {
        val combined = "${voiceName.lowercase(Locale.US)} ${features.lowercase(Locale.US)}"
        if (FEMALE_TOKENS.any { combined.contains(it) }) return NarrationGender.FEMALE // "female" contains "male", so test first
        if (MALE_TOKENS.any { combined.contains(it) }) return NarrationGender.MALE
        return null
    }

    /** Pitch used to nudge an engine voice toward the requested gender when it can't be matched exactly. */
    fun compensationPitch(wanted: NarrationGender, match: DeviceMatch): Float = when (match) {
        DeviceMatch.MATCHED -> 1.0f
        DeviceMatch.UNKNOWN_GENDER -> if (wanted == NarrationGender.FEMALE) 1.10f else 0.88f
        DeviceMatch.OPPOSITE_ONLY -> if (wanted == NarrationGender.FEMALE) 1.22f else 0.80f
    }
}

/** How well an on-device voice satisfied the requested gender. Ordered best -> worst. */
enum class DeviceMatch { MATCHED, UNKNOWN_GENDER, OPPOSITE_ONLY }
