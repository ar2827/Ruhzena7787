package com.example.ruhzena.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.R
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.notifications.NotificationActionReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HydrationWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val snap = RuhZenaWidgetUpdater.loadSnapshot(context)
                val isBn = snap.prefs.language == AppLanguage.BANGLA

                val addWaterIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                    action = NotificationActionReceiver.ACTION_WIDGET_WATER_250
                }
                val addWaterPending = PendingIntent.getBroadcast(
                    context,
                    4202,
                    addWaterIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                for (appWidgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_hydration).apply {
                        setTextViewText(R.id.widget_hydration_title, if (isBn) "রূহজেনা • পানি পান" else "RuhZena • HYDRATION")
                        setTextViewText(R.id.widget_hydration_amount, "${snap.waterTodayMl} / ${snap.prefs.hydrationGoalMl} ml")
                        setTextViewText(
                            R.id.widget_hydration_pct,
                            if (isBn) "${snap.hydrationPct}% পূর্ণ" else "${snap.hydrationPct}% of daily goal"
                        )
                        setOnClickPendingIntent(
                            R.id.widget_hydration_root,
                            RuhZenaWidgetUpdater.launchAppPendingIntent(context, 4201)
                        )
                        setOnClickPendingIntent(R.id.widget_hydration_add_250, addWaterPending)
                    }
                    appWidgetManager.updateAppWidget(appWidgetId, views)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
