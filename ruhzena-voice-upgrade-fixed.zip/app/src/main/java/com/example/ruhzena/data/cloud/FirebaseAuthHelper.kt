package com.example.ruhzena.data.cloud

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

sealed interface GoogleAuthOutcome {
    data class Success(val user: FirebaseUser) : GoogleAuthOutcome
    data object Cancelled : GoogleAuthOutcome
    data object NoSavedCredential : GoogleAuthOutcome
    data class Error(val message: String) : GoogleAuthOutcome
}

object FirebaseAuthHelper {
    private const val TAG = "Auth"

    fun authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
        val auth = Firebase.auth
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        trySend(auth.currentUser)
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    /**
     * Silent auto sign-in using a single GetGoogleIdOption per request (API 36 compatible).
     */
    suspend fun attemptAutoSignIn(context: Context): GoogleAuthOutcome {
        val existing = Firebase.auth.currentUser
        if (existing != null) return GoogleAuthOutcome.Success(existing)

        val webClientId = resolveWebClientId(context)
            ?: return GoogleAuthOutcome.Error("Google Sign-In client ID is not configured.")

        val credentialManager = CredentialManager.create(context)
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(true)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        return try {
            val result = credentialManager.getCredential(context = context, request = request)
            exchangeGoogleCredential(result.credential)
        } catch (e: CancellationException) {
            throw e
        } catch (e: NoCredentialException) {
            Log.d(TAG, "No previously authorized Google account found for silent sign-in.")
            GoogleAuthOutcome.NoSavedCredential
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Silent Google sign-in cancelled by user", e)
            GoogleAuthOutcome.Cancelled
        } catch (e: GetCredentialException) {
            Log.w(TAG, "Silent Google sign-in unavailable: ${e.message}")
            GoogleAuthOutcome.NoSavedCredential
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during silent sign-in", e)
            GoogleAuthOutcome.NoSavedCredential
        }
    }

    /**
     * Interactive Sign in with Google button flow using a single GetSignInWithGoogleOption.
     */
    suspend fun signInWithGoogle(context: Context): GoogleAuthOutcome {
        val webClientId = resolveWebClientId(context)
            ?: return GoogleAuthOutcome.Error("Google Sign-In client ID is not configured.")

        val credentialManager = CredentialManager.create(context)
        val signInOption = GetSignInWithGoogleOption.Builder(webClientId)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()

        return try {
            val result = credentialManager.getCredential(context = context, request = request)
            exchangeGoogleCredential(result.credential)
        } catch (e: CancellationException) {
            throw e
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google sign-in dismissed by user", e)
            GoogleAuthOutcome.Cancelled
        } catch (e: NoCredentialException) {
            Log.w(TAG, "No Google accounts available on this device", e)
            GoogleAuthOutcome.Error("No Google account found on this device. Add a Google account in device Settings and try again.")
        } catch (e: GetCredentialException) {
            Log.e(TAG, "Google sign-in failed", e)
            GoogleAuthOutcome.Error(e.message ?: "Google Sign-In failed. Please try again.")
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during Google sign-in", e)
            GoogleAuthOutcome.Error(e.message ?: "Unable to sign in right now. Please try again.")
        }
    }

    /**
     * Signs out of Firebase Auth and clears Credential Manager state inside NonCancellable
     * so cancellation of the caller coroutine never leaves half-cleared session state.
     */
    suspend fun signOut(context: Context) = withContext(NonCancellable) {
        runCatching {
            Firebase.auth.signOut()
        }.onFailure { e ->
            Log.e(TAG, "Firebase signOut failed", e)
        }
        runCatching {
            CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
        }.onFailure { e ->
            Log.w(TAG, "Clear credential state failed", e)
        }
    }

    private suspend fun exchangeGoogleCredential(credential: androidx.credentials.Credential): GoogleAuthOutcome {
        if (credential !is CustomCredential ||
            credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            Log.w(TAG, "Received unexpected credential type: ${credential.type}")
            return GoogleAuthOutcome.Error("Unsupported credential type returned.")
        }
        return try {
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
            val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
            val authResult = Firebase.auth.signInWithCredential(firebaseCredential).await()
            val user = authResult.user
            if (user != null) {
                GoogleAuthOutcome.Success(user)
            } else {
                GoogleAuthOutcome.Error("Firebase sign-in returned no user.")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: GoogleIdTokenParsingException) {
            Log.e(TAG, "Failed to parse Google ID token", e)
            GoogleAuthOutcome.Error("Invalid Google sign-in token. Please try again.")
        } catch (e: Exception) {
            Log.e(TAG, "Firebase Auth credential exchange failed", e)
            GoogleAuthOutcome.Error(e.message ?: "Could not complete Firebase Sign-In.")
        }
    }

    private fun resolveWebClientId(context: Context): String? {
        return runCatching {
            context.getString(R.string.default_web_client_id).takeIf { it.isNotBlank() }
        }.onFailure { e ->
            Log.e(TAG, "Failed to read R.string.default_web_client_id", e)
        }.getOrNull()
    }
}
