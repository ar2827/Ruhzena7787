package com.example.ruhzena.media

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.ruhzena.data.islamic.QuranAudioRef
import com.example.ruhzena.data.islamic.QuranReciter
import com.example.ruhzena.data.islamic.SurahCatalog
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

data class AudioPlaybackState(
    val activeSurahNumber: Int = 0,
    val activeTrackId: String = "",
    val activeTitle: String = "",
    val activeSubtitle: String = "",
    val isDhikrMode: Boolean = false,
    val currentAyahNumber: Int = 1,
    val totalAyahs: Int = 0,
    val reciter: QuranReciter = SurahCatalog.reciters.first(),
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val errorMessage: String? = null,
    val repeatAyah: Boolean = false,
    val repeatSurah: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val volume: Float = 1.0f,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isHifzMode: Boolean = false,
    val hifzRepeatIndex: Int = 1,
    val hifzTotalRepeats: Int = 1,
    val hifzPauseGapSeconds: Int = 0,
    val isHifzGapPause: Boolean = false,
    val sleepTimerRemainingSec: Int = 0,
    val sleepStopAtEndOfSurah: Boolean = false
)

class QuranAudioController(
    private val context: Context,
    private val speechPlayer: RuhZenaSpeechPlayer? = null
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
    private val json = Json { ignoreUnknownKeys = true }
    private val hisnCacheDir = File(context.filesDir, "hisn_audio_index").apply { mkdirs() }

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pendingPlayback: Pair<List<MediaItem>, Int>? = null
    private var progressJob: Job? = null
    private var gapPauseJob: Job? = null
    private var sleepTimerJob: Job? = null
    private var hifzItemMetadata: List<Pair<Int, Int>> = emptyList() // (ayahNum, repeatIdx)

    init {
        // Pre-bind MediaSessionService immediately so the very first Play tap has zero bind delay
        scope.launch { runCatching { connect() } }
    }

    private val _state = MutableStateFlow(AudioPlaybackState())
    val state: StateFlow<AudioPlaybackState> = _state.asStateFlow()

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) startProgressTicker() else progressJob?.cancel()
            syncGlassMediaNotification()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED && _state.value.sleepStopAtEndOfSurah) {
                cancelSleepTimer()
            }
            _state.update {
                it.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    errorMessage = if (playbackState == Player.STATE_READY) null else it.errorMessage
                )
            }
            if (playbackState == Player.STATE_READY) {
                syncGlassMediaNotification()
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val idx = controller?.currentMediaItemIndex ?: 0
            val s = _state.value
            if (s.isHifzMode && idx in hifzItemMetadata.indices) {
                val (ayahNum, repIdx) = hifzItemMetadata[idx]
                _state.update { it.copy(currentAyahNumber = ayahNum, hifzRepeatIndex = repIdx) }
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && s.hifzPauseGapSeconds > 0) {
                    gapPauseJob?.cancel()
                    gapPauseJob = scope.launch {
                        controller?.pause()
                        _state.update { it.copy(isHifzGapPause = true) }
                        delay(s.hifzPauseGapSeconds * 1000L)
                        _state.update { it.copy(isHifzGapPause = false) }
                        controller?.play()
                    }
                }
            } else {
                _state.update { it.copy(currentAyahNumber = idx + 1) }
            }
            syncGlassMediaNotification()
        }

        override fun onPlayerError(error: PlaybackException) {
            _state.update {
                it.copy(
                    isBuffering = false,
                    isPlaying = false,
                    isHifzGapPause = false,
                    errorMessage = error.localizedMessage ?: "Audio stream unavailable"
                )
            }
            syncGlassMediaNotification()
        }
    }

    private var lastNotifProgressPushMs: Long = 0L

    private fun syncGlassMediaNotification(force: Boolean = true) {
        val s = _state.value
        if (s.activeSurahNumber <= 0 && s.activeTrackId.isBlank()) {
            RuhZenaMediaNotificationManager.dismiss(
                context,
                RuhZenaMediaNotificationManager.AudioSource.QURAN
            )
            return
        }
        val nowMs = System.currentTimeMillis()
        if (!force && nowMs - lastNotifProgressPushMs < 1400L) return
        lastNotifProgressPushMs = nowMs

        val title = when {
            s.isDhikrMode -> s.activeTitle.ifBlank { "Hisn al-Muslim Audio" }
            s.isHifzMode -> "${s.activeTitle} • Ayah ${s.currentAyahNumber} (${s.hifzRepeatIndex}/${s.hifzTotalRepeats})"
            else -> "${s.activeTitle} • Ayah ${s.currentAyahNumber}/${s.totalAyahs.coerceAtLeast(1)}"
        }
        val badge = when {
            s.isDhikrMode -> "DUA PLAYER"
            s.isHifzMode -> "HIFZ LOOP"
            else -> "QURAN PLAYER"
        }
        val themeVariant = when {
            s.isHifzMode -> RuhZenaMediaNotificationManager.GlassThemeVariant.HIFZ_VIOLET
            else -> RuhZenaMediaNotificationManager.GlassThemeVariant.QURAN_EMERALD
        }
        val speedStr = if (s.playbackSpeed != 1.0f) "${s.playbackSpeed}x" else "1.0x"
        val repeatTag = when {
            s.repeatAyah -> " • Repeat Ayah"
            s.repeatSurah -> " • Repeat Surah"
            else -> ""
        }
        RuhZenaMediaNotificationManager.showOrUpdate(
            context = context,
            control = RuhZenaMediaNotificationManager.ActiveMediaControl(
                source = RuhZenaMediaNotificationManager.AudioSource.QURAN,
                title = title,
                subtitle = s.activeSubtitle.ifBlank { s.reciter.nameEn },
                badge = badge,
                isPlaying = s.isPlaying,
                canSkip = !s.isDhikrMode && s.totalAyahs > 1,
                positionMs = s.positionMs,
                durationMs = s.durationMs,
                metaPill = "$speedStr$repeatTag",
                themeVariant = themeVariant,
                onPlayPause = { togglePlayPause() },
                onPrev = { previousAyah() },
                onNext = { nextAyah() },
                onStop = { stopPlayback() }
            )
        )
    }

    fun connect() {
        if (controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, RuhZenaPlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val ctrl = future.get()
                controller = ctrl
                ctrl.addListener(playerListener)
                ctrl.volume = _state.value.volume
                applyRepeatMode()
                pendingPlayback?.let { (items, idx) ->
                    pendingPlayback = null
                    ctrl.setMediaItems(items, idx, 0L)
                    ctrl.prepare()
                    ctrl.play()
                }
            } catch (e: Exception) {
                _state.update { it.copy(errorMessage = e.localizedMessage) }
            }
        }, MoreExecutors.directExecutor())
    }

    fun playSurah(surahNumber: Int, startAyahNumber: Int, reciter: QuranReciter) {
        speechPlayer?.stop()
        gapPauseJob?.cancel()
        hifzItemMetadata = emptyList()
        val meta = SurahCatalog.getMeta(surahNumber)
        val startIdx = (startAyahNumber - 1).coerceIn(0, meta.ayahCount - 1)
        _state.update {
            it.copy(
                activeSurahNumber = surahNumber,
                activeTrackId = "SURAH_$surahNumber",
                activeTitle = meta.englishName,
                activeSubtitle = reciter.nameEn,
                isDhikrMode = false,
                isHifzMode = false,
                isHifzGapPause = false,
                currentAyahNumber = startIdx + 1,
                totalAyahs = meta.ayahCount,
                reciter = reciter,
                isBuffering = true,
                errorMessage = null
            )
        }

        val items = (1..meta.ayahCount).map { ayahNum ->
            val globalNum = SurahCatalog.globalAyahNumber(surahNumber, ayahNum)
            val url = reciter.audioUrlForGlobalAyah(globalNum)
            MediaItem.Builder()
                .setUri(Uri.parse(url))
                .setMediaId("${reciter.id}_$globalNum")
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle("${meta.englishName} • Ayah $ayahNum")
                        .setArtist(reciter.nameEn)
                        .build()
                )
                .build()
        }
        startMediaItems(items, startIdx)
    }

    fun playHifzRange(
        surahNumber: Int,
        startAyah: Int,
        endAyah: Int,
        repeatCountPerAyah: Int,
        pauseGapSeconds: Int,
        reciter: QuranReciter
    ) {
        gapPauseJob?.cancel()
        val meta = SurahCatalog.getMeta(surahNumber)
        val safeStart = startAyah.coerceIn(1, meta.ayahCount)
        val safeEnd = endAyah.coerceIn(safeStart, meta.ayahCount)
        val repeats = repeatCountPerAyah.coerceIn(1, 100)
        val gap = pauseGapSeconds.coerceIn(0, 20)

        val pairs = mutableListOf<Pair<Int, Int>>()
        val items = mutableListOf<MediaItem>()
        for (ayah in safeStart..safeEnd) {
            val globalNum = SurahCatalog.globalAyahNumber(surahNumber, ayah)
            val url = reciter.audioUrlForGlobalAyah(globalNum)
            for (rep in 1..repeats) {
                pairs.add(ayah to rep)
                items.add(
                    MediaItem.Builder()
                        .setUri(Uri.parse(url))
                        .setMediaId("hifz_${reciter.id}_${globalNum}_$rep")
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle("Hifz • ${meta.englishName} $ayah ($rep/$repeats)")
                                .setArtist(reciter.nameEn)
                                .build()
                        )
                        .build()
                )
            }
        }
        hifzItemMetadata = pairs
        _state.update {
            it.copy(
                activeSurahNumber = surahNumber,
                activeTrackId = "HIFZ_${surahNumber}_${safeStart}_${safeEnd}",
                activeTitle = "Hifz • ${meta.englishName} ($safeStart-$safeEnd)",
                activeSubtitle = reciter.nameEn,
                isDhikrMode = false,
                isHifzMode = true,
                hifzRepeatIndex = 1,
                hifzTotalRepeats = repeats,
                hifzPauseGapSeconds = gap,
                isHifzGapPause = false,
                currentAyahNumber = safeStart,
                totalAyahs = meta.ayahCount,
                reciter = reciter,
                isBuffering = true,
                errorMessage = null
            )
        }
        startMediaItems(items, 0)
    }

    /**
     * Plays 100% real human Arabic recitation via Media3 ExoPlayer (never synthetic/AI TTS).
     * Uses Quranic reciter MP3s for Quranic Adhkar/Duas or resolved Hisn al-Muslim human MP3s.
     */
    fun playHumanDhikrOrDua(
        trackId: String,
        title: String,
        subtitle: String,
        quranRef: QuranAudioRef?,
        hisnChapterId: Int?,
        arabicText: String,
        reciter: QuranReciter
    ) {
        if (_state.value.activeTrackId == trackId && _state.value.isPlaying) {
            togglePlayPause()
            return
        }

        _state.update {
            it.copy(
                activeSurahNumber = -1,
                activeTrackId = trackId,
                activeTitle = title,
                activeSubtitle = subtitle,
                isDhikrMode = true,
                currentAyahNumber = 1,
                totalAyahs = 1,
                reciter = reciter,
                isBuffering = true,
                errorMessage = null
            )
        }

        scope.launch {
            if (quranRef != null) {
                val items = (quranRef.startAyah..quranRef.endAyah).map { ayah ->
                    val globalNum = SurahCatalog.globalAyahNumber(quranRef.surahNumber, ayah)
                    val url = reciter.audioUrlForGlobalAyah(globalNum)
                    MediaItem.Builder()
                        .setUri(Uri.parse(url))
                        .setMediaId("dhikr_${trackId}_$globalNum")
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(title)
                                .setArtist(reciter.nameEn)
                                .build()
                        )
                        .build()
                }
                _state.update { it.copy(totalAyahs = items.size) }
                startMediaItems(items, 0)
            } else if (hisnChapterId != null) {
                val url = resolveHisnHumanAudioUrl(hisnChapterId, arabicText)
                if (url != null) {
                    val item = MediaItem.Builder()
                        .setUri(Uri.parse(url))
                        .setMediaId("hisn_${trackId}")
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(title)
                                .setArtist("Hisn al-Muslim Human Reciter")
                                .build()
                        )
                        .build()
                    startMediaItems(listOf(item), 0)
                } else {
                    fallbackToRealisticArabicVoice(trackId, arabicText)
                }
            } else {
                fallbackToRealisticArabicVoice(trackId, arabicText)
            }
        }
    }

    private fun fallbackToRealisticArabicVoice(trackId: String, arabicText: String) {
        if (speechPlayer != null && arabicText.isNotBlank()) {
            _state.update {
                it.copy(
                    isBuffering = false,
                    isPlaying = false,
                    errorMessage = null
                )
            }
            speechPlayer.toggleSpeakArabic(itemId = "dua_$trackId", arabicText = arabicText)
        } else {
            _state.update {
                it.copy(
                    isBuffering = false,
                    isPlaying = false,
                    errorMessage = "Audio unavailable offline."
                )
            }
        }
    }

    private suspend fun resolveHisnHumanAudioUrl(chapterId: Int, arabicHint: String): String? = withContext(Dispatchers.IO) {
        try {
            val cacheFile = File(hisnCacheDir, "chapter_$chapterId.json")
            val body = if (cacheFile.exists() && cacheFile.length() > 50) {
                cacheFile.readText()
            } else {
                val req = Request.Builder()
                    .url("https://www.hisnmuslim.com/api/ar/$chapterId.json")
                    .header("User-Agent", "RuhZena/1.0 (Android)")
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext null
                    val str = resp.body?.string().orEmpty()
                    if (str.isNotBlank()) cacheFile.writeText(str)
                    str
                }
            }

            val rootObj = json.parseToJsonElement(body).jsonObject
            val array = rootObj.values.firstOrNull()?.jsonArray ?: return@withContext null
            val cleanHint = normalizeArabicForMatch(arabicHint).take(18)

            var fallbackUrl: String? = null
            for (elem in array) {
                val obj = elem.jsonObject
                val audio = obj["AUDIO"]?.jsonPrimitive?.content?.trim().orEmpty()
                if (audio.isNotBlank() && fallbackUrl == null) {
                    fallbackUrl = normalizeHisnAudioUrl(audio)
                }
                val text = normalizeArabicForMatch(obj["ARABIC_TEXT"]?.jsonPrimitive?.content.orEmpty())
                if (cleanHint.isNotBlank() && text.contains(cleanHint)) {
                    if (audio.isNotBlank()) return@withContext normalizeHisnAudioUrl(audio)
                }
            }
            fallbackUrl
        } catch (_: Exception) {
            null
        }
    }

    private fun normalizeHisnAudioUrl(raw: String): String = when {
        raw.startsWith("http://") -> raw.replaceFirst("http://", "https://")
        raw.startsWith("https://") -> raw
        raw.startsWith("/") -> "https://www.hisnmuslim.com$raw"
        else -> "https://www.hisnmuslim.com/$raw"
    }

    private fun normalizeArabicForMatch(input: String): String =
        input.replace(Regex("[\\u064B-\\u065F\\u0670\\s.,۝۞ۖۗۘۙۚۛۜ]"), "")

    private fun startMediaItems(items: List<MediaItem>, startIdx: Int) {
        val ctrl = controller
        if (ctrl == null) {
            pendingPlayback = items to startIdx
            connect()
            return
        }
        pendingPlayback = null
        ctrl.volume = _state.value.volume
        ctrl.setMediaItems(items, startIdx, 0L)
        ctrl.prepare()
        ctrl.play()
    }

    fun switchReciter(newReciter: QuranReciter) {
        val current = _state.value
        _state.update { it.copy(reciter = newReciter) }
        if (!current.isDhikrMode && current.activeSurahNumber > 0) {
            playSurah(current.activeSurahNumber, current.currentAyahNumber, newReciter)
        }
    }

    fun togglePlayPause() {
        val ctrl = controller ?: return
        if (ctrl.isPlaying) ctrl.pause() else ctrl.play()
    }

    fun nextAyah() {
        val ctrl = controller ?: return
        if (ctrl.hasNextMediaItem()) {
            ctrl.seekToNextMediaItem()
            ctrl.play()
        }
    }

    fun previousAyah() {
        val ctrl = controller ?: return
        if (ctrl.hasPreviousMediaItem()) {
            ctrl.seekToPreviousMediaItem()
            ctrl.play()
        }
    }

    fun toggleRepeatAyah() {
        _state.update { it.copy(repeatAyah = !it.repeatAyah, repeatSurah = if (!it.repeatAyah) false else it.repeatSurah) }
        applyRepeatMode()
    }

    fun toggleRepeatSurah() {
        _state.update { it.copy(repeatSurah = !it.repeatSurah, repeatAyah = if (!it.repeatSurah) false else it.repeatAyah) }
        applyRepeatMode()
    }

    fun cyclePlaybackSpeed() {
        val nextSpeed = when (_state.value.playbackSpeed) {
            0.75f -> 1.0f
            1.0f -> 1.25f
            1.25f -> 1.5f
            1.5f -> 1.75f
            1.75f -> 2.0f
            else -> 0.75f
        }
        setPlaybackSpeed(nextSpeed)
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        _state.update { it.copy(playbackSpeed = clamped) }
        controller?.playbackParameters = PlaybackParameters(clamped)
    }

    fun jumpToAyah(ayahNumber: Int) {
        val ctrl = controller ?: return
        val s = _state.value
        if (s.isDhikrMode || s.totalAyahs <= 0) return
        val idx = (ayahNumber - 1).coerceIn(0, (ctrl.mediaItemCount - 1).coerceAtLeast(0))
        ctrl.seekToDefaultPosition(idx)
        ctrl.play()
        _state.update { it.copy(currentAyahNumber = idx + 1) }
    }

    fun setSleepTimerMinutes(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _state.update { it.copy(sleepTimerRemainingSec = 0, sleepStopAtEndOfSurah = false) }
            return
        }
        val totalSec = minutes * 60
        _state.update { it.copy(sleepTimerRemainingSec = totalSec, sleepStopAtEndOfSurah = false) }
        sleepTimerJob = scope.launch {
            var remaining = totalSec
            while (isActive && remaining > 0) {
                delay(1000L)
                remaining--
                _state.update { it.copy(sleepTimerRemainingSec = remaining) }
            }
            if (isActive) {
                controller?.pause()
                _state.update { it.copy(sleepTimerRemainingSec = 0, isPlaying = false) }
            }
        }
    }

    fun setSleepAtEndOfSurah(enabled: Boolean) {
        sleepTimerJob?.cancel()
        _state.update { it.copy(sleepTimerRemainingSec = 0, sleepStopAtEndOfSurah = enabled) }
        if (enabled) {
            _state.update { it.copy(repeatSurah = false) }
            applyRepeatMode()
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _state.update { it.copy(sleepTimerRemainingSec = 0, sleepStopAtEndOfSurah = false) }
    }

    fun seekTo(positionMs: Long) {
        val safePos = positionMs.coerceAtLeast(0L)
        controller?.seekTo(safePos)
        _state.update { it.copy(positionMs = safePos) }
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        controller?.volume = clamped
        _state.update { it.copy(volume = clamped) }
    }

    fun stopPlayback() {
        gapPauseJob?.cancel()
        sleepTimerJob?.cancel()
        hifzItemMetadata = emptyList()
        controller?.stop()
        _state.update {
            it.copy(
                isPlaying = false,
                isBuffering = false,
                activeSurahNumber = 0,
                activeTrackId = "",
                isDhikrMode = false,
                isHifzMode = false,
                isHifzGapPause = false,
                sleepTimerRemainingSec = 0,
                sleepStopAtEndOfSurah = false,
                errorMessage = null
            )
        }
        RuhZenaMediaNotificationManager.dismiss(
            context,
            RuhZenaMediaNotificationManager.AudioSource.QURAN
        )
    }

    private fun applyRepeatMode() {
        val s = _state.value
        controller?.repeatMode = when {
            s.repeatAyah -> Player.REPEAT_MODE_ONE
            s.repeatSurah -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
    }

    private fun startProgressTicker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                val ctrl = controller
                if (ctrl != null) {
                    val s = _state.value
                    val idx = ctrl.currentMediaItemIndex
                    val ayahNumber = if (s.isHifzMode && idx in hifzItemMetadata.indices) {
                        hifzItemMetadata[idx].first
                    } else {
                        (idx + 1).coerceAtLeast(1)
                    }
                    _state.update {
                        it.copy(
                            positionMs = ctrl.currentPosition.coerceAtLeast(0L),
                            durationMs = ctrl.duration.coerceAtLeast(0L),
                            currentAyahNumber = ayahNumber
                        )
                    }
                    syncGlassMediaNotification(force = false)
                }
                delay(350)
            }
        }
    }

    fun release() {
        gapPauseJob?.cancel()
        progressJob?.cancel()
        runCatching { controller?.removeListener(playerListener) }
        runCatching {
            controllerFuture?.let {
                if (it.isDone) MediaController.releaseFuture(it) else it.cancel(true)
            }
        }
        controllerFuture = null
        controller = null
    }
}
