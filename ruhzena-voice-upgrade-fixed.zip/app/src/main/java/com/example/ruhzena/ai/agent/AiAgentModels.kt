package com.example.ruhzena.ai.agent

import kotlinx.serialization.Serializable

enum class AiProviderId(val displayName: String) {
    GROQ("Groq"),
    OPENROUTER("OpenRouter"),
    CLOUDFLARE("Cloudflare Workers AI"),
    FIREBASE_GEMINI("Firebase AI Logic"),
    OFFLINE_CORPUS("Verified Offline Corpus")
}

data class ProviderPingResult(
    val providerId: AiProviderId,
    val modelId: String,
    val success: Boolean,
    val latencyMs: Long,
    val detail: String
)

enum class AiPersonality(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String
) {
    PEACE_COMPANION(
        id = "COMPANION",
        titleEn = "Peace & Life Companion",
        titleBn = "শান্তি ও জীবনসঙ্গী",
        subtitleEn = "Calm, empathetic, warm & reflective",
        subtitleBn = "শান্ত, সহানুভূতিশীল ও আন্তরিক"
    ),
    PRACTICAL_EXPERT(
        id = "EXPERT",
        titleEn = "Practical & Knowledge Expert",
        titleBn = "বাস্তবসম্মত ও জ্ঞান বিশেষজ্ঞ",
        subtitleEn = "Direct, structured, precise & analytical",
        subtitleBn = "সুনির্দিষ্ট, কাঠামোবদ্ধ ও বিশ্লেষণধর্মী"
    );

    companion object {
        fun fromId(id: String?): AiPersonality =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: PEACE_COMPANION
    }
}

enum class AiFailureKind {
    RATE_LIMIT_429,
    HIGH_DEMAND_OVERLOAD,
    SERVER_OUTAGE_5XX,
    MODEL_UNAVAILABLE,
    QUOTA_EXHAUSTED,
    TIMEOUT_OR_STALL,
    NETWORK_ERROR,
    MID_STREAM_INTERRUPT,
    AUTH_INVALID,
    EMPTY_RESPONSE,
    UNKNOWN
}

class AiProviderException(
    val kind: AiFailureKind,
    val httpCode: Int? = null,
    val retryAfterSeconds: Long? = null,
    override val message: String,
    override val cause: Throwable? = null
) : Exception(message, cause)

enum class QueryDomain {
    ISLAMIC_KNOWLEDGE,
    WELLNESS_FITNESS,
    CODING_TECHNICAL,
    MULTI_STEP_PLANNING,
    EMOTIONAL_SUPPORT,
    EVERYDAY_CHAT
}

enum class QueryComplexity {
    SIMPLE,
    STANDARD,
    COMPLEX
}

data class QueryProfile(
    val domain: QueryDomain,
    val complexity: QueryComplexity,
    val requiresVision: Boolean = false,
    val requiresStructuredJson: Boolean = false,
    val estimatedInputTokens: Int = 400
)

data class AiModelSpec(
    val provider: AiProviderId,
    val modelId: String,
    val displayName: String,
    val priorityTier: Int, // 1 = Groq, 2 = OpenRouter, 3 = Cloudflare, 4 = Firebase AI
    val contextWindowTokens: Int,
    val safePromptBudgetTokens: Int,
    val supportsVision: Boolean = false,
    val supportsStreaming: Boolean = true,
    val supportsTools: Boolean = false,
    val isHighReasoning: Boolean = false,
    val isUltraFast: Boolean = false,
    val maxOutputTokens: Int = 1400
) {
    val modelKey: String get() = "${provider.name}::$modelId"
}

data class ProviderHealthState(
    val modelKey: String,
    val provider: AiProviderId,
    val modelId: String,
    val consecutiveFailures: Int = 0,
    val cooldownUntilMillis: Long = 0L,
    val lastLatencyMs: Long = 0L,
    val firstTokenLatencyMs: Long = 0L,
    val lastErrorKind: AiFailureKind? = null,
    val lastErrorSummary: String = "",
    val totalSuccesses: Int = 0,
    val totalFailures: Int = 0,
    val sessionDisabled: Boolean = false
) {
    fun isInCooldown(nowMillis: Long): Boolean = cooldownUntilMillis > nowMillis
}

data class ChatTurn(
    val isUser: Boolean,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AgentRequestPayload(
    val systemPrompt: String,
    val messages: List<ChatTurn>,
    val maxOutputTokens: Int = 1400,
    val temperature: Double = 0.55,
    val expectJson: Boolean = false,
    val streamTimeoutMs: Long = 30_000L
)

@Serializable
data class CandidateMemoryProposal(
    val category: String,
    val content: String,
    val sourcePrompt: String = ""
)

@Serializable
data class StructuredTaskSnapshot(
    val title: String,
    val objective: String,
    val constraints: String = "",
    val completedSteps: List<String> = emptyList(),
    val remainingSteps: List<String> = emptyList(),
    val findings: List<String> = emptyList(),
    val workingNotes: String = "",
    val nextAction: String = "",
    val unresolvedQuestions: List<String> = emptyList(),
    val status: String = "ACTIVE"
)

sealed interface AgentStreamEvent {
    data class Status(val friendlyMessage: String, val isFailover: Boolean = false) : AgentStreamEvent
    data class TextProgress(val accumulatedText: String) : AgentStreamEvent
    data class Completed(
        val rawText: String,
        val mainReply: String,
        val explanation: String,
        val citedSources: List<String>,
        val topic: String,
        val actionTags: List<String>,
        val memoryProposal: CandidateMemoryProposal?,
        val usedFailover: Boolean,
        val attemptCount: Int,
        val servedByProvider: AiProviderId,
        val servedByModelId: String
    ) : AgentStreamEvent

    data class Failed(
        val friendlyMessage: String,
        val preservedUserPrompt: String,
        val allProvidersExhausted: Boolean
    ) : AgentStreamEvent
}

fun interface AgentClock {
    fun nowMillis(): Long
}

object SystemAgentClock : AgentClock {
    override fun nowMillis(): Long = System.currentTimeMillis()
}
