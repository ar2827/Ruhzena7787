package com.example.ruhzena.ui.exercises

import androidx.compose.ui.geometry.Offset

enum class BreathingCue { INHALE, EXHALE, STEADY }

enum class MuscleZone { CHEST_ARMS, CORE, LEGS_GLUTES, SPINE_BACK, FULL_BODY }

data class SkeletalPose(
    val head: Offset,
    val shoulder: Offset,
    val elbow: Offset,
    val wrist: Offset,
    val hip: Offset,
    val knee: Offset,
    val ankle: Offset,
    // Optional second limb for bilateral/split poses
    val elbow2: Offset? = null,
    val wrist2: Offset? = null,
    val knee2: Offset? = null,
    val ankle2: Offset? = null
)

data class ExercisePhaseInfo(
    val pose: SkeletalPose,
    val captionEn: String,
    val captionBn: String,
    val breathing: BreathingCue
)

data class ExerciseItem(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val categoryEn: String,
    val categoryBn: String,
    val difficulty: String, // Beginner, Intermediate, Advanced
    val activeZone: MuscleZone,
    val musclesEn: String,
    val musclesBn: String,
    val setsRepsEn: String,
    val setsRepsBn: String,
    val restSeconds: Int,
    val breathingEn: String,
    val breathingBn: String,
    val postureEn: List<String>,
    val postureBn: List<String>,
    val mistakesEn: List<String>,
    val mistakesBn: List<String>,
    val easierAltEn: String,
    val easierAltBn: String,
    val progressionEn: String,
    val progressionBn: String,
    val floorY: Float,
    val phases: List<ExercisePhaseInfo>, // 4 distinct phases (0..3)
    val equipmentRequired: String = "Bodyweight",
    val movementPattern: String = "Full Body"
)

data class WorkoutStation(
    val exerciseId: String,
    val targetReps: Int? = null,
    val durationSec: Int? = null,
    val restAfterSec: Int = 25
)

data class WorkoutProgram(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val focusAreaEn: String,
    val focusAreaBn: String,
    val level: String, // Beginner, Intermediate, Advanced
    val durationMinutes: Int,
    val estimatedKcal: Int,
    val accentTag: String,
    val stations: List<WorkoutStation>,
    val equipmentTag: String = "Bodyweight"
)

object ExerciseLibrary {
    val exercises: List<ExerciseItem> = listOf(
        ExerciseItem(
            id = "push_up",
            nameEn = "Push-Up",
            nameBn = "পুশ-আপ (বুক ডন)",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Chest (Pectorals), Triceps, Anterior Shoulders, Core",
            musclesBn = "বুক (পেক্টোরালস), ট্রাইসেপস, কাঁধ ও কোর",
            setsRepsEn = "3 sets × 10–12 reps",
            setsRepsBn = "৩ সেট × ১০–১২ বার",
            restSeconds = 45,
            breathingEn = "Inhale smoothly as you lower your chest; exhale firmly as you press back up.",
            breathingBn = "নিচে নামার সময় শ্বাস নিন এবং উপরে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hands slightly wider than shoulders, fingers spread firmly",
                "Keep a straight plank line from ears to ankles",
                "Tuck elbows ~45° back—do not flare them wide"
            ),
            postureBn = listOf(
                "হাত কাঁধের চেয়ে সামান্য প্রশস্ত রাখুন",
                "মাথা থেকে গোড়ালি পর্যন্ত শরীর এক সরলরেখায় রাখুন",
                "কনুই ৪৫ ডিগ্রি কোণে শরীরের দিকে রাখুন"
            ),
            mistakesEn = listOf("Letting hips sag toward the floor", "Flaring elbows 90° outward", "Half-reps without chest depth"),
            mistakesBn = listOf("কোমর নিচে ঝুলে যাওয়া", "কনুই ৯০ ডিগ্রিতে বাইরে ছড়ানো", "সম্পূর্ণ নিচে না নামা"),
            easierAltEn = "Incline Push-Up (hands on sturdy wall or chair) or Knee Push-Up.",
            easierAltBn = "দেয়াল বা চেয়ারে হাত রেখে ইনক্লাইন পুশ-আপ অথবা হাঁটু গেড়ে পুশ-আপ।",
            progressionEn = "Tempo Push-Up (3s lower) or Decline Push-Up with feet elevated.",
            progressionBn = "ধীর গতির টেম্পো পুশ-আপ (৩ সেকেন্ডে নামা) বা পা উঁচুতে রেখে ডিক্লাইন পুশ-আপ।",
            floorY = 0.80f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.36f),
                        shoulder = Offset(0.68f, 0.43f),
                        elbow = Offset(0.69f, 0.61f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.42f, 0.57f),
                        knee = Offset(0.27f, 0.68f),
                        ankle = Offset(0.13f, 0.80f)
                    ),
                    captionEn = "1. Starting High Plank: Wrists under shoulders, core braced.",
                    captionBn = "১. শুরুর পজিশন: কাঁধের নিচে হাত, শরীর সোজা ও কোর শক্ত।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.78f, 0.50f),
                        shoulder = Offset(0.69f, 0.56f),
                        elbow = Offset(0.62f, 0.66f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.43f, 0.65f),
                        knee = Offset(0.28f, 0.72f),
                        ankle = Offset(0.13f, 0.80f)
                    ),
                    captionEn = "2. Lowering (Eccentric): Bend elbows 45° back with control.",
                    captionBn = "২. নিচে নামা: নিয়ন্ত্রিতভাবে কনুই ৪৫° কোণে ভাঁজ করুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.80f, 0.62f),
                        shoulder = Offset(0.70f, 0.67f),
                        elbow = Offset(0.57f, 0.68f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.43f, 0.72f),
                        knee = Offset(0.28f, 0.76f),
                        ankle = Offset(0.13f, 0.80f)
                    ),
                    captionEn = "3. Bottom Hold: Chest hovers above floor, hips stay aligned.",
                    captionBn = "৩. নিচের হোল্ড: বুক মেঝের কাছাকাছি, কোমর সোজা রাখুন।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.36f),
                        shoulder = Offset(0.68f, 0.43f),
                        elbow = Offset(0.69f, 0.61f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.42f, 0.57f),
                        knee = Offset(0.27f, 0.68f),
                        ankle = Offset(0.13f, 0.80f)
                    ),
                    captionEn = "4. Press Up (Concentric): Exhale and push floor away cleanly.",
                    captionBn = "৪. উপরে ওঠা: শ্বাস ছেড়ে মেঝে ঠেলে পূর্ণ অবস্থায় ফিরুন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "incline_push_up",
            nameEn = "Incline Push-Up",
            nameBn = "ইনক্লাইন পুশ-আপ",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Lower Chest, Shoulders, Triceps, Joint-Safe Core",
            musclesBn = "বুক, কাঁধ ও ট্রাইসেপস (হাঁটু-নিরাপদ)",
            setsRepsEn = "3 sets × 10–14 reps",
            setsRepsBn = "৩ সেট × ১০–১৪ বার",
            restSeconds = 40,
            breathingEn = "Inhale while leaning chest smoothly toward bench/wall; exhale to press out.",
            breathingBn = "সামনে নামার সময় শ্বাস নিন; ধাক্কা দিয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Place palms firmly on a sturdy chair, desk edge, or bench",
                "Keep heels grounded and glutes lightly engaged",
                "Bring lower chest cleanly toward the hand edge"
            ),
            postureBn = listOf(
                "শক্ত চেয়ার, বেঞ্চ বা টেবিলের কিনারায় হাত রাখুন",
                "মাথা থেকে গোড়ালি পর্যন্ত সোজা লাইন বজায় রাখুন",
                "বুক হাতের কাছাকাছি এনে আবার ধাক্কা দিন"
            ),
            mistakesEn = listOf("Shrugging shoulders up toward ears", "Bending waist instead of elbows"),
            mistakesBn = listOf("কাঁধ কানের দিকে তুলে ফেলা", "কোমর বাঁকিয়ে ফেলা"),
            easierAltEn = "Wall Push-Up standing 2 steps from a wall.",
            easierAltBn = "দেয়ালে হাত রেখে ওয়াল পুশ-আপ।",
            progressionEn = "Lower the incline height gradually until transitioning to Floor Push-Ups.",
            progressionBn = "ধীরে ধীরে উচ্চতা কমিয়ে মেঝেতে পূর্ণ পুশ-আপে যান।",
            floorY = 0.84f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.73f, 0.25f),
                        shoulder = Offset(0.65f, 0.34f),
                        elbow = Offset(0.71f, 0.48f),
                        wrist = Offset(0.77f, 0.59f),
                        hip = Offset(0.42f, 0.57f),
                        knee = Offset(0.28f, 0.70f),
                        ankle = Offset(0.14f, 0.84f)
                    ),
                    captionEn = "1. Elevated Setup: Straight diagonal line, core tight.",
                    captionBn = "১. উঁচু সেটআপ: শরীর তির্যক ও সোজা রাখুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.34f),
                        shoulder = Offset(0.68f, 0.42f),
                        elbow = Offset(0.64f, 0.52f),
                        wrist = Offset(0.77f, 0.59f),
                        hip = Offset(0.43f, 0.61f),
                        knee = Offset(0.28f, 0.72f),
                        ankle = Offset(0.14f, 0.84f)
                    ),
                    captionEn = "2. Controlled Lower: Elbows track back at 45 degrees.",
                    captionBn = "২. নিয়ন্ত্রিত নামা: কনুই ৪৫ ডিগ্রি পেছনে ভাঁজ করুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.79f, 0.42f),
                        shoulder = Offset(0.71f, 0.50f),
                        elbow = Offset(0.60f, 0.54f),
                        wrist = Offset(0.77f, 0.59f),
                        hip = Offset(0.44f, 0.65f),
                        knee = Offset(0.29f, 0.74f),
                        ankle = Offset(0.14f, 0.84f)
                    ),
                    captionEn = "3. Chest Touch Point: Pause briefly with shoulders steady.",
                    captionBn = "৩. নিচের হোল্ড: বুক প্রান্তের কাছে এনে ১ সেকেন্ড থামুন।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.73f, 0.25f),
                        shoulder = Offset(0.65f, 0.34f),
                        elbow = Offset(0.71f, 0.48f),
                        wrist = Offset(0.77f, 0.59f),
                        hip = Offset(0.42f, 0.57f),
                        knee = Offset(0.28f, 0.70f),
                        ankle = Offset(0.14f, 0.84f)
                    ),
                    captionEn = "4. Strong Press: Exhale smoothly back to start.",
                    captionBn = "৪. পুশ ব্যাক: শ্বাস ছেড়ে শুরুর অবস্থানে ফিরুন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "bodyweight_squat",
            nameEn = "Bodyweight Squat",
            nameBn = "বডিওয়েট স্কোয়াট",
            categoryEn = "Lower Body Strength",
            categoryBn = "নিম্নাঙ্গের শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quadriceps, Glutes, Hamstrings, Lower Core",
            musclesBn = "উরু (কোয়াডস), গ্লুটস, হ্যামস্ট্রিং ও কোর",
            setsRepsEn = "3 sets × 12–15 reps",
            setsRepsBn = "৩ সেট × ১২–১৫ বার",
            restSeconds = 45,
            breathingEn = "Inhale as you sit hips back; exhale as you drive through heels to stand.",
            breathingBn = "নিচে বসার সময় শ্বাস নিন; গোড়ালিতে ভর দিয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Feet shoulder-width apart, toes slightly turned out",
                "Chest proud, spine neutral throughout",
                "Weight balanced over mid-foot and heels"
            ),
            postureBn = listOf(
                "পা কাঁধের সমান দূরত্বে রাখুন",
                "বুক সোজা ও মেরুদণ্ড স্বাভাবিক রাখুন",
                "শরীরের ভার পায়ের মাঝখান ও গোড়ালিতে রাখুন"
            ),
            mistakesEn = listOf("Heels lifting off the ground", "Knees caving inward", "Rounding the lower back"),
            mistakesBn = listOf("গোড়ালি মেঝে থেকে উঠে যাওয়া", "হাঁটু ভেতরের দিকে বেঁকে যাওয়া", "কোমর অতিরিক্ত ঝুঁকে পড়া"),
            easierAltEn = "Box / Chair Squat (lightly tap a chair seat before standing).",
            easierAltBn = "চেয়ার স্কোয়াট (চেয়ারে হালকা স্পর্শ করে আবার উঠে দাঁড়ানো)।",
            progressionEn = "Pause Squat (2s hold at bottom) or Jump Squat.",
            progressionBn = "পজ স্কোয়াট (নিচে ২ সেকেন্ড ধরে রাখা) অথবা জাম্প স্কোয়াট।",
            floorY = 0.86f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.48f, 0.14f),
                        shoulder = Offset(0.47f, 0.25f),
                        elbow = Offset(0.49f, 0.40f),
                        wrist = Offset(0.51f, 0.52f),
                        hip = Offset(0.47f, 0.50f),
                        knee = Offset(0.49f, 0.68f),
                        ankle = Offset(0.48f, 0.86f)
                    ),
                    captionEn = "1. Standing Start: Tall posture, feet planted shoulder-width.",
                    captionBn = "১. শুরুর অবস্থান: সোজা হয়ে দাঁড়ান, পা সমান দূরত্বে।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.53f, 0.24f),
                        shoulder = Offset(0.49f, 0.34f),
                        elbow = Offset(0.59f, 0.39f),
                        wrist = Offset(0.69f, 0.35f),
                        hip = Offset(0.39f, 0.56f),
                        knee = Offset(0.53f, 0.69f),
                        ankle = Offset(0.48f, 0.86f)
                    ),
                    captionEn = "2. Descent: Push hips backward as arms counterbalance forward.",
                    captionBn = "২. নিচে নামা: নিতম্ব পেছনে নিন এবং ভারসাম্যের জন্য হাত সামনে বাড়ান।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.56f, 0.35f),
                        shoulder = Offset(0.51f, 0.45f),
                        elbow = Offset(0.62f, 0.46f),
                        wrist = Offset(0.73f, 0.42f),
                        hip = Offset(0.36f, 0.65f),
                        knee = Offset(0.57f, 0.67f),
                        ankle = Offset(0.48f, 0.86f)
                    ),
                    captionEn = "3. Depth Target: Thighs near parallel, heels firmly down.",
                    captionBn = "৩. নিচের অবস্থান: উরু মেঝের সমান্তরাল, গোড়ালি মাটিতে স্থির।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.48f, 0.14f),
                        shoulder = Offset(0.47f, 0.25f),
                        elbow = Offset(0.49f, 0.40f),
                        wrist = Offset(0.51f, 0.52f),
                        hip = Offset(0.47f, 0.50f),
                        knee = Offset(0.49f, 0.68f),
                        ankle = Offset(0.48f, 0.86f)
                    ),
                    captionEn = "4. Drive Up: Exhale and extend hips & knees smoothly.",
                    captionBn = "৪. উঠে দাঁড়ানো: শ্বাস ছেড়ে নিতম্ব ও হাঁটু সোজা করে উঠে আসুন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "reverse_lunge",
            nameEn = "Reverse Lunge",
            nameBn = "রিভার্স লাঞ্জ",
            categoryEn = "Lower Body Strength",
            categoryBn = "ভারসাম্য ও পায়ের শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quads, Glutes, Hamstrings, Hip Stabilizers",
            musclesBn = "উরু, গ্লুটস ও হিপের ভারসাম্য পেশী",
            setsRepsEn = "3 sets × 10 reps / side",
            setsRepsBn = "৩ সেট × ১০ বার (প্রতি পা)",
            restSeconds = 45,
            breathingEn = "Inhale while stepping back and lowering; exhale as you press up via front heel.",
            breathingBn = "পেছনে পা ফেলে নামার সময় শ্বাস নিন; সামনের পায়ে ভর দিয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Keep torso tall and core lightly braced",
                "Front shin stays nearly vertical—knee tracks over toes",
                "Lower back knee gently toward floor without slamming"
            ),
            postureBn = listOf(
                "শরীরের উপরের অংশ সোজা রাখুন",
                "সামনের হাঁটু গোড়ালির ওপর সোজা রাখুন",
                "পেছনের হাঁটু মেঝেতে আঘাত না করে ধীরে নামান"
            ),
            mistakesEn = listOf("Tightrope stance (feet directly in one line)", "Leaning chest far forward"),
            mistakesBn = listOf("দুই পা এক সরলরেখায় রেখে ভারসাম্য হারানো", "বুক অতিরিক্ত সামনে ঝুঁকানো"),
            easierAltEn = "Supported Split Squat holding a chair or wall lightly.",
            easierAltBn = "দেয়াল বা চেয়ার ধরে সাপোর্টেড স্প্লিট স্কোয়াট।",
            progressionEn = "Reverse Lunge to High Knee Drive or Tempo Lunge.",
            progressionBn = "রিভার্স লাঞ্জ থেকে হাঁটু উপরে তোলা (হাই-নি ড্রাইভ)।",
            floorY = 0.86f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.50f, 0.14f),
                        shoulder = Offset(0.50f, 0.25f),
                        elbow = Offset(0.49f, 0.40f),
                        wrist = Offset(0.50f, 0.52f),
                        hip = Offset(0.50f, 0.50f),
                        knee = Offset(0.51f, 0.68f),
                        ankle = Offset(0.50f, 0.86f),
                        knee2 = Offset(0.49f, 0.68f),
                        ankle2 = Offset(0.48f, 0.86f)
                    ),
                    captionEn = "1. Tall Start: Feet hip-width apart for lateral stability.",
                    captionBn = "১. শুরুর অবস্থান: কোমরের সমান দূরত্বে পা রেখে সোজা দাঁড়ান।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.53f, 0.19f),
                        shoulder = Offset(0.52f, 0.30f),
                        elbow = Offset(0.49f, 0.44f),
                        wrist = Offset(0.54f, 0.51f),
                        hip = Offset(0.50f, 0.53f),
                        knee = Offset(0.61f, 0.68f),
                        ankle = Offset(0.62f, 0.86f),
                        knee2 = Offset(0.39f, 0.70f),
                        ankle2 = Offset(0.31f, 0.84f)
                    ),
                    captionEn = "2. Step Back: Reach one foot backward softly onto ball of foot.",
                    captionBn = "২. পেছনে পা ফেলা: এক পা নিয়ন্ত্রিতভাবে পেছনে নিন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.53f, 0.28f),
                        shoulder = Offset(0.52f, 0.39f),
                        elbow = Offset(0.49f, 0.52f),
                        wrist = Offset(0.56f, 0.54f),
                        hip = Offset(0.49f, 0.61f),
                        knee = Offset(0.64f, 0.64f),
                        ankle = Offset(0.63f, 0.86f),
                        knee2 = Offset(0.40f, 0.78f),
                        ankle2 = Offset(0.28f, 0.84f)
                    ),
                    captionEn = "3. 90/90 Split Bottom: Both knees bent ~90°, upright torso.",
                    captionBn = "৩. নিচের হোল্ড: উভয় হাঁটু প্রায় ৯০° ভাঁজ, বুক সোজা।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.50f, 0.14f),
                        shoulder = Offset(0.50f, 0.25f),
                        elbow = Offset(0.49f, 0.40f),
                        wrist = Offset(0.50f, 0.52f),
                        hip = Offset(0.50f, 0.50f),
                        knee = Offset(0.51f, 0.68f),
                        ankle = Offset(0.50f, 0.86f),
                        knee2 = Offset(0.49f, 0.68f),
                        ankle2 = Offset(0.48f, 0.86f)
                    ),
                    captionEn = "4. Drive Through Front Heel: Return upright cleanly.",
                    captionBn = "৪. ফিরে আসা: সামনের গোড়ালিতে ভর দিয়ে আবার সোজা হোন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "glute_bridge",
            nameEn = "Glute Bridge",
            nameBn = "গ্লুট ব্রিজ",
            categoryEn = "Lower Body Strength",
            categoryBn = "কোমর ও হিপ শক্তিবর্ধক",
            difficulty = "Beginner",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Glutes, Hamstrings, Lower Back Stabilizers",
            musclesBn = "গ্লুটস, হ্যামস্ট্রিং ও কোমরের সহায়ক পেশী",
            setsRepsEn = "3 sets × 12–15 reps",
            setsRepsBn = "৩ সেট × ১২–১৫ বার",
            restSeconds = 40,
            breathingEn = "Exhale as you lift hips toward the ceiling; inhale while lowering smoothly.",
            breathingBn = "কোমর উপরে তোলার সময় শ্বাস ছাড়ুন এবং নামানোর সময় শ্বাস নিন।",
            postureEn = listOf(
                "Feet flat hip-width apart near glutes",
                "Press through heels without over-arching the lower back",
                "Pause 1 second at the top straight-line position"
            ),
            postureBn = listOf(
                "হাঁটু ভাঁজ করে পায়ের পাতা মেঝেতে সমানভাবে রাখুন",
                "গোড়ালিতে চাপ দিয়ে কোমর তুলুন, পিঠ অতিরিক্ত বাঁকাবেন না",
                "উপরে উঠে ১ সেকেন্ড স্থির থাকুন"
            ),
            mistakesEn = listOf("Hyperextending the lower spine at top", "Pushing through toes instead of heels"),
            mistakesBn = listOf("কোমর প্রয়োজনের চেয়ে বেশি উঁচুতে বাঁকানো", "গোড়ালির বদলে পায়ের আঙুলে ভর দেওয়া"),
            easierAltEn = "Smaller range of motion with 2-second hold.",
            easierAltBn = "কম উচ্চতায় তুলে ২ সেকেন্ড ধরে রাখা।",
            progressionEn = "Single-Leg Glute Bridge or March Bridge.",
            progressionBn = "এক পা উঁচু করে সিঙ্গেল-লেগ গ্লুট ব্রিজ।",
            floorY = 0.80f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.17f, 0.73f),
                        shoulder = Offset(0.28f, 0.76f),
                        elbow = Offset(0.37f, 0.78f),
                        wrist = Offset(0.47f, 0.79f),
                        hip = Offset(0.51f, 0.78f),
                        knee = Offset(0.65f, 0.57f),
                        ankle = Offset(0.75f, 0.80f)
                    ),
                    captionEn = "1. Supine Start: Back flat, knees bent, heels grounded.",
                    captionBn = "১. শুরুর অবস্থান: চিত হয়ে শুয়ে হাঁটু ভাঁজ ও গোড়ালি মেঝেতে।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.17f, 0.73f),
                        shoulder = Offset(0.28f, 0.76f),
                        elbow = Offset(0.37f, 0.78f),
                        wrist = Offset(0.47f, 0.79f),
                        hip = Offset(0.49f, 0.65f),
                        knee = Offset(0.65f, 0.56f),
                        ankle = Offset(0.75f, 0.80f)
                    ),
                    captionEn = "2. Drive Hips: Exhale and press heels into floor.",
                    captionBn = "২. উপরে ওঠা: শ্বাস ছেড়ে গোড়ালির সাহায্যে কোমর তুলুন।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.17f, 0.73f),
                        shoulder = Offset(0.28f, 0.76f),
                        elbow = Offset(0.37f, 0.78f),
                        wrist = Offset(0.47f, 0.79f),
                        hip = Offset(0.47f, 0.56f),
                        knee = Offset(0.65f, 0.54f),
                        ankle = Offset(0.75f, 0.80f)
                    ),
                    captionEn = "3. Bridge Peak: Straight line from shoulders to knees.",
                    captionBn = "৩. শীর্ষ অবস্থান: কাঁধ থেকে হাঁটু পর্যন্ত এক সরলরেখা।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.17f, 0.73f),
                        shoulder = Offset(0.28f, 0.76f),
                        elbow = Offset(0.37f, 0.78f),
                        wrist = Offset(0.47f, 0.79f),
                        hip = Offset(0.51f, 0.78f),
                        knee = Offset(0.65f, 0.57f),
                        ankle = Offset(0.75f, 0.80f)
                    ),
                    captionEn = "4. Controlled Lower: Inhale as spine returns vertebra by vertebra.",
                    captionBn = "৪. নিচে নামা: শ্বাস নিয়ে ধীরে ধীরে পিঠ মেঝেতে নামান।",
                    breathing = BreathingCue.INHALE
                )
            )
        ),
        ExerciseItem(
            id = "forearm_plank",
            nameEn = "Forearm Plank",
            nameBn = "ফোরআর্ম প্ল্যাঙ্ক",
            categoryEn = "Core Stability",
            categoryBn = "কোর স্থিতিশীলতা",
            difficulty = "Beginner",
            activeZone = MuscleZone.CORE,
            musclesEn = "Transverse Abdominis, Obliques, Lower Back, Shoulders",
            musclesBn = "পেটের গভীর পেশী, কোমর ও কাঁধ",
            setsRepsEn = "3 sets × 30–45s hold",
            setsRepsBn = "৩ সেট × ৩০–৪৫ সেকেন্ড",
            restSeconds = 40,
            breathingEn = "Breathe steadily through your nose and mouth—never hold your breath.",
            breathingBn = "শ্বাস আটকে রাখবেন না; ধীরে ও স্বাভাবিকভাবে শ্বাস-প্রশ্বাস চালিয়ে যান।",
            postureEn = listOf(
                "Elbows directly beneath shoulders",
                "Squeeze glutes and gently tuck pelvis to protect lower back",
                "Gaze down at your hands to keep neck neutral"
            ),
            postureBn = listOf(
                "কনুই ঠিক কাঁধের নিচে রাখুন",
                "পেট ও গ্লুটস হালকা টানটান রাখুন যাতে কোমর না ঝোলে",
                "ঘাড় সোজা রাখতে হাতের মাঝখানে তাকান"
            ),
            mistakesEn = listOf("Arching lower back downward", "Piking hips high in the air", "Holding breath"),
            mistakesBn = listOf("কোমর নিচে বেঁকে যাওয়া", "নিতম্ব খুব উঁচুতে তুলে ফেলা", "শ্বাস বন্ধ করে রাখা"),
            easierAltEn = "Knee Forearm Plank or Elevated Plank on a sturdy bench.",
            easierAltBn = "হাঁটু মেঝেতে রেখে প্ল্যাঙ্ক অথবা উঁচু টেবিলে হাত রেখে প্ল্যাঙ্ক।",
            progressionEn = "Plank Shoulder Taps or Single-Leg Lift Plank.",
            progressionBn = "প্ল্যাঙ্ক শোল্ডার ট্যাপস অথবা এক পা তুলে প্ল্যাঙ্ক।",
            floorY = 0.78f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.79f, 0.49f),
                        shoulder = Offset(0.70f, 0.56f),
                        elbow = Offset(0.69f, 0.77f),
                        wrist = Offset(0.81f, 0.77f),
                        hip = Offset(0.43f, 0.62f),
                        knee = Offset(0.28f, 0.70f),
                        ankle = Offset(0.14f, 0.78f)
                    ),
                    captionEn = "1. Setup: Forearms parallel, elbows stacked under shoulders.",
                    captionBn = "১. সেটআপ: কনুই কাঁধের নিচে এবং বাহু মেঝেতে সমান্তরাল।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.79f, 0.48f),
                        shoulder = Offset(0.70f, 0.55f),
                        elbow = Offset(0.69f, 0.77f),
                        wrist = Offset(0.81f, 0.77f),
                        hip = Offset(0.43f, 0.60f),
                        knee = Offset(0.28f, 0.69f),
                        ankle = Offset(0.14f, 0.78f)
                    ),
                    captionEn = "2. Brace Core: Gentle abdominal tension, straight spinal line.",
                    captionBn = "২. কোর সক্রিয়: পেটের পেশী টানটান ও মেরুদণ্ড সোজা।",
                    breathing = BreathingCue.STEADY
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.79f, 0.49f),
                        shoulder = Offset(0.70f, 0.56f),
                        elbow = Offset(0.69f, 0.77f),
                        wrist = Offset(0.81f, 0.77f),
                        hip = Offset(0.43f, 0.61f),
                        knee = Offset(0.28f, 0.70f),
                        ankle = Offset(0.14f, 0.78f)
                    ),
                    captionEn = "3. Isometric Hold: Steady nasal inhale & calm exhale.",
                    captionBn = "৩. হোল্ড: স্থির অবস্থায় শান্তভাবে শ্বাস নিতে ও ছাড়তে থাকুন।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.79f, 0.49f),
                        shoulder = Offset(0.70f, 0.56f),
                        elbow = Offset(0.69f, 0.77f),
                        wrist = Offset(0.81f, 0.77f),
                        hip = Offset(0.43f, 0.62f),
                        knee = Offset(0.28f, 0.70f),
                        ankle = Offset(0.14f, 0.78f)
                    ),
                    captionEn = "4. Maintain Alignment: Keep shoulders pressed away from ears.",
                    captionBn = "৪. অবস্থান বজায় রাখা: কাঁধ শক্ত ও শরীরের সরলরেখা ধরে রাখুন।",
                    breathing = BreathingCue.STEADY
                )
            )
        ),
        ExerciseItem(
            id = "jumping_jack",
            nameEn = "Jumping Jack",
            nameBn = "জাম্পিং জ্যাক (কার্ডিও)",
            categoryEn = "Cardio & Warm-Up",
            categoryBn = "কার্ডিও ও ওয়ার্ম-আপ",
            difficulty = "Beginner",
            activeZone = MuscleZone.FULL_BODY,
            musclesEn = "Calves, Shoulders, Hip Abductors, Cardiovascular System",
            musclesBn = "পায়ের পেশী, কাঁধ ও হৃদযন্ত্রের সক্ষমতা",
            setsRepsEn = "3 sets × 30–45s",
            setsRepsBn = "৩ সেট × ৩০–৪৫ সেকেন্ড",
            restSeconds = 30,
            breathingEn = "Inhale as arms sweep overhead; exhale rhythmically as you return.",
            breathingBn = "হাত উপরে তোলার সময় শ্বাস নিন; নিচে নামানোর সময় ছন্দময়ভাবে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Land softly on the balls of your feet with slight knee bend",
                "Sweep arms smoothly in full arc overhead",
                "Keep rhythm controlled and upright"
            ),
            postureBn = listOf(
                "পায়ের সামনের অংশে হালকাভাবে নামুন",
                "হাত সম্পূর্ণ মাথার ওপর তুলে আবার নিচে নামান",
                "ছন্দ ও শরীরের সোজা ভঙ্গি বজায় রাখুন"
            ),
            mistakesEn = listOf("Locking knees on landing", "Slapping heels hard onto the floor"),
            mistakesBn = listOf("হাঁটু শক্ত করে নামা", "গোড়ালিতে জোরে আঘাত লাগা"),
            easierAltEn = "Low-Impact Step Jacks (step one foot out at a time without jumping).",
            easierAltBn = "লো-ইমপ্যাক্ট স্টেপ জ্যাক (লাফ ছাড়া এক পা এক পা করে পাশে নেওয়া)।",
            progressionEn = "Power Jacks or Star Jumps.",
            progressionBn = "পাওয়ার জ্যাক বা দ্রুত টেম্পো জ্যাক।",
            floorY = 0.86f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.50f, 0.16f),
                        shoulder = Offset(0.50f, 0.27f),
                        elbow = Offset(0.42f, 0.40f),
                        wrist = Offset(0.41f, 0.53f),
                        hip = Offset(0.50f, 0.51f),
                        knee = Offset(0.46f, 0.69f),
                        ankle = Offset(0.46f, 0.86f),
                        elbow2 = Offset(0.58f, 0.40f),
                        wrist2 = Offset(0.59f, 0.53f),
                        knee2 = Offset(0.54f, 0.69f),
                        ankle2 = Offset(0.54f, 0.86f)
                    ),
                    captionEn = "1. Narrow Start: Feet together, arms relaxed at sides.",
                    captionBn = "১. শুরুর অবস্থান: পা একত্রে, হাত দুই পাশে।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.50f, 0.13f),
                        shoulder = Offset(0.50f, 0.24f),
                        elbow = Offset(0.36f, 0.26f),
                        wrist = Offset(0.28f, 0.21f),
                        hip = Offset(0.50f, 0.48f),
                        knee = Offset(0.40f, 0.66f),
                        ankle = Offset(0.34f, 0.82f),
                        elbow2 = Offset(0.64f, 0.26f),
                        wrist2 = Offset(0.72f, 0.21f),
                        knee2 = Offset(0.60f, 0.66f),
                        ankle2 = Offset(0.66f, 0.82f)
                    ),
                    captionEn = "2. Outward Open: Hop feet wide while raising arms.",
                    captionBn = "২. প্রসারণ: লাফ দিয়ে পা প্রশস্ত করুন ও হাত উপরে তুলুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.50f, 0.16f),
                        shoulder = Offset(0.50f, 0.27f),
                        elbow = Offset(0.40f, 0.18f),
                        wrist = Offset(0.45f, 0.08f),
                        hip = Offset(0.50f, 0.51f),
                        knee = Offset(0.39f, 0.69f),
                        ankle = Offset(0.32f, 0.86f),
                        elbow2 = Offset(0.60f, 0.18f),
                        wrist2 = Offset(0.55f, 0.08f),
                        knee2 = Offset(0.61f, 0.69f),
                        ankle2 = Offset(0.68f, 0.86f)
                    ),
                    captionEn = "3. Wide Peak: Soft knees, hands meet lightly overhead.",
                    captionBn = "৩. শীর্ষ অবস্থান: হাত মাথার ওপর, হাঁটু সামান্য নমনীয়।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.50f, 0.16f),
                        shoulder = Offset(0.50f, 0.27f),
                        elbow = Offset(0.42f, 0.40f),
                        wrist = Offset(0.41f, 0.53f),
                        hip = Offset(0.50f, 0.51f),
                        knee = Offset(0.46f, 0.69f),
                        ankle = Offset(0.46f, 0.86f),
                        elbow2 = Offset(0.58f, 0.40f),
                        wrist2 = Offset(0.59f, 0.53f),
                        knee2 = Offset(0.54f, 0.69f),
                        ankle2 = Offset(0.54f, 0.86f)
                    ),
                    captionEn = "4. Return Rhythm: Exhale softly back to center.",
                    captionBn = "৪. কেন্দ্রে ফেরা: শ্বাস ছেড়ে ছন্দের সাথে শুরুর অবস্থানে ফিরুন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "mountain_climbers",
            nameEn = "Mountain Climbers",
            nameBn = "মাউন্টেন ক্লাইম্বার্স",
            categoryEn = "Cardio & Warm-Up",
            categoryBn = "কার্ডিও ও কোর কন্ডিশনিং",
            difficulty = "Intermediate",
            activeZone = MuscleZone.FULL_BODY,
            musclesEn = "Core, Hip Flexors, Shoulders, Cardiovascular Endurance",
            musclesBn = "পেট, হিপ ফ্লেক্সর, কাঁধ ও হৃদযন্ত্রের সক্ষমতা",
            setsRepsEn = "3 sets × 30s alternating",
            setsRepsBn = "৩ সেট × ৩০ সেকেন্ড",
            restSeconds = 35,
            breathingEn = "Keep rhythmic quick breaths—exhale lightly on every second knee drive.",
            breathingBn = "শ্বাস আটকে না রেখে ছন্দময় দ্রুত শ্বাস-প্রশ্বাস চালিয়ে যান।",
            postureEn = listOf(
                "Stack shoulders directly over wrists in high plank",
                "Drive one knee cleanly toward chest without bouncing hips",
                "Keep neck elongated and gaze slightly ahead of fingertips"
            ),
            postureBn = listOf(
                "হাই প্ল্যাঙ্ক অবস্থানে কাঁধ হাতের কব্জির ওপর রাখুন",
                "কোমর বেশি না দুলিয়ে পর্যায়ক্রমে হাঁটু বুকের দিকে আনুন",
                "ঘাড় ও মেরুদণ্ড সোজা রাখুন"
            ),
            mistakesEn = listOf("Hips bouncing high upward", "Drifting shoulders backward behind hands"),
            mistakesBn = listOf("কোমর অতিরিক্ত উঁচুতে তোলা", "কাঁধ হাতের পেছনে সরে যাওয়া"),
            easierAltEn = "Slow Elevated Mountain Climbers with hands on a sturdy chair or bench.",
            easierAltBn = "চেয়ার বা বেঞ্চে হাত রেখে ধীর গতির মাউন্টেন ক্লাইম্বার।",
            progressionEn = "Cross-Body Mountain Climbers aiming knee toward opposite elbow.",
            progressionBn = "বিপরীত কনুইয়ের দিকে হাঁটু নিয়ে ক্রস-বডি ক্লাইম্বার।",
            floorY = 0.80f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.36f),
                        shoulder = Offset(0.68f, 0.43f),
                        elbow = Offset(0.69f, 0.61f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.41f, 0.56f),
                        knee = Offset(0.27f, 0.68f),
                        ankle = Offset(0.13f, 0.80f),
                        knee2 = Offset(0.28f, 0.69f),
                        ankle2 = Offset(0.15f, 0.80f)
                    ),
                    captionEn = "1. High Plank Base: Core tight, hands locked under shoulders.",
                    captionBn = "১. হাই প্ল্যাঙ্ক: কোর শক্ত, হাত কাঁধের ঠিক নিচে।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.37f),
                        shoulder = Offset(0.68f, 0.44f),
                        elbow = Offset(0.69f, 0.61f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.41f, 0.55f),
                        knee = Offset(0.57f, 0.65f),
                        ankle = Offset(0.49f, 0.78f),
                        knee2 = Offset(0.26f, 0.68f),
                        ankle2 = Offset(0.12f, 0.80f)
                    ),
                    captionEn = "2. Right Knee Drive: Pull knee smoothly toward chest.",
                    captionBn = "২. ডান হাঁটু ড্রাইভ: ডান হাঁটু বুকের কাছে টেনে আনুন।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.36f),
                        shoulder = Offset(0.68f, 0.43f),
                        elbow = Offset(0.69f, 0.61f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.41f, 0.56f),
                        knee = Offset(0.32f, 0.68f),
                        ankle = Offset(0.18f, 0.80f),
                        knee2 = Offset(0.38f, 0.67f),
                        ankle2 = Offset(0.25f, 0.79f)
                    ),
                    captionEn = "3. Crisp Switch: Swap legs swiftly while keeping hips level.",
                    captionBn = "৩. দ্রুত পরিবর্তন: কোমর স্থির রেখে পা অদলবদল করুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.37f),
                        shoulder = Offset(0.68f, 0.44f),
                        elbow = Offset(0.69f, 0.61f),
                        wrist = Offset(0.70f, 0.80f),
                        hip = Offset(0.41f, 0.55f),
                        knee = Offset(0.26f, 0.68f),
                        ankle = Offset(0.12f, 0.80f),
                        knee2 = Offset(0.57f, 0.65f),
                        ankle2 = Offset(0.49f, 0.78f)
                    ),
                    captionEn = "4. Left Knee Drive: Maintain rhythm without sagging back.",
                    captionBn = "৪. বাম হাঁটু ড্রাইভ: ছন্দ ধরে বাম হাঁটু সামনে আনুন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "bicycle_crunch",
            nameEn = "Bicycle Crunch",
            nameBn = "বাইসাইকেল ক্রাঞ্চ",
            categoryEn = "Core Stability",
            categoryBn = "কোর ও অ্যাবস",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CORE,
            musclesEn = "Rectus Abdominis, Obliques, Deep Core",
            musclesBn = "অ্যাবস ও পেটের পাশের পেশী (অবলিকস)",
            setsRepsEn = "3 sets × 14–16 alternating",
            setsRepsBn = "৩ সেট × ১৪–১৬ বার",
            restSeconds = 35,
            breathingEn = "Exhale gently on each rotational twist toward the raised knee.",
            breathingBn = "হাঁটুর দিকে শরীর ঘোরানোর সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Press lower back softly into the floor",
                "Fingertips light behind ears—never yank your neck",
                "Rotate chest toward knee rather than pulling elbow"
            ),
            postureBn = listOf(
                "কোমর মেঝের সাথে হালকাভাবে চেপে রাখুন",
                "কানের পাশে আঙুল আলতোভাবে রাখুন, ঘাড়ে টান দেবেন না",
                "কনুইয়ের বদলে বুক ঘুরিয়ে হাঁটুর দিকে নিন"
            ),
            mistakesEn = listOf("Pulling head forward with hands", "Rushing legs like pedaling recklessly"),
            mistakesBn = listOf("হাত দিয়ে মাথা সামনে টানা", "নিয়ন্ত্রণ ছাড়া দ্রুত পা ছোঁড়া"),
            easierAltEn = "Bent-Knee Dead Bug alternating heel taps.",
            easierAltBn = "ডেড বাগ (হাঁটু ভাঁজ রেখে পা মেঝেতে আলতো স্পর্শ)।",
            progressionEn = "Slow 2-second pause on each oblique twist.",
            progressionBn = "প্রতিটি টুইস্টে ২ সেকেন্ড হোল্ড করুন।",
            floorY = 0.82f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.18f, 0.62f),
                        shoulder = Offset(0.28f, 0.69f),
                        elbow = Offset(0.22f, 0.56f),
                        wrist = Offset(0.18f, 0.58f),
                        hip = Offset(0.50f, 0.77f),
                        knee = Offset(0.58f, 0.57f),
                        ankle = Offset(0.68f, 0.57f),
                        knee2 = Offset(0.64f, 0.64f),
                        ankle2 = Offset(0.79f, 0.66f)
                    ),
                    captionEn = "1. Hollow Crunch Start: Shoulders lifted gently, knees tabletop.",
                    captionBn = "১. শুরুর অবস্থান: কাঁধ সামান্য ওপরে ও হাঁটু ভাঁজ।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.22f, 0.56f),
                        shoulder = Offset(0.32f, 0.62f),
                        elbow = Offset(0.41f, 0.54f),
                        wrist = Offset(0.24f, 0.52f),
                        hip = Offset(0.50f, 0.77f),
                        knee = Offset(0.46f, 0.55f),
                        ankle = Offset(0.54f, 0.61f),
                        knee2 = Offset(0.69f, 0.71f),
                        ankle2 = Offset(0.86f, 0.68f)
                    ),
                    captionEn = "2. Twist Right: Rotate torso toward tucked knee while extending other leg.",
                    captionBn = "২. ডান টুইস্ট: এক পা সোজা করে বিপরীত হাঁটু ও কাঁধ কাছে আনুন।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.18f, 0.62f),
                        shoulder = Offset(0.28f, 0.69f),
                        elbow = Offset(0.22f, 0.56f),
                        wrist = Offset(0.18f, 0.58f),
                        hip = Offset(0.50f, 0.77f),
                        knee = Offset(0.62f, 0.58f),
                        ankle = Offset(0.75f, 0.58f),
                        knee2 = Offset(0.58f, 0.58f),
                        ankle2 = Offset(0.70f, 0.60f)
                    ),
                    captionEn = "3. Center Pass: Reset breath briefly through middle.",
                    captionBn = "৩. মধ্য অবস্থান: শ্বাস নিয়ে অপর পাশের জন্য প্রস্তুত হোন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.22f, 0.56f),
                        shoulder = Offset(0.32f, 0.62f),
                        elbow = Offset(0.41f, 0.54f),
                        wrist = Offset(0.24f, 0.52f),
                        hip = Offset(0.50f, 0.77f),
                        knee = Offset(0.69f, 0.71f),
                        ankle = Offset(0.86f, 0.68f),
                        knee2 = Offset(0.46f, 0.55f),
                        ankle2 = Offset(0.54f, 0.61f)
                    ),
                    captionEn = "4. Twist Left: Exhale cleanly and control extended leg.",
                    captionBn = "৪. বাম টুইস্ট: শ্বাস ছেড়ে নিয়ন্ত্রিতভাবে বাম দিকে ঘোরান।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "superman_hold",
            nameEn = "Superman Back Hold",
            nameBn = "সুপারম্যান ব্যাক হোল্ড",
            categoryEn = "Mobility & Recovery",
            categoryBn = "পিঠ ও ভঙ্গির শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Spinal Erectors, Upper Back, Glutes, Rear Shoulders",
            musclesBn = "মেরুদণ্ডের পেশী, উপরের পিঠ ও গ্লুটস",
            setsRepsEn = "3 sets × 10 lifts (2s hold)",
            setsRepsBn = "৩ সেট × ১০ বার (২ সেকেন্ড হোল্ড)",
            restSeconds = 35,
            breathingEn = "Inhale gently as chest and thighs hover off mat; exhale as you relax down.",
            breathingBn = "বুক ও পা হালকা তোলার সময় শ্বাস নিন; নামানোর সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Lie prone on mat with gaze directed straight downward",
                "Lift chest and thighs smoothly—only 2–4 inches is plenty",
                "Squeeze glutes gently to protect lower lumbar spine"
            ),
            postureBn = listOf(
                "উপুড় হয়ে শুয়ে দৃষ্টি নিচের দিকে রাখুন",
                "বুক ও পা মাত্র ২-৪ ইঞ্চি ওপরে তুললেই যথেষ্ট",
                "গ্লুটস হালকা শক্ত রাখুন যাতে কোমরে অতিরিক্ত চাপ না পড়ে"
            ),
            mistakesEn = listOf("Cranking head back looking up", "Jerking violently off the floor"),
            mistakesBn = listOf("মাথা পেছনে বাঁকিয়ে ওপরে তাকানো", "হঠাৎ ঝাঁকুনি দিয়ে ওঠা"),
            easierAltEn = "Alternating Bird-Dog lifts on hands and knees.",
            easierAltBn = "হাত ও হাঁটুর ওপর ভর দিয়ে বার্ড-ডগ ব্যায়াম।",
            progressionEn = "Hold peak extension for 5 seconds or perform Y-W shoulder retractions.",
            progressionBn = "শীর্ষ অবস্থানে ৫ সেকেন্ড হোল্ড অথবা হাত 'W' আকারে টানা।",
            floorY = 0.80f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.74f),
                        shoulder = Offset(0.64f, 0.76f),
                        elbow = Offset(0.78f, 0.77f),
                        wrist = Offset(0.89f, 0.78f),
                        hip = Offset(0.41f, 0.77f),
                        knee = Offset(0.26f, 0.78f),
                        ankle = Offset(0.11f, 0.79f)
                    ),
                    captionEn = "1. Prone Rest: Body relaxed long on mat, gaze down.",
                    captionBn = "১. শুরুর অবস্থান: ম্যাটে উপুড় হয়ে লম্বা হয়ে শুয়ে পড়ুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.77f, 0.65f),
                        shoulder = Offset(0.65f, 0.70f),
                        elbow = Offset(0.78f, 0.67f),
                        wrist = Offset(0.89f, 0.64f),
                        hip = Offset(0.42f, 0.77f),
                        knee = Offset(0.26f, 0.73f),
                        ankle = Offset(0.11f, 0.68f)
                    ),
                    captionEn = "2. Smooth Lift: Raise arms, chest & legs gently together.",
                    captionBn = "২. ধীরে তোলা: বুক, হাত ও পা একসাথে হালকা উপরে তুলুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.77f, 0.62f),
                        shoulder = Offset(0.65f, 0.68f),
                        elbow = Offset(0.78f, 0.63f),
                        wrist = Offset(0.89f, 0.59f),
                        hip = Offset(0.42f, 0.77f),
                        knee = Offset(0.26f, 0.71f),
                        ankle = Offset(0.11f, 0.65f)
                    ),
                    captionEn = "3. Top Hold (2s): Squeeze upper back and glutes steadily.",
                    captionBn = "৩. ২ সেকেন্ড হোল্ড: পিঠ ও গ্লুটস স্থিরভাবে টানটান রাখুন।",
                    breathing = BreathingCue.STEADY
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.76f, 0.74f),
                        shoulder = Offset(0.64f, 0.76f),
                        elbow = Offset(0.78f, 0.77f),
                        wrist = Offset(0.89f, 0.78f),
                        hip = Offset(0.41f, 0.77f),
                        knee = Offset(0.26f, 0.78f),
                        ankle = Offset(0.11f, 0.79f)
                    ),
                    captionEn = "4. Soft Lower: Exhale and relax smoothly onto mat.",
                    captionBn = "৪. নিচে নামা: শ্বাস ছেড়ে ধীরে ম্যাটে ফিরে আসুন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        ),
        ExerciseItem(
            id = "cat_cow",
            nameEn = "Cat-Cow Mobility",
            nameBn = "ক্যাট-কাউ মেরুদণ্ড স্ট্রেচ",
            categoryEn = "Mobility & Recovery",
            categoryBn = "সচলতা ও রিকভারি",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Thoracic & Lumbar Spine, Neck, Core",
            musclesBn = "মেরুদণ্ড, ঘাড় ও পেটের পেশী",
            setsRepsEn = "2 sets × 8–10 slow cycles",
            setsRepsBn = "২ সেট × ৮–১০ বার",
            restSeconds = 25,
            breathingEn = "Inhale as chest opens (Cow); exhale slowly as spine rounds upward (Cat).",
            breathingBn = "বুক খোলার সময় শ্বাস নিন; পিঠ উঁচু করার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Wrists under shoulders, knees under hips",
                "Move slowly segment-by-segment through your spine",
                "Keep shoulders relaxed away from ears"
            ),
            postureBn = listOf(
                "হাত কাঁধের নিচে ও হাঁটু কোমরের নিচে রাখুন",
                "মেরুদণ্ড ধীরে ধীরে ছন্দময়ভাবে বাঁকান",
                "ঘাড়ে অতিরিক্ত চাপ দেবেন না"
            ),
            mistakesEn = listOf("Rushing the movement", "Bending elbows instead of mobilizing the spine"),
            mistakesBn = listOf("খুব দ্রুত নড়াচড়া করা", "মেরুদণ্ডের বদলে কনুই ভাঁজ করা"),
            easierAltEn = "Seated Cat-Cow with hands resting gently on knees.",
            easierAltBn = "চেয়ারে বসে হাঁটুতে হাত রেখে সিটেড ক্যাট-কাউ।",
            progressionEn = "Add Thread-the-Needle thoracic rotation after each set.",
            progressionBn = "প্রতি সেটের পর থ্রেড-দ্য-নিডল রোটেশন যোগ করুন।",
            floorY = 0.80f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.74f, 0.44f),
                        shoulder = Offset(0.64f, 0.48f),
                        elbow = Offset(0.64f, 0.64f),
                        wrist = Offset(0.64f, 0.80f),
                        hip = Offset(0.34f, 0.48f),
                        knee = Offset(0.34f, 0.79f),
                        ankle = Offset(0.18f, 0.80f)
                    ),
                    captionEn = "1. Tabletop Neutral: Flat back, gaze softly down.",
                    captionBn = "১. নিউট্রাল টেবিলটপ: পিঠ সোজা, হাত ও হাঁটুতে সমান ভর।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.75f, 0.36f),
                        shoulder = Offset(0.64f, 0.49f),
                        elbow = Offset(0.64f, 0.65f),
                        wrist = Offset(0.64f, 0.80f),
                        hip = Offset(0.34f, 0.47f),
                        knee = Offset(0.34f, 0.79f),
                        ankle = Offset(0.18f, 0.80f)
                    ),
                    captionEn = "2. Cow Pose (Inhale): Lift chest, gently drop belly.",
                    captionBn = "২. কাউ পোজ (শ্বাস নিন): বুক সামনে খুলুন, পেট হালকা নিচে দিন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.71f, 0.54f),
                        shoulder = Offset(0.63f, 0.40f),
                        elbow = Offset(0.64f, 0.61f),
                        wrist = Offset(0.64f, 0.80f),
                        hip = Offset(0.35f, 0.44f),
                        knee = Offset(0.34f, 0.79f),
                        ankle = Offset(0.18f, 0.80f)
                    ),
                    captionEn = "3. Cat Pose (Exhale): Round upper back up, tuck chin.",
                    captionBn = "৩. ক্যাট পোজ (শ্বাস ছাড়ুন): পিঠ ধনুকের মতো উপরে তুলুন।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.74f, 0.44f),
                        shoulder = Offset(0.64f, 0.48f),
                        elbow = Offset(0.64f, 0.64f),
                        wrist = Offset(0.64f, 0.80f),
                        hip = Offset(0.34f, 0.48f),
                        knee = Offset(0.34f, 0.79f),
                        ankle = Offset(0.18f, 0.80f)
                    ),
                    captionEn = "4. Return to Neutral: Smooth transition ready for next breath.",
                    captionBn = "৪. স্বাভাবিক অবস্থায় ফেরা: পরবর্তী শ্বাসের জন্য প্রস্তুত।",
                    breathing = BreathingCue.INHALE
                )
            )
        ),
        ExerciseItem(
            id = "childs_pose_stretch",
            nameEn = "Child's Pose Recovery",
            nameBn = "চাইল্ডস পোজ রিকভারি স্ট্রেচ",
            categoryEn = "Mobility & Recovery",
            categoryBn = "সচলতা ও বিশ্রাম",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Lower Back, Lats, Shoulders, Hip Mobility",
            musclesBn = "কোমর, পিঠ, কাঁধ ও হিপ রিকভারি",
            setsRepsEn = "1 hold × 30–45s deep breathing",
            setsRepsBn = "১ বার × ৩০–৪৫ সেকেন্ড গভীর শ্বাস",
            restSeconds = 15,
            breathingEn = "Breathe deeply into your back ribs (4s nasal inhale, 6s calm exhale).",
            breathingBn = "পিঠের পাঁজর প্রসারিত করে গভীর শ্বাস নিন (৪ সেকেন্ড ইনহেল, ৬ সেকেন্ড এক্সহেল)।",
            postureEn = listOf(
                "Sit hips gently toward heels with knees slightly wide",
                "Reach arms comfortably forward along the mat",
                "Rest forehead lightly and drop tension in neck & jaw"
            ),
            postureBn = listOf(
                "নিতম্ব গোড়ালির দিকে বসান এবং হাঁটু সামান্য ফাঁকা রাখুন",
                "হাত সামনে মেঝে বরাবর লম্বা করে দিন",
                "কপাল ম্যাটে রেখে ঘাড় ও কাঁধ শিথিল করুন"
            ),
            mistakesEn = listOf("Forcing hips down if knees hurt", "Tensing shoulders"),
            mistakesBn = listOf("হাঁটুতে ব্যথা সত্ত্বেও জোর করে বসা", "কাঁধ শক্ত করে রাখা"),
            easierAltEn = "Place a folded cushion behind knees or under forehead.",
            easierAltBn = "হাঁটুর নিচে বা কপালের নিচে নরম বালিশ রাখুন।",
            progressionEn = "Walk hands slightly left and right for gentle side-lat lengthening.",
            progressionBn = "হাত ডানে ও বামে সামান্য সরিয়ে পার্শ্ব-পেশী স্ট্রেচ করুন।",
            floorY = 0.80f,
            phases = listOf(
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.71f, 0.45f),
                        shoulder = Offset(0.61f, 0.49f),
                        elbow = Offset(0.62f, 0.65f),
                        wrist = Offset(0.63f, 0.80f),
                        hip = Offset(0.35f, 0.49f),
                        knee = Offset(0.35f, 0.79f),
                        ankle = Offset(0.18f, 0.80f)
                    ),
                    captionEn = "1. Kneeling Base: Start calmly in tabletop alignment.",
                    captionBn = "১. শুরুর অবস্থান: টেবিলটপ ভঙ্গি থেকে শুরু করুন।",
                    breathing = BreathingCue.INHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.63f, 0.62f),
                        shoulder = Offset(0.55f, 0.62f),
                        elbow = Offset(0.69f, 0.73f),
                        wrist = Offset(0.82f, 0.79f),
                        hip = Offset(0.28f, 0.62f),
                        knee = Offset(0.34f, 0.79f),
                        ankle = Offset(0.18f, 0.80f)
                    ),
                    captionEn = "2. Sink Back: Ease hips slowly toward heels.",
                    captionBn = "২. পেছনে বসা: ধীরে ধীরে নিতম্ব গোড়ালির দিকে নামান।",
                    breathing = BreathingCue.EXHALE
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.61f, 0.73f),
                        shoulder = Offset(0.52f, 0.70f),
                        elbow = Offset(0.69f, 0.77f),
                        wrist = Offset(0.85f, 0.79f),
                        hip = Offset(0.24f, 0.67f),
                        knee = Offset(0.34f, 0.79f),
                        ankle = Offset(0.17f, 0.80f)
                    ),
                    captionEn = "3. Deep Rib Expansion: Hold and breathe slowly.",
                    captionBn = "৩. গভীর বিশ্রাম: পিঠে গভীর শ্বাস অনুভব করে স্থির থাকুন।",
                    breathing = BreathingCue.STEADY
                ),
                ExercisePhaseInfo(
                    pose = SkeletalPose(
                        head = Offset(0.62f, 0.71f),
                        shoulder = Offset(0.53f, 0.68f),
                        elbow = Offset(0.69f, 0.76f),
                        wrist = Offset(0.84f, 0.79f),
                        hip = Offset(0.25f, 0.66f),
                        knee = Offset(0.34f, 0.79f),
                        ankle = Offset(0.17f, 0.80f)
                    ),
                    captionEn = "4. Calm Release: Let heart rate settle in gratitude.",
                    captionBn = "৪. প্রশান্তি: হৃদস্পন্দন স্বাভাবিক করুন ও শুকরিয়া আদায় করুন।",
                    breathing = BreathingCue.EXHALE
                )
            )
        )
    ) + ExpandedExerciseCatalog.extraExercises + EquipmentExerciseCatalog.equipmentExercises

    fun findById(id: String): ExerciseItem = exercises.firstOrNull { it.id == id } ?: exercises.first()
}

object WorkoutProgramCatalog {
    val programs: List<WorkoutProgram> = listOf(
        WorkoutProgram(
            id = "full_body_foundation",
            titleEn = "Full Body Foundation",
            titleBn = "ফুল বডি ফাউন্ডেশন",
            subtitleEn = "Balanced strength + conditioning circuit with zero equipment",
            subtitleBn = "কোনো সরঞ্জাম ছাড়াই সম্পূর্ণ শরীরের শক্তি ও ফিটনেস সার্কিট",
            focusAreaEn = "Full Body",
            focusAreaBn = "সম্পূর্ণ শরীর",
            level = "Beginner",
            durationMinutes = 14,
            estimatedKcal = 135,
            accentTag = "POPULAR",
            stations = listOf(
                WorkoutStation("jumping_jack", durationSec = 35, restAfterSec = 20),
                WorkoutStation("incline_push_up", targetReps = 10, restAfterSec = 25),
                WorkoutStation("bodyweight_squat", targetReps = 14, restAfterSec = 25),
                WorkoutStation("glute_bridge", targetReps = 12, restAfterSec = 20),
                WorkoutStation("forearm_plank", durationSec = 30, restAfterSec = 20),
                WorkoutStation("childs_pose_stretch", durationSec = 30, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "upper_body_sculpt",
            titleEn = "Upper Body & Chest Sculpt",
            titleBn = "আপার বডি ও বুক শক্তিবর্ধন",
            subtitleEn = "Push-up progressions paired with posture & shoulder stability",
            subtitleBn = "পুশ-আপ ও কাঁধ-পিঠের সমন্বিত শক্তি প্রশিক্ষণ",
            focusAreaEn = "Chest & Arms",
            focusAreaBn = "বুক, হাত ও কাঁধ",
            level = "Intermediate",
            durationMinutes = 16,
            estimatedKcal = 145,
            accentTag = "STRENGTH",
            stations = listOf(
                WorkoutStation("jumping_jack", durationSec = 30, restAfterSec = 20),
                WorkoutStation("incline_push_up", targetReps = 12, restAfterSec = 25),
                WorkoutStation("push_up", targetReps = 10, restAfterSec = 30),
                WorkoutStation("forearm_plank", durationSec = 35, restAfterSec = 25),
                WorkoutStation("superman_hold", targetReps = 10, restAfterSec = 25),
                WorkoutStation("push_up", targetReps = 8, restAfterSec = 20),
                WorkoutStation("childs_pose_stretch", durationSec = 30, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "core_posture_reset",
            titleEn = "Core & Posture Reset",
            titleBn = "কোর ও সঠিক ভঙ্গি রিসেট",
            subtitleEn = "Anti-slouch core stability for desk workers & students",
            subtitleBn = "ডেস্ক কর্মী ও শিক্ষার্থীদের মেরুদণ্ড ও পেটের গভীর পেশীর ব্যায়াম",
            focusAreaEn = "Abs & Spine",
            focusAreaBn = "কোর ও মেরুদণ্ড",
            level = "Beginner",
            durationMinutes = 12,
            estimatedKcal = 95,
            accentTag = "POSTURE",
            stations = listOf(
                WorkoutStation("cat_cow", targetReps = 10, restAfterSec = 15),
                WorkoutStation("forearm_plank", durationSec = 35, restAfterSec = 25),
                WorkoutStation("bicycle_crunch", targetReps = 14, restAfterSec = 25),
                WorkoutStation("glute_bridge", targetReps = 14, restAfterSec = 20),
                WorkoutStation("superman_hold", targetReps = 10, restAfterSec = 20),
                WorkoutStation("childs_pose_stretch", durationSec = 35, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "lower_body_power",
            titleEn = "Lower Body & Glute Power",
            titleBn = "লোয়ার বডি ও লেগ পাওয়ার",
            subtitleEn = "Knee-friendly glute, quad & balance strength sequence",
            subtitleBn = "পা, উরু ও ভারসাম্য বৃদ্ধির নিরাপদ হোম ওয়ার্কআউট",
            focusAreaEn = "Legs & Glutes",
            focusAreaBn = "পা ও গ্লুটস",
            level = "Intermediate",
            durationMinutes = 15,
            estimatedKcal = 150,
            accentTag = "LEGS",
            stations = listOf(
                WorkoutStation("jumping_jack", durationSec = 30, restAfterSec = 20),
                WorkoutStation("bodyweight_squat", targetReps = 15, restAfterSec = 25),
                WorkoutStation("reverse_lunge", targetReps = 12, restAfterSec = 25),
                WorkoutStation("glute_bridge", targetReps = 15, restAfterSec = 25),
                WorkoutStation("bodyweight_squat", targetReps = 12, restAfterSec = 20),
                WorkoutStation("childs_pose_stretch", durationSec = 30, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "fajr_mobility_flow",
            titleEn = "Fajr Wake-Up & Joint Mobility",
            titleBn = "ফজর-পরবর্তী জাগরণ ও জয়েন্ট সচলতা",
            subtitleEn = "Gentle 8-minute flow to energize spine, hips & focus",
            subtitleBn = "সকালে শরীর ও মেরুদণ্ড সতেজ করার ৮ মিনিটের হালকা রুটিন",
            focusAreaEn = "Mobility",
            focusAreaBn = "সচলতা ও সতেজতা",
            level = "Beginner",
            durationMinutes = 8,
            estimatedKcal = 55,
            accentTag = "MORNING",
            stations = listOf(
                WorkoutStation("cat_cow", targetReps = 10, restAfterSec = 15),
                WorkoutStation("glute_bridge", targetReps = 12, restAfterSec = 15),
                WorkoutStation("superman_hold", targetReps = 8, restAfterSec = 15),
                WorkoutStation("bodyweight_squat", targetReps = 10, restAfterSec = 15),
                WorkoutStation("childs_pose_stretch", durationSec = 35, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "hiit_fat_burn",
            titleEn = "HIIT Fat Burn & Conditioning",
            titleBn = "হাই-ইনটেনসিটি ফ্যাট বার্ন সার্কিট",
            subtitleEn = "High-energy bodyweight intervals to boost stamina",
            subtitleBn = "স্ট্যামিনা ও ক্যালোরি বার্ন বৃদ্ধির দ্রুতগতির বডিওয়েট সার্কিট",
            focusAreaEn = "Cardio HIIT",
            focusAreaBn = "কার্ডিও HIIT",
            level = "Advanced",
            durationMinutes = 18,
            estimatedKcal = 210,
            accentTag = "INTENSE",
            stations = listOf(
                WorkoutStation("jumping_jack", durationSec = 40, restAfterSec = 20),
                WorkoutStation("mountain_climbers", durationSec = 30, restAfterSec = 25),
                WorkoutStation("push_up", targetReps = 12, restAfterSec = 25),
                WorkoutStation("bodyweight_squat", targetReps = 16, restAfterSec = 25),
                WorkoutStation("bicycle_crunch", targetReps = 18, restAfterSec = 20),
                WorkoutStation("mountain_climbers", durationSec = 30, restAfterSec = 20),
                WorkoutStation("childs_pose_stretch", durationSec = 35, restAfterSec = 0)
            )
        )
    ) + ExpandedExerciseCatalog.extraPrograms + EquipmentExerciseCatalog.equipmentPrograms
}
