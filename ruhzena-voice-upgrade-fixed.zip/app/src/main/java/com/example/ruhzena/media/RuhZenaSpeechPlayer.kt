package com.example.ruhzena.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.ruhzena.core.ui.stripMarkdownForSpeech
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerateContentResponse
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.InlineDataPart
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.SpeechConfig
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import com.google.firebase.ai.type.Voice as GeminiVoice

private const val SPEECH_TAG = "RuhZenaSpeechPlayer"
private const val NEURAL_TTS_MODEL = "gemini-3.1-flash-tts-preview"
private const val PCM_SAMPLE_RATE = 24_000

/** Max wait for the first audible packet of the opening chunk before using the on-device voice. */
private const val FIRST_BYTE_TIMEOUT_MS = 7_000L
private const val CHUNK_TIMEOUT_MS = 20_000L
private const val PREFETCH_DEPTH = 2
private const val START_BUFFER_MS = 120
private const val TRACK_BUFFER_MS = 300
private const val SENTENCE_GAP_MS = 90
private const val PARAGRAPH_GAP_MS = 380
private const val MAX_CLOUD_FAILURES = 2
private const val CLOUD_COOLDOWN_MS = 45_000L
private const val DEVICE_INIT_TIMEOUT_MS = 4_000L
private const val MAX_STORY_CHARS = 20_000
private const val MAX_REPLY_CHARS = 6_000

/**
 * RuhZena AI narration engine (stories, AI replies, lessons/context, duas, Arabic letters).
 * NOT used for Quran recitation: QuranAudioController plays the selected reciter's real audio and
 * is never routed through this class for ayahs.
 *
 * Pipeline
 *  1. Disk cache hit  -> PCM is streamed from the file (no full read) => starts in a few ms.
 *  2. Otherwise Gemini TTS with a REAL prebuilt voice for the user's gender: chunk 0 is streamed
 *     packet-by-packet into an AudioTrack (starts after ~120 ms of PCM), chunks 1..N are
 *     prefetched [PREFETCH_DEPTH] ahead, and paragraph/sentence pauses are inserted between chunks.
 *  3. Offline / cloud cooling-down / cloud failure -> on-device TextToSpeech with an explicitly
 *     selected voice of the SAME gender (see [configureDeviceVoice] for the documented tiers).
 *     If cloud dies mid-narration, the remaining text continues on-device (no text is dropped).
 *
 * Voice gender comes only from [applyVoicePreference] (onboarding/profile gender).
 */
class RuhZenaSpeechPlayer(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cache = NarrationAudioCache(File(appContext.cacheDir, "ruhzena_voice_cache"))
    private val lock = Any()

    // ---- voice -------------------------------------------------------------------------------
    @Volatile
    private var voice: NarrationVoiceConfig = NarrationVoiceResolver.resolve("", "")

    // One reusable client per (backend, voice); never rebuilt per tap.
    private val models = ConcurrentHashMap<String, GenerativeModel>()
    @Volatile private var preferredBackend = 0 // 0 = Firebase default backend, 1 = Google AI backend
    @Volatile private var consecutiveCloudFailures = 0
    @Volatile private var cloudCooldownUntil = 0L

    // ---- session / state ---------------------------------------------------------------------
    private val sessionCounter = AtomicLong(0)
    @Volatile private var activeSession = 0L
    private var activePlaybackJob: Job? = null
    @Volatile private var activeSink: PcmSink? = null

    @Volatile private var currentTitle: String = "RuhZena Voice"
    @Volatile private var currentSubtitle: String = "Human Studio Voice"
    @Volatile private var currentBadge: String = "RUHZENA VOICE"

    private val _speakingItemId = MutableStateFlow<String?>(null)
    val speakingItemId: StateFlow<String?> = _speakingItemId.asStateFlow()

    private val _loadingItemId = MutableStateFlow<String?>(null)
    val loadingItemId: StateFlow<String?> = _loadingItemId.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    // ---- on-device TTS fallback --------------------------------------------------------------
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var ttsInitDone = false
    private var pendingDeviceStart: (() -> Unit)? = null
    private val lockedLocalVoices = ConcurrentHashMap<String, Voice>()
    @Volatile private var deviceActive = false
    @Volatile private var deviceChunks: List<String> = emptyList()
    @Volatile private var deviceIndex = 0
    @Volatile private var deviceSession = 0L
    @Volatile private var deviceItemId: String? = null

    /**
     * Single entry point for the voice preference. [characterGender] is the onboarding/profile
     * gender; [legacyStyle] is only a tone variant inside that gender. Safe to call repeatedly.
     * If the effective voice changes while something is playing, that narration is stopped so the
     * old voice never keeps going.
     */
    fun applyVoicePreference(characterGender: String?, legacyStyle: String?) {
        val next = NarrationVoiceResolver.resolve(characterGender, legacyStyle)
        if (next == voice) return
        voice = next
        val busy = _speakingItemId.value != null || _loadingItemId.value != null
        if (busy) stop()
        scope.launch { runCatching { modelFor(preferredBackend, next) } } // pre-warm the new voice's client
    }

    // SpeechConfig / Voice are part of the Firebase AI "public preview" surface and require this opt-in.
    @OptIn(PublicPreviewAPI::class)
    private fun modelFor(backend: Int, v: NarrationVoiceConfig): GenerativeModel =
        models.getOrPut("$backend:${v.geminiVoice}") {
            val config = generationConfig {
                responseModalities = listOf(ResponseModality.AUDIO)
                // Real voice selection (not a prose instruction).
                speechConfig = SpeechConfig(voice = GeminiVoice(v.geminiVoice))
            }
            val ai = if (backend == 0) Firebase.ai else Firebase.ai(backend = GenerativeBackend.googleAI())
            ai.generativeModel(modelName = NEURAL_TTS_MODEL, generationConfig = config)
        }

    private fun backendOrder(): List<Int> = if (preferredBackend == 0) listOf(0, 1) else listOf(1, 0)

    // =========================================================================================
    // Public API (unchanged signatures)
    // =========================================================================================

    /** Arabic text (alphabet, duas, adhkar, tasbih) — NOT Quran recitation. */
    fun toggleSpeakArabic(itemId: String, arabicText: String, fallbackPronunciation: String = "") {
        if (isActiveItem(itemId)) { stop(); return }
        stop()

        val waqfArabic = normalizeArabicWaqfForSpeech(arabicText).take(MAX_REPLY_CHARS)
        if (waqfArabic.isBlank()) return

        currentTitle = fallbackPronunciation.take(44).ifBlank { "Arabic Recitation" }
        currentSubtitle = "RuhZena Human Voice • Arabic"
        currentBadge = "ARABIC AUDIO • RUHZENA"

        beginNarration(
            itemId,
            buildRequest(
                type = NarrationType.ARABIC,
                isBangla = false,
                text = waqfArabic,
                firstMax = 90,
                nextMax = 260,
                device = DeviceSpec(
                    locales = listOf(Locale("ar", "SA"), Locale("ar", "EG"), Locale("ar")),
                    rate = 0.86f,
                    transliterationFallback = fallbackPronunciation.takeIf { it.isNotBlank() }
                )
            )
        )
    }

    /** Lessons, prophet/Islamic stories, encyclopedia/context, hourly wisdom. */
    fun toggleSpeakLocalized(itemId: String, text: String, isBangla: Boolean, titleOverride: String? = null) {
        if (isActiveItem(itemId)) { stop(); return }
        stop()

        val expanded = expandIslamicHonorificsForSpeech(stripMarkdownForSpeech(text), isBangla)
        val cleanText = truncateAtSentence(normalizeArabicWaqfForSpeech(expanded), MAX_STORY_CHARS)
        if (cleanText.isBlank()) return

        val isStory = itemId.startsWith("story_", ignoreCase = true)
        currentTitle = titleOverride?.take(48)
            ?: cleanText.substringBefore('.').substringBefore('।').take(46).ifBlank {
                if (isStory) "Islamic Story" else "RuhZena Audio"
            }
        currentSubtitle = if (isStory) {
            if (isBangla) "বিস্তারিত ইসলামী গল্প • হিউম্যান ভয়েস" else "Narrated Islamic Story • Studio Voice"
        } else {
            if (isBangla) "রূহযেনা অডিও পাঠ" else "RuhZena Human Voice"
        }
        currentBadge = if (isStory) "STORY AUDIO • RUHZENA" else "RUHZENA VOICE"

        beginNarration(
            itemId,
            buildRequest(
                type = if (isStory) NarrationType.STORY else NarrationType.EDUCATIONAL,
                isBangla = isBangla,
                text = cleanText,
                firstMax = 130,
                nextMax = 380,
                device = DeviceSpec(
                    locales = localesFor(isBangla),
                    rate = if (isStory) 0.93f else 0.97f,
                    transliterationFallback = null
                )
            )
        )
    }

    /** RuhZena AI companion reply. */
    fun toggleSpeakAiReply(itemId: String, markdownText: String, isBangla: Boolean) {
        if (isActiveItem(itemId)) { stop(); return }
        stop()

        val expanded = expandIslamicHonorificsForSpeech(stripMarkdownForSpeech(markdownText), isBangla)
        val cleanText = truncateAtSentence(normalizeArabicWaqfForSpeech(expanded), MAX_REPLY_CHARS)
        if (cleanText.isBlank()) return

        currentTitle = if (isBangla) "রূহযেনা এআই উত্তর" else "RuhZena AI Companion"
        currentSubtitle = cleanText.take(48)
        currentBadge = "AI HUMAN VOICE • RUHZENA"

        beginNarration(
            itemId,
            buildRequest(
                type = NarrationType.AI_REPLY,
                isBangla = isBangla,
                text = cleanText,
                firstMax = 110,
                nextMax = 320,
                device = DeviceSpec(localesFor(isBangla), 0.97f, null)
            )
        )
    }

    fun togglePauseResume() {
        val currentId = _speakingItemId.value ?: return
        val newPaused = !_isPaused.value
        _isPaused.value = newPaused
        activeSink?.setPaused(newPaused)
        if (deviceActive) {
            if (newPaused) {
                runCatching { tts?.stop() }
            } else {
                val id = deviceItemId
                if (id != null) speakDeviceFrom(deviceSession, id, deviceIndex)
            }
        }
        if (_speakingItemId.value == currentId) publishSpeechNotification(isPlaying = !newPaused)
    }

    fun stop() {
        synchronized(lock) {
            activeSession = sessionCounter.incrementAndGet() // invalidates every in-flight coroutine/callback
            activePlaybackJob?.cancel()
            activePlaybackJob = null
            pendingDeviceStart = null
            deviceActive = false
            deviceChunks = emptyList()
            activeSink?.hardStop()
            activeSink = null
            runCatching { tts?.stop() }
            _loadingItemId.value = null
            _speakingItemId.value = null
            _isPaused.value = false
        }
        RuhZenaMediaNotificationManager.dismiss(appContext, RuhZenaMediaNotificationManager.AudioSource.SPEECH)
    }

    fun release() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
        ttsReady = false
        ttsInitDone = false
    }

    // =========================================================================================
    // Request plumbing
    // =========================================================================================

    private class DeviceSpec(val locales: List<Locale>, val rate: Float, val transliterationFallback: String?)

    private class NarrationRequest(
        val type: NarrationType,
        val language: String,
        val voice: NarrationVoiceConfig,
        val cacheKey: String,
        val chunks: List<SpeechChunk>,
        val device: DeviceSpec
    )

    private fun buildRequest(
        type: NarrationType,
        isBangla: Boolean,
        text: String,
        firstMax: Int,
        nextMax: Int,
        device: DeviceSpec
    ): NarrationRequest {
        val v = voice // snapshot: a gender change mid-play can never mix voices inside one narration
        val language = NarrationPrompts.languageName(isBangla, type)
        return NarrationRequest(
            type = type,
            language = language,
            voice = v,
            cacheKey = NarrationCacheKeys.build(type, language, v, text),
            chunks = NarrationChunker.split(text, firstMax, nextMax),
            device = device
        )
    }

    private fun localesFor(isBangla: Boolean) =
        if (isBangla) listOf(Locale("bn", "BD"), Locale("bn", "IN"), Locale("bn"))
        else listOf(Locale.US, Locale.UK, Locale.ENGLISH)

    private fun isActiveItem(itemId: String) =
        _speakingItemId.value == itemId || _loadingItemId.value == itemId

    private fun isCurrent(session: Long) = session == activeSession

    private fun truncateAtSentence(text: String, max: Int): String {
        if (text.length <= max) return text
        val cut = text.substring(0, max)
        val end = cut.lastIndexOfAny(charArrayOf('.', '!', '?', '।', '؟', '\n'))
        return if (end > max / 2) cut.substring(0, end + 1) else cut
    }

    private fun beginNarration(itemId: String, req: NarrationRequest) {
        synchronized(lock) {
            val session = sessionCounter.incrementAndGet()
            activeSession = session
            _isPaused.value = false
            _loadingItemId.value = itemId   // UI reacts immediately
            _speakingItemId.value = itemId
            publishSpeechNotification(isPlaying = true)
            activePlaybackJob = scope.launch { runNarration(session, itemId, req) }
        }
    }

    private fun publishSpeechNotification(isPlaying: Boolean) {
        RuhZenaMediaNotificationManager.showOrUpdate(
            context = appContext,
            control = RuhZenaMediaNotificationManager.ActiveMediaControl(
                source = RuhZenaMediaNotificationManager.AudioSource.SPEECH,
                title = currentTitle,
                subtitle = currentSubtitle,
                badge = currentBadge,
                isPlaying = isPlaying,
                canSkip = false,
                onPlayPause = { togglePauseResume() },
                onStop = { stop() }
            )
        )
    }

    /** Ends the session (state + notification) only if it is still the current one. */
    private fun finishSession(session: Long) {
        val done = synchronized(lock) {
            if (!isCurrent(session)) false else {
                deviceActive = false
                _loadingItemId.value = null
                _speakingItemId.value = null
                _isPaused.value = false
                true
            }
        }
        if (done) {
            RuhZenaMediaNotificationManager.dismiss(appContext, RuhZenaMediaNotificationManager.AudioSource.SPEECH)
        }
    }

    // =========================================================================================
    // Narration orchestration
    // =========================================================================================

    private suspend fun runNarration(session: Long, itemId: String, req: NarrationRequest) {
        var sink: PcmSink? = null
        try {
            if (req.chunks.isEmpty()) { finishSession(session); return }

            // 1) Disk cache: stream the file; no full read before start.
            val hit = cache.lookup(req.cacheKey)
            if (hit != null) {
                sink = PcmSink(session, hit.sampleRate, cacheKey = null).also { activeSink = it }
                playFromCache(session, hit, sink)
                if (isCurrent(session)) sink.drain()
                finishSession(session)
                return
            }

            // 2) No usable cloud -> device voice immediately (no pointless waiting).
            if (!isNetworkAvailable() || System.currentTimeMillis() < cloudCooldownUntil) {
                fallbackToDevice(session, itemId, req, 0)
                return
            }

            // 3) Cloud streaming.
            sink = PcmSink(session, null, cacheKey = req.cacheKey).also { activeSink = it }
            val deviceStartIndex = runCloudPipeline(session, req, sink)
            if (!isCurrent(session)) return
            if (deviceStartIndex == null) {
                consecutiveCloudFailures = 0
                sink.commitCache()
                sink.drain()
                finishSession(session)
            } else {
                recordCloudFailure()
                sink.abortCache()
                sink.drain() // let already-spoken audio finish before the device voice continues
                if (isCurrent(session)) fallbackToDevice(session, itemId, req, deviceStartIndex)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(SPEECH_TAG, "Narration failed, using on-device voice", e)
            if (isCurrent(session)) {
                recordCloudFailure()
                sink?.abortCache()
                fallbackToDevice(session, itemId, req, 0)
            }
        } finally {
            sink?.abortCache() // no-op after commit; guarantees no partial cache file survives
            sink?.release()
            if (activeSink === sink) activeSink = null
        }
    }

    private fun recordCloudFailure() {
        if (++consecutiveCloudFailures >= MAX_CLOUD_FAILURES) {
            cloudCooldownUntil = System.currentTimeMillis() + CLOUD_COOLDOWN_MS
            consecutiveCloudFailures = 0
        }
    }

    private fun isNetworkAvailable(): Boolean = runCatching {
        val cm = appContext.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(true)

    private suspend fun playFromCache(session: Long, hit: NarrationAudioCache.Hit, sink: PcmSink) =
        withContext(Dispatchers.IO) {
            FileInputStream(hit.file).use { input ->
                input.channel.position(NarrationAudioCache.HEADER_SIZE.toLong())
                val buf = ByteArray(16 * 1024)
                while (isActive && isCurrent(session)) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    sink.write(buf, n)
                }
            }
        }

    /**
     * Returns null when every chunk was generated and written, or the chunk index from which the
     * on-device voice must continue.
     */
    private suspend fun runCloudPipeline(session: Long, req: NarrationRequest, sink: PcmSink): Int? =
        coroutineScope {
            val chunks = req.chunks
            val prompts = chunks.map { NarrationPrompts.build(req.type, req.language, it.text) }
            val ahead = HashMap<Int, Deferred<SynthesizedAudio?>>()

            fun launchAhead(i: Int) {
                if (i in 1 until chunks.size && i !in ahead) {
                    ahead[i] = async(Dispatchers.IO) { synthesizeChunk(session, prompts[i], req.voice) }
                }
            }

            try {
                // Prefetch starts BEFORE chunk 0 finishes streaming, so later chunks are ready in time.
                for (i in 1..PREFETCH_DEPTH) launchAhead(i)

                when (streamFirstChunk(session, prompts[0], req.voice, sink)) {
                    FirstChunk.FAILED -> return@coroutineScope 0
                    FirstChunk.PARTIAL -> return@coroutineScope if (chunks.size > 1) 1 else null
                    FirstChunk.OK -> Unit
                }

                for (i in 1 until chunks.size) {
                    if (!isCurrent(session)) return@coroutineScope null
                    sink.writeSilence(if (chunks[i - 1].paragraphBreakAfter) PARAGRAPH_GAP_MS else SENTENCE_GAP_MS)
                    launchAhead(i + PREFETCH_DEPTH)
                    val audio = (ahead.remove(i) ?: async(Dispatchers.IO) {
                        synthesizeChunk(session, prompts[i], req.voice)
                    }).await()
                    if (audio == null) return@coroutineScope i
                    sink.write(audio.bytes, audio.bytes.size, audio.sampleRate)
                }
                null
            } finally {
                // coroutineScope waits for children: cancel unneeded prefetches so Stop / fallback is immediate.
                ahead.values.forEach { it.cancel() }
            }
        }

    // ---- Gemini streaming --------------------------------------------------------------------

    private class SynthesizedAudio(val bytes: ByteArray, val sampleRate: Int)
    private class PcmPacket(val bytes: ByteArray, val sampleRate: Int)
    private enum class FirstChunk { OK, PARTIAL, FAILED }
    private enum class StreamOutcome { OK, PARTIAL, TIMEOUT, ERROR }

    private fun extractPcm(resp: GenerateContentResponse): List<PcmPacket> {
        val parts = resp.candidates.firstOrNull()?.content?.parts.orEmpty()
        val out = ArrayList<PcmPacket>(1)
        for (part in parts.filterIsInstance<InlineDataPart>()) {
            if (part.inlineData.isEmpty()) continue
            val mime = part.mimeType.lowercase(Locale.US)
            if (mime.contains("mp3") || mime.contains("mpeg") || mime.contains("ogg") ||
                mime.contains("aac") || mime.contains("flac") || mime.contains("opus")
            ) {
                throw IllegalStateException("Unsupported encoded audio from TTS: $mime")
            }
            val pcm = stripWavHeaderIfPresent(part.inlineData)
            if (pcm.isNotEmpty()) out.add(PcmPacket(pcm, parseSampleRate(mime)))
        }
        return out
    }

    private suspend fun streamFirstChunk(
        session: Long,
        prompt: String,
        v: NarrationVoiceConfig,
        sink: PcmSink
    ): FirstChunk {
        for (backend in backendOrder()) {
            if (!isCurrent(session)) return FirstChunk.FAILED
            when (streamOnce(session, backend, prompt, v, sink)) {
                StreamOutcome.OK -> { preferredBackend = backend; return FirstChunk.OK }
                StreamOutcome.PARTIAL -> { preferredBackend = backend; return FirstChunk.PARTIAL }
                StreamOutcome.TIMEOUT -> return FirstChunk.FAILED // slow network: don't stack another long wait
                StreamOutcome.ERROR -> continue                    // fast failure: try the other backend once
            }
        }
        return FirstChunk.FAILED
    }

    private suspend fun streamOnce(
        session: Long,
        backend: Int,
        prompt: String,
        v: NarrationVoiceConfig,
        sink: PcmSink
    ): StreamOutcome = coroutineScope {
        val model = modelFor(backend, v)
        val firstAudio = CompletableDeferred<Unit>()
        var failure: Throwable? = null
        val streamJob = launch(Dispatchers.IO) {
            try {
                model.generateContentStream(prompt).collect { resp ->
                    for (pkt in extractPcm(resp)) {
                        if (!isCurrent(session)) throw CancellationException("session ended")
                        sink.write(pkt.bytes, pkt.bytes.size, pkt.sampleRate)
                        if (!firstAudio.isCompleted) firstAudio.complete(Unit)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failure = e
                Log.d(SPEECH_TAG, "Stream error (backend=$backend): ${e.message}")
            }
        }
        val gotAudio: Boolean? = withTimeoutOrNull(FIRST_BYTE_TIMEOUT_MS) {
            select<Boolean> {
                firstAudio.onAwait { true }
                streamJob.onJoin { firstAudio.isCompleted }
            }
        }
        when {
            gotAudio == null -> { streamJob.cancel(); StreamOutcome.TIMEOUT }
            gotAudio == false -> StreamOutcome.ERROR
            else -> {
                val finished = withTimeoutOrNull(CHUNK_TIMEOUT_MS) { streamJob.join(); true } ?: false
                if (!finished) { streamJob.cancel(); StreamOutcome.PARTIAL }
                else if (failure != null) StreamOutcome.PARTIAL
                else StreamOutcome.OK
            }
        }
    }

    /** Non-streaming synthesis of one prefetched chunk. At most one attempt per backend. */
    private suspend fun synthesizeChunk(session: Long, prompt: String, v: NarrationVoiceConfig): SynthesizedAudio? {
        for (backend in backendOrder()) {
            if (!isCurrent(session)) return null
            val result = withTimeoutOrNull(CHUNK_TIMEOUT_MS) {
                try {
                    val out = java.io.ByteArrayOutputStream()
                    var rate = PCM_SAMPLE_RATE
                    modelFor(backend, v).generateContentStream(prompt).collect { resp ->
                        for (pkt in extractPcm(resp)) { rate = pkt.sampleRate; out.write(pkt.bytes) }
                    }
                    val bytes = out.toByteArray()
                    if (bytes.size >= 2) SynthesizedAudio(bytes, rate) else null
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.d(SPEECH_TAG, "Chunk synthesis failed (backend=$backend): ${e.message}")
                    null
                }
            }
            if (result != null) { preferredBackend = backend; return result }
        }
        return null
    }

    // =========================================================================================
    // AudioTrack sink
    // =========================================================================================

    /**
     * Owns one AudioTrack for one narration. Starts playing after [START_BUFFER_MS] of PCM (or at the
     * end of the stream), handles odd-length packets, pause/resume, silence gaps, tee-ing into the
     * disk cache, and drains the buffered tail before releasing so the last words are never cut off.
     */
    private inner class PcmSink(
        private val session: Long,
        initialRate: Int?,
        cacheKey: String?
    ) {
        private val released = AtomicBoolean(false)
        @Volatile private var track: AudioTrack? = null
        @Volatile private var rate = initialRate ?: PCM_SAMPLE_RATE
        @Volatile private var started = false
        @Volatile private var paused = false
        private var framesWritten = 0L
        private var carry: Byte? = null
        private var pending: NarrationAudioCache.PendingWrite? = null
        private val cacheKeyOrNull = cacheKey
        private var cacheClosed = false

        private fun ensureTrack(sampleRate: Int): AudioTrack {
            track?.let { return it }
            rate = sampleRate
            val t = createPcmAudioTrack(sampleRate)
            if (t.state != AudioTrack.STATE_INITIALIZED) {
                runCatching { t.release() }
                throw IllegalStateException("AudioTrack failed to initialise")
            }
            track = t
            if (cacheKeyOrNull != null) pending = cache.beginWrite(cacheKeyOrNull, sampleRate)
            if (released.get()) { runCatching { t.release() }; throw CancellationException("released") }
            return t
        }

        suspend fun write(data: ByteArray, length: Int = data.size, sampleRate: Int = rate) {
            var buf = data
            var len = length
            val c = carry
            if (c != null) {
                buf = ByteArray(len + 1).also { it[0] = c; System.arraycopy(data, 0, it, 1, len) }
                len += 1
                carry = null
            }
            if (len % 2 != 0) { carry = buf[len - 1]; len -= 1 }
            if (len <= 0) return
            val t = ensureTrack(sampleRate)
            pending?.write(buf, 0, len)
            writeToTrack(t, buf, len)
        }

        suspend fun writeSilence(ms: Int) {
            val t = track ?: return
            val bytes = (rate * 2L * ms / 1000L).toInt().let { it - it % 2 }
            if (bytes <= 0) return
            val silence = ByteArray(bytes)
            pending?.write(silence, 0, bytes)
            writeToTrack(t, silence, bytes)
        }

        private suspend fun writeToTrack(t: AudioTrack, buf: ByteArray, len: Int) {
            var off = 0
            while (off < len) {
                while (_isPaused.value && isCurrent(session) && !released.get()) delay(40L)
                if (!isCurrent(session) || released.get()) return
                val n = t.write(buf, off, minOf(8 * 1024, len - off))
                if (n < 0) {
                    if (!isCurrent(session) || released.get()) return
                    throw IOException("AudioTrack write error $n")
                }
                if (n == 0) { startPlayback(t); delay(5L); continue }
                off += n
                framesWritten += n / 2
                if (!started && framesWritten * 1000L >= rate.toLong() * START_BUFFER_MS) startPlayback(t)
            }
        }

        private fun startPlayback(t: AudioTrack) {
            if (started || released.get()) return
            started = true
            if (!paused) runCatching { t.play() }
            if (isCurrent(session)) _loadingItemId.value = null // audio is actually audible now
        }

        fun setPaused(p: Boolean) {
            paused = p
            val t = track ?: return
            if (!started) return
            runCatching { if (p) t.pause() else t.play() }
        }

        /** Let everything already written play out, then release. */
        suspend fun drain() {
            val t = track ?: return
            if (released.get()) return
            try {
                if (!started && framesWritten > 0) startPlayback(t)
                while (_isPaused.value && isCurrent(session) && !released.get()) delay(40L)
                runCatching { t.stop() } // MODE_STREAM: queued data keeps playing until consumed
                val deadline = System.currentTimeMillis() + TRACK_BUFFER_MS + 1_500L
                while (isCurrent(session) && !released.get() &&
                    t.playbackHeadPosition < framesWritten && System.currentTimeMillis() < deadline
                ) delay(30L)
            } finally {
                release()
            }
        }

        fun commitCache() {
            if (cacheClosed) return
            cacheClosed = true
            pending?.commit()
            pending = null
        }

        fun abortCache() {
            if (cacheClosed) return
            cacheClosed = true
            pending?.abort()
            pending = null
        }

        /** Immediate cut (Stop / new narration). Safe from any thread, idempotent. */
        fun hardStop() {
            if (!released.compareAndSet(false, true)) return
            val t = track
            runCatching { t?.pause(); t?.flush(); t?.stop() }
            runCatching { t?.release() }
            pending?.abort()
        }

        fun release() {
            if (!released.compareAndSet(false, true)) return
            runCatching { track?.release() }
        }
    }

    private fun createPcmAudioTrack(sampleRate: Int): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(2048)
        // Start threshold is START_BUFFER_MS; the buffer is larger than that so writes never block
        // before play() and short network jitter doesn't underrun. It adds no start latency.
        val wanted = (sampleRate * 2 * TRACK_BUFFER_MS / 1000)
        val bufferBytes = maxOf(minBuf * 2, wanted)

        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun parseSampleRate(mime: String): Int =
        Regex("rate=(\\d+)").find(mime)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: PCM_SAMPLE_RATE

    private fun stripWavHeaderIfPresent(data: ByteArray): ByteArray {
        return if (data.size > 44 &&
            data[0] == 'R'.code.toByte() && data[1] == 'I'.code.toByte() &&
            data[2] == 'F'.code.toByte() && data[3] == 'F'.code.toByte()
        ) data.copyOfRange(44, data.size) else data
    }

    // =========================================================================================
    // On-device TextToSpeech fallback (same gender, same language)
    // =========================================================================================

    private suspend fun fallbackToDevice(session: Long, itemId: String, req: NarrationRequest, startChunk: Int) {
        if (!isCurrent(session)) return
        val text = buildString {
            for (i in startChunk until req.chunks.size) {
                if (isNotEmpty()) append(if (req.chunks[i - 1].paragraphBreakAfter) "\n" else " ")
                append(req.chunks[i].text)
            }
        }
        withContext(Dispatchers.Main) {
            if (isCurrent(session)) startDeviceSpeech(session, itemId, req, text)
        }
    }

    private fun ensureDeviceTts() {
        if (tts != null) return
        tts = TextToSpeech(appContext) { status ->
            ttsReady = (status == TextToSpeech.SUCCESS)
            ttsInitDone = true
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(deviceListener)
            } else {
                runCatching { tts?.shutdown() }
                tts = null // allow a later retry
            }
            val p = pendingDeviceStart
            pendingDeviceStart = null
            p?.invoke()
        }
    }

    private val deviceListener = object : UtteranceProgressListener() {
        private fun parse(id: String?): Pair<Long, Int>? {
            val parts = id?.split(":") ?: return null
            if (parts.size != 3 || parts[0] != "rz") return null
            return (parts[1].toLongOrNull() ?: return null) to (parts[2].toIntOrNull() ?: return null)
        }

        override fun onStart(utteranceId: String?) {
            val (session, index) = parse(utteranceId) ?: return
            if (!isCurrent(session)) return
            deviceIndex = index
            _loadingItemId.value = null
        }

        override fun onDone(utteranceId: String?) {
            val (session, index) = parse(utteranceId) ?: return
            if (isCurrent(session) && !_isPaused.value && index >= deviceChunks.lastIndex) finishSession(session)
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            val (session, _) = parse(utteranceId) ?: return
            if (!_isPaused.value) finishSession(session)
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            val (session, _) = parse(utteranceId) ?: return
            Log.w(SPEECH_TAG, "Device TTS error $errorCode")
            if (!_isPaused.value) finishSession(session)
        }
    }

    private fun startDeviceSpeech(session: Long, itemId: String, req: NarrationRequest, text: String) {
        val begin = begin@{
            if (!isCurrent(session)) return@begin
            val engine = tts
            if (!ttsReady || engine == null) { finishSession(session); return@begin }

            val available = configureDeviceVoice(engine, req.device.locales, req.voice.gender)
            val spoken: String = when {
                available != null -> text
                req.device.transliterationFallback != null &&
                    configureDeviceVoice(engine, listOf(Locale.US, Locale.UK, Locale.ENGLISH), req.voice.gender) != null ->
                    req.device.transliterationFallback
                else -> {
                    Log.w(SPEECH_TAG, "No on-device voice for ${req.language}; ending narration quietly")
                    finishSession(session)
                    return@begin
                }
            }
            engine.setSpeechRate(req.device.rate)
            deviceChunks = NarrationChunker.split(spoken, 220, 600).map { it.text }.ifEmpty { listOf(spoken) }
            deviceIndex = 0
            deviceSession = session
            deviceItemId = itemId
            deviceActive = true
            speakDeviceFrom(session, itemId, 0)
        }

        _loadingItemId.value = itemId // stays "loading" until the engine reports onStart
        ensureDeviceTts()
        if (ttsInitDone) {
            begin()
        } else {
            pendingDeviceStart = begin
            scope.launch {
                delay(DEVICE_INIT_TIMEOUT_MS)
                if (!ttsInitDone && isCurrent(session)) {
                    pendingDeviceStart = null
                    finishSession(session) // never stay stuck in loading
                }
            }
        }
    }

    private fun speakDeviceFrom(session: Long, itemId: String, startIndex: Int) {
        val engine = tts ?: return
        val chunks = deviceChunks
        if (!isCurrent(session) || startIndex !in chunks.indices) return
        for (i in startIndex until chunks.size) {
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "rz:$session:$i")
            }
            engine.speak(
                chunks[i],
                if (i == startIndex) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                params,
                "rz:$session:$i"
            )
        }
    }

    /**
     * Voice selection tiers (never knowingly the opposite gender):
     *  1. MATCHED        – an installed voice classified as the requested gender, best quality first.
     *  2. UNKNOWN_GENDER – an unclassified voice, nudged toward the requested gender with pitch.
     *  3. OPPOSITE_ONLY  – ONLY when every voice for the language is known to be the other gender
     *                      (rare); spoken with strong pitch compensation and logged, because ending
     *                      silently would be worse for the user.
     * Returns the locale used, or null when the language isn't installed at all.
     */
    private fun configureDeviceVoice(engine: TextToSpeech, locales: List<Locale>, gender: NarrationGender): Locale? {
        data class Candidate(val locale: Locale, val voice: Voice?, val match: DeviceMatch)
        var best: Candidate? = null

        for (loc in locales) {
            if (engine.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) continue
            val (v, match) = pickVoice(engine, loc, gender)
            val cand = Candidate(loc, v, match)
            if (best == null || cand.match.ordinal < best.match.ordinal) best = cand
            if (match == DeviceMatch.MATCHED) break
        }
        val chosen = best ?: return null
        engine.language = chosen.locale
        chosen.voice?.let { runCatching { engine.voice = it } }
        engine.setPitch(DeviceVoiceGender.compensationPitch(gender, chosen.match))
        if (chosen.match == DeviceMatch.OPPOSITE_ONLY) {
            Log.w(SPEECH_TAG, "Only opposite-gender device voices for ${chosen.locale}; using pitch compensation")
        }
        return chosen.locale
    }

    private fun pickVoice(engine: TextToSpeech, locale: Locale, gender: NarrationGender): Pair<Voice?, DeviceMatch> {
        val lockKey = "${locale.language.lowercase(Locale.US)}_${locale.country}_${gender.name}"
        lockedLocalVoices[lockKey]?.let { return it to DeviceMatch.MATCHED }

        val voices = runCatching { engine.voices }.getOrNull().orEmpty()
            .filter { it.locale.language.equals(locale.language, ignoreCase = true) }

        fun score(v: Voice): Int {
            val n = v.name.lowercase(Locale.US)
            var s = v.quality
            if (v.locale.country.equals(locale.country, ignoreCase = true)) s += 60
            if (v.quality >= Voice.QUALITY_VERY_HIGH) s += 180 else if (v.quality >= Voice.QUALITY_HIGH) s += 110
            if (n.contains("neural") || n.contains("wavenet") || n.contains("studio") || n.contains("journey")) s += 220
            if (n.contains("network")) s += 55
            if (!v.isNetworkConnectionRequired) s += 20
            return s
        }

        val classified = voices.map { v ->
            v to DeviceVoiceGender.classify(v.name, v.features?.joinToString(" ").orEmpty())
        }
        classified.filter { it.second == gender }.maxByOrNull { score(it.first) }?.let { (v, _) ->
            lockedLocalVoices[lockKey] = v
            return v to DeviceMatch.MATCHED
        }
        classified.filter { it.second == null }.maxByOrNull { score(it.first) }?.let { (v, _) ->
            return v to DeviceMatch.UNKNOWN_GENDER
        }
        classified.maxByOrNull { score(it.first) }?.let { (v, _) -> return v to DeviceMatch.OPPOSITE_ONLY }
        // Engine exposes no voice list: keep its default voice and compensate with pitch.
        return null to DeviceMatch.UNKNOWN_GENDER
    }

    init {
        // Everything that can be warmed before the first tap is warmed here, off the UI thread.
        scope.launch { runCatching { cache.cleanup() } }
        scope.launch {
            runCatching { modelFor(preferredBackend, voice) }
            runCatching { createPcmAudioTrack(PCM_SAMPLE_RATE).release() } // loads the audio output path
        }
        scope.launch(Dispatchers.Main) { runCatching { ensureDeviceTts() } }
    }

    companion object {
        /** Kept for compatibility; delegates to [NarrationChunker]. */
        fun splitIntoLowLatencyChunks(
            text: String,
            firstChunkMax: Int = 130,
            nextChunkMax: Int = 380
        ): List<String> =
            NarrationChunker.split(text, firstChunkMax, nextChunkMax).map { it.text }.ifEmpty { listOf(text.trim()) }

        fun expandIslamicHonorificsForSpeech(input: String, isBangla: Boolean): String {
            if (input.isBlank()) return input
            val saw = if (isBangla) "সাল্লাল্লাহু আলাইহি ওয়া সাল্লাম" else "Sallallahu Alayhi Wasallam"
            val aS = if (isBangla) "আলাইহিস সালাম" else "Alayhis Salam"
            val rA = if (isBangla) "রাদিয়াল্লাহু আনহু" else "Radiyallahu Anhu"
            val swt = if (isBangla) "সুবহানাহু ওয়া তাআলা" else "Subhanahu wa Ta'ala"
            val rh = if (isBangla) "রাহিমাহুল্লাহ" else "Rahimahullah"

            return input
                .replace("(ﷺ)", " $saw ")
                .replace("ﷺ", " $saw ")
                .replace(Regex("\\(\\s*(?:SAW|S\\.A\\.W\\.?|PBUH|P\\.B\\.U\\.H\\.?|sm\\.?|সা\\.?|সাল্লাল্লাহু)\\s*\\)", RegexOption.IGNORE_CASE), " $saw ")
                .replace(Regex("\\b(?:S\\.A\\.W\\.|P\\.B\\.U\\.H\\.|sm\\.)(?=\\s|[.,;:!?]|$)", RegexOption.IGNORE_CASE), " $saw ")
                .replace(Regex("\\(\\s*(?:AS|A\\.S\\.?|আ\\.?|আলাইহিস সালাম)\\s*\\)", RegexOption.IGNORE_CASE), " $aS ")
                .replace(Regex("\\bA\\.S\\.(?=\\s|[.,;:!?]|$)", RegexOption.IGNORE_CASE), " $aS ")
                .replace(Regex("\\(\\s*(?:RA|R\\.A\\.?|রা\\.?|রাদিয়াল্লাহু)\\s*\\)", RegexOption.IGNORE_CASE), " $rA ")
                .replace(Regex("\\bR\\.A\\.(?=\\s|[.,;:!?]|$)", RegexOption.IGNORE_CASE), " $rA ")
                .replace(Regex("\\(\\s*(?:SWT|S\\.W\\.T\\.?)\\s*\\)", RegexOption.IGNORE_CASE), " $swt ")
                .replace(Regex("\\(\\s*(?:RH|R\\.H\\.?|রহ\\.?)\\s*\\)", RegexOption.IGNORE_CASE), " $rh ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        fun normalizeArabicWaqfForSpeech(input: String): String {
            if (input.isBlank()) return input
            var s = input
                .replace("اللَّهُ أَكْبَرُ", "اللَّهُ أَكْبَرْ")
                .replace("اللهُ أَكْبَرُ", "اللهُ أَكْبَرْ")
                .replace("أَكْبَرُ", "أَكْبَرْ")
                .replace("سُبْحَانَ اللَّهِ", "سُبْحَانَ اللَّهْ")
                .replace("سُبْحَانَ اللهِ", "سُبْحَانَ اللهْ")
                .replace("الْحَمْدُ لِلَّهِ", "الْحَمْدُ لِلَّهْ")
                .replace("الْحَمْدُ للهِ", "الْحَمْدُ للهْ")
                .replace("أَسْتَغْفِرُ اللَّهَ", "أَسْتَغْفِرُ اللَّهْ")
                .replace("أَسْتَغْفِرُ اللهَ", "أَسْتَغْفِرُ اللهْ")
                .replace("لَا إِلَهَ إِلَّا اللَّهُ", "لَا إِلَهَ إِلَّا اللَّهْ")
                .replace("لَا إِلٰهَ إِلَّا اللهُ", "لَا إِلٰهَ إِلَّا اللهْ")
                .replace("وَبِحَمْدِهِ", "وَبِحَمْدِهْ")
                .replace("الْعَظِيمِ", "الْعَظِيمْ")
                .replace("الْعَظِيمَ", "الْعَظِيمْ")

            s = s.replace(Regex("([\u0621-\u064A\u0671])[\u064B-\u0650]+(?=\\s*([.,،؛:!؟\\n]|$))"), "$1\u0652")
            return s
        }
    }
}
