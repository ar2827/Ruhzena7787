package com.example.ruhzena.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.local.HabitCheckEntity
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.data.local.WorkoutLogEntity
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private enum class HomeGraphMetric { HYDRATION, HABITS, WORKOUTS, BALANCE }

/**
 * Interactive Digital Analytics Graph Card for the Home Dashboard.
 * Plots real 7-day telemetry with smooth animated cubic-Bezier spline draw-in, luminous gradient
 * area fill, glowing live data nodes, and interactive day-by-day inspection.
 */
@Composable
fun HomeDigitalAnalyticsCard(
    isBn: Boolean,
    hydrationGoalMl: Int,
    waterMlToday: Int,
    habitsDoneToday: Int,
    totalHabits: Int,
    workoutsToday: Int,
    caloriesToday: Int,
    weeklyWaterLogs: List<WaterLogEntity>,
    habitChecks30Days: List<HabitCheckEntity>,
    recentWorkouts: List<WorkoutLogEntity>,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    var activeMetric by remember { mutableStateOf(HomeGraphMetric.HYDRATION) }
    var selectedDayIdx by remember { mutableIntStateOf(6) }

    val daySlots = remember(isBn) {
        val keyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val shortFmt = SimpleDateFormat("EEE", Locale.US)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -6)
        (0..6).map {
            val key = keyFmt.format(cal.time)
            val labelEn = shortFmt.format(cal.time).take(3)
            val labelBn = when (cal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SATURDAY -> "শনি"
                Calendar.SUNDAY -> "রবি"
                Calendar.MONDAY -> "সোম"
                Calendar.TUESDAY -> "মঙ্গল"
                Calendar.WEDNESDAY -> "বুধ"
                Calendar.THURSDAY -> "বৃহঃ"
                else -> "শুক্র"
            }
            cal.add(Calendar.DAY_OF_YEAR, 1)
            key to (if (isBn) labelBn else labelEn)
        }
    }

    val seriesData: List<Float> = remember(
        activeMetric, daySlots, weeklyWaterLogs, habitChecks30Days, recentWorkouts,
        waterMlToday, habitsDoneToday, totalHabits, workoutsToday, caloriesToday, hydrationGoalMl
    ) {
        val waterByDay = weeklyWaterLogs.groupBy { it.dateKey }.mapValues { (_, list) -> list.sumOf { it.amountMl } }
        val habitsByDay = habitChecks30Days.groupBy { it.dateKey }.mapValues { (_, list) -> list.map { it.habitId }.toSet().size }
        val workoutsByDay = recentWorkouts.groupBy { it.dateKey }.mapValues { (_, list) -> list.sumOf { it.durationMinutes } }
        val safeWaterGoal = hydrationGoalMl.coerceAtLeast(1500).toFloat()
        val safeHabits = totalHabits.coerceAtLeast(1).toFloat()

        daySlots.mapIndexed { idx, (key, _) ->
            val isToday = idx == 6
            when (activeMetric) {
                HomeGraphMetric.HYDRATION -> {
                    val ml = if (isToday) maxOf(waterMlToday, waterByDay[key] ?: 0) else (waterByDay[key] ?: 0)
                    ml.toFloat()
                }
                HomeGraphMetric.HABITS -> {
                    val done = if (isToday) maxOf(habitsDoneToday, habitsByDay[key] ?: 0) else (habitsByDay[key] ?: 0)
                    done.toFloat()
                }
                HomeGraphMetric.WORKOUTS -> {
                    val mins = workoutsByDay[key] ?: 0
                    val effective = if (isToday && mins == 0 && workoutsToday > 0) workoutsToday * 15 else mins
                    effective.toFloat()
                }
                HomeGraphMetric.BALANCE -> {
                    val wPct = ((if (isToday) maxOf(waterMlToday, waterByDay[key] ?: 0) else (waterByDay[key] ?: 0)) / safeWaterGoal).coerceIn(0f, 1f)
                    val hPct = ((if (isToday) maxOf(habitsDoneToday, habitsByDay[key] ?: 0) else (habitsByDay[key] ?: 0)) / safeHabits).coerceIn(0f, 1f)
                    val wkPct = ((workoutsByDay[key] ?: 0) / 25f).coerceIn(0f, 1f)
                    val calBoost = if (isToday && caloriesToday > 0) 0.15f else 0f
                    ((wPct * 0.40f + hPct * 0.40f + wkPct * 0.20f + calBoost).coerceIn(0f, 1f) * 100f)
                }
            }
        }
    }

    val maxVal = remember(activeMetric, seriesData, hydrationGoalMl, totalHabits) {
        val rawMax = seriesData.maxOrNull() ?: 0f
        when (activeMetric) {
            HomeGraphMetric.HYDRATION -> maxOf(rawMax, hydrationGoalMl.toFloat(), 2000f)
            HomeGraphMetric.HABITS -> maxOf(rawMax, totalHabits.toFloat(), 5f)
            HomeGraphMetric.WORKOUTS -> maxOf(rawMax, 30f)
            HomeGraphMetric.BALANCE -> 100f
        }
    }

    val lineColor = when (activeMetric) {
        HomeGraphMetric.HYDRATION -> palette.sky
        HomeGraphMetric.HABITS -> palette.accentSoft
        HomeGraphMetric.WORKOUTS -> palette.gold
        HomeGraphMetric.BALANCE -> palette.amber
    }

    val unitSuffix = when (activeMetric) {
        HomeGraphMetric.HYDRATION -> "ml"
        HomeGraphMetric.HABITS -> if (isBn) "টি" else "done"
        HomeGraphMetric.WORKOUTS -> "min"
        HomeGraphMetric.BALANCE -> "%"
    }

    val drawProgress = remember(activeMetric) { Animatable(0f) }
    LaunchedEffect(activeMetric, seriesData) {
        drawProgress.snapTo(0f)
        drawProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 720, easing = FastOutSlowInEasing)
        )
    }

    val selVal = seriesData.getOrElse(selectedDayIdx) { 0f }.toInt()
    val selDayLabel = daySlots.getOrElse(selectedDayIdx) { "" to "" }.second
    val avgVal = (seriesData.average()).toInt()

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_digital_analytics_card"),
        elevated = true,
        accentBorder = true
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(lineColor.copy(alpha = 0.16f), RoundedCornerShape(10.dp))
                        .border(0.8.dp, lineColor.copy(alpha = 0.50f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Insights, contentDescription = null, tint = lineColor, modifier = Modifier.size(18.dp))
                }
                Column {
                    Text(
                        text = if (isBn) "৭-দিনের ডিজিটাল অ্যানালিটিক্স" else "7-Day Live Analytics",
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isBn) "গড়: $avgVal $unitSuffix • $selDayLabel: $selVal $unitSuffix"
                        else "7d Avg: $avgVal $unitSuffix • $selDayLabel: $selVal $unitSuffix",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = lineColor
                    )
                }
            }
            StatusPillBadge(
                label = "$selVal $unitSuffix",
                accentColor = lineColor
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Metric Selector Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                HomeGraphMetric.HYDRATION to (if (isBn) "পানি" else "Water"),
                HomeGraphMetric.HABITS to (if (isBn) "অভ্যাস" else "Habits"),
                HomeGraphMetric.WORKOUTS to (if (isBn) "ব্যায়াম" else "Workout"),
                HomeGraphMetric.BALANCE to (if (isBn) "স্কোর" else "Score")
            ).forEach { (metric, label) ->
                GlassFilterChip(
                    label = label,
                    selected = activeMetric == metric,
                    onClick = { activeMetric = metric },
                    modifier = Modifier.weight(1f).testTag("home_graph_tab_${metric.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Animated Digital Spline Graph Stage
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(148.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(palette.voidBg.copy(alpha = if (palette.isLight) 0.55f else 0.72f))
                .border(0.8.dp, lineColor.copy(alpha = 0.28f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val padX = 12f
                val padTop = 10f
                val padBottom = 10f
                val plotW = (size.width - padX * 2f).coerceAtLeast(10f)
                val plotH = (size.height - padTop - padBottom).coerceAtLeast(10f)

                // Digital telemetry horizontal gridlines
                val gridColor = palette.textMuted.copy(alpha = 0.18f)
                for (g in 0..3) {
                    val gy = padTop + plotH * (g / 3f)
                    drawLine(gridColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1.1f)
                }

                // Compute 7 data points
                val pts = seriesData.mapIndexed { idx, value ->
                    val norm = (value / maxVal).coerceIn(0f, 1f)
                    val x = padX + (plotW * idx / 6f)
                    val y = padTop + plotH * (1f - norm)
                    Offset(x, y)
                }

                // Build smooth cubic-Bezier curve path
                val curvePath = Path().apply {
                    moveTo(pts.first().x, pts.first().y)
                    for (i in 0 until pts.size - 1) {
                        val p0 = pts[i]
                        val p1 = pts[i + 1]
                        val cx = (p0.x + p1.x) * 0.5f
                        cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                    }
                }

                val fillPath = Path().apply {
                    addPath(curvePath)
                    lineTo(pts.last().x, padTop + plotH)
                    lineTo(pts.first().x, padTop + plotH)
                    close()
                }

                // Animated left-to-right reveal sweep
                clipRect(right = size.width * drawProgress.value) {
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                lineColor.copy(alpha = 0.36f),
                                lineColor.copy(alpha = 0.04f)
                            ),
                            startY = padTop,
                            endY = padTop + plotH
                        )
                    )
                    // Outer neon digital glow stroke
                    drawPath(
                        path = curvePath,
                        color = lineColor.copy(alpha = 0.28f),
                        style = Stroke(width = 8.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                    // Crisp core curve stroke
                    drawPath(
                        path = curvePath,
                        color = lineColor,
                        style = Stroke(width = 3.2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )

                    // Vertical drop guide on selected day
                    val selPt = pts[selectedDayIdx.coerceIn(pts.indices)]
                    drawLine(
                        color = lineColor.copy(alpha = 0.45f),
                        start = Offset(selPt.x, selPt.y),
                        end = Offset(selPt.x, padTop + plotH),
                        strokeWidth = 1.6f
                    )

                    // Data point nodes
                    pts.forEachIndexed { idx, p ->
                        val isSel = idx == selectedDayIdx
                        if (isSel) {
                            drawCircle(color = lineColor.copy(alpha = 0.30f), radius = 12f, center = p)
                        }
                        drawCircle(color = palette.surfaceBg, radius = if (isSel) 6.5f else 4.5f, center = p)
                        drawCircle(
                            color = lineColor,
                            radius = if (isSel) 6.5f else 4.5f,
                            center = p,
                            style = Stroke(width = if (isSel) 3.0f else 2.2f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Interactive Day Picker Row (tap any day to inspect live telemetry)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            daySlots.forEachIndexed { idx, (_, label) ->
                val isSel = idx == selectedDayIdx
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSel) lineColor.copy(alpha = 0.18f) else Color.Transparent)
                        .border(
                            width = if (isSel) 0.9.dp else 0.dp,
                            color = if (isSel) lineColor.copy(alpha = 0.65f) else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedDayIdx = idx }
                        .padding(horizontal = 7.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSel) lineColor else palette.textMuted
                    )
                }
            }
        }
    }
}
