package com.example.ruhzena.notifications

/**
 * Extended 450+ curated bilingual Hikmah & Motivation bank merged into [MotivationKnowledgeCatalog],
 * bringing the hourly rotation library to 520+ unique, non-repeating entries spanning:
 *  - Quranic Reflections & Tafsir
 *  - Sahih Hadiths & Sunnah Habits
 *  - Prophetic Seerah & Companions' Wisdom
 *  - Classical Islamic Scholars (Imam al-Ghazali, Ibn al-Qayyim, Imam al-Shafi'i, Hasan al-Basri)
 *  - Universal Discipline, Focus, Resilience, Fitness & Mindset Mastery
 */
internal object MotivationWisdomBank {

    private data class Seed(
        val category: String,
        val titleEn: String,
        val bodyEn: String,
        val titleBn: String,
        val bodyBn: String,
        val sourceRef: String
    )

    private val curatedExtra: List<Seed> = listOf(
        // --- Universal Mindset, Discipline, Growth & Focus ---
        Seed("Mindset", "Small Steps Beat Zero", "A 5-minute honest effort today builds a stronger future than a perfect plan postponed until next week.", "ছোট পদক্ষেপ শূন্যের চেয়ে শ্রেয়", "আগামী সপ্তাহের নিখুঁত পরিকল্পনার চেয়ে আজকের ৫ মিনিটের আন্তরিক চেষ্টা অনেক শক্তিশালী।", "Daily Discipline Principle"),
        Seed("Discipline", "Protect Your First Hour", "Win the first 60 minutes after waking with prayer, water, and clarity—the rest of your day will follow your rhythm.", "দিনের প্রথম ঘণ্টা রক্ষা করুন", "ঘুম থেকে ওঠার প্রথম ৬০ মিনিট সালাত, পানি ও মনোযোগ দিয়ে শুরু করুন—পুরো দিন সুন্দর ছন্দে চলবে।", "Mindful Routine Wisdom"),
        Seed("Focus", "Single-Task With Excellence", "Multitasking fractures your peace and halves your quality. Close extra noise and finish one meaningful task with Ihsan.", "এক কাজে পূর্ণ মনোযোগ দিন", "একসাথে অনেক কাজ শান্তি ও মান কমিয়ে দেয়। অপ্রয়োজনীয় শব্দ বন্ধ করে এক কাজে ইহসান আনুন।", "Ihsan Productivity"),
        Seed("Resilience", "Storms Deepen Roots", "Trees grow their strongest roots during high winds. Let today's friction build steadiness rather than frustration.", "ঝড় শিকড়কে গভীর করে", "প্রবল বাতাসেই গাছের শিকড় শক্ত হয়। আজকের বাধাকে হতাশা নয়, দৃঢ়তার শক্তি বানান।", "Growth Mindset Reflection"),
        Seed("Discipline", "Action Cures Anxiety", "Overthinking magnifies fear; taking one clear, tiny step shrinks it. Pick the smallest next action and begin now.", "কাজ দুশ্চিন্তা কমায়", "অতিরিক্ত চিন্তা ভয় বাড়ায়; একটি ছোট কার্যকর পদক্ষেপ তা কমিয়ে দেয়। এখনই ছোট ধাপটি নিন।", "Clarity Habit"),
        Seed("Mindset", "Compare With Yesterday's Self", "Your only fair measure is who you were yesterday. Grow 1% steadier in worship, kindness, and focus today.", "গতকালের নিজের সাথে তুলনা করুন", "সত্যিকারের তুলনা হলো গতকালের আপনার সাথে। আজ ইবাদত, দয়া ও মনোযোগে ১% এগিয়ে যান।", "Personal Mastery"),
        Seed("Wellness", "Posture Shapes Energy", "Uncurl your shoulders, take three slow deep breaths, and drink a glass of water—your brain responds immediately to your body.", "সঠিক ভঙ্গি শক্তি বাড়ায়", "কাঁধ সোজা করুন, তিনবার গভীর শ্বাস নিন এবং এক গ্লাস পানি পান করুন—শরীরের সাথে সাথে মনও সতেজ হবে।", "Holistic Wellness"),
        Seed("Discipline", "Keep Promises to Yourself", "Self-respect grows every time you do what you told yourself you would do—especially when nobody is watching.", "নিজের কাছে দেওয়া প্রতিশ্রুতি রাখুন", "নিজের সাথে করা ওয়াদা পূরণ করলে আত্মসম্মান বাড়ে—বিশেষত যখন কেউ দেখছে না।", "Integrity Principle"),
        Seed("Focus", "Guard Your Attention", "What you repeatedly give your eyes and ears becomes the climate of your heart. Curate your feeds deliberately.", "মনোযোগের হেফাজত করুন", "চোখ ও কান যা বারবার গ্রহণ করে, তা-ই অন্তরের আবহাওয়া তৈরি করে। সচেতনভাবে তথ্য নির্বাচন করুন।", "Digital Mindfulness"),
        Seed("Resilience", "Restart Without Guilt", "Stumbling once does not erase your journey. Make Istighfar, learn the trigger, and step back onto the path immediately.", "অপরাধবোধ নয়, নতুন শুরু", "একবার হোঁচট খেলে যাত্রা শেষ হয় না। ইস্তিগফার করুন, শিক্ষা নিন এবং সাথে সাথেই ফিরে আসুন।", "Steady Recovery"),
        Seed("Mindset", "Energy Follows Purpose", "When your work serves a higher purpose—helping family, learning truth, pleasing Allah—fatigue turns into quiet strength.", "উদ্দেশ্য শক্তি জোগায়", "আপনার কাজ যখন মহৎ উদ্দেশ্যে হয়—পরিবারের সেবা, সত্য শেখা, আল্লাহর সন্তুষ্টি—ক্লান্তিও শক্তিতে বদলে যায়।", "Purposeful Living"),
        Seed("Wellness", "Sleep Is Worship When Intended", "Resting on time so you can wake fresh for Fajr and serve others turns ordinary sleep into rewarded renewal.", "সঠিক নিয়তে ঘুমও ইবাদত", "ফজরের জন্য সতেজ হয়ে ওঠার নিয়তে সময়মতো ঘুমালে সাধারণ বিশ্রামও বরকতময় হয়ে ওঠে।", "Sunnah Lifestyle"),
        Seed("Discipline", "Systems Outlast Motivation", "Moods rise and fall every day. Anchor your prayer, hydration, and learning to fixed daily cues so habits run automatically.", "মোটিভেশনের চেয়ে সিস্টেম শক্তিশালী", "মনের অবস্থা বদলায়; তাই সালাত, পানি পান ও শেখাকে নির্দিষ্ট সময়ের সাথে যুক্ত করুন।", "Habit Architecture"),
        Seed("Character", "Speak With Calm Authority", "Raising your voice weakens your message. Calm words delivered with sincerity travel deeper into every heart.", "শান্ত কণ্ঠে গভীর প্রভাব", "চিৎকার কথাকে দুর্বল করে। আন্তরিকতা ও শান্ত স্বরের কথা প্রতিটি হৃদয়ে গভীরভাবে পৌঁছায়।", "Prophetic Composure"),
        Seed("Mindset", "Done Beats Delayed Perfection", "Perfectionism is often fear dressed in neat clothes. Complete the honest draft, the 10-minute workout, or the one page today.", "অসমাপ্ত নিখুঁততার চেয়ে সমাপ্ত চেষ্টা শ্রেয়", "নিখুঁত করার অজুহাতে কাজ ফেলে রাখবেন না। আজকের ১০ মিনিটের ব্যায়াম বা এক পৃষ্ঠা পড়াই সম্পন্ন করুন।", "Momentum Habit"),
        Seed("Resilience", "Gratitude Rewires Stress", "It is impossible for panic and genuine gratitude to occupy the same breath. Pause and thank Allah for three working blessings.", "কৃতজ্ঞতা মানসিক চাপ দূর করে", "একই নিঃশ্বাসে আতঙ্ক আর আন্তরিক কৃতজ্ঞতা থাকতে পারে না। থেমে তিনটি নিয়ামতের শুকরিয়া জানান।", "Heart Science"),
        Seed("Focus", "Deep Work Needs Silence", "Give yourself a 25-minute phone-free focus block today. You will finish more in calm silence than in three distracted hours.", "গভীর কাজের জন্য নীরবতা দরকার", "আজ ফোন দূরে রেখে ২৫ মিনিট একাগ্র কাজ করুন—বিক্ষিপ্ত ৩ ঘণ্টার চেয়ে বেশি ফল পাবেন।", "Deep Focus Method"),
        Seed("Wellness", "Move Before You Feel Ready", "Motion creates emotion. Five minutes of stretching or walking unlocks energy that sitting still will never deliver.", "প্রস্তুত হওয়ার আগেই নড়াচড়া করুন", "চলাফেরা শক্তি তৈরি করে। মাত্র ৫ মিনিট হাঁটা বা স্ট্রেচিং বসে থাকার ক্লান্তি দূর করে দেয়।", "Active Body Principle"),
        Seed("Discipline", "Respect Your Future Self", "Every disciplined choice today is a quiet gift you mail forward to your future self six months from now.", "ভবিষ্যৎ নিজেকে সম্মান করুন", "আজকের প্রতিটি সুশৃঙ্খল সিদ্ধান্ত ছয় মাস পরের আপনার জন্য একটি সুন্দর উপহার।", "Long-Term Thinking"),
        Seed("Mindset", "Curiosity Beats Judgment", "When something goes wrong, ask 'What can this teach me?' instead of 'Why me?' Growth starts where excuses stop.", "অভিযোগের বদলে কৌতূহল", "ভুল হলে 'আমার সাথেই কেন' না বলে জিজ্ঞাসা করুন 'এখান থেকে কী শিখব?' এখান থেকেই উন্নতি শুরু।", "Wisdom of Growth"),

        // --- Authentic Quranic Reflections ---
        Seed("Quran", "Allah Does Not Burden Beyond Capacity", "\"Allah does not charge a soul except [with that within] its capacity.\" Whatever stands before you today, He already placed the strength inside you.", "সাধ্যের বাইরে বোঝা নয়", "“আল্লাহ কাউকে তার সাধ্যের অতীত বোঝা চাপিয়ে দেন না।” আজ যে দায়িত্ব সামনে, তা বহনের শক্তিও তিনি দিয়েছেন।", "Quran 2:286"),
        Seed("Quran", "Remember Me, I Will Remember You", "\"So remember Me; I will remember you. And be grateful to Me and do not deny Me.\" The highest honor is being mentioned by the King of Heavens.", "আমাকে স্মরণ করো, আমিও তোমাদের স্মরণ করব", "“অতএব তোমরা আমাকে স্মরণ করো, আমিও তোমাদের স্মরণ করব।” রবের স্মরণে থাকা সবচেয়ে বড় মর্যাদা।", "Quran 2:152"),
        Seed("Quran", "Seek Help Through Patience & Prayer", "\"O you who have believed, seek help through patience and prayer. Indeed, Allah is with the patient.\"", "ধৈর্য ও সালাতের মাধ্যমে সাহায্য চাও", "“হে মুমিনগণ, ধৈর্য ও সালাতের মাধ্যমে সাহায্য প্রার্থনা করো। নিশ্চয়ই আল্লাহ ধৈর্যশীলদের সাথে আছেন।”", "Quran 2:153"),
        Seed("Quran", "A Good Word Is Like a Good Tree", "\"A good word is like a good tree whose root is firmly fixed and its branches reach the sky.\" Speak words that plant shade for others.", "উত্তম কথা উৎকৃষ্ট বৃক্ষের মতো", "“উত্তম কথা উৎকৃষ্ট বৃক্ষের মতো, যার মূল সুদৃঢ় এবং শাখা আকাশে বিস্তৃত।” মানুষের জন্য ছায়া হয় এমন কথা বলুন।", "Quran 14:24"),
        Seed("Quran", "Repel Evil With What Is Best", "\"Repel [evil] by that which is better; and thereupon the one whom between you and him is enmity will become as though he was a devoted friend.\"", "মন্দকে উত্তম আচরণ দিয়ে প্রতিহত করো", "“মন্দকে উত্তম আচরণ দ্বারা প্রতিহত করো; তখন শত্রুও প্রাণের বন্ধুর মতো হয়ে যাবে।”", "Quran 41:34"),
        Seed("Quran", "Allah Loves Those Who Rely on Him", "\"And when you have decided, then rely upon Allah. Indeed, Allah loves those who rely upon Him.\"", "দৃঢ় সংকল্পের পর আল্লাহর ওপর ভরসা করো", "“যখন তুমি দৃঢ় সংকল্প করবে, তখন আল্লাহর ওপর ভরসা করো। নিশ্চয়ই আল্লাহ ভরসাকারীদের ভালোবাসেন।”", "Quran 3:159"),
        Seed("Quran", "Do Not Lose Heart or Grieve", "\"So do not weaken and do not grieve, and you will be superior if you are [true] believers.\"", "হতাশ হয়ো না, দুঃখ কোরো না", "“তোমরা হীনবল হয়ো না এবং দুঃখিত হয়ো না; তোমরাই বিজয়ী হবে যদি মুমিন হও।”", "Quran 3:139"),
        Seed("Quran", "Every Atom of Good Is Seen", "\"So whoever does an atom's weight of good will see it.\" No quiet kindness, no hidden Dua, and no unseen restraint is ever wasted.", "অণু পরিমাণ ভালো কাজও বৃথা যাবে না", "“কেউ অণু পরিমাণ সৎকর্ম করলে তা দেখতে পাবে।” কোনো নীরব ভালো কাজ কখনো হারায় না।", "Quran 99:7"),
        Seed("Quran", "Whoever Fears Allah Finds a Way Out", "\"And whoever fears Allah — He will make for him a way out and provide for him from where he does not expect.\"", "তাকওয়াবানদের জন্য পথ খুলে দেওয়া হয়", "“যে আল্লাহকে ভয় করে, তিনি তার জন্য উত্তরণের পথ তৈরি করেন এবং অকল্পনীয় উৎস থেকে রিযিক দেন।”", "Quran 65:2-3"),
        Seed("Quran", "Speak to People Gently", "\"And speak to people good [words].\" Even a short, gentle greeting softens hearts and honors human dignity.", "মানুষের সাথে সুন্দর কথা বলো", "“মানুষের সাথে উত্তম ও সুন্দর কথা বলো।” কোমল আচরণ মানুষের মর্যাদা ও হৃদয়ের শান্তি বাড়ায়।", "Quran 2:83"),
        Seed("Quran", "My Mercy Encompasses All Things", "\"My mercy encompasses all things.\" Never let temporary regret convince you that the door of Allah's love has closed.", "আমার রহমত সব কিছুকে পরিবেষ্টন করে আছে", "“আমার রহমত সব কিছুকে পরিবেষ্টন করে আছে।” সাময়িক অনুতাপে কখনো রবের ভালোবাসা থেকে দূরে সরে যাবেন না।", "Quran 7:156"),
        Seed("Quran", "Race Toward Good Deeds", "\"So race to [all that is] good.\" Don't wait for ideal moods to help someone, read an ayah, or guard a prayer.", "কল্যাণের কাজে প্রতিযোগিতা করো", "“অতএব তোমরা সৎকাজে প্রতিযোগিতা করো।” ভালো কাজ শুরু করার জন্য নিখুঁত সময়ের অপেক্ষা করবেন না।", "Quran 2:148"),
        Seed("Quran", "Lower Your Wing of Humility to Parents", "\"And lower to them the wing of humility out of mercy and say: My Lord, have mercy upon them as they brought me up when I was small.\"", "মা-বাবার জন্য বিনয়ের ডানা বিছিয়ে দাও", "“তাদের প্রতি দয়ায় বিনয়ের ডানা নত করে দাও এবং বলো: হে রব, তাদের প্রতি দয়া করুন যেমন তাঁরা আমাকে শৈশবে লালন করেছেন।”", "Quran 17:24"),
        Seed("Quran", "He Is With You Wherever You Are", "\"And He is with you wherever you are.\" You are never truly alone in a quiet room, a difficult exam, or a lonely night.", "তোমরা যেখানেই থাকো, তিনি তোমাদের সাথে আছেন", "“তোমরা যেখানেই থাকো না কেন, তিনি তোমাদের সাথেই আছেন।” কঠিন মুহূর্তেও আপনি কখনো একা নন।", "Quran 57:4"),
        Seed("Quran", "Establish Prayer at Both Ends of the Day", "\"Indeed, good deeds do away with misdeeds.\" Let your next sincere prayer wash away the dust of earlier mistakes.", "নেক কাজ মন্দ কাজকে মুছে দেয়", "“নিশ্চয়ই সৎকাজ অসৎকাজকে দূর করে দেয়।” পরের আন্তরিক সালাতই আগের ভুলের ধুলো মুছে দিক।", "Quran 11:114"),

        // --- Authentic Sahih Hadiths & Sunnah ---
        Seed("Hadith", "The Best of You Are Best in Character", "The Prophet (ﷺ) said: \"The best among you are those who have the best manners and character.\"", "তোমাদের মধ্যে উত্তম চরিত্রবানরাই শ্রেষ্ঠ", "নবী (ﷺ) বলেছেন: “তোমাদের মধ্যে সর্বোত্তম হলো যারা চরিত্রে সবচেয়ে সুন্দর।”", "Sahih al-Bukhari 3559"),
        Seed("Hadith", "Make Things Easy, Not Difficult", "The Prophet (ﷺ) instructed: \"Make things easy and do not make them difficult; give glad tidings and do not repel people.\"", "সহজ করো, কঠিন কোরো না", "নবী (ﷺ) বলেছেন: “সহজ করো, কঠিন কোরো না; সুসংবাদ দাও, মানুষকে বিমুখ কোরো না।”", "Sahih al-Bukhari 69"),
        Seed("Hadith", "Charity Never Decreases Wealth", "\"Charity does not decrease wealth, no one forgives except that Allah increases his honor, and no one humbles himself for Allah except that Allah raises him.\"", "সদকায় সম্পদ কখনো কমে না", "“সদকা সম্পদ কমায় না, ক্ষমা করলে আল্লাহ সম্মান বাড়ান এবং বিনয়ী হলে আল্লাহ মর্যাদা উঁচু করেন।”", "Sahih Muslim 2588"),
        Seed("Hadith", "Purity Is Half of Faith", "\"Cleanliness is half of faith, Alhamdulillah fills the scale, and SubhanAllah and Alhamdulillah fill what is between heaven and earth.\"", "পবিত্রতা ঈমানের অর্ধেক", "“পবিত্রতা ঈমানের অর্ধেক, আলহামদুলিল্লাহ মিযান পূর্ণ করে দেয়।”", "Sahih Muslim 223"),
        Seed("Hadith", "Help Your Brother, Allah Helps You", "\"Allah continues to help the servant so long as the servant continues to help his brother.\"", "বান্দার সাহায্যে আল্লাহর সাহায্য", "“বান্দা যতক্ষণ তার ভাইয়ের সাহায্যে থাকে, আল্লাহ ততক্ষণ তার সাহায্যে থাকেন।”", "Sahih Muslim 2699"),
        Seed("Hadith", "Mercy Earns Mercy", "\"The merciful are shown mercy by the Most Merciful. Be merciful to those on earth, and the One above the heavens will have mercy upon you.\"", "দয়াশীলদের প্রতি দয়াময় দয়া করেন", "“দয়াশীলদের ওপর দয়াময় আল্লাহ দয়া করেন। পৃথিবীবাসীর প্রতি দয়া করো, আসমানের মালিক তোমার প্রতি দয়া করবেন।”", "Jami' at-Tirmidhi 1924"),
        Seed("Hadith", "Every Joint Owes Daily Charity", "Every good word, every step to prayer, removing harm from a path, and helping someone carry a load counts as charity for your joints.", "প্রতিটি জোড়ার জন্য দৈনিক সদকা", "উত্তম কথা, সালাতের প্রতিটি কদম, রাস্তা থেকে কষ্টদায়ক বস্তু সরানো—সবই সদকা হিসেবে গণ্য হয়।", "Sahih al-Bukhari 2989"),
        Seed("Hadith", "Wondrous Is the Affair of the Believer", "\"Wondrous is the affair of the believer! If good reaches him he is grateful, and if hardship touches him he is patient—and both are good for him.\"", "মুমিনের বিষয় কতই না বিস্ময়কর!", "“মুমিনের বিষয় বিস্ময়কর! সুখে শুকরিয়া আর দুঃখে ধৈর্য—দুটোই তার জন্য কল্যাণকর।”", "Sahih Muslim 2999"),
        Seed("Hadith", "Allah Looks at Hearts and Deeds", "\"Verily Allah does not look at your appearances or wealth, rather He looks at your hearts and your actions.\"", "আল্লাহ অন্তর ও আমলের দিকে তাকান", "“নিশ্চয়ই আল্লাহ তোমাদের চেহারা ও সম্পদ দেখেন না, বরং তিনি তোমাদের অন্তর ও আমল দেখেন।”", "Sahih Muslim 2564"),
        Seed("Hadith", "A Good Word Is Charity", "Never underestimate the power of an encouraging sentence, a sincere thank-you, or a gentle apology—each is written as charity.", "উত্তম কথা বলাও সদকা", "একটি উৎসাহমূলক বাক্য, আন্তরিক ধন্যবাদ কিংবা বিনীত ক্ষমা চাওয়াকে ছোট ভাববেন না—প্রতিটিই সদকা।", "Sahih al-Bukhari 2989"),
        Seed("Sunnah", "Begin With Bismillah", "Starting your work, meals, study, and travel with Bismillah invites barakah (quiet unseen blessing) into ordinary minutes.", "বিসমিল্লাহ দিয়ে শুরু করুন", "কাজ, খাবার, পড়াশোনা ও যাত্রা বিসমিল্লাহ বলে শুরু করলে সাধারণ সময়েও বরকত নেমে আসে।", "Sunnah Practice"),
        Seed("Sunnah", "Pause & Drink Seated", "When tired or stressed, pause your screen, sit down properly, and drink water mindfully in three sips following the Prophetic Sunnah.", "বসে মনোযোগে পানি পান করুন", "ক্লান্তি বা চাপে স্ক্রিন থেকে চোখ সরিয়ে বসে তিন শ্বাসে সুন্নাহ মেনে পানি পান করুন।", "Sahih Muslim 2028"),
        Seed("Sunnah", "Walk With Purposeful Stride", "The Prophet (ﷺ) walked briskly with calm dignity, never slouching or dragging his feet. Move your body with purposeful energy today.", "উদ্যমী ও গাম্ভীর্যপূর্ণ হাঁটা", "নবী (ﷺ) স্থির গাম্ভীর্য ও প্রাণবন্ত ভঙ্গিতে হাঁটতেন। আজ উদ্যমের সাথে শরীর সচল রাখুন।", "Shama'il al-Tirmidhi"),
        Seed("Sunnah", "Spread Peace With Warm Salam", "\"Spread Salam among yourselves\"—initiate Assalamu Alaikum warmly to family and neighbors to dissolve coldness and build love.", "আন্তরিক সালামের প্রসার ঘটান", "“তোমাদের মাঝে সালামের প্রসার ঘটাও”—আন্তরিক আসসালামু আলাইকুম মানুষের মাঝে ভালোবাসা বাড়ায়।", "Sahih Muslim 54"),
        Seed("Sunnah", "Evening Reflection & Forgiveness", "Before sleep, forgive those who annoyed you today and say SubhanAllah 33, Alhamdulillah 33, Allahu Akbar 34 for a light, rested heart.", "ঘুমের আগে হৃদয় হালকা করুন", "ঘুমানোর আগে অন্যকে ক্ষমা করুন এবং তাসবিহে ফাতেমী পড়ে প্রশান্ত মনে বিশ্রাম নিন।", "Sahih al-Bukhari 3113"),

        // --- Classical Scholarly Gems ---
        Seed("Wisdom", "Guard the Moments of Life", "Hasan al-Basri said: \"O son of Adam, you are only a collection of days; whenever a day passes, a part of you has passed.\" Spend this hour meaningfully.", "সময়ই জীবনের মূলধন", "হাসান বসরী (রহ.) বলেন: “হে আদম সন্তান, তুমি কেবল কিছু দিনের সমষ্টি; একটি দিন চলে যাওয়া মানে তোমার একটি অংশ চলে যাওয়া।”", "Hasan al-Basri"),
        Seed("Wisdom", "Knowledge Demands Action", "Imam al-Shafi'i reminded seekers that knowledge is not merely what is memorized, but what benefits your character and actions.", "আমলই জ্ঞানের প্রাণ", "ইমাম শাফেয়ী (রহ.) বলেন: কেবল মুখস্থ করা জ্ঞান নয়, বরং যা উপকার করে ও আমলে আসে তা-ই প্রকৃত জ্ঞান।", "Imam al-Shafi'i"),
        Seed("Wisdom", "Cure the Heart Through Dhikr", "Ibn al-Qayyim noted that Dhikr is to the heart what water is to a fish—without it, the soul feels breathless even in comfort.", "যিকির অন্তরের প্রাণবায়ু", "ইবনুল কাইয়্যিম (রহ.) বলেন: মাছের জন্য পানি যেমন, অন্তরের জন্য আল্লাহর যিকির তেমনই অপরিহার্য।", "Al-Wabil al-Sayyib"),
        Seed("Wisdom", "Gentleness Wins What Harshness Breaks", "Imam al-Ghazali taught that correcting someone gently in private heals, while shaming them publicly only hardens the soul.", "নম্রতা হৃদয় জয় করে", "ইমাম গাজ্জালী (রহ.) শেখান: গোপনে নম্রভাবে সংশোধন করলে মানুষ বদলায়, আর জনসমক্ষে লজ্জা দিলে মন শক্ত হয়ে যায়।", "Ihya Ulum al-Din"),
        Seed("Wisdom", "Sincerity Is Quiet Power", "Umar ibn al-Khattab (RA) advised: \"Hold yourselves accountable before you are held accountable.\" Spend two quiet minutes reviewing today.", "আত্মসমালোচনাই উন্নতির চাবিকাঠি", "উমর (রা.) বলেছেন: “হিসাব নেওয়া হওয়ার আগেই নিজেদের হিসাব নাও।” আজকের কাজ দুই মিনিট পর্যালোচনা করুন।", "Umar ibn al-Khattab (RA)")
    )

    private data class PillarTheme(
        val category: String,
        val focusEn: String,
        val focusBn: String,
        val sourceRef: String
    )

    private data class ActionAnchor(
        val titlePrefixEn: String,
        val titlePrefixBn: String,
        val promptEn: String,
        val promptBn: String
    )

    /**
     * Generates 400+ distinct, deeply meaningful, non-repetitive bilingual reflection & motivation cards
     * pairing 20 timeless spiritual/mindset pillars with 20 distinct practical daily actions (20 x 20 = 400),
     * plus 55 curated bespoke gems above = 455 items (+ 72 base catalog = 527 unique hourly items!).
     */
    private val pillars: List<PillarTheme> = listOf(
        PillarTheme("Quran", "Tawakkul (Trust in Allah)", "তাওয়াক্কুল (আল্লাহর ওপর ভরসা)", "Quran 65:3"),
        PillarTheme("Hadith", "Ihsan (Quiet Excellence)", "ইহসান (নীরব উৎকর্ষতা)", "Sahih Muslim 8"),
        PillarTheme("Sunnah", "Shukr (Active Gratitude)", "শুকর (সক্রিয় কৃতজ্ঞতা)", "Quran 14:7"),
        PillarTheme("Mindset", "Sabr (Calm Steadfastness)", "সবর (শান্ত দৃঢ়তা)", "Quran 2:153"),
        PillarTheme("Discipline", "Istiqamah (Daily Consistency)", "ইস্তিকামাহ (দৈনিক ধারাবাহিকতা)", "Sahih al-Bukhari 6464"),
        PillarTheme("Character", "Rahmah (Gentle Compassion)", "রহমাহ (কোমল দয়া)", "Jami' at-Tirmidhi 1924"),
        PillarTheme("Focus", "Khushu (Deep Presence)", "খুশু (গভীর একাগ্রতা)", "Quran 23:2"),
        PillarTheme("Wellness", "Amanah of the Body", "শরীরের আমানত রক্ষা", "Sahih al-Bukhari 5199"),
        PillarTheme("Wisdom", "Muhasabah (Honest Self-Check)", "মুহাসাবাহ (আত্মপর্যালোচনা)", "Quran 59:18"),
        PillarTheme("Resilience", "Tawbah (Fresh New Start)", "তাওবাহ (নতুন সূচনা)", "Quran 39:53"),
        PillarTheme("Mindset", "Barakah in Early Hours", "ভোরের সময়ের বরকত", "Jami' at-Tirmidhi 1212"),
        PillarTheme("Character", "Hilm (Calm Over Anger)", "হিলম (রাগের ওপর নিয়ন্ত্রণ)", "Sahih al-Bukhari 6114"),
        PillarTheme("Discipline", "Purposeful Intention (Niyyah)", "বিশুদ্ধ নিয়ত ও লক্ষ্য", "Sahih al-Bukhari 1"),
        PillarTheme("Focus", "Guarding Eyes & Attention", "চোখ ও মনোযোগের সংযম", "Quran 24:30"),
        PillarTheme("Sunnah", "Generous Service (Khidmah)", "মানুষের সেবায় উদারতা", "Sahih Muslim 2699"),
        PillarTheme("Wellness", "Balanced Rest & Hydration", "পরিমিত বিশ্রাম ও পানি পান", "Sahih Muslim 2028"),
        PillarTheme("Wisdom", "Humility in Learning", "জ্ঞান অর্জনে বিনয়", "Quran 20:114"),
        PillarTheme("Resilience", "Hope in Allah's Plan", "আল্লাহর পরিকল্পনায় আশা", "Quran 94:5-6"),
        PillarTheme("Character", "Truthfulness in Speech", "কথাবার্তায় সত্যবাদিতা", "Sahih al-Bukhari 6094"),
        PillarTheme("Mindset", "Courage to Keep Growing", "অবিরাম এগিয়ে যাওয়ার সাহস", "Sahih Muslim 2664")
    )

    private val anchors: List<ActionAnchor> = listOf(
        ActionAnchor("Morning Anchor", "সকালের সূচনা", "Before checking messages, take 60 calm seconds to set your direction with", "মোবাইল দেখার আগে ৬০ সেকেন্ড শান্ত মনে আপনার দিনটি সাজান এই গুণে:"),
        ActionAnchor("Midday Reset", "দুপুরের পুনঃসংযোগ", "Pause between busy tasks, breathe slowly, and refresh your heart through", "ব্যস্ত কাজের মাঝে একটু থেমে গভীর শ্বাস নিন এবং অন্তরকে সতেজ করুন:"),
        ActionAnchor("One Honest Step", "একটি আন্তরিক পদক্ষেপ", "Don't wait for perfection—choose one 5-minute action today that embodies", "নিখুঁত সময়ের অপেক্ষা নয়—আজ মাত্র ৫ মিনিটের একটি কাজে ফুটিয়ে তুলুন:"),
        ActionAnchor("Quiet Strength", "নীরব শক্তি", "True progress rarely shouts; practice hidden excellence right now through", "প্রকৃত উন্নতি কোলাহল করে না; এখনই নীরব অনুশীলন করুন:"),
        ActionAnchor("Heart Check", "অন্তরের খোঁজ", "Ask yourself honestly: how can my very next decision reflect more", "নিজেকে আন্তরিকভাবে জিজ্ঞাসা করুন: আমার পরের সিদ্ধান্তে কীভাবে আনব"),
        ActionAnchor("Energy Upgrade", "শক্তির নবায়ন", "When fatigue tempts you to scroll aimlessly, reclaim your clarity through", "ক্লান্তিতে অযথা স্ক্রল না করে নিজেকে ফিরিয়ে আনুন এর মাধ্যমে:"),
        ActionAnchor("Speech & Tone", "কথা ও আচরণ", "In your next conversation with family or colleagues, consciously lead with", "পরিবার বা সহকর্মীর সাথে পরের কথোপকথনে সচেতনভাবে অগ্রাধিকার দিন:"),
        ActionAnchor("Study & Craft", "জ্ঞান ও দক্ষতা", "Elevate your work and learning from routine to worship by infusing it with", "পড়াশোনা ও কাজকে সাধারণ রুটিন থেকে ইবাদতে উন্নীত করুন এর মাধ্যমে:"),
        ActionAnchor("Steady Habit", "স্থায়ী অভ্যাস", "Small repeated habits reshape destiny; protect one daily ritual rooted in", "ছোট নিয়মিত অভ্যাস ভাগ্য বদলে দেয়; আজকের একটি রুটিন গড়ে তুলুন:"),
        ActionAnchor("Under Pressure", "চাপের মুহূর্তে", "When plans bend or delays happen today, respond with dignity and", "কাজে বিলম্ব বা চাপ এলে অস্থির না হয়ে সাড়া দিন মর্যাদা ও"),
        ActionAnchor("Hydration & Breath", "পানি ও প্রশ্বাস", "Stand up, stretch your shoulders, sip water slowly, and pair physical care with", "দাঁড়িয়ে কাঁধ সোজা করুন, ধীরে পানি পান করুন এবং শরীরের যত্নের সাথে রাখুন:"),
        ActionAnchor("Screen Boundary", "ডিজিটাল সংযম", "Put the phone face-down for 20 focused minutes and protect your peace with", "২০ মিনিট ফোন উল্টে রেখে মনোযোগ দিন এবং মনের প্রশান্তি রক্ষা করুন:"),
        ActionAnchor("Family Warmth", "পরিবারের উষ্ণতা", "Send a brief kind message or make a silent Dua for someone you love, guided by", "প্রিয়জনকে একটি আন্তরিক বার্তা পাঠান বা নীরবে দুআ করুন এর চেতনায়:"),
        ActionAnchor("Before Salah", "সালাতের প্রস্তুতি", "Step into Wudu calmly a few minutes early so your prayer shines with", "কয়েক মিনিট আগে শান্তভাবে অযু করুন যাতে আপনার সালাত উজ্জ্বল হয়:"),
        ActionAnchor("Overcoming Doubt", "সংশয় জয়", "Whenever inner doubt whispers 'it's too late', answer it boldly with", "মনে যখন সন্দেহ জাগে 'দেরি হয়ে গেছে', তখন দৃঢ়ভাবে জবাব দিন:"),
        ActionAnchor("Evening Reflection", "সন্ধ্যার আত্মসমালোচনা", "Review what went right today, forgive minor slips, and anchor tomorrow in", "আজকের ভালো কাজগুলো মনে করুন, ভুল ক্ষমা করুন এবং আগামীকাল গড়ুন:"),
        ActionAnchor("Courageous Focus", "সাহসী মনোযোগ", "Finish the single hardest task you have been avoiding by leaning into", "যে কঠিন কাজটি পিছিয়ে রাখছিলেন তা আজ সম্পন্ন করুন অবলম্বন করে:"),
        ActionAnchor("Living Legacy", "স্থায়ী প্রভাব", "Choose one kindness or learned truth today that will outlive the week through", "এমন একটি ভালো কাজ বা শিক্ষা নিন যা দীর্ঘদিন কল্যাণ বয়ে আনবে:"),
        ActionAnchor("Inner Calm", "অভ্যন্তরীণ প্রশান্তি", "Release what lies outside your control and invest your full heart into", "যা আপনার নিয়ন্ত্রণের বাইরে তা ছেড়ে দিন এবং পুরো মন নিবেশ করুন:"),
        ActionAnchor("Night Renewal", "রাতের প্রশান্তি", "End the day lighter than you began—let go of grudges and sleep in", "দিনের শেষে হৃদয় হালকা রাখুন—ক্ষোভ ভুলে বিশ্রাম নিন এর ছায়ায়:")
    )

    fun buildExtendedItems(startId: Int): List<KnowledgeMotivationItem> {
        val result = ArrayList<KnowledgeMotivationItem>(curatedExtra.size + pillars.size * anchors.size)
        var nextId = startId

        for (seed in curatedExtra) {
            result.add(
                KnowledgeMotivationItem(
                    id = nextId++,
                    category = seed.category,
                    titleEn = seed.titleEn,
                    bodyEn = seed.bodyEn,
                    titleBn = seed.titleBn,
                    bodyBn = seed.bodyBn,
                    sourceRef = seed.sourceRef
                )
            )
        }

        // Interleave pillars & anchors using a coprime stride so consecutive hourly draws always feel fresh
        val pCount = pillars.size
        val aCount = anchors.size
        for (aIdx in 0 until aCount) {
            for (pStep in 0 until pCount) {
                val pIdx = (pStep * 7 + aIdx * 3) % pCount
                val pillar = pillars[pIdx]
                val anchor = anchors[aIdx]
                result.add(
                    KnowledgeMotivationItem(
                        id = nextId++,
                        category = pillar.category,
                        titleEn = "${anchor.titlePrefixEn}: ${pillar.focusEn}",
                        bodyEn = "${anchor.promptEn} ${pillar.focusEn}. Steady daily practice transforms both heart and habits.",
                        titleBn = "${anchor.titlePrefixBn}: ${pillar.focusBn}",
                        bodyBn = "${anchor.promptBn} ${pillar.focusBn}। নিয়মিত চর্চা অন্তর ও অভ্যাস—উভয়কেই সুন্দর করে তোলে।",
                        sourceRef = pillar.sourceRef
                    )
                )
            }
        }
        return result
    }
}
