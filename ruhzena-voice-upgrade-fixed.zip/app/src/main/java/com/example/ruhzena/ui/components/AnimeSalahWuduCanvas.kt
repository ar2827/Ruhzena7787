package com.example.ruhzena.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalRuhZenaPalette
import com.example.ui.theme.RuhZenaGlassPalette
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * Unified Lifelike Anatomical Salah & Wudu Demonstration Viewport.
 *
 * Uses the EXACT SAME 28-joint flexible-spine + analytical 2-bone IK human model as the Workouts
 * studio (`drawUnifiedAnatomicalHuman` with `HumanOutfitStyle.PRAYER_ROBE`):
 * - Proper Sunnah prayer attire (crisp textured Thobe + Kufi for Male; modest Abaya + layered Hijab for Female).
 * - Authentic Salah biomechanics: 90° flat-back Ruku with IK-locked hands on knees, Qawmah with BOTH
 *   arms cleanly released straight down at sides (Male & Female), 7-point grounded Sujud, Jalsa,
 *   Tashahhud with raised index finger, and Taslim.
 * - Real Wudu water washing physics: stationary stone basin + gooseneck faucet + lower foot-wash spout,
 *   hands/forearms/feet IK-aligned right into the pouring water stream with splashing droplets, cascading
 *   face-wash water ribbons, wet skin specular sheen, and 3-stage Arms -> Head Wipe -> Feet cycle!
 */
@Composable
fun AnimeSalahWuduViewport(
    stepId: String,
    isWudu: Boolean,
    isFemale: Boolean,
    caption: String,
    height: Dp = 286.dp,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    var isPlaying by remember(stepId) { mutableStateOf(true) }
    var phase by remember(stepId) { mutableFloatStateOf(0f) }

    LaunchedEffect(stepId, isPlaying) {
        if (!isPlaying) return@LaunchedEffect
        var last = 0L
        // Slightly unhurried cadence for multi-part wudu_step_3 (arms -> head -> feet)
        val speed = if (stepId == "wudu_step_3") 0.16f else 0.36f
        while (isPlaying) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                    phase = (phase + dt * speed) % 1f
                }
                last = now
            }
        }
    }

    val (motionT, motionVelocity) = when {
        phase < 0.34f -> {
            val u = phase / 0.34f
            easeOutQuart(u) to (3.4f * (1f - u).pow(3f)).coerceIn(0f, 1.3f)
        }
        phase < 0.78f -> 1f to 0f
        else -> {
            val u = (phase - 0.78f) / 0.22f
            (1f - easeInOutCubic(u)) to (-sin(u * PI).toFloat() * 0.65f)
        }
    }

    val clothLagT = when {
        phase < 0.42f -> easeOutCubic((phase / 0.42f).coerceIn(0f, 1f))
        phase < 0.80f -> 1f
        else -> 1f - easeInOutCubic(((phase - 0.80f) / 0.20f).coerceIn(0f, 1f))
    }
    val clothDrag = (motionT - clothLagT) * 1.25f

    val taslimYaw = if (stepId == "salah_step_8") {
        when {
            phase < 0.34f -> easeOutQuart(phase / 0.34f)
            phase < 0.54f -> 1f
            phase < 0.84f -> 1f - 2f * easeInOutCubic((phase - 0.54f) / 0.30f)
            else -> -1f + easeOutCubic((phase - 0.84f) / 0.16f)
        }
    } else 0f

    // Determine active Wudu substage & wet zone
    val wuduStage = when (stepId) {
        "wudu_step_1" -> WuduActionStage.WASH_HANDS
        "wudu_step_2" -> WuduActionStage.WASH_FACE
        "wudu_step_3" -> when {
            phase < 0.40f -> WuduActionStage.WASH_ARMS
            phase < 0.68f -> WuduActionStage.WIPE_HEAD
            else -> WuduActionStage.WASH_FEET
        }
        "wudu_step_4" -> WuduActionStage.POST_DUA
        else -> WuduActionStage.NONE
    }

    val wetZone = when (wuduStage) {
        WuduActionStage.WASH_HANDS -> WuduWetZone.HANDS
        WuduActionStage.WASH_FACE -> WuduWetZone.FACE
        WuduActionStage.WASH_ARMS -> WuduWetZone.ARMS
        WuduActionStage.WIPE_HEAD -> WuduWetZone.HEAD
        WuduActionStage.WASH_FEET -> WuduWetZone.FEET
        else -> WuduWetZone.NONE
    }

    val liveFkPose = remember(stepId, isFemale, motionT, phase) {
        resolveSalahWuduPose(stepId, isFemale, motionT, phase)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, palette.borderAccent.copy(alpha = 0.72f), RoundedCornerShape(18.dp))
            .testTag("anime_salah_viewport_$stepId")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val floorY = size.height * 0.865f
            val sinkSpec = computeWuduSinkGeometry(size, floorY)

            // 1. Sanctuary backdrop + Prayer rug or stationary Wudu stone basin & faucet
            drawSanctuaryStage(
                palette = palette,
                isWudu = isWudu,
                wuduStage = wuduStage,
                sink = sinkSpec,
                floorY = floorY,
                phase = phase,
                motionVelocity = motionVelocity
            )

            // 2. Solve unified 28-joint skeleton with exact IK locks + natural Salah/Wudu weight-shift physics
            val salahBio = solveSalahWuduBiomechanics(
                stepId = stepId,
                phase = phase,
                motionT = motionT,
                motionVelocity = motionVelocity
            )
            val scaleMul = when (stepId) {
                "salah_step_5", "salah_step_6" -> 0.92f
                else -> 0.96f
            }
            val baseSkel = solveFkSkeleton(
                pose = liveFkPose,
                canvasSize = size,
                floorY = floorY,
                isFemale = isFemale,
                scaleMultiplier = scaleMul,
                breathPhase = phase,
                physics = salahBio
            )
            val ikLocks = resolveSalahWuduIkLocks(
                stepId = stepId,
                wuduStage = wuduStage,
                baseSkel = baseSkel,
                sink = sinkSpec,
                motionT = motionT,
                phase = phase
            )
            val skel = if (ikLocks != null) {
                solveFkSkeleton(
                    pose = liveFkPose,
                    canvasSize = size,
                    floorY = floorY,
                    isFemale = isFemale,
                    scaleMultiplier = scaleMul,
                    breathPhase = phase,
                    ikLocks = ikLocks,
                    physics = salahBio
                )
            } else {
                baseSkel
            }

            // 3. Render the EXACT SAME lifelike unified anatomical human in proper Prayer attire
            drawUnifiedAnatomicalHuman(
                skel = skel,
                isFemale = isFemale,
                outfitStyle = HumanOutfitStyle.PRAYER_ROBE,
                palette = palette,
                floorY = floorY,
                phase = phase,
                isWudu = isWudu,
                wetZone = wetZone,
                clothDrag = clothDrag,
                taslimYaw = taslimYaw,
                physics = salahBio
            )

            // 4. Foreground Wudu Water Physics (pouring stream colliding on hands/arms/feet + face splash ribbons!)
            if (isWudu) {
                drawLiveWuduWaterPhysics(
                    wuduStage = wuduStage,
                    skel = skel,
                    sink = sinkSpec,
                    phase = phase
                )
            }

            // 5. Subtle Salah Guidance Cues (Qawmah released-arms halo, Taslim directional waves)
            if (stepId == "salah_step_4" && motionT > 0.72f) {
                drawCircle(
                    color = Color(0xFFE7C782).copy(alpha = 0.45f * ((motionT - 0.72f) / 0.28f)),
                    radius = skel.unit * 0.28f,
                    center = skel.nearHand,
                    style = Stroke(width = 1.8f)
                )
            }
            if (stepId == "salah_step_8" && abs(taslimYaw) > 0.30f) {
                val dirSign = if (taslimYaw > 0f) 1f else -1f
                val waveCenter = skel.head + Offset(dirSign * skel.unit * 1.05f, 0f)
                drawArc(
                    color = Color(0xFFE7C782).copy(alpha = 0.60f * abs(taslimYaw)),
                    startAngle = if (dirSign > 0f) -45f else 135f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(waveCenter.x - skel.unit * 0.44f, waveCenter.y - skel.unit * 0.44f),
                    size = Size(skel.unit * 0.88f, skel.unit * 0.88f),
                    style = Stroke(width = 2.4f, cap = StrokeCap.Round)
                )
            }
        }

        // Caption pill bottom-left (dynamically indicates sub-stage during multi-part wudu_step_3!)
        val dynamicCaption = when (wuduStage) {
            WuduActionStage.WASH_ARMS -> "$caption • Arms to Elbows"
            WuduActionStage.WIPE_HEAD -> "$caption • Head & Ears Wipe"
            WuduActionStage.WASH_FEET -> "$caption • Washing Feet"
            else -> caption
        }
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
                .background(Color(0xD6080B13), RoundedCornerShape(10.dp))
                .border(0.8.dp, Color(0x66D5B77A), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Text(
                text = dynamicCaption,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFEBD299)
            )
        }

        // Play / Pause toggle top-right
        IconButton(
            onClick = { isPlaying = !isPlaying },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .size(36.dp)
                .background(Color(0xCC0A0E18), CircleShape)
                .border(0.8.dp, Color(0x66B4C8E8), CircleShape)
                .testTag("anime_prayer_play_pause")
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause animation" else "Play animation",
                tint = Color(0xFFEBD299),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

private enum class WuduActionStage {
    NONE,
    WASH_HANDS,
    WASH_FACE,
    WASH_ARMS,
    WIPE_HEAD,
    WASH_FEET,
    POST_DUA
}

private data class WuduSinkSpec(
    val basinLeft: Float,
    val basinTop: Float,
    val basinWidth: Float,
    val basinHeight: Float,
    val upperNozzle: Offset,
    val lowerFootNozzle: Offset
)

private fun computeWuduSinkGeometry(size: Size, floorY: Float): WuduSinkSpec {
    val basinLeft = size.width * 0.62f
    val basinTop = size.height * 0.56f
    val basinWidth = size.width * 0.27f
    val basinHeight = size.height * 0.068f
    val upperNozzle = Offset(basinLeft + basinWidth * 0.34f, basinTop - size.height * 0.13f)
    val lowerFootNozzle = Offset(basinLeft + basinWidth * 0.28f, floorY - size.height * 0.20f)
    return WuduSinkSpec(basinLeft, basinTop, basinWidth, basinHeight, upperNozzle, lowerFootNozzle)
}

private fun easeOutQuart(t: Float): Float {
    val c = t.coerceIn(0f, 1f)
    return 1f - (1f - c).pow(4f)
}

private fun easeOutCubic(t: Float): Float {
    val c = t.coerceIn(0f, 1f)
    return 1f - (1f - c).pow(3f)
}

private fun easeInOutCubic(t: Float): Float {
    val c = t.coerceIn(0f, 1f)
    return if (c < 0.5f) 4f * c * c * c else 1f - (-2f * c + 2f).pow(3f) / 2f
}

private fun DrawScope.drawSanctuaryStage(
    @Suppress("UNUSED_PARAMETER") palette: RuhZenaGlassPalette,
    isWudu: Boolean,
    wuduStage: WuduActionStage,
    sink: WuduSinkSpec,
    floorY: Float,
    phase: Float,
    motionVelocity: Float
) {
    val topCol = if (isWudu) Color(0xFF060E18) else Color(0xFF060811)
    val midCol = if (isWudu) Color(0xFF0B1C2E) else Color(0xFF101627)
    val botCol = if (isWudu) Color(0xFF050A12) else Color(0xFF070910)
    drawRect(brush = Brush.verticalGradient(listOf(topCol, midCol, botCol)))

    val accentGlow = if (isWudu) Color(0xFF7AD8FF) else Color(0xFFE7C782)
    val rimCyan = if (isWudu) Color(0xFF9BE6FF) else Color(0xFFA8C6F0)

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                rimCyan.copy(alpha = 0.20f + abs(motionVelocity) * 0.05f),
                accentGlow.copy(alpha = 0.08f),
                Color.Transparent
            ),
            center = Offset(size.width * 0.50f, size.height * 0.44f),
            radius = size.minDimension * 0.62f
        ),
        radius = size.minDimension * 0.62f,
        center = Offset(size.width * 0.50f, size.height * 0.44f)
    )

    // Geometric Mihrab Arch
    val archW = size.width * 0.52f
    val archH = size.height * 0.78f
    val archLeft = (size.width - archW) * 0.5f
    val archTop = size.height * 0.05f
    val archPath = Path().apply {
        moveTo(archLeft, archTop + archH)
        lineTo(archLeft, archTop + archH * 0.36f)
        lineTo(size.width * 0.5f, archTop)
        lineTo(archLeft + archW, archTop + archH * 0.36f)
        lineTo(archLeft + archW, archTop + archH)
        close()
    }
    drawPath(
        path = archPath,
        brush = Brush.verticalGradient(
            listOf(rimCyan.copy(alpha = 0.13f), Color.Transparent),
            startY = archTop,
            endY = archTop + archH
        )
    )
    drawPath(path = archPath, color = rimCyan.copy(alpha = 0.32f), style = Stroke(width = 1.4f))

    // Ascending serene light motes
    for (i in 0..9) {
        val drift = (phase + i * 0.10f) % 1f
        val mx = size.width * (0.10f + (i * 0.082f) % 0.78f) + sin(drift * 6.28f + i) * 6f
        val my = size.height * (0.84f - drift * 0.74f)
        val alpha = sin(drift * PI).toFloat().coerceIn(0f, 1f) * 0.58f
        val col = if (i % 3 == 0) accentGlow else rimCyan
        drawCircle(color = col.copy(alpha = alpha), radius = 1.6f, center = Offset(mx, my))
    }

    // Sanctuary floor
    drawRect(
        brush = Brush.verticalGradient(listOf(Color(0xFF0A0F1A), Color(0xFF04060B)), startY = floorY, endY = size.height),
        topLeft = Offset(0f, floorY),
        size = Size(size.width, size.height - floorY)
    )
    drawLine(
        brush = Brush.horizontalGradient(
            listOf(Color.Transparent, rimCyan.copy(alpha = 0.45f), accentGlow.copy(alpha = 0.55f), Color.Transparent)
        ),
        start = Offset(0f, floorY),
        end = Offset(size.width, floorY),
        strokeWidth = 1.5f
    )

    if (!isWudu) {
        // Prayer Rug anchored solidly to floor
        val rugLeft = size.width * 0.14f
        val rugW = size.width * 0.72f
        val rugH = size.height * 0.048f
        drawRoundRect(
            brush = Brush.horizontalGradient(listOf(Color(0xFF0E1D24), Color(0xFF19353B), Color(0xFF0E1D24))),
            topLeft = Offset(rugLeft, floorY - rugH * 0.30f),
            size = Size(rugW, rugH),
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = Color(0xFFE7C782).copy(alpha = 0.80f),
            topLeft = Offset(rugLeft + 4f, floorY - rugH * 0.14f),
            size = Size(rugW - 8f, rugH - 4f),
            cornerRadius = CornerRadius(3f, 3f),
            style = Stroke(width = 1.2f)
        )
    } else {
        // Stationary Stone Wudu Station (Pedestal + Ceramic Basin + Curved Chrome Faucet + Lower Foot Spout)
        val wallX = sink.basinLeft + sink.basinWidth * 0.86f
        // Vertical stone pillar wall
        drawRoundRect(
            brush = Brush.horizontalGradient(listOf(Color(0xFF1A2535), Color(0xFF243347), Color(0xFF121A26))),
            topLeft = Offset(wallX, size.height * 0.24f),
            size = Size(size.width * 0.075f, floorY - size.height * 0.24f),
            cornerRadius = CornerRadius(6f, 6f)
        )
        // Lower foot-wash drain tray on floor
        drawRoundRect(
            brush = Brush.horizontalGradient(listOf(Color(0xFF162436), Color(0xFF21364E), Color(0xFF162436))),
            topLeft = Offset(sink.basinLeft - 6f, floorY - 12f),
            size = Size(sink.basinWidth + 10f, 14f),
            cornerRadius = CornerRadius(5f, 5f)
        )
        // Pedestal column supporting sink
        val pedW = sink.basinWidth * 0.38f
        val pedLeft = sink.basinLeft + sink.basinWidth * 0.44f
        drawRect(
            brush = Brush.horizontalGradient(listOf(Color(0xFF1B2738), Color(0xFF2B3D54), Color(0xFF121B28))),
            topLeft = Offset(pedLeft, sink.basinTop + sink.basinHeight - 2f),
            size = Size(pedW, floorY - (sink.basinTop + sink.basinHeight) - 8f)
        )
        // Ceramic Wudu Basin bowl
        val basinPath = Path().apply {
            moveTo(sink.basinLeft, sink.basinTop)
            lineTo(sink.basinLeft + sink.basinWidth, sink.basinTop)
            quadraticTo(
                sink.basinLeft + sink.basinWidth * 0.86f, sink.basinTop + sink.basinHeight * 1.15f,
                sink.basinLeft + sink.basinWidth * 0.50f, sink.basinTop + sink.basinHeight * 1.12f
            )
            quadraticTo(
                sink.basinLeft + sink.basinWidth * 0.14f, sink.basinTop + sink.basinHeight * 1.15f,
                sink.basinLeft, sink.basinTop
            )
            close()
        }
        drawPath(
            basinPath,
            brush = Brush.verticalGradient(listOf(Color(0xFFD5E1EE), Color(0xFF7D93AC), Color(0xFF334357)))
        )
        drawPath(basinPath, color = Color(0xFF0A0F18), style = Stroke(width = 1.6f, join = StrokeJoin.Round))

        // Curved Chrome Gooseneck Faucet (Upper sink tap)
        val tapBase = Offset(wallX + 2f, sink.upperNozzle.y + 8f)
        val faucetPath = Path().apply {
            moveTo(tapBase.x, tapBase.y)
            quadraticTo(tapBase.x - 16f, sink.upperNozzle.y - 26f, sink.upperNozzle.x, sink.upperNozzle.y)
        }
        drawPath(faucetPath, color = Color(0xFFCFDCEB), style = Stroke(width = 5.5f, cap = StrokeCap.Round))
        drawPath(faucetPath, color = Color.White.copy(alpha = 0.72f), style = Stroke(width = 1.8f, cap = StrokeCap.Round))

        // Lower Foot-Wash Chrome Tap (active during wudu_step_3 foot washing!)
        val lowTapBase = Offset(wallX + 2f, sink.lowerFootNozzle.y)
        val lowTapPath = Path().apply {
            moveTo(lowTapBase.x, lowTapBase.y)
            quadraticTo(lowTapBase.x - 14f, sink.lowerFootNozzle.y - 12f, sink.lowerFootNozzle.x, sink.lowerFootNozzle.y + 4f)
        }
        val lowTapAlpha = if (wuduStage == WuduActionStage.WASH_FEET) 1f else 0.55f
        drawPath(lowTapPath, color = Color(0xFFCFDCEB).copy(alpha = lowTapAlpha), style = Stroke(width = 4.5f, cap = StrokeCap.Round))
    }
}

/**
 * Renders live animated Wudu water streams, collision splash arcs, shimmering water droplets,
 * and cascading water ribbons directly interacting with the human hands, face, forearms, and feet!
 */
private fun DrawScope.drawLiveWuduWaterPhysics(
    wuduStage: WuduActionStage,
    skel: SolvedFkSkeleton,
    sink: WuduSinkSpec,
    phase: Float
) {
    val waterCore = Color(0xFF56C9FF)
    val waterBright = Color(0xFFD6F5FF)
    val waterRim = Color(0xFFFFFFFF)
    val animT = (phase * 7.5f) % 1f

    fun drawShimmeringStream(top: Offset, bottom: Offset, width: Float) {
        val len = hypot(bottom.x - top.x, bottom.y - top.y).coerceAtLeast(4f)
        // Soft outer aqua glow
        drawLine(waterCore.copy(alpha = 0.28f), top, bottom, strokeWidth = width * 2.2f, cap = StrokeCap.Round)
        // Translucent flowing stream body
        drawLine(waterCore.copy(alpha = 0.85f), top, bottom, strokeWidth = width, cap = StrokeCap.Round)
        // Animated inner bright highlight pulse sliding down the stream!
        for (k in 0..2) {
            val f0 = ((animT + k * 0.33f) % 1f)
            val f1 = (f0 + 0.16f).coerceAtMost(1f)
            val p0 = lerpOffset(top, bottom, f0)
            val p1 = lerpOffset(top, bottom, f1)
            drawLine(waterRim.copy(alpha = 0.90f), p0, p1, strokeWidth = width * 0.38f, cap = StrokeCap.Round)
        }
        // Subtle gentle ripple ring at impact bottom
        if (len > 10f) {
            val rippleR = 6f + animT * 12f
            drawOval(
                color = waterBright.copy(alpha = (1f - animT) * 0.65f),
                topLeft = Offset(bottom.x - rippleR, bottom.y - 3f),
                size = Size(rippleR * 2f, 6f),
                style = Stroke(width = 1.4f)
            )
        }
    }

    fun drawSplashDroplets(origin: Offset, count: Int, spreadX: Float, arcHeight: Float) {
        for (i in 0 until count) {
            val t = ((phase * 4.5f + i * (1f / count)) % 1f)
            val dir = ((i % 2) * 2 - 1) * (0.45f + (i / count.toFloat()) * 0.85f)
            val x = origin.x + dir * spreadX * t
            val y = origin.y - sin(t * PI).toFloat() * arcHeight + t * t * (arcHeight * 1.45f)
            val r = (2.8f - t * 1.4f).coerceAtLeast(1.1f)
            val alpha = (1f - t).coerceIn(0f, 1f) * 0.92f
            drawCircle(waterBright.copy(alpha = alpha), radius = r, center = Offset(x, y))
            drawCircle(waterRim.copy(alpha = alpha * 0.85f), radius = r * 0.45f, center = Offset(x - 0.6f, y - 0.6f))
        }
    }

    when (wuduStage) {
        WuduActionStage.WASH_HANDS -> {
            // Stream pours from upper faucet directly onto cupped hands, then drains into basin!
            val impact = lerpOffset(skel.nearWrist, skel.nearHand, 0.55f)
            drawShimmeringStream(sink.upperNozzle, impact, width = 5.4f)
            // Secondary drainage ribbons falling from hands into the basin
            drawShimmeringStream(impact + Offset(-3f, 4f), Offset(impact.x - 4f, sink.basinTop + 6f), width = 2.8f)
            drawShimmeringStream(impact + Offset(4f, 4f), Offset(impact.x + 5f, sink.basinTop + 6f), width = 2.4f)
            drawSplashDroplets(impact, count = 8, spreadX = 24f, arcHeight = 16f)
        }

        WuduActionStage.WASH_FACE -> {
            // Gentle stream runs into basin while hands scoop water up onto mouth/nose/face!
            drawShimmeringStream(sink.upperNozzle, Offset(sink.upperNozzle.x, sink.basinTop + 5f), width = 4.6f)
            drawSplashDroplets(Offset(sink.upperNozzle.x, sink.basinTop + 2f), count = 5, spreadX = 16f, arcHeight = 10f)

            // When hands are near the face, animate glistening water ribbons cascading down cheeks & chin!
            val handToFaceDist = hypot(skel.nearHand.x - skel.head.x, skel.nearHand.y - skel.head.y)
            if (handToFaceDist < skel.unit * 1.45f) {
                val faceFront = skel.head + Offset(skel.unit * 0.42f, skel.unit * 0.10f)
                drawSplashDroplets(faceFront, count = 7, spreadX = 18f, arcHeight = 12f)
                for (r in 0..2) {
                    val dropT = ((phase * 5.2f + r * 0.31f) % 1f)
                    val rx = faceFront.x + (r - 1) * 5.5f
                    val ry = faceFront.y + dropT * (sink.basinTop - faceFront.y).coerceAtLeast(24f)
                    drawLine(
                        color = waterBright.copy(alpha = (1f - dropT * 0.6f) * 0.85f),
                        start = Offset(rx, ry - 9f),
                        end = Offset(rx, ry),
                        strokeWidth = 2.1f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }

        WuduActionStage.WASH_ARMS -> {
            // Stream pours directly onto forearm and runs cleanly from wrist down to elbow!
            val forearmMid = lerpOffset(skel.nearWrist, skel.nearElbow, 0.45f)
            drawShimmeringStream(sink.upperNozzle, forearmMid, width = 5.2f)
            // Sparkling water ribbon gliding along forearm to elbow then dripping down
            drawLine(
                brush = Brush.linearGradient(listOf(waterRim, waterCore), start = skel.nearWrist, end = skel.nearElbow),
                start = skel.nearWrist,
                end = skel.nearElbow,
                strokeWidth = 3.2f,
                cap = StrokeCap.Round
            )
            drawShimmeringStream(skel.nearElbow + Offset(0f, 4f), Offset(skel.nearElbow.x, sink.basinTop + 10f), width = 2.6f)
            drawSplashDroplets(forearmMid, count = 8, spreadX = 24f, arcHeight = 14f)
        }

        WuduActionStage.WIPE_HEAD -> {
            // Faucet lightly trickles into basin while wet hands sweep over head leaving a fresh water mist arc
            drawShimmeringStream(sink.upperNozzle, Offset(sink.upperNozzle.x, sink.basinTop + 5f), width = 3.4f)
            drawSplashDroplets(skel.head + Offset(0f, -skel.unit * 0.48f), count = 6, spreadX = 20f, arcHeight = 10f)
        }

        WuduActionStage.WASH_FEET -> {
            // Lower foot-wash spout pours directly onto the lifted foot & ankle with rich splashes!
            val footTarget = lerpOffset(skel.nearAnkle, skel.nearBall, 0.55f)
            drawShimmeringStream(sink.lowerFootNozzle + Offset(0f, 4f), footTarget, width = 5.0f)
            drawShimmeringStream(footTarget + Offset(0f, 6f), Offset(footTarget.x, sink.lowerFootNozzle.y + size.height * 0.18f), width = 2.8f)
            drawSplashDroplets(footTarget, count = 8, spreadX = 22f, arcHeight = 14f)
        }

        WuduActionStage.POST_DUA, WuduActionStage.NONE -> Unit
    }
}

/**
 * Resolves exact analytical 2-bone IK locks for Salah (Ruku knee grip) and Wudu (hands/arms/feet
 * accurately aligned under the pouring water stream!).
 */
private fun resolveSalahWuduIkLocks(
    stepId: String,
    wuduStage: WuduActionStage,
    baseSkel: SolvedFkSkeleton,
    sink: WuduSinkSpec,
    motionT: Float,
    phase: Float
): IkTargetLocks? {
    val u = baseSkel.unit
    return when {
        stepId == "salah_step_3" && motionT > 0.70f -> {
            // Lock both hands cleanly onto the knees in 90° Ruku!
            IkTargetLocks(
                nearHand = baseSkel.nearKnee + Offset(u * 0.08f, -u * 0.08f),
                farHand = baseSkel.farKnee + Offset(u * 0.08f, -u * 0.08f),
                nearElbowBendSign = 1f,
                farElbowBendSign = 1f
            )
        }
        wuduStage == WuduActionStage.WASH_HANDS -> {
            // Both hands rub gently right under the pouring faucet water stream!
            val rubX = sin(phase * 6f * PI.toFloat()) * u * 0.14f
            val rubY = cos(phase * 6f * PI.toFloat()) * u * 0.08f
            val target = Offset(sink.upperNozzle.x - u * 0.18f + rubX, sink.basinTop - u * 0.36f + rubY)
            IkTargetLocks(
                nearHand = target,
                farHand = target + Offset(u * 0.16f, -u * 0.06f),
                nearElbowBendSign = 1f,
                farElbowBendSign = 1f
            )
        }
        wuduStage == WuduActionStage.WASH_FACE -> {
            // Smooth cycle scooping sparkling water from faucet stream up to mouth/nose/face!
            val scoopT = ((1f - cos(phase * 4f * PI.toFloat())) * 0.5f)
            val streamPoint = Offset(sink.upperNozzle.x - u * 0.18f, sink.basinTop - u * 0.32f)
            val facePoint = baseSkel.head + Offset(u * 0.42f, u * 0.12f)
            val target = lerpOffset(streamPoint, facePoint, scoopT)
            IkTargetLocks(
                nearHand = target,
                farHand = target + Offset(u * 0.12f, -u * 0.04f),
                nearElbowBendSign = 1f,
                farElbowBendSign = 1f
            )
        }
        wuduStage == WuduActionStage.WASH_ARMS -> {
            // Extend right forearm cleanly under the faucet stream while far hand glides water to elbow!
            val rubT = sin(phase * 14f * PI.toFloat()) * 0.5f + 0.5f
            val streamWrist = Offset(sink.upperNozzle.x + u * 0.12f, sink.basinTop - u * 0.42f)
            val rubPoint = lerpOffset(baseSkel.nearElbow, streamWrist, rubT)
            IkTargetLocks(
                nearHand = streamWrist,
                farHand = rubPoint,
                nearElbowBendSign = 1f,
                farElbowBendSign = 1f
            )
        }
        wuduStage == WuduActionStage.WIPE_HEAD -> {
            // Wet palms wipe smoothly from front hairline across crown to nape and back!
            val subT = ((phase - 0.40f) / 0.28f).coerceIn(0f, 1f)
            val sweep = sin(subT * PI.toFloat())
            val frontHair = baseSkel.head + Offset(u * 0.34f, -u * 0.44f)
            val crownBack = baseSkel.head + Offset(-u * 0.44f, -u * 0.48f)
            val target = lerpOffset(frontHair, crownBack, sweep)
            IkTargetLocks(
                nearHand = target,
                farHand = target + Offset(u * 0.08f, u * 0.04f),
                nearElbowBendSign = 1f,
                farElbowBendSign = 1f
            )
        }
        wuduStage == WuduActionStage.WASH_FEET -> {
            // Lift near foot under lower spout while hands wash ankle & toes!
            val footTarget = Offset(sink.lowerFootNozzle.x - u * 0.12f, sink.lowerFootNozzle.y + u * 0.52f)
            val rubOffset = Offset(sin(phase * 16f * PI.toFloat()) * u * 0.12f, 0f)
            IkTargetLocks(
                nearFoot = footTarget,
                nearKneeBendSign = -1f,
                nearHand = footTarget + Offset(-u * 0.06f, -u * 0.12f) + rubOffset,
                farHand = footTarget + Offset(u * 0.12f, -u * 0.14f) - rubOffset,
                nearElbowBendSign = 1f,
                farElbowBendSign = 1f
            )
        }
        else -> null
    }
}

/**
 * Connected Hierarchical FK Keyframes for all Salah (1..8) and Wudu (1..4) steps.
 * Guaranteed Qawmah accuracy (`salah_step_4`): BOTH arms release cleanly straight down at sides!
 */
private fun resolveSalahWuduPose(
    stepId: String,
    isFemale: Boolean,
    motionT: Float,
    phase: Float
): FkPose {
    val standingReleased = FkPose(
        rootXNorm = 0.48f,
        pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 4f,
        nearShoulderDeg = 90f, nearElbowFlexDeg = -6f, nearWristBendDeg = 0f,
        farShoulderDeg = 88f, farElbowFlexDeg = -6f, farWristBendDeg = 0f,
        nearHipDeg = 90f, nearKneeFlexDeg = 1f, nearAnkleDeg = 0f,
        farHipDeg = 91f, farKneeFlexDeg = 1f, farAnkleDeg = 0f,
        contactMode = GroundContactMode.FEET_ONLY
    )

    val standingTakbir = standingReleased.copy(
        nearShoulderDeg = if (isFemale) 58f else 48f,
        nearElbowFlexDeg = if (isFemale) -126f else -134f,
        nearWristBendDeg = 6f,
        farShoulderDeg = if (isFemale) 54f else 44f,
        farElbowFlexDeg = if (isFemale) -124f else -132f,
        farWristBendDeg = 6f
    )

    val standingQiyam = standingReleased.copy(
        nearShoulderDeg = if (isFemale) 80f else 84f,
        nearElbowFlexDeg = if (isFemale) -106f else -96f,
        nearWristBendDeg = 4f,
        farShoulderDeg = if (isFemale) 78f else 82f,
        farElbowFlexDeg = if (isFemale) -104f else -94f,
        farWristBendDeg = 4f
    )

    val rukuPose = FkPose(
        rootXNorm = 0.40f,
        pelvisTiltDeg = -2f, spineFlexDeg = 2f, neckBendDeg = 4f,
        nearShoulderDeg = 96f, nearElbowFlexDeg = 4f, nearWristBendDeg = 8f,
        farShoulderDeg = 94f, farElbowFlexDeg = 4f, farWristBendDeg = 8f,
        nearHipDeg = 86f, nearKneeFlexDeg = 4f, nearAnkleDeg = 0f,
        farHipDeg = 88f, farKneeFlexDeg = 4f, farAnkleDeg = 0f,
        contactMode = GroundContactMode.FEET_ONLY
    )

    val sujudPose = FkPose(
        rootXNorm = 0.40f,
        pelvisTiltDeg = 32f, spineFlexDeg = 8f, lumbarFlexBias = 4f, thoracicFlexBias = 4f, neckBendDeg = 18f,
        nearShoulderDeg = if (isFemale) 82f else 68f,
        nearElbowFlexDeg = if (isFemale) -72f else -54f,
        nearWristBendDeg = -10f,
        farShoulderDeg = if (isFemale) 78f else 64f,
        farElbowFlexDeg = if (isFemale) -70f else -52f,
        farWristBendDeg = -10f,
        nearHipDeg = 78f, nearKneeFlexDeg = 98f, nearAnkleDeg = 92f, nearHeelLift = 1f,
        farHipDeg = 80f, farKneeFlexDeg = 96f, farAnkleDeg = 92f, farHeelLift = 1f,
        contactMode = GroundContactMode.KNEELING_SUJUD,
        handStyle = HandStyle.FLAT_PRESS
    )

    val sittingPose = FkPose(
        rootXNorm = 0.46f,
        pelvisTiltDeg = -88f, spineFlexDeg = 2f, neckBendDeg = 8f,
        nearShoulderDeg = 76f, nearElbowFlexDeg = -64f, nearWristBendDeg = 14f,
        farShoulderDeg = 72f, farElbowFlexDeg = -62f, farWristBendDeg = 14f,
        nearHipDeg = 20f, nearKneeFlexDeg = 152f, nearAnkleDeg = 172f,
        farHipDeg = 22f, farKneeFlexDeg = 150f, farAnkleDeg = 172f,
        contactMode = GroundContactMode.KNEELING_SUJUD
    )

    val wuduAtBasin = standingReleased.copy(
        rootXNorm = 0.42f,
        pelvisTiltDeg = -80f, spineFlexDeg = 8f, neckBendDeg = 16f,
        nearShoulderDeg = 54f, nearElbowFlexDeg = -52f,
        farShoulderDeg = 50f, farElbowFlexDeg = -50f,
        handStyle = HandStyle.CUPPED_WUDU
    )

    val wuduFootWashPose = standingReleased.copy(
        rootXNorm = 0.39f,
        pelvisTiltDeg = -62f, spineFlexDeg = 16f, lumbarFlexBias = 6f, thoracicFlexBias = 6f, neckBendDeg = 22f,
        nearShoulderDeg = 64f, nearElbowFlexDeg = -22f,
        farShoulderDeg = 60f, farElbowFlexDeg = -20f,
        nearHipDeg = 34f, nearKneeFlexDeg = 46f, nearAnkleDeg = 18f,
        farHipDeg = 92f, farKneeFlexDeg = 2f, farAnkleDeg = 0f,
        contactMode = GroundContactMode.FEET_ONLY,
        handStyle = HandStyle.CUPPED_WUDU
    )

    val wuduDua = standingReleased.copy(
        rootXNorm = 0.44f,
        nearShoulderDeg = 68f, nearElbowFlexDeg = -96f,
        farShoulderDeg = 64f, farElbowFlexDeg = -94f
    )

    return when (stepId) {
        "salah_step_1" -> lerpFkPose(standingReleased, standingTakbir, motionT)
        "salah_step_2" -> lerpFkPose(standingTakbir, standingQiyam, motionT)
        "salah_step_3" -> lerpFkPose(standingQiyam, rukuPose, motionT)
        "salah_step_4" -> lerpFkPose(rukuPose, standingReleased, motionT)
        "salah_step_5" -> lerpFkPose(standingReleased, sujudPose, motionT)
        "salah_step_6" -> lerpFkPose(sujudPose, sittingPose, motionT)
        "salah_step_7" -> lerpFkPose(
            sittingPose,
            sittingPose.copy(nearElbowFlexDeg = -70f, handStyle = HandStyle.TASHAHHUD_INDEX),
            motionT
        )
        "salah_step_8" -> sittingPose
        "wudu_step_1" -> wuduAtBasin
        "wudu_step_2" -> wuduAtBasin.copy(pelvisTiltDeg = -78f, neckBendDeg = 14f)
        "wudu_step_3" -> when {
            phase < 0.40f -> wuduAtBasin
            phase < 0.68f -> wuduAtBasin.copy(pelvisTiltDeg = -84f, spineFlexDeg = 4f, neckBendDeg = 10f, handStyle = HandStyle.OPEN_RELAXED)
            else -> {
                val blend = ((phase - 0.68f) / 0.08f).coerceIn(0f, 1f)
                lerpFkPose(wuduAtBasin, wuduFootWashPose, blend)
            }
        }
        else -> lerpFkPose(standingReleased.copy(rootXNorm = 0.44f), wuduDua, motionT)
    }
}
