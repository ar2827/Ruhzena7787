package com.example.ruhzena.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlin.math.abs
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.BundledQuranSurahs
import com.example.ruhzena.data.islamic.QuranAyah
import com.example.ruhzena.data.islamic.QuranReciter
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.local.BookmarkEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.media.AudioPlaybackState
import com.example.ruhzena.ui.AyahExplanationState
import com.example.ruhzena.ui.QuranReaderUiState
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette

@Composable
fun QuranReaderSection(
    prefs: UserPreferences,
    quranState: QuranReaderUiState,
    ayahExplanationState: AyahExplanationState,
    cachedSurahNumbers: List<Int>,
    audioState: AudioPlaybackState,
    bookmarks: List<BookmarkEntity>,
    isOnline: Boolean,
    openSurahDirect: Boolean,
    onSetReaderOpen: (Boolean) -> Unit,
    onSelectSurah: (Int) -> Unit,
    onPlaySurahAyah: (Int, Int) -> Unit,
    onTogglePlayPause: () -> Unit,
    onSelectReciter: (QuranReciter) -> Unit,
    onChangeFontSize: (Int) -> Unit,
    onTogglePronunciation: (Boolean) -> Unit,
    onDownloadAllOffline: () -> Unit,
    onToggleBookmark: (BookmarkEntity, Boolean) -> Unit,
    onMarkLastRead: (Int, Int) -> Unit,
    onLoadAyahExplanation: (QuranAyah) -> Unit,
    onRetryAyahExplanation: (QuranAyah) -> Unit = onLoadAyahExplanation,
    onClearAyahExplanation: () -> Unit,
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> },
    targetScrollAyah: Int? = null,
    onConsumedTargetScroll: () -> Unit = {}
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    var searchQuery by remember { mutableStateOf("") }
    var showBookmarksOnly by remember { mutableStateOf(false) }

    val offlineSet = remember(cachedSurahNumbers) {
        cachedSurahNumbers.toSet() + BundledQuranSurahs.bundledSurahNumbers()
    }

    if (!openSurahDirect) {
        val filteredSurahs = remember(searchQuery, showBookmarksOnly, bookmarks) {
            val q = searchQuery.trim().lowercase()
            val bookmarkedSurahs = bookmarks.filter { it.itemType == "QURAN" }.map { it.surahNumber }.toSet()
            SurahCatalog.allSurahs.filter { surah ->
                val matchesSearch = q.isEmpty() ||
                    surah.englishName.lowercase().contains(q) ||
                    surah.englishMeaning.lowercase().contains(q) ||
                    surah.banglaName.contains(q) ||
                    surah.arabicName.contains(q) ||
                    surah.number.toString() == q
                val matchesBm = !showBookmarksOnly || bookmarkedSurahs.contains(surah.number)
                matchesSearch && matchesBm
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .tutorialTarget(TutorialTargetKeys.QURAN_OFFLINE_CARD),
                    accentBorder = true
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${strings.surahsCountLabel} • ${offlineSet.size}/114 ${strings.offlineReadyLabel}",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary
                            )
                            Text(
                                text = if (isBn) "যাচাইকৃত আরবি, ইংরেজি, বাংলা অনুবাদ ও উচ্চারণ" else "Verified Uthmani text, EN/BN translations & transliteration",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                        if (quranState.isDownloadingAll) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = palette.accentSoft,
                                strokeWidth = 2.5.dp
                            )
                        }
                    }
                    if (quranState.isDownloadingAll) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { quranState.downloadProgressCount / 114f },
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)),
                            color = palette.accentPrimary,
                            trackColor = palette.blockBg
                        )
                        Text(
                            text = "${strings.downloadingSurahs} (${quranState.downloadProgressCount}/114)",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.accentSoft,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    } else if (offlineSet.size < 114) {
                        Spacer(modifier = Modifier.height(10.dp))
                        EmeraldActionButton(
                            text = strings.downloadAllSurahs,
                            icon = Icons.Default.CloudDownload,
                            enabled = isOnline,
                            onClick = onDownloadAllOffline,
                            modifier = Modifier.fillMaxWidth().testTag("download_all_surahs_button")
                        )
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (isBn) "এখানে লিখুন" else "Type here", color = palette.textMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.textSecondary) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accentPrimary,
                        unfocusedBorderColor = palette.borderNeutral,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .tutorialTarget(TutorialTargetKeys.QURAN_SEARCH_BAR)
                        .testTag("surah_search_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassFilterChip(
                        label = strings.surahsCountLabel,
                        selected = !showBookmarksOnly,
                        onClick = { showBookmarksOnly = false }
                    )
                    GlassFilterChip(
                        label = "${strings.bookmarksFilter} (${bookmarks.count { it.itemType == "QURAN" }})",
                        selected = showBookmarksOnly,
                        onClick = { showBookmarksOnly = true },
                        icon = Icons.Default.Bookmark
                    )
                }
            }

            items(filteredSurahs, key = { it.number }) { surah ->
                val isCached = offlineSet.contains(surah.number)
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("surah_row_${surah.number}"),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    onClick = {
                        onSelectSurah(surah.number)
                        onSetReaderOpen(true)
                    }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(palette.accentPrimary.copy(alpha = 0.15f), CircleShape)
                                    .border(0.8.dp, palette.accentPrimary.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = surah.number.toString(),
                                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                    color = palette.accentSoft
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isBn) surah.banglaName else surah.englishName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = "${surah.englishMeaning} • ${surah.ayahCount} ${strings.ayahsLabel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = surah.arabicName,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = ArabicFontFamily,
                                    textDirection = TextDirection.Rtl
                                ),
                                color = palette.gold
                            )
                            if (isCached) {
                                Icon(
                                    imageVector = Icons.Default.OfflinePin,
                                    contentDescription = strings.cachedOffline,
                                    tint = palette.accentSoft,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    } else {
        // Surah Reader Screen
        val meta = SurahCatalog.getMeta(quranState.selectedSurahNumber)
        val activeReciter = SurahCatalog.reciters.firstOrNull { it.id == prefs.selectedReciterId }
            ?: SurahCatalog.reciters.first()
        var reciterMenuExpanded by remember { mutableStateOf(false) }
        var reciterSearch by remember { mutableStateOf("") }

        Column(modifier = Modifier.fillMaxSize()) {
            // Reader Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(
                        onClick = { onSetReaderOpen(false) },
                        modifier = Modifier.testTag("quran_back_to_list")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = palette.textPrimary)
                    }
                    Column {
                        Text(
                            text = "${meta.number}. ${if (isBn) meta.banglaName else meta.englishName}",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${meta.arabicName} • ${meta.ayahCount} ${strings.ayahsLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.gold
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.tutorialTarget(TutorialTargetKeys.SURAH_READER_DISPLAY_BAR)
                ) {
                    IconButton(onClick = { onChangeFontSize(prefs.quranFontSizeSp - 2) }) {
                        Text("A-", style = MaterialTheme.typography.labelLarge, color = palette.textSecondary)
                    }
                    IconButton(onClick = { onChangeFontSize(prefs.quranFontSizeSp + 2) }) {
                        Icon(Icons.Default.FormatSize, contentDescription = strings.textSizeLabel, tint = palette.textPrimary)
                    }
                    IconButton(
                        onClick = { onTogglePronunciation(!prefs.showPronunciation) },
                        modifier = Modifier.testTag("toggle_pronunciation_button")
                    ) {
                        Icon(
                            Icons.Default.RecordVoiceOver,
                            contentDescription = strings.showPronunciation,
                            tint = if (prefs.showPronunciation) palette.accentSoft else palette.textMuted
                        )
                    }
                }
            }

            // Searchable Human Reciter Dropdown Selector + Play Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .tutorialTarget(TutorialTargetKeys.SURAH_READER_RECITER_PLAY),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    Surface(
                        onClick = { reciterMenuExpanded = true },
                        shape = RoundedCornerShape(14.dp),
                        color = palette.cardBg,
                        border = BorderStroke(0.8.dp, palette.borderAccent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("reciter_dropdown_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    Icons.Default.GraphicEq,
                                    contentDescription = strings.selectReciter,
                                    tint = palette.accentSoft,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (isBn) activeReciter.nameBn else activeReciter.nameEn,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = palette.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${activeReciter.style} • ${activeReciter.bitrate}kbps",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.textMuted,
                                        maxLines = 1
                                    )
                                }
                            }
                            Icon(
                                Icons.Default.ArrowDropDown,
                                contentDescription = strings.selectReciter,
                                tint = palette.gold
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = reciterMenuExpanded,
                        onDismissRequest = { reciterMenuExpanded = false },
                        modifier = Modifier
                            .width(300.dp)
                            .background(palette.surfaceBg)
                    ) {
                        OutlinedTextField(
                            value = reciterSearch,
                            onValueChange = { reciterSearch = it },
                            placeholder = {
                                Text(
                                    if (isBn) "এখানে লিখুন" else "Type here",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textMuted
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = palette.accentPrimary,
                                unfocusedBorderColor = palette.borderNeutral,
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("reciter_search_input")
                        )
                        val matchingReciters = SurahCatalog.reciters.filter { r ->
                            val q = reciterSearch.trim().lowercase()
                            q.isEmpty() || r.nameEn.lowercase().contains(q) || r.nameBn.contains(q) || r.style.lowercase().contains(q)
                        }
                        matchingReciters.forEach { reciter ->
                            val isSelected = activeReciter.id == reciter.id
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isBn) reciter.nameBn else reciter.nameEn,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = if (isSelected) palette.accentSoft else palette.textPrimary
                                            )
                                            Text(
                                                text = "${reciter.style} • ${reciter.bitrate}kbps",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = palette.textMuted
                                            )
                                        }
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                },
                                onClick = {
                                    onSelectReciter(reciter)
                                    reciterMenuExpanded = false
                                },
                                modifier = Modifier.testTag("reciter_${reciter.id}")
                            )
                        }
                    }
                }

                val thisSurahPlaying = audioState.activeSurahNumber == meta.number && audioState.isPlaying
                EmeraldActionButton(
                    text = if (thisSurahPlaying) strings.pauseAudio else strings.playSurah,
                    icon = if (thisSurahPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    onClick = {
                        if (audioState.activeSurahNumber == meta.number) onTogglePlayPause()
                        else onPlaySurahAyah(meta.number, 1)
                    },
                    modifier = Modifier.testTag("play_surah_button")
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPillBadge(
                    label = if (quranState.isFromOfflineCache) strings.cachedOffline else strings.onlineBadge,
                    accentColor = if (quranState.isFromOfflineCache) palette.accentSoft else palette.gold
                )
                if (audioState.errorMessage != null && audioState.activeSurahNumber == meta.number) {
                    Text(
                        text = audioState.errorMessage,
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.coral,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp).weight(1f, fill = false)
                    )
                }
            }

            if (prefs.showPronunciation) {
                Text(
                    text = strings.pronunciationDisclaimer,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.gold.copy(alpha = 0.85f),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            when {
                quranState.isLoading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = palette.accentPrimary)
                    }
                }
                quranState.errorMessage != null -> {
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        GlassCard {
                            Text(quranState.errorMessage, style = MaterialTheme.typography.bodyMedium, color = palette.coral)
                            Spacer(modifier = Modifier.height(10.dp))
                            EmeraldActionButton(
                                text = if (isBn) "আবার চেষ্টা করুন" else "Retry",
                                onClick = { onSelectSurah(meta.number) }
                            )
                        }
                    }
                }
                else -> {
                    val ayahListState = rememberLazyListState()
                    val surahAuthContext = remember(meta.number) {
                        com.example.ruhzena.data.islamic.SurahAuthenticContextCatalog.forSurah(meta.number)
                    }
                    var surahContextExpanded by rememberSaveable(meta.number) { mutableStateOf(false) }

                    // Auto-scroll directly to the saved Continue Reading Ayah when opening this Surah
                    // (+1 accounts for the Surah Context header item at index 0)
                    LaunchedEffect(quranState.selectedSurahNumber, quranState.ayahs.size, targetScrollAyah) {
                        if (quranState.ayahs.isNotEmpty()) {
                            val desiredAyah = targetScrollAyah
                                ?: if (prefs.lastReadSurah == quranState.selectedSurahNumber && prefs.lastReadAyah > 1) {
                                    prefs.lastReadAyah
                                } else null
                            if (desiredAyah != null) {
                                val targetIndex = quranState.ayahs.indexOfFirst { it.ayahNumber == desiredAyah }
                                if (targetIndex >= 0) {
                                    ayahListState.scrollToItem(index = targetIndex + 1, scrollOffset = 0)
                                }
                                if (targetScrollAyah != null) onConsumedTargetScroll()
                            }
                        }
                    }

                    // Silently auto-bookmark whichever Ayah sits closest to the vertical center of the viewport
                    LaunchedEffect(ayahListState, quranState.selectedSurahNumber, quranState.ayahs) {
                        if (quranState.ayahs.isEmpty()) return@LaunchedEffect
                        snapshotFlow {
                            val layout = ayahListState.layoutInfo
                            val visible = layout.visibleItemsInfo
                            if (visible.isEmpty()) return@snapshotFlow null
                            val viewportCenter = (layout.viewportStartOffset + layout.viewportEndOffset) / 2
                            val centerItem = visible.minByOrNull { item ->
                                val itemCenter = item.offset + (item.size / 2)
                                abs(itemCenter - viewportCenter)
                            }
                            centerItem?.index?.let { idx ->
                                if (idx > 0) quranState.ayahs.getOrNull(idx - 1) else null
                            }
                        }
                            .filterNotNull()
                            .distinctUntilChanged { old, new ->
                                old.surahNumber == new.surahNumber && old.ayahNumber == new.ayahNumber
                            }
                            .collect { centeredAyah ->
                                onMarkLastRead(centeredAyah.surahNumber, centeredAyah.ayahNumber)
                            }
                    }

                    LazyColumn(
                        state = ayahListState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 32.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item(key = "surah_authentic_context_${meta.number}") {
                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .tutorialTarget(TutorialTargetKeys.SURAH_READER_FIRST_AYAH)
                                    .testTag("surah_authentic_context_card"),
                                accentBorder = true,
                                contentPadding = PaddingValues(14.dp),
                                onClick = { surahContextExpanded = !surahContextExpanded }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isBn) "সূরার পূর্ণাঙ্গ প্রেক্ষাপট ও শানে নুযূল" else "Full Surah Context & Authentic Tafsir Background",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = palette.gold,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isBn) surahAuthContext.periodDetailBn else surahAuthContext.periodDetailEn,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.accentSoft
                                        )
                                    }
                                    StatusPillBadge(
                                        label = if (surahContextExpanded) {
                                            if (isBn) "সংক্ষিপ্ত" else "Hide"
                                        } else {
                                            if (isBn) "পূর্ণ প্রেক্ষাপট" else "Read Full"
                                        },
                                        accentColor = palette.gold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isBn) surahAuthContext.revelationBackgroundBn else surahAuthContext.revelationBackgroundEn,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textPrimary,
                                    maxLines = if (surahContextExpanded) Int.MAX_VALUE else 3,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 20.sp
                                )
                                if (surahContextExpanded) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (isBn) "মূল বিষয়বস্তু ও তাফসীর:" else "Core Themes & Classical Tafsir:",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = palette.accentSoft,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = if (isBn) surahAuthContext.coreThemesBn else surahAuthContext.coreThemesEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary,
                                        lineHeight = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (isBn) "প্রামাণ্য ফজিলত ও হাদীস:" else "Authentic Prophetic Virtues:",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = palette.gold,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = if (isBn) surahAuthContext.propheticVirtueBn else surahAuthContext.propheticVirtueEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary,
                                        lineHeight = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    GoldSourceTag(sourceText = surahAuthContext.classicalSourceRef)
                                }
                            }
                        }

                        items(quranState.ayahs, key = { it.globalNumber }) { ayah ->
                            val isCurrentlyPlayingAyah =
                                audioState.activeSurahNumber == ayah.surahNumber &&
                                    audioState.currentAyahNumber == ayah.ayahNumber
                            val bmKey = "QURAN_${ayah.surahNumber}_${ayah.ayahNumber}"
                            val isSaved = bookmarks.any { it.key == bmKey }

                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ayah_card_${ayah.ayahNumber}"),
                                accentBorder = isCurrentlyPlayingAyah
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    StatusPillBadge(
                                        label = "${ayah.surahNumber}:${ayah.ayahNumber}",
                                        accentColor = if (isCurrentlyPlayingAyah) palette.accentSoft else palette.gold
                                    )
                                    Row {
                                        IconButton(
                                            onClick = { onPlaySurahAyah(ayah.surahNumber, ayah.ayahNumber) },
                                            modifier = Modifier.testTag("play_ayah_${ayah.ayahNumber}")
                                        ) {
                                            Icon(
                                                imageVector = if (isCurrentlyPlayingAyah && audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = strings.listenPronunciation,
                                                tint = palette.accentSoft
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                onToggleBookmark(
                                                    BookmarkEntity(
                                                        key = bmKey,
                                                        itemType = "QURAN",
                                                        title = "${meta.englishName} ${ayah.surahNumber}:${ayah.ayahNumber}",
                                                        subtitle = if (isBn) ayah.banglaTranslation else ayah.englishTranslation,
                                                        arabicText = ayah.arabicText,
                                                        surahNumber = ayah.surahNumber,
                                                        ayahNumber = ayah.ayahNumber
                                                    ),
                                                    isSaved
                                                )
                                            },
                                            modifier = Modifier.testTag("bookmark_ayah_${ayah.ayahNumber}")
                                        ) {
                                            Icon(
                                                imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                                contentDescription = strings.bookmarkSaved,
                                                tint = if (isSaved) palette.gold else palette.textSecondary
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Arabic Quranic Text — ALWAYS RTL & preserved regardless of UI language
                                Text(
                                    text = ayah.arabicText,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontFamily = ArabicFontFamily,
                                        fontSize = prefs.quranFontSizeSp.sp,
                                        lineHeight = (prefs.quranFontSizeSp * 1.65f).sp,
                                        textDirection = TextDirection.Rtl
                                    ),
                                    color = palette.textPrimary,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                if (prefs.showPronunciation) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = if (isBn) ayah.banglaTransliteration else ayah.englishTransliteration,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = palette.accentSoft,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isBn) ayah.banglaTranslation else ayah.englishTranslation,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = palette.textSecondary
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    GlassFilterChip(
                                        label = strings.explanationAction,
                                        selected = false,
                                        icon = Icons.Default.AutoAwesome,
                                        onClick = { onLoadAyahExplanation(ayah) },
                                        modifier = Modifier.testTag("ayah_explain_${ayah.ayahNumber}")
                                    )
                                    GlassFilterChip(
                                        label = if (isBn) "রূহযেনা AI" else "Ask RuhZena AI",
                                        selected = false,
                                        onClick = {
                                            val q = if (isBn) {
                                                "সূরা ${meta.banglaName} (${ayah.surahNumber}:${ayah.ayahNumber}) এর তাফসীর ও বাস্তব শিক্ষা সহজভাবে বুঝিয়ে দিন।"
                                            } else {
                                                "Explain Surah ${meta.englishName} (${ayah.surahNumber}:${ayah.ayahNumber}) in depth with historical context and everyday reflection."
                                            }
                                            onAskRuhZebaAi("ISLAMIC", q)
                                        },
                                        modifier = Modifier.testTag("ayah_ask_ai_${ayah.ayahNumber}")
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (ayahExplanationState.selectedAyah != null) {
            AyahExplanationDialog(
                state = ayahExplanationState,
                isBn = isBn,
                fontSizeSp = prefs.quranFontSizeSp,
                onRetryOnline = { onRetryAyahExplanation(ayahExplanationState.selectedAyah) },
                onAskRuhZebaAi = {
                    val a = ayahExplanationState.selectedAyah
                    onClearAyahExplanation()
                    val q = if (isBn) {
                        "কুরআন ${a.surahNumber}:${a.ayahNumber} সম্পর্কে আমার আরও প্রশ্ন আছে—এর শিক্ষা কীভাবে জীবনে প্রয়োগ করব?"
                    } else {
                        "Can we explore Quran ${a.surahNumber}:${a.ayahNumber} further and see how to practice its message daily?"
                    }
                    onAskRuhZebaAi("ISLAMIC", q)
                },
                onDismiss = onClearAyahExplanation
            )
        }
    }
}

@Composable
private fun AyahExplanationDialog(
    state: AyahExplanationState,
    isBn: Boolean,
    fontSizeSp: Int,
    onRetryOnline: () -> Unit,
    onAskRuhZebaAi: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val context = LocalContext.current
    val ayah = state.selectedAyah ?: return
    val exp = state.explanation

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .testTag("ayah_explanation_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = palette.surfaceBg,
            border = BorderStroke(1.dp, palette.borderAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_ayah_explanation_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.closeAction, tint = palette.textPrimary)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (exp != null) (if (isBn) exp.titleBn else exp.titleEn) else "${ayah.surahNumber}:${ayah.ayahNumber}",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary
                        )
                        if (exp != null) {
                            Text(
                                text = if (isBn) exp.surahContextBn else exp.surahContextEn,
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.gold
                            )
                        }
                    }
                }

                GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                    Text(
                        text = ayah.arabicText,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = ArabicFontFamily,
                            fontSize = fontSizeSp.sp,
                            lineHeight = (fontSizeSp * 1.65f).sp,
                            textDirection = TextDirection.Rtl
                        ),
                        color = palette.gold,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(strings.pronunciationNote, style = MaterialTheme.typography.labelMedium, color = palette.accentSoft)
                    Text(
                        text = if (isBn) ayah.banglaTransliteration else ayah.englishTransliteration,
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(strings.meaningTitle, style = MaterialTheme.typography.labelMedium, color = palette.gold)
                    Text(
                        text = if (isBn) ayah.banglaTranslation else ayah.englishTranslation,
                        style = MaterialTheme.typography.bodyLarge,
                        color = palette.textSecondary
                    )
                }

                if (state.networkError != null) {
                    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                        Text(
                            text = if (isBn) {
                                "অনলাইন গভীর তাফসীর পাওয়া যায়নি (${state.networkError}) — যাচাইকৃত অফলাইন তাফসীর দেখানো হচ্ছে।"
                            } else {
                                "Online deep Tafsir unavailable (${state.networkError}) — showing verified offline context below."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.amber
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onRetryOnline,
                            modifier = Modifier.testTag("retry_ayah_explanation_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isBn) "আবার চেষ্টা করুন" else "Retry AI Tafsir")
                        }
                    }
                }

                if (state.isLoading) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(color = palette.accentSoft, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isBn) "তাফসীর ও প্রাসঙ্গিক তথ্য লোড হচ্ছে..." else "Loading Surah & Tafsir explanation...",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.accentSoft
                        )
                    }
                } else if (exp != null) {
                    val deeperText = if (isBn) exp.deeperContextBn else exp.deeperContextEn
                    if (deeperText.isNotBlank()) {
                        GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                            Text(
                                text = strings.deeperContextTitle,
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.gold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = deeperText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textPrimary,
                                modifier = Modifier.testTag("ayah_deeper_context_body")
                            )
                        }
                    }

                    GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.explanationTitle, style = MaterialTheme.typography.labelLarge, color = palette.accentSoft)
                            }
                            StatusPillBadge(
                                label = if (state.isAiGenerated) "RuhZena AI" else strings.cachedOffline,
                                accentColor = if (state.isAiGenerated) palette.accentSoft else palette.gold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isBn) exp.explanationBn else exp.explanationEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textPrimary,
                            modifier = Modifier.testTag("ayah_explanation_body")
                        )
                    }

                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(strings.lifeLessonTitle, style = MaterialTheme.typography.labelLarge, color = palette.gold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isBn) exp.lifeLessonBn else exp.lifeLessonEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textSecondary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        val quranUrl = "https://quran.com/${ayah.surahNumber}/${ayah.ayahNumber}"
                        GoldSourceTag(
                            sourceText = "${exp.sourceNote} • quran.com/${ayah.surahNumber}/${ayah.ayahNumber} ↗",
                            modifier = Modifier.clickable {
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(quranUrl))) }
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        EmeraldActionButton(
                            text = if (isBn) "এই আয়াত নিয়ে রূহযেনা AI-কে জিজ্ঞাসা করুন" else "Ask RuhZena AI About This Ayah",
                            icon = Icons.Default.AutoAwesome,
                            onClick = onAskRuhZebaAi,
                            modifier = Modifier.fillMaxWidth().testTag("ayah_dialog_ask_ai")
                        )
                    }
                }
            }
        }
    }
}
