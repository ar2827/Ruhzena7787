package com.example.ruhzena.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.SectionHeader
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.DailyPrayerSchedule
import com.example.ruhzena.data.islamic.IslamicContentData
import com.example.ruhzena.data.islamic.NextPrayerInfo
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.local.HabitCheckEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.data.local.WorkoutLogEntity
import com.example.ruhzena.notifications.MotivationKnowledgeCatalog
import com.example.ruhzena.ui.components.HomeDigitalAnalyticsCard
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import java.util.Calendar

@Composable
fun HomeDashboardScreen(
    prefs: UserPreferences,
    isOnline: Boolean,
    nextPrayer: NextPrayerInfo,
    prayerSchedule: DailyPrayerSchedule,
    waterMlToday: Int,
    workoutsTodayCount: Int,
    habitsDoneCount: Int,
    totalHabitsCount: Int,
    caloriesToday: Int,
    mealsTodayCount: Int,
    weeklyWaterLogs: List<WaterLogEntity> = emptyList(),
    habitChecks30Days: List<HabitCheckEntity> = emptyList(),
    recentWorkouts: List<WorkoutLogEntity> = emptyList(),
    onOpenSettings: () -> Unit,
    onOpenSearch: () -> Unit = {},
    onOpenMotivationWindow: () -> Unit,
    onDismissMotivationBanner: () -> Unit = {},
    onQuickAction: (HomeQuickDestination) -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current

    val prayerDisplayName = when (nextPrayer.prayerKey) {
        "FAJR" -> strings.fajr
        "DHUHR" -> strings.dhuhr
        "ASR" -> strings.asr
        "MAGHRIB" -> strings.maghrib
        else -> strings.isha
    }
    val remH = nextPrayer.minutesRemaining / 60
    val remM = nextPrayer.minutesRemaining % 60
    val countdownStr = if (remH > 0) "${remH}h ${remM}m" else "${remM}m"

    val lastSurah = SurahCatalog.getMeta(prefs.lastReadSurah)
    val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
    val dailyLesson = IslamicContentData.lessonsList[dayOfYear % IslamicContentData.lessonsList.size]

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Futuristic Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.ruhzena_emblem),
                        contentDescription = strings.appName,
                        modifier = Modifier.size(34.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (prefs.userName.isNotBlank()) "${strings.salamGreeting}, ${prefs.userName}" else strings.salamGreeting,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.accentSoft,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = strings.appName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = palette.textPrimary
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onOpenSearch,
                        modifier = Modifier
                            .tutorialTarget(TutorialTargetKeys.BTN_SEARCH)
                            .testTag("global_search_button")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = palette.textPrimary)
                    }
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .tutorialTarget(TutorialTargetKeys.BTN_SETTINGS)
                            .testTag("home_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = strings.settingsTitle, tint = palette.textPrimary)
                    }
                }
            }
        }

        // Next Prayer Hero Glass Card with Inline 5-Prayer Strip
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.CARD_NEXT_PRAYER)
                    .testTag("home_next_prayer_card"),
                elevated = true,
                accentBorder = true,
                contentPadding = PaddingValues(14.dp),
                onClick = { onQuickAction(HomeQuickDestination.PRAYER_QIBLA) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.nextPrayerLabel.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.accentSoft
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = prayerDisplayName,
                                style = MaterialTheme.typography.headlineMedium,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = nextPrayer.timeFormatted,
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = palette.gold
                            )
                        }
                        Text(
                            text = "${prefs.locationName} • ${strings.prayerInPrefix} $countdownStr",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(palette.accentPrimary.copy(alpha = 0.16f), CircleShape)
                            .border(0.8.dp, palette.borderAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Explore, contentDescription = strings.qiblaAction, tint = palette.accentSoft, modifier = Modifier.size(22.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                val slots = listOf(
                    Triple("FAJR", strings.fajr, prayerSchedule.fajrMinutes),
                    Triple("DHUHR", strings.dhuhr, prayerSchedule.dhuhrMinutes),
                    Triple("ASR", strings.asr, prayerSchedule.asrMinutes),
                    Triple("MAGHRIB", strings.maghrib, prayerSchedule.maghribMinutes),
                    Triple("ISHA", strings.isha, prayerSchedule.ishaMinutes)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    slots.forEach { (key, label, mins) ->
                        val active = nextPrayer.prayerKey == key
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (active) palette.accentContainer else palette.blockBg,
                                    RoundedCornerShape(10.dp)
                                )
                                .border(
                                    0.7.dp,
                                    if (active) palette.borderAccent else palette.borderNeutral.copy(alpha = 0.45f),
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(vertical = 6.dp, horizontal = 3.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) palette.accentSoft else palette.textMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = PrayerCalculator.formatMinutes(mins).substringBefore(" "),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (active) palette.gold else palette.textPrimary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Daily Rhythm Telemetry (2x2 Bento)
        item {
            SectionHeader(title = strings.dailyOverviewTitle)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val waterPct = (waterMlToday.toFloat() / prefs.hydrationGoalMl.coerceAtLeast(1)).coerceIn(0f, 1f)
                MetricGlassTile(
                    title = strings.hydrationLabel,
                    value = "$waterMlToday ml",
                    subtitle = "/ ${prefs.hydrationGoalMl} ml",
                    progress = waterPct,
                    icon = Icons.Default.WaterDrop,
                    accentColor = palette.sky,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_metric_water"),
                    onClick = { onQuickAction(HomeQuickDestination.HYDRATION) }
                )
                MetricGlassTile(
                    title = strings.habitsLabel,
                    value = "$habitsDoneCount / $totalHabitsCount",
                    subtitle = if (isBn) "আজকের লক্ষ্য" else "Today",
                    progress = if (totalHabitsCount > 0) habitsDoneCount.toFloat() / totalHabitsCount else 0f,
                    icon = Icons.Default.CheckCircle,
                    accentColor = palette.accentSoft,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_metric_habits"),
                    onClick = { onQuickAction(HomeQuickDestination.HABITS) }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricGlassTile(
                    title = strings.workoutLabel,
                    value = "$workoutsTodayCount",
                    subtitle = if (isBn) "সেশন আজ" else "Sessions today",
                    progress = if (workoutsTodayCount > 0) 1f else 0.12f,
                    icon = Icons.Default.FitnessCenter,
                    accentColor = palette.gold,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_metric_workouts"),
                    onClick = { onQuickAction(HomeQuickDestination.WORKOUTS) }
                )
                val calPct = (caloriesToday / 2100f).coerceIn(0f, 1f)
                MetricGlassTile(
                    title = strings.nutritionLabel,
                    value = "$caloriesToday kcal",
                    subtitle = if (isBn) "$mealsTodayCount টি খাবার" else "$mealsTodayCount meals",
                    progress = calPct,
                    icon = Icons.Default.Restaurant,
                    accentColor = palette.amber,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_metric_nutrition"),
                    onClick = { onQuickAction(HomeQuickDestination.NUTRITION) }
                )
            }
        }

        // Animated 7-Day Digital Analytics Graph Dashboard
        item {
            HomeDigitalAnalyticsCard(
                isBn = isBn,
                hydrationGoalMl = prefs.hydrationGoalMl,
                waterMlToday = waterMlToday,
                habitsDoneToday = habitsDoneCount,
                totalHabits = totalHabitsCount,
                workoutsToday = workoutsTodayCount,
                caloriesToday = caloriesToday,
                weeklyWaterLogs = weeklyWaterLogs,
                habitChecks30Days = habitChecks30Days,
                recentWorkouts = recentWorkouts
            )
        }

        // Quick Access Compact 3x2 Grid
        item {
            SectionHeader(title = strings.quickActionsTitle)
            Spacer(modifier = Modifier.height(6.dp))
            val actions = listOf(
                Triple(strings.qiblaAction, Icons.Default.Explore, HomeQuickDestination.PRAYER_QIBLA),
                Triple(strings.tasbihAction, Icons.Default.RadioButtonChecked, HomeQuickDestination.TASBIH),
                Triple(strings.adhkarAction, Icons.Default.Spa, HomeQuickDestination.ADHKAR),
                Triple(strings.duaAction, Icons.Default.VolunteerActivism, HomeQuickDestination.DUA),
                Triple(strings.journalAction, Icons.AutoMirrored.Filled.MenuBook, HomeQuickDestination.JOURNAL),
                Triple(strings.aiCoachAction, Icons.Default.AutoAwesome, HomeQuickDestination.AI_CHAT)
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                actions.chunked(3).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { (label, icon, dest) ->
                            GlassCard(
                                cornerRadius = 14.dp,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                                onClick = { onQuickAction(dest) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("quick_action_${dest.name.lowercase()}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(icon, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = palette.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Continue Reading Quran Card (auto-synced silently from middle of Quran reader viewport)
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_continue_reading_card"),
                accentBorder = true,
                elevated = true,
                contentPadding = PaddingValues(14.dp),
                onClick = { onQuickAction(HomeQuickDestination.QURAN_CONTINUE) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(palette.accentContainer, RoundedCornerShape(12.dp))
                                .border(1.dp, palette.gold.copy(alpha = 0.55f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = palette.gold, modifier = Modifier.size(21.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = strings.continueReadingQuran,
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.gold,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${lastSurah.number}. ${if (isBn) lastSurah.banglaName else lastSurah.englishName}",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isBn) {
                                    "আয়াত ${prefs.lastReadAyah} / ${lastSurah.ayahCount}"
                                } else {
                                    "Ayah ${prefs.lastReadAyah} of ${lastSurah.ayahCount}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = lastSurah.arabicName,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = ArabicFontFamily,
                                textDirection = TextDirection.Rtl
                            ),
                            color = palette.gold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        StatusPillBadge(
                            label = if (isBn) "পড়া চালিয়ে যান" else "Resume",
                            accentColor = palette.accentSoft
                        )
                    }
                }
            }
        }

        // Islamic Learning Hub Card (Wudu, Salah, Hajj, 5-Level Arabic, History & Kids)
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_learning_hub_card"),
                contentPadding = PaddingValues(13.dp),
                onClick = { onQuickAction(HomeQuickDestination.LEARNING_HUB) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(palette.accentPrimary.copy(alpha = 0.14f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.School, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isBn) "ইসলামিক শিক্ষা" else "Islamic Learning",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                            Text(
                                text = if (isBn) {
                                    "ধাপে ধাপে পাঠ ও কুইজ, সালাত ও অজু গাইড, আরবি লিখন ও অডিও গল্প"
                                } else {
                                    "Step-by-step path & quizzes, Salah & Wudu guide, Arabic studio & stories"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = palette.accentSoft,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Monthly Dashboard & Today's Progress Card
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_my_day_button"),
                contentPadding = PaddingValues(13.dp),
                onClick = { onQuickAction(HomeQuickDestination.MY_DAY_JOURNEY) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(palette.gold.copy(alpha = 0.14f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Today, contentDescription = null, tint = palette.gold, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isBn) "মাসিক ড্যাশবোর্ড ও আজকের দিন" else "Monthly Dashboard & Today",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                            Text(
                                text = if (isBn) {
                                    "৩০ দিনের হিটম্যাপ এবং কুরআন, শিক্ষা, ব্যায়াম, পানি ও অভ্যাসের সম্পূর্ণ রেকর্ড"
                                } else {
                                    "30-day activity heatmap & live records across every section"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = palette.gold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Subtle Dismissible Hourly Motivation, Knowledge & Reminders Window Card
        if (!prefs.motivationBannerDismissed) {
            item {
                val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val hourlyInsight = MotivationKnowledgeCatalog.forHour(currentHour, 0)
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_motivation_window_card"),
                    accentBorder = true,
                    contentPadding = PaddingValues(12.dp),
                    onClick = onOpenMotivationWindow
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(palette.accentPrimary.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = strings.motivationWindowTitle,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = if (isBn) hourlyInsight.motivationBn else hourlyInsight.motivationEn,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        IconButton(
                            onClick = onDismissMotivationBanner,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = strings.closeAction,
                                tint = palette.textMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Daily Verified Islamic Insight Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.dailyIslamicLesson, style = MaterialTheme.typography.labelMedium, color = palette.accentSoft)
                    StatusPillBadge(label = dailyLesson.grading, accentColor = palette.gold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBn) dailyLesson.titleBn else dailyLesson.titleEn,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = dailyLesson.arabicText,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontFamily = ArabicFontFamily,
                        fontSize = 19.sp,
                        lineHeight = 30.sp,
                        textDirection = TextDirection.Rtl
                    ),
                    color = palette.gold,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isBn) dailyLesson.bodyBn else dailyLesson.bodyEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                GoldSourceTag(
                    sourceText = "${dailyLesson.sourceRef} ↗",
                    modifier = Modifier.clickable {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(dailyLesson.sourceUrl)))
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun MetricGlassTile(
    title: String,
    value: String,
    subtitle: String,
    progress: Float,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    GlassCard(
        modifier = modifier,
        cornerRadius = 16.dp,
        contentPadding = PaddingValues(12.dp),
        onClick = onClick
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = palette.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(15.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.SemiBold),
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = palette.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(modifier = Modifier.height(6.dp))
        val animatedProgress by animateFloatAsState(
            targetValue = progress.coerceIn(0f, 1f),
            animationSpec = tween(durationMillis = 500),
            label = "metricProgress"
        )
        LinearProgressIndicator(
            progress = { animatedProgress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = accentColor,
            trackColor = palette.blockBg
        )
    }
}

enum class HomeQuickDestination {
    QURAN_CONTINUE, PRAYER_QIBLA, TASBIH, ADHKAR, DUA, HYDRATION, WORKOUTS, NUTRITION, HABITS, JOURNAL, AI_CHAT, LEARNING_HUB, MY_DAY_JOURNEY
}
