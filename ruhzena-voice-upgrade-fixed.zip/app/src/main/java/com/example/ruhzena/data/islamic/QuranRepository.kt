package com.example.ruhzena.data.islamic

import android.util.Log
import com.example.ruhzena.ai.FirebaseGeminiService
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.local.CachedSurahDao
import com.example.ruhzena.data.local.CachedSurahEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

sealed interface SurahLoadResult {
    data class Success(val ayahs: List<QuranAyah>, val fromOfflineCache: Boolean) : SurahLoadResult
    data class Error(val message: String, val isOffline: Boolean) : SurahLoadResult
}

data class AyahExplanationResult(
    val explanation: AyahExplanation,
    val isAiGenerated: Boolean,
    val networkError: String? = null
)

class QuranRepository(
    private val cachedSurahDao: CachedSurahDao,
    private val aiAyahExplainer: suspend (QuranAyah, AppLanguage) -> AyahExplanation = { ayah, lang ->
        FirebaseGeminiService.explainAyahInDepth(ayah, lang)
    }
) {

    private val json = Json { ignoreUnknownKeys = true }
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val surahContextCache = ConcurrentHashMap<Int, String>()
    private val ayahExplanationCache = ConcurrentHashMap<String, AyahExplanation>()

    fun observeCachedSurahNumbers(): Flow<List<Int>> = cachedSurahDao.getCachedSurahNumbers()

    suspend fun loadSurah(surahNumber: Int, isOnline: Boolean): SurahLoadResult = withContext(Dispatchers.IO) {
        // 1. Check Room cache first
        val cached = cachedSurahDao.getSurah(surahNumber)
        if (cached != null) {
            return@withContext try {
                val ayahs = json.decodeFromString<List<QuranAyah>>(cached.ayahsJson)
                SurahLoadResult.Success(ayahs, fromOfflineCache = true)
            } catch (_: Exception) {
                fetchAndCacheSurah(surahNumber, isOnline)
            }
        }

        // 2. Check verified bundled Surahs
        val bundled = BundledQuranSurahs.getBundledSurah(surahNumber)
        if (bundled != null) {
            return@withContext SurahLoadResult.Success(bundled, fromOfflineCache = true)
        }

        // 3. Fetch verified dataset online from api.alquran.cloud
        fetchAndCacheSurah(surahNumber, isOnline)
    }

    suspend fun loadAyahExplanation(
        ayah: QuranAyah,
        isOnline: Boolean,
        language: AppLanguage = AppLanguage.ENGLISH,
        forceRefresh: Boolean = false
    ): AyahExplanationResult = withContext(Dispatchers.IO) {
        val cacheKey = "${ayah.surahNumber}:${ayah.ayahNumber}:${language.code}"
        if (!forceRefresh) {
            ayahExplanationCache[cacheKey]?.let {
                return@withContext AyahExplanationResult(explanation = it, isAiGenerated = true)
            }
        }

        var aiError: String? = null
        if (isOnline) {
            try {
                val aiExplanation = aiAyahExplainer(ayah, language)
                ayahExplanationCache[cacheKey] = aiExplanation
                return@withContext AyahExplanationResult(explanation = aiExplanation, isAiGenerated = true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w("QuranRepository", "Multi-provider Tafsir fallback to local for $cacheKey", e)
                aiError = e.localizedMessage ?: "AI Tafsir temporarily unavailable"
            }
        }

        val cachedWeb = surahContextCache[ayah.surahNumber]
        if (cachedWeb != null) {
            return@withContext AyahExplanationResult(
                explanation = QuranExplanationProvider.buildExplanation(ayah, cachedWeb),
                isAiGenerated = false,
                networkError = aiError
            )
        }

        if (isOnline && ayah.surahNumber !in setOf(1, 97, 103, 108, 110, 112, 113, 114)) {
            val fetched = fetchSurahSummaryContextOnline(ayah.surahNumber)
            if (!fetched.isNullOrBlank()) {
                surahContextCache[ayah.surahNumber] = fetched
                return@withContext AyahExplanationResult(
                    explanation = QuranExplanationProvider.buildExplanation(ayah, fetched),
                    isAiGenerated = false,
                    networkError = aiError
                )
            }
        }
        AyahExplanationResult(
            explanation = QuranExplanationProvider.buildExplanation(ayah, null),
            isAiGenerated = false,
            networkError = aiError
        )
    }

    private fun fetchSurahSummaryContextOnline(surahNumber: Int): String? {
        val meta = SurahCatalog.getMeta(surahNumber)
        val search = URLEncoder.encode("Surah ${meta.englishName}", "UTF-8")
        val title = runCatching {
            val url = "https://en.wikipedia.org/w/api.php?action=opensearch&search=$search&limit=2&namespace=0&format=json"
            val req = Request.Builder().url(url).header("User-Agent", "RuhZena/1.0").build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val arr = JSONArray(resp.body?.string().orEmpty())
                val titles = arr.optJSONArray(1)
                if (titles != null && titles.length() > 0) titles.optString(0) else null
            }
        }.getOrNull() ?: return null

        return runCatching {
            val slug = URLEncoder.encode(title.replace(" ", "_"), "UTF-8")
            val sumUrl = "https://en.wikipedia.org/api/rest_v1/page/summary/$slug"
            val req = Request.Builder().url(sumUrl).header("User-Agent", "RuhZena/1.0").build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val obj = JSONObject(resp.body?.string().orEmpty())
                obj.optString("extract").trim().take(420).takeIf { it.length >= 40 }
            }
        }.getOrNull()
    }

    private suspend fun fetchAndCacheSurah(surahNumber: Int, isOnline: Boolean): SurahLoadResult {
        if (!isOnline) {
            return SurahLoadResult.Error(
                message = "Surah not yet downloaded for offline reading. Connect to the internet once to cache it locally.",
                isOffline = true
            )
        }

        return try {
            val url =
                "https://api.alquran.cloud/v1/surah/$surahNumber/editions/quran-uthmani,en.sahih,bn.bengali,en.transliteration"
            val request = Request.Builder().url(url).build()
            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return SurahLoadResult.Error("API returned HTTP ${response.code}", isOffline = false)
            }
            val body = response.body?.string().orEmpty()
            val root = json.parseToJsonElement(body).jsonObject
            val editions = root["data"]?.jsonArray
                ?: return SurahLoadResult.Error("Malformed Quran response", isOffline = false)
            if (editions.size < 4) {
                return SurahLoadResult.Error("Incomplete editions returned", isOffline = false)
            }

            val arabicAyahs = editions[0].jsonObject["ayahs"]!!.jsonArray
            val englishAyahs = editions[1].jsonObject["ayahs"]!!.jsonArray
            val banglaAyahs = editions[2].jsonObject["ayahs"]!!.jsonArray
            val translitAyahs = editions[3].jsonObject["ayahs"]!!.jsonArray

            val result = arabicAyahs.indices.map { idx ->
                val arObj = arabicAyahs[idx].jsonObject
                val enObj = englishAyahs[idx].jsonObject
                val bnObj = banglaAyahs[idx].jsonObject
                val trObj = translitAyahs[idx].jsonObject
                val numInSurah = arObj["numberInSurah"]!!.jsonPrimitive.int
                val globalNum = arObj["number"]!!.jsonPrimitive.int
                val enTranslit = trObj["text"]!!.jsonPrimitive.content
                QuranAyah(
                    surahNumber = surahNumber,
                    ayahNumber = numInSurah,
                    globalNumber = globalNum,
                    arabicText = arObj["text"]!!.jsonPrimitive.content,
                    englishTranslation = enObj["text"]!!.jsonPrimitive.content,
                    banglaTranslation = bnObj["text"]!!.jsonPrimitive.content,
                    englishTransliteration = enTranslit,
                    banglaTransliteration = BanglaPhoneticConverter.toBanglaPhonetic(enTranslit)
                )
            }

            cachedSurahDao.insertSurah(
                CachedSurahEntity(
                    surahNumber = surahNumber,
                    ayahsJson = json.encodeToString(result)
                )
            )
            SurahLoadResult.Success(result, fromOfflineCache = false)
        } catch (e: Exception) {
            SurahLoadResult.Error(e.message ?: "Network error", isOffline = false)
        }
    }

    suspend fun downloadAllMissingSurahs(
        isOnline: Boolean,
        onProgress: (downloaded: Int, total: Int) -> Unit
    ): Int = withContext(Dispatchers.IO) {
        if (!isOnline) return@withContext 0
        var count = 0
        for (surah in SurahCatalog.allSurahs) {
            val existing = cachedSurahDao.getSurah(surah.number)
            if (existing == null) {
                val res = fetchAndCacheSurah(surah.number, isOnline = true)
                if (res is SurahLoadResult.Success) {
                    count++
                }
            } else {
                count++
            }
            onProgress(surah.number, 114)
        }
        count
    }
}
