package com.example.ruhzena.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import android.graphics.Paint as AndroidPaint
import android.graphics.Rect as AndroidRect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.IslamicAcademyCatalog
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.LocalRuhZenaPalette

private data class DrawnStroke(
    val points: List<Offset>,
    val color: Color,
    val widthPx: Float
)

@Composable
fun ArabicWritingStudioTab(
    isBn: Boolean,
    masteredLetterKeys: Set<String>,
    speakingItemId: String? = null,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit = { _, _, _ -> },
    onToggleMastered: (String) -> Unit,
    onAskRuhZenaAi: (String) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val letters = IslamicAcademyCatalog.all28ArabicLetters
    var selectedIdx by rememberSaveable { mutableIntStateOf(0) }
    val activeLetter = letters[selectedIdx.coerceIn(letters.indices)]

    var showTraceGuide by rememberSaveable { mutableStateOf(true) }
    var brushWidthPx by rememberSaveable { mutableFloatStateOf(16f) }
    var selectedInkIdx by rememberSaveable { mutableIntStateOf(0) }

    val inkColors = listOf(palette.gold, palette.accentSoft, palette.sky, palette.textPrimary)
    val activeInk = inkColors[selectedInkIdx.coerceIn(inkColors.indices)]

    val completedStrokes = remember(activeLetter.key) { mutableStateListOf<DrawnStroke>() }
    val activePoints = remember(activeLetter.key) { mutableStateListOf<Offset>() }

    val isMastered = masteredLetterKeys.contains(activeLetter.key)
    val masteryRatio = (masteredLetterKeys.size.toFloat() / letters.size.toFloat()).coerceIn(0f, 1f)
    val letterSpeechId = "arabic_letter_${activeLetter.key}"
    val isSpeakingActive = speakingItemId == letterSpeechId

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("arabic_writing_studio_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Mastery Progress Header
        item {
            GlassCard(accentBorder = true, elevated = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "আরবি লিখন ও উচ্চারণ স্টুডিও" else "Arabic Writing & Audio Studio",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isBn) {
                                "${masteredLetterKeys.size} / ${letters.size} টি হরফ আয়ত্ত হয়েছে"
                            } else {
                                "${masteredLetterKeys.size} of ${letters.size} Arabic letters mastered"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.gold
                        )
                    }
                    StatusPillBadge(
                        label = "${(masteryRatio * 100).toInt()}%",
                        accentColor = palette.accentSoft
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { masteryRatio },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = palette.accentSoft,
                    trackColor = palette.blockBg
                )
            }
        }

        // All 28 Letters Selector Strip
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.ARABIC_LETTER_STRIP)
                    .testTag("arabic_28_letters_row")
            ) {
                itemsIndexed(letters, key = { _, l -> l.key }) { idx, item ->
                    val selected = idx == selectedIdx
                    val mastered = masteredLetterKeys.contains(item.key)
                    Column(
                        modifier = Modifier
                            .size(width = 58.dp, height = 68.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                when {
                                    selected -> palette.accentContainer
                                    mastered -> palette.gold.copy(alpha = 0.14f)
                                    else -> palette.cardBg
                                }
                            )
                            .border(
                                width = if (selected) 1.3.dp else 0.7.dp,
                                color = when {
                                    selected -> palette.borderAccent
                                    mastered -> palette.gold.copy(alpha = 0.55f)
                                    else -> palette.borderNeutral
                                },
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                selectedIdx = idx
                                onSpeakArabic(
                                    "arabic_letter_${item.key}",
                                    item.isolated,
                                    "${item.nameEn}. Sound: ${item.transliteration}"
                                )
                            }
                            .padding(vertical = 4.dp)
                            .testTag("arabic_letter_chip_${item.key}"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = item.isolated,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontFamily = ArabicFontFamily,
                                textDirection = TextDirection.Rtl
                            ),
                            color = if (selected) palette.gold else palette.textPrimary
                        )
                        Text(
                            text = if (isBn) item.nameBn else item.nameEn,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (mastered) palette.accentSoft else palette.textMuted,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Interactive Touch-Drawing Canvas Card (supports both single-tap Nuqta dots and continuous swipes)
        item {
            GlassCard(accentBorder = true, elevated = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${if (isBn) activeLetter.nameBn else activeLetter.nameEn} (${activeLetter.transliteration})",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isBn) activeLetter.strokeHintBn else activeLetter.strokeHintEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                onSpeakArabic(
                                    letterSpeechId,
                                    activeLetter.isolated,
                                    "${activeLetter.nameEn}. Pronunciation: ${activeLetter.transliteration}"
                                )
                            },
                            modifier = Modifier.testTag("arabic_listen_letter_button")
                        ) {
                            Icon(
                                imageVector = if (isSpeakingActive) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = if (isBn) "উচ্চারণ শুনুন" else "Listen to letter",
                                tint = if (isSpeakingActive) palette.gold else palette.accentSoft
                            )
                        }
                        IconButton(
                            onClick = { showTraceGuide = !showTraceGuide },
                            modifier = Modifier.testTag("arabic_canvas_toggle_guide")
                        ) {
                            Icon(
                                imageVector = if (showTraceGuide) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Toggle trace guide",
                                tint = if (showTraceGuide) palette.gold else palette.textMuted
                            )
                        }
                        IconButton(
                            onClick = { if (completedStrokes.isNotEmpty()) completedStrokes.removeAt(completedStrokes.lastIndex) },
                            enabled = completedStrokes.isNotEmpty(),
                            modifier = Modifier.testTag("arabic_canvas_undo")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Undo,
                                contentDescription = "Undo stroke",
                                tint = if (completedStrokes.isNotEmpty()) palette.textPrimary else palette.textMuted
                            )
                        }
                        IconButton(
                            onClick = {
                                completedStrokes.clear()
                                activePoints.clear()
                            },
                            modifier = Modifier.testTag("arabic_canvas_clear")
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear canvas", tint = palette.coral)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Drawing Canvas Surface — single tap stamps a calligraphic dot (nuqta), swipe draws strokes
                val context = LocalContext.current
                val density = LocalDensity.current
                val amiriTypeface = remember(context) {
                    runCatching { ResourcesCompat.getFont(context, R.font.amiri) }.getOrNull()
                }
                val guideColorArgb = palette.textMuted.copy(alpha = if (palette.isLight) 0.22f else 0.26f).toArgb()
                val guideTextSizePx = with(density) { 126.sp.toPx() }
                val guidePaint = remember(amiriTypeface, guideColorArgb, guideTextSizePx) {
                    AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
                        color = guideColorArgb
                        textSize = guideTextSizePx
                        textAlign = AndroidPaint.Align.LEFT
                        if (amiriTypeface != null) typeface = amiriTypeface
                    }
                }
                val guideInkBounds = remember(activeLetter.isolated, guidePaint) {
                    AndroidRect().also { rect ->
                        guidePaint.getTextBounds(activeLetter.isolated, 0, activeLetter.isolated.length, rect)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(242.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(
                                    palette.cardElevatedBg.copy(alpha = 0.85f),
                                    palette.voidBg.copy(alpha = if (palette.isLight) 0.55f else 0.90f)
                                )
                            )
                        )
                        .border(1.1.dp, palette.borderAccent.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
                        .tutorialTarget(TutorialTargetKeys.ARABIC_WRITING_CANVAS)
                        .testTag("arabic_drawing_canvas"),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(activeLetter.key, activeInk, brushWidthPx) {
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    down.consume()
                                    activePoints.clear()
                                    activePoints.add(down.position)
                                    val pointerId = down.id

                                    while (true) {
                                        val event = awaitPointerEvent()
                                        val change = event.changes.firstOrNull { it.id == pointerId } ?: break
                                        if (change.pressed) {
                                            change.consume()
                                            val prev = activePoints.lastOrNull()
                                            if (prev == null || (change.position - prev).getDistance() >= 2.5f) {
                                                activePoints.add(change.position)
                                            }
                                        } else {
                                            change.consume()
                                            break
                                        }
                                    }

                                    if (activePoints.isNotEmpty()) {
                                        completedStrokes.add(
                                            DrawnStroke(
                                                points = activePoints.toList(),
                                                color = activeInk,
                                                widthPx = brushWidthPx
                                            )
                                        )
                                        activePoints.clear()
                                    }
                                }
                            }
                    ) {
                        // Subtle symmetrical 4-corner studio framing markers
                        val guideTint = palette.gold.copy(alpha = 0.20f)
                        val mLen = 14f
                        val pad = 12f
                        drawLine(guideTint, Offset(pad, pad), Offset(pad + mLen, pad), strokeWidth = 2f, cap = StrokeCap.Round)
                        drawLine(guideTint, Offset(pad, pad), Offset(pad, pad + mLen), strokeWidth = 2f, cap = StrokeCap.Round)
                        drawLine(guideTint, Offset(size.width - pad, pad), Offset(size.width - pad - mLen, pad), strokeWidth = 2f, cap = StrokeCap.Round)
                        drawLine(guideTint, Offset(size.width - pad, pad), Offset(size.width - pad, pad + mLen), strokeWidth = 2f, cap = StrokeCap.Round)
                        drawLine(guideTint, Offset(pad, size.height - pad), Offset(pad + mLen, size.height - pad), strokeWidth = 2f, cap = StrokeCap.Round)
                        drawLine(guideTint, Offset(pad, size.height - pad), Offset(pad, size.height - pad - mLen), strokeWidth = 2f, cap = StrokeCap.Round)
                        drawLine(guideTint, Offset(size.width - pad, size.height - pad), Offset(size.width - pad - mLen, size.height - pad), strokeWidth = 2f, cap = StrokeCap.Round)
                        drawLine(guideTint, Offset(size.width - pad, size.height - pad), Offset(size.width - pad, size.height - pad - mLen), strokeWidth = 2f, cap = StrokeCap.Round)

                        // True visual dead-center trace glyph using exact native ink bounds
                        // (eliminates Arabic font ascent/padding droop so every letter sits strictly centered)
                        if (showTraceGuide) {
                            val targetCenterX = size.width * 0.5f
                            val targetCenterY = (size.height - 22.dp.toPx()) * 0.5f
                            val drawX = targetCenterX - guideInkBounds.exactCenterX()
                            val drawY = targetCenterY - guideInkBounds.exactCenterY()
                            drawContext.canvas.nativeCanvas.drawText(
                                activeLetter.isolated,
                                drawX,
                                drawY,
                                guidePaint
                            )
                        }

                        fun drawStroke(pts: List<Offset>, color: Color, width: Float) {
                            if (pts.size == 1) {
                                // Single tap stamps a crisp calligraphic dot (nuqta)
                                drawCircle(
                                    color = color.copy(alpha = 0.22f),
                                    radius = (width * 0.85f).coerceAtLeast(11f),
                                    center = pts.first()
                                )
                                drawCircle(
                                    color = color,
                                    radius = (width * 0.58f).coerceAtLeast(8f),
                                    center = pts.first()
                                )
                                return
                            }
                            if (pts.size > 1) {
                                val path = Path().apply {
                                    moveTo(pts.first().x, pts.first().y)
                                    for (i in 1 until pts.size) {
                                        val prev = pts[i - 1]
                                        val cur = pts[i]
                                        quadraticTo(prev.x, prev.y, (prev.x + cur.x) / 2f, (prev.y + cur.y) / 2f)
                                    }
                                    lineTo(pts.last().x, pts.last().y)
                                }
                                drawPath(
                                    path = path,
                                    color = color.copy(alpha = 0.18f),
                                    style = Stroke(width = width * 1.45f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                )
                                drawPath(
                                    path = path,
                                    color = color,
                                    style = Stroke(width = width, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                )
                            }
                        }

                        completedStrokes.forEach { s -> drawStroke(s.points, s.color, s.widthPx) }
                        if (activePoints.isNotEmpty()) {
                            drawStroke(activePoints, activeInk, brushWidthPx)
                        }
                    }

                    if (completedStrokes.isEmpty() && activePoints.isEmpty()) {
                        Text(
                            text = if (isBn) "আঙুল টেনে লিখুন • নুকতার জন্য ট্যাপ করুন" else "Swipe to write (Right → Left) • Tap once to place dots",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textMuted,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Ink Color & Brush Size Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        inkColors.forEachIndexed { idx, col ->
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(col)
                                    .border(
                                        width = if (idx == selectedInkIdx) 2.5.dp else 1.dp,
                                        color = if (idx == selectedInkIdx) Color.White else palette.borderNeutral,
                                        shape = CircleShape
                                    )
                                    .clickable { selectedInkIdx = idx }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(10f to "S", 16f to "M", 24f to "L").forEach { (w, lbl) ->
                            GlassFilterChip(
                                label = lbl,
                                selected = kotlin.math.abs(brushWidthPx - w) < 2f,
                                onClick = { brushWidthPx = w }
                            )
                        }
                    }
                }
            }
        }

        // 4 Contextual Forms + Makharij Articulation Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (isBn) "৪টি অবস্থানগত রূপ (শুরু • মধ্য • শেষ • একক)" else "4 Contextual Letter Forms",
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.accentSoft
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        (if (isBn) "একক" else "Isolated") to activeLetter.isolated,
                        (if (isBn) "শুরু" else "Initial") to activeLetter.initial,
                        (if (isBn) "মধ্য" else "Medial") to activeLetter.medial,
                        (if (isBn) "শেষ" else "Final") to activeLetter.finalForm
                    ).forEach { (label, glyph) ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.blockBg)
                                .border(0.7.dp, palette.borderNeutral, RoundedCornerShape(14.dp))
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = glyph,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontFamily = ArabicFontFamily,
                                    textDirection = TextDirection.Rtl
                                ),
                                color = palette.gold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(label, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = palette.sky, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isBn) "মাখরাজ (সঠিক উচ্চারণ স্থান)" else "Makhraj (Pronunciation Point)",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.sky
                        )
                        Text(
                            text = if (isBn) activeLetter.makhrajBn else activeLetter.makhrajEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EmeraldActionButton(
                        text = if (isMastered) {
                            if (isBn) "আয়ত্ত সম্পন্ন ✓" else "Mastered ✓"
                        } else {
                            if (isBn) "আয়ত্ত হিসেবে চিহ্নিত করুন" else "Mark Mastered"
                        },
                        icon = Icons.Default.CheckCircle,
                        onClick = { onToggleMastered(activeLetter.key) },
                        modifier = Modifier
                            .weight(1f)
                            .tutorialTarget(TutorialTargetKeys.ARABIC_MASTERED_BTN)
                            .testTag("arabic_mark_mastered_button")
                    )
                    GlassFilterChip(
                        label = if (isBn) "AI-কে প্রশ্ন" else "Ask RuhZena AI",
                        selected = false,
                        icon = Icons.Default.AutoAwesome,
                        onClick = {
                            val q = if (isBn) {
                                "আরবি হরফ '${activeLetter.nameBn}' (${activeLetter.isolated}) এর সঠিক মাখরাজ ও ৩টি কুরআনিক উদাহরণ শেখান।"
                            } else {
                                "Teach me how to pronounce the Arabic letter '${activeLetter.nameEn}' (${activeLetter.isolated}) with its Makhraj and 3 short Quranic word examples."
                            }
                            onAskRuhZenaAi(q)
                        }
                    )
                }
            }
        }
    }
}
