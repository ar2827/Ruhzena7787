package com.example.ruhzena.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.media.LocalRuhZenaSound
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.sp
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.ArabicFontFamily
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.SegmentedGlassTabRow
import com.example.ruhzena.core.ui.SegmentedTabItem
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.local.HabitCheckEntity
import com.example.ruhzena.data.local.HabitEntity
import com.example.ruhzena.data.local.JournalEntryEntity
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.coroutines.launch

enum class DisciplineSubTab { HABITS, JOURNAL }

@Composable
private fun disciplineFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = LocalRuhZenaPalette.current.accentPrimary,
    unfocusedBorderColor = LocalRuhZenaPalette.current.borderNeutral,
    focusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    unfocusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    focusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted,
    unfocusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted
)

@Composable
fun DisciplineJournalScreen(
    selectedTab: DisciplineSubTab,
    onSelectTab: (DisciplineSubTab) -> Unit,
    habits: List<HabitEntity>,
    checksToday: List<HabitCheckEntity>,
    journalEntries: List<JournalEntryEntity>,
    openUrgeDialogTrigger: Int = 0,
    onAddHabit: (String, String, Boolean, String) -> Unit,
    onToggleHabit: (HabitEntity, Boolean) -> Unit,
    onSaveHabitRecovery: (HabitEntity, String) -> Unit,
    onDeleteHabit: (Long) -> Unit,
    onAddJournal: (String, String, String, String) -> Unit,
    onDeleteJournal: (Long) -> Unit,
    onExportJournalJson: suspend () -> String,
    formatTime: (Long) -> String,
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> },
    speakingItemId: String? = null,
    onSpeakArabic: (itemId: String, arabicText: String, fallback: String) -> Unit = { _, _, _ -> }
) {
    val strings = LocalStrings.current

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            SegmentedGlassTabRow(
                items = listOf(
                    SegmentedTabItem(DisciplineSubTab.HABITS, strings.tabHabits, "discipline_tab_habits"),
                    SegmentedTabItem(DisciplineSubTab.JOURNAL, strings.tabJournal, "discipline_tab_journal")
                ),
                selected = selectedTab,
                onSelect = onSelectTab
            )
        }

        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = {
                val forward = targetState == DisciplineSubTab.JOURNAL
                (fadeIn(tween(220, easing = FastOutSlowInEasing)) +
                    slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { if (forward) it / 10 else -it / 10 }) togetherWith
                    (fadeOut(tween(150)) + slideOutHorizontally(tween(160)) { if (forward) -it / 12 else it / 12 })
            },
            modifier = Modifier.weight(1f),
            label = "disciplineTabTransition"
        ) { activeTab ->
            if (activeTab == DisciplineSubTab.HABITS) {
                HabitsTab(
                    habits = habits,
                    checksToday = checksToday,
                    openUrgeDialogTrigger = openUrgeDialogTrigger,
                    onAddHabit = onAddHabit,
                    onToggleHabit = onToggleHabit,
                    onSaveRecovery = onSaveHabitRecovery,
                    onDeleteHabit = onDeleteHabit,
                    onAddJournal = onAddJournal,
                    onAskRuhZebaAi = onAskRuhZebaAi,
                    speakingItemId = speakingItemId,
                    onSpeakArabic = onSpeakArabic
                )
            } else {
                JournalTab(
                    entries = journalEntries,
                    onAddJournal = onAddJournal,
                    onDeleteJournal = onDeleteJournal,
                    onExportJson = onExportJournalJson,
                    formatTime = formatTime,
                    onAskRuhZebaAi = onAskRuhZebaAi
                )
            }
        }
    }
}

@Composable
private fun HabitsTab(
    habits: List<HabitEntity>,
    checksToday: List<HabitCheckEntity>,
    openUrgeDialogTrigger: Int = 0,
    onAddHabit: (String, String, Boolean, String) -> Unit,
    onToggleHabit: (HabitEntity, Boolean) -> Unit,
    onSaveRecovery: (HabitEntity, String) -> Unit,
    onDeleteHabit: (Long) -> Unit,
    onAddJournal: (String, String, String, String) -> Unit,
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> },
    speakingItemId: String? = null,
    onSpeakArabic: (itemId: String, arabicText: String, fallback: String) -> Unit = { _, _, _ -> }
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val completedIds = remember(checksToday) { checksToday.map { it.habitId }.toSet() }
    val doneTodayCount = remember(habits, completedIds) { habits.count { completedIds.contains(it.id) } }
    val topStreak = remember(habits) { habits.maxOfOrNull { it.bestStreak } ?: 0 }

    var newHabitTitle by remember { mutableStateOf("") }
    var newHabitCategory by remember { mutableStateOf("Spirituality") }
    var recoveryTarget by remember { mutableStateOf<HabitEntity?>(null) }
    var recoveryNoteText by remember { mutableStateOf("") }
    var showUrgeDialog by remember { mutableStateOf(false) }

    LaunchedEffect(openUrgeDialogTrigger) {
        if (openUrgeDialogTrigger > 0) {
            showUrgeDialog = true
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("habits_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 52.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true, elevated = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(label = "$doneTodayCount/${habits.size} • ${strings.habitsLabel}", accentColor = palette.accentSoft)
                    StatusPillBadge(label = "${strings.bestStreakLabel}: $topStreak", accentColor = palette.gold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.recoveryBanner, style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                }
                Spacer(modifier = Modifier.height(10.dp))
                val isBnHabit = LocalAppLanguage.current == AppLanguage.BANGLA
                EmeraldActionButton(
                    text = if (isBnHabit) "প্রলোভন রিসেট • শান্ত শ্বাস" else "Urge Reset",
                    icon = Icons.Default.SelfImprovement,
                    onClick = { showUrgeDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .tutorialTarget(TutorialTargetKeys.HABITS_URGE_RESET_BTN)
                        .testTag("habits_urge_recovery_button")
                )
                Spacer(modifier = Modifier.height(8.dp))
                GlassFilterChip(
                    label = if (isBnHabit) "রূহযেবা AI-এর সাথে কথা বলুন" else "Talk It Out with RuhZeba AI",
                    selected = false,
                    icon = Icons.Default.AutoAwesome,
                    onClick = {
                        val q = if (isBnHabit) {
                            "আমার ভালো অভ্যাসে ধারাবাহিক থাকতে ও দুর্বল মুহূর্ত সামলাতে একটু পরামর্শ ও অনুপ্রেরণা দরকার।"
                        } else {
                            "I want steady guidance on building consistent daily habits and bouncing back gently after a missed day."
                        }
                        onAskRuhZebaAi("WELLNESS", q)
                    },
                    modifier = Modifier.testTag("habits_talk_it_out_button")
                )
            }
        }

        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.HABITS_ADD_CARD)
            ) {
                Text(strings.addHabit, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = newHabitTitle,
                    onValueChange = { newHabitTitle = it },
                    placeholder = { Text(strings.habitNameHint, color = palette.textMuted) },
                    singleLine = true,
                    colors = disciplineFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("new_habit_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("Spirituality", "Health", "Discipline", "Learning")) { cat ->
                        GlassFilterChip(label = cat, selected = newHabitCategory == cat, onClick = { newHabitCategory = cat })
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                EmeraldActionButton(
                    text = strings.addHabit,
                    icon = Icons.Default.Add,
                    onClick = {
                        if (newHabitTitle.isNotBlank()) {
                            onAddHabit(newHabitTitle.trim(), newHabitCategory, false, "08:00")
                            newHabitTitle = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("add_habit_button")
                )
            }
        }

        items(habits, key = { it.id }) { habit ->
            val done = completedIds.contains(habit.id)
            GlassCard(
                modifier = Modifier.fillMaxWidth().testTag("habit_card_${habit.id}"),
                accentBorder = done
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconButton(
                            onClick = { onToggleHabit(habit, done) },
                            modifier = Modifier.testTag("toggle_habit_${habit.id}")
                        ) {
                            Icon(
                                imageVector = if (done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = habit.title,
                                tint = if (done) palette.accentSoft else palette.textSecondary
                            )
                        }
                        Column {
                            Text(habit.title, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(
                                text = "${habit.category} • ${strings.streakLabel}: ${habit.currentStreak} • ${strings.bestStreakLabel}: ${habit.bestStreak}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.gold
                            )
                        }
                    }
                    IconButton(onClick = { onDeleteHabit(habit.id) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = strings.deleteAction, tint = palette.textMuted)
                    }
                }
                if (habit.recoveryNote.isNotBlank()) {
                    Text("Recovery Note: ${habit.recoveryNote}", style = MaterialTheme.typography.bodySmall, color = palette.accentSoft, modifier = Modifier.padding(start = 12.dp, top = 4.dp))
                }
                Row(modifier = Modifier.padding(start = 12.dp, top = 6.dp)) {
                    GlassFilterChip(
                        label = strings.recoverMissedDay,
                        selected = false,
                        onClick = {
                            recoveryNoteText = habit.recoveryNote
                            recoveryTarget = habit
                        }
                    )
                }
            }
        }
    }

    if (showUrgeDialog) {
        UrgeBreathingRecoveryDialog(
            speakingItemId = speakingItemId,
            onSpeakArabic = onSpeakArabic,
            onCompleteReset = { reflection ->
                val target = habits.firstOrNull()
                val note = reflection.ifBlank { "Calm 4-4-6 Istighfar reset completed" }
                if (target != null) {
                    onSaveRecovery(target, note)
                } else {
                    onAddJournal(
                        "Urge Reset • Calm Victory",
                        note,
                        "Calm",
                        "Paused, breathed 4-4-6, and remembered Allah"
                    )
                }
                showUrgeDialog = false
            },
            onDismiss = { showUrgeDialog = false }
        )
    }

    recoveryTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { recoveryTarget = null },
            containerColor = palette.surfaceBg,
            title = { Text(strings.recoverMissedDay, color = palette.textPrimary) },
            text = {
                OutlinedTextField(
                    value = recoveryNoteText,
                    onValueChange = { recoveryNoteText = it },
                    placeholder = { Text("What small step brings you back smoothly?", color = palette.textMuted) },
                    colors = disciplineFieldColors(),
                    shape = RoundedCornerShape(12.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onSaveRecovery(target, recoveryNoteText.trim())
                    recoveryTarget = null
                }) {
                    Text("Save", color = palette.accentSoft)
                }
            },
            dismissButton = {
                TextButton(onClick = { recoveryTarget = null }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun UrgeBreathingRecoveryDialog(
    speakingItemId: String?,
    onSpeakArabic: (itemId: String, arabicText: String, fallback: String) -> Unit,
    onCompleteReset: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    // Phase 0: Realistic 60fps modern biometric breathing sanctuary
    // Phase 1: Post-breathing grounding Dua (with Listen button) + optional reflection log
    var phaseStep by remember { mutableIntStateOf(0) }
    var elapsedSecFloat by remember { mutableFloatStateOf(0f) }
    var reflectionText by remember { mutableStateOf("") }

    val cycleDurationSec = 14f // 4s Inhale -> 4s Hold -> 6s Exhale
    val totalCycles = 3
    val totalDurationSec = cycleDurationSec * totalCycles

    LaunchedEffect(phaseStep) {
        if (phaseStep == 0) {
            var lastNanos = 0L
            var lastCueBucket = -1
            while (elapsedSecFloat < totalDurationSec) {
                withFrameNanos { now ->
                    if (lastNanos != 0L) {
                        val dt = ((now - lastNanos) / 1_000_000_000f).coerceAtMost(0.06f)
                        elapsedSecFloat = (elapsedSecFloat + dt).coerceAtMost(totalDurationSec)
                    }
                    lastNanos = now
                }
                val secInCycleInt = (elapsedSecFloat % cycleDurationSec).toInt()
                val cycleNum = (elapsedSecFloat / cycleDurationSec).toInt()
                val bucket = cycleNum * 2 + if (secInCycleInt >= 8) 1 else 0
                if (bucket != lastCueBucket && (secInCycleInt == 0 || secInCycleInt == 8)) {
                    lastCueBucket = bucket
                    sound?.playBreathPhaseCue(isInhale = secInCycleInt == 0)
                }
            }
            sound?.playChime()
            phaseStep = 1
        }
    }

    val cycleIndex = ((elapsedSecFloat / cycleDurationSec).toInt() + 1).coerceIn(1, totalCycles)
    val tInCycle = elapsedSecFloat % cycleDurationSec

    // 0 = Inhale (0..4s), 1 = Hold (4..8s), 2 = Exhale (8..14s)
    val breathStage = when {
        tInCycle < 4f -> 0
        tInCycle < 8f -> 1
        else -> 2
    }

    val stageProgress = when (breathStage) {
        0 -> (tInCycle / 4f).coerceIn(0f, 1f)
        1 -> ((tInCycle - 4f) / 4f).coerceIn(0f, 1f)
        else -> ((tInCycle - 8f) / 6f).coerceIn(0f, 1f)
    }

    val phaseSecLeft = when (breathStage) {
        0 -> ceil(4f - tInCycle).toInt().coerceIn(1, 4)
        1 -> ceil(8f - tInCycle).toInt().coerceIn(1, 4)
        else -> ceil(14f - tInCycle).toInt().coerceIn(1, 6)
    }

    val cueWord = when (breathStage) {
        0 -> if (isBn) "শ্বাস নিন" else "Inhale"
        1 -> if (isBn) "ধরে রাখুন" else "Hold"
        else -> if (isBn) "ধীরে ছাড়ুন" else "Exhale"
    }

    // Physiological lung expansion curve: smooth sinusoidal rise -> subtle pressurized pulse -> slow sigh release
    val lungExpansion = when (breathStage) {
        0 -> {
            val s = ((1f - cos(stageProgress * PI)) / 2f).toFloat()
            0.46f + 0.54f * s
        }
        1 -> {
            // Subtle calm heartbeat resonance while holding full breath
            1.0f + 0.016f * sin(stageProgress * 4f * PI.toFloat())
        }
        else -> {
            // Smooth decelerating physiological exhale
            val ease = 1f - (1f - stageProgress).pow(2.15f)
            1.0f - 0.54f * ease
        }
    }

    val activePhaseColor by animateColorAsState(
        targetValue = when (breathStage) {
            0 -> Color(0xFF7CC6F2) // Crisp serene inhale sky-silver
            1 -> palette.gold      // Calm golden stillness
            else -> Color(0xFF8FB8AE) // Deep grounding release slate-jade
        },
        animationSpec = tween(durationMillis = 700),
        label = "breathPhaseColor"
    )

    val calmArabicDua = "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ"
    val calmDuaTranslit = "Astaghfirullāhal-‘Aẓīm wa atūbu ilayh"
    val calmDuaMeaning = if (isBn) {
        "আমি মহান আল্লাহর কাছে ক্ষমা প্রার্থনা করছি এবং তাঁর দিকেই ফিরে আসছি।"
    } else {
        "I seek forgiveness from Allah the Almighty and turn to Him in repentance."
    }
    val duaSpeechId = "urge_reset_dua"
    val isSpeakingDua = speakingItemId == duaSpeechId

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF060910),
                            Color(0xFF0B111C),
                            Color(0xFF05070C)
                        )
                    )
                )
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .testTag("urge_breathing_dialog")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPillBadge(
                    label = if (phaseStep == 0) {
                        if (isBn) "ধাপ ১/২" else "Step 1 of 2"
                    } else {
                        if (isBn) "ধাপ ২/২" else "Step 2 of 2"
                    },
                    accentColor = activePhaseColor
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textSecondary)
                }
            }

            AnimatedContent(
                targetState = phaseStep,
                transitionSpec = {
                    (fadeIn(tween(260, easing = FastOutSlowInEasing)) +
                        scaleIn(initialScale = 0.96f, animationSpec = tween(260))) togetherWith
                        fadeOut(tween(180))
                },
                modifier = Modifier.weight(1f),
                label = "urgePhaseTransition"
            ) { activePhaseStep ->
            if (activePhaseStep == 0) {
                // PHASE 1: Realistic 60fps Modern Biometric Breathing Sanctuary
                Column(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically)
                ) {
                    // Minimal cycle progress dots
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(totalCycles) { idx ->
                            val isActive = (idx + 1) == cycleIndex
                            val isPast = (idx + 1) < cycleIndex
                            Box(
                                modifier = Modifier
                                    .size(if (isActive) 10.dp else 7.dp)
                                    .background(
                                        color = when {
                                            isActive -> activePhaseColor
                                            isPast -> activePhaseColor.copy(alpha = 0.55f)
                                            else -> Color.White.copy(alpha = 0.16f)
                                        },
                                        shape = CircleShape
                                    )
                            )
                        }
                    }

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(292.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val center = this.center
                            val maxR = size.minDimension * 0.45f
                            val coreR = maxR * lungExpansion

                            // 1. Soft atmospheric ambient bloom
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        activePhaseColor.copy(alpha = 0.24f * lungExpansion),
                                        activePhaseColor.copy(alpha = 0.06f),
                                        Color.Transparent
                                    ),
                                    center = center,
                                    radius = maxR * 1.24f
                                ),
                                radius = maxR * 1.24f,
                                center = center
                            )

                            // 2. Three phase-lagged volumetric acoustic ripple rings
                            for (ring in 1..3) {
                                val waveShift = sin((elapsedSecFloat * 0.85f) - ring * 0.65f) * 0.035f
                                val r = (coreR * (0.86f + ring * 0.14f + waveShift)).coerceAtMost(maxR * 1.12f)
                                drawCircle(
                                    color = activePhaseColor.copy(alpha = (0.28f - ring * 0.07f).coerceAtLeast(0.05f)),
                                    radius = r,
                                    center = center,
                                    style = Stroke(width = 1.6f)
                                )
                            }

                            // 3. 24 realistic drifting breath particles (draw in on inhale, orbit on hold, exhale outward)
                            val particleCount = 24
                            for (i in 0 until particleCount) {
                                val baseAngle = (i.toFloat() / particleCount) * 2f * PI.toFloat() + elapsedSecFloat * 0.14f
                                val radialPhase = ((i * 0.19f) + stageProgress) % 1f
                                val particleDist = when (breathStage) {
                                    0 -> maxR * (1.12f - 0.62f * radialPhase) // flowing inward
                                    1 -> coreR * (1.02f + 0.06f * sin(elapsedSecFloat * 2.2f + i)) // calm hover
                                    else -> coreR * 0.65f + (maxR * 0.52f) * radialPhase // drifting outward
                                }
                                val px = center.x + cos(baseAngle) * particleDist
                                val py = center.y + sin(baseAngle) * particleDist
                                val pAlpha = sin(radialPhase * PI).toFloat().coerceIn(0.15f, 0.85f)
                                drawCircle(
                                    color = activePhaseColor.copy(alpha = pAlpha * 0.72f),
                                    radius = if (i % 3 == 0) 2.8f else 1.8f,
                                    center = Offset(px, py)
                                )
                            }

                            // 4. Translucent Liquid-Glass Lung Core with top specular highlight
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.22f),
                                        activePhaseColor.copy(alpha = 0.34f),
                                        Color(0xCC0D1422)
                                    ),
                                    center = Offset(center.x - coreR * 0.24f, center.y - coreR * 0.28f),
                                    radius = coreR * 1.18f
                                ),
                                radius = coreR,
                                center = center
                            )

                            // Crisp specular glass rim
                            drawCircle(
                                brush = Brush.verticalGradient(
                                    listOf(
                                        Color.White.copy(alpha = 0.65f),
                                        activePhaseColor.copy(alpha = 0.50f),
                                        Color.White.copy(alpha = 0.12f)
                                    )
                                ),
                                radius = coreR,
                                center = center,
                                style = Stroke(width = 2.2f)
                            )

                            // 5. Precision outer biometric progress track + live sweep arc
                            val trackR = maxR * 1.06f
                            val arcTopLeft = Offset(center.x - trackR, center.y - trackR)
                            val arcSize = Size(trackR * 2f, trackR * 2f)
                            drawArc(
                                color = Color.White.copy(alpha = 0.10f),
                                startAngle = -90f,
                                sweepAngle = 360f,
                                useCenter = false,
                                topLeft = arcTopLeft,
                                size = arcSize,
                                style = Stroke(width = 3.2f, cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = activePhaseColor,
                                startAngle = -90f,
                                sweepAngle = 360f * stageProgress,
                                useCenter = false,
                                topLeft = arcTopLeft,
                                size = arcSize,
                                style = Stroke(width = 4.2f, cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = cueWord,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${phaseSecLeft}s",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = activePhaseColor
                            )
                        }
                    }

                    Text(
                        text = if (isBn) {
                            "ধীরে ধীরে শ্বাসের ছন্দে মনোযোগ দিন"
                        } else {
                            "Breathe smoothly with the rhythm"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textSecondary,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                GlassFilterChip(
                    label = if (isBn) "পরবর্তী" else "Next",
                    selected = true,
                    onClick = { phaseStep = 1 },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .testTag("breathing_continue_phase2_btn")
                )
                }
            } else {
                // PHASE 2: Calm Post-Breathing Dua + Listen + Optional Log
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = if (isBn) "মন এখন শান্ত ও স্থির" else "Steady Heart & Grounding",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )

                    GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true, elevated = true) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isBn) "ইস্তিগফার" else "Istighfar & Renewal",
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.gold,
                                fontWeight = FontWeight.SemiBold
                            )
                            GlassFilterChip(
                                label = if (isSpeakingDua) (if (isBn) "থামান" else "Stop") else (if (isBn) "শুনুন" else "Listen"),
                                selected = isSpeakingDua,
                                icon = if (isSpeakingDua) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                onClick = { onSpeakArabic(duaSpeechId, calmArabicDua, calmDuaTranslit) }
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = calmArabicDua,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontFamily = ArabicFontFamily,
                                textDirection = TextDirection.Rtl,
                                lineHeight = 38.sp
                            ),
                            color = palette.gold,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = calmDuaTranslit,
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.accentSoft
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = calmDuaMeaning,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textPrimary
                        )
                    }

                    OutlinedTextField(
                        value = reflectionText,
                        onValueChange = { reflectionText = it },
                        placeholder = {
                            Text(
                                if (isBn) "কী আপনাকে শান্ত করল? (ঐচ্ছিক)" else "Optional calm reflection note...",
                                color = palette.textMuted
                            )
                        },
                        singleLine = true,
                        colors = disciplineFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassFilterChip(
                            label = if (isBn) "আবার শ্বাস নিন" else "Breathe Again",
                            selected = false,
                            onClick = {
                                elapsedSecFloat = 0f
                                phaseStep = 0
                            }
                        )
                        EmeraldActionButton(
                            text = if (isBn) "সম্পন্ন" else "Done",
                            icon = Icons.Default.CheckCircle,
                            onClick = {
                                sound?.playChime()
                                onCompleteReset(reflectionText.trim())
                            },
                            modifier = Modifier.weight(1f).testTag("log_urge_recovery_button")
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
            }
        }
    }
}

@Composable
private fun JournalTab(
    entries: List<JournalEntryEntity>,
    onAddJournal: (String, String, String, String) -> Unit,
    onDeleteJournal: (Long) -> Unit,
    onExportJson: suspend () -> String,
    formatTime: (Long) -> String,
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> }
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var achievement by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("Grateful") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("journal_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 52.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.tabJournal,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                GlassFilterChip(
                    label = strings.exportJournal,
                    selected = false,
                    icon = Icons.Default.Download,
                    onClick = {
                        scope.launch {
                            val exported = onExportJson()
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                putExtra(Intent.EXTRA_TEXT, exported)
                                type = "application/json"
                            }
                            runCatching {
                                context.startActivity(Intent.createChooser(sendIntent, strings.exportJournal))
                            }
                        }
                    },
                    modifier = Modifier.tutorialTarget(TutorialTargetKeys.JOURNAL_EXPORT_BTN)
                )
            }
        }

        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.JOURNAL_EDITOR_CARD)
            ) {
                Text(strings.addJournalEntry, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("Grateful", "Calm", "Focused", "Hopeful", "Struggling")) { m ->
                        GlassFilterChip(label = m, selected = mood == m, onClick = { mood = m })
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text(strings.journalTitleHint, color = palette.textMuted) },
                    singleLine = true,
                    colors = disciplineFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("journal_title_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = { Text(strings.journalContentHint, color = palette.textMuted) },
                    minLines = 3,
                    colors = disciplineFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("journal_content_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = achievement,
                    onValueChange = { achievement = it },
                    placeholder = { Text(strings.achievementHint, color = palette.textMuted) },
                    singleLine = true,
                    colors = disciplineFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                EmeraldActionButton(
                    text = strings.addJournalEntry,
                    onClick = {
                        if (title.isNotBlank() || content.isNotBlank()) {
                            onAddJournal(
                                title.ifBlank { mood },
                                content.trim(),
                                mood,
                                achievement.trim()
                            )
                            title = ""
                            content = ""
                            achievement = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("save_journal_button")
                )
            }
        }

        items(entries, key = { it.id }) { entry ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(label = entry.mood, accentColor = palette.accentSoft)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(entry.timestamp), style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        IconButton(onClick = { onDeleteJournal(entry.id) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = strings.deleteAction, tint = palette.textSecondary)
                        }
                    }
                }
                Text(entry.title, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                if (entry.content.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(entry.content, style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                }
                if (entry.achievement.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("★ ${entry.achievement}", style = MaterialTheme.typography.labelMedium, color = palette.gold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                val isBnJournal = LocalAppLanguage.current == AppLanguage.BANGLA
                GlassFilterChip(
                    label = if (isBnJournal) "রূহযেবা AI-এর সাথে কথা বলুন" else "Talk It Out",
                    selected = false,
                    icon = Icons.Default.AutoAwesome,
                    onClick = {
                        val snippet = entry.content.take(180)
                        val q = if (isBnJournal) {
                            "আমার আজকের অনুভূতি (${entry.mood}): '${entry.title}'. $snippet — এটি নিয়ে একটু কথা বলতে ও শান্ত পরামর্শ পেতে চাই।"
                        } else {
                            "I journaled today feeling ${entry.mood} about '${entry.title}': $snippet — can we talk this through kindly?"
                        }
                        onAskRuhZebaAi("WELLNESS", q)
                    },
                    modifier = Modifier.testTag("journal_talk_it_out_${entry.id}")
                )
            }
        }
    }
}
