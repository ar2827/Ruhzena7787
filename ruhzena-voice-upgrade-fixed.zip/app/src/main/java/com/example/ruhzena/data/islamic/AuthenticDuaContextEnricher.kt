package com.example.ruhzena.data.islamic

data class RichDuaAuthenticContext(
    val propheticOccasionEn: String,
    val propheticOccasionBn: String,
    val spiritualMeaningEn: String,
    val spiritualMeaningBn: String,
    val sunnahEtiquetteEn: String,
    val sunnahEtiquetteBn: String
)

/**
 * Provides full, detailed, authentic Prophetic context, spiritual depth, and Sunnah etiquette
 * for every Dua and Adhkar in the library so users never see brief 1-line summaries.
 */
object AuthenticDuaContextEnricher {

    fun enrich(
        titleEn: String,
        categoryEn: String,
        existingExplanationEn: String,
        existingExplanationBn: String,
        sourceRef: String
    ): RichDuaAuthenticContext {
        val hay = "$titleEn $categoryEn $sourceRef".lowercase()

        val (occasionEn, occasionBn, meaningEn, meaningBn, etiquetteEn, etiquetteBn) = when {
            hay.contains("washroom") || hay.contains("bathroom") || hay.contains("toilet") -> {
                if (hay.contains("exit") || hay.contains("leav")) {
                    Sextuple(
                        "Authentic Prophetic Context: Whenever Prophet Muhammad ﷺ stepped out of the washroom, he immediately said 'Ghufranaka' (I ask You for Your forgiveness) as narrated by Aishah (RA) in Sunan Abi Dawud (30) and Jami' at-Tirmidhi (7, Sahih).",
                        "প্রামাণ্য নববী প্রেক্ষাপট: আয়েশা (রা.) থেকে আবু দাউদ (৩০) ও তিরমিযী (৭, সহীহ)-এ বর্ণিত—নবী মুহাম্মদ ﷺ যখনই ওযুখানা বা শৌচাগার থেকে বের হতেন, সাথে সাথেই বলতেন 'গুফরানাকা' (হে আল্লাহ, আমি আপনার ক্ষমা প্রার্থনা করছি)।",
                        "Why Seek Forgiveness Upon Exiting? Classical scholars (Ibn al-Qayyim and Imam al-Nawawi) highlight two deep insights: first, humbly apologizing for the brief minutes spent unable to verbally remember Allah; second, thanking Allah for relieving bodily impurity and asking Him to similarly purify the soul from the unseen burden of sins.",
                        "বের হওয়ার পর ক্ষমা চাওয়ার প্রজ্ঞা: ইবনুল কাইয়্যিম ও ইমাম নববী (রহ.) দুটি গভীর তাৎপর্য উল্লেখ করেন—প্রথমত, ভেতরে থাকাকালীন মুখে আল্লাহর যিকির করতে না পারার বিনীত ক্ষমা প্রার্থনা; দ্বিতীয়ত, শরীরের কষ্ট দূর হওয়ার শুকরিয়ায় আত্মার গুনাহ থেকেও পবিত্রতা কামনা।",
                        "Sunnah Etiquette: Step out with the RIGHT foot first, then recite 'Ghufranaka' softly with gratitude for the quiet blessing of healthy digestion and bodily ease.",
                        "সুন্নাহ আদব: প্রথমে ডান পা দিয়ে বের হোন এবং সুস্থতা ও স্বাচ্ছন্দ্যের শুকরিয়াসহ নরম কণ্ঠে 'গুফরানাকা' পাঠ করুন।"
                    )
                } else {
                    Sextuple(
                        "Authentic Prophetic Context: Narrated by Anas ibn Malik (RA) in Sahih al-Bukhari (142) and Sahih Muslim (375), before entering the washroom Prophet Muhammad ﷺ sought refuge with Allah from male and female harmful spirits (Al-Khubuth wal-Khaba'ith) and began with 'Bismillah' as a spiritual veil (Tirmidhi 606).",
                        "প্রামাণ্য নববী প্রেক্ষাপট: আনাস ইবনে মালিক (রা.) থেকে সহীহ বুখারী (১৪২) ও সহীহ মুসলিম (৩৭৫)-এ বর্ণিত—নবীজি ﷺ শৌচাগারে প্রবেশের পূর্বে দুষ্ট পুরুষ ও নারী জিন (খুবুস ও খাবাইস) থেকে আল্লাহর আশ্রয় চাইতেন এবং 'বিসমিল্লাহ' বলতেন (তিরমিযী ৬০৬)।",
                        "Spiritual Protection & Mindfulness: Islam teaches that remembrance of Allah protects a believer even in the most private moments of daily hygiene—transforming an ordinary biological routine into a conscious act of Tawhid and reliance on Allah's guardianship.",
                        "আত্মিক সুরক্ষা ও সচেতনতা: ইসলাম শেখায় যে দৈনন্দিন জীবনের সবচেয়ে সাধারণ ও ব্যক্তিগত মুহূর্তেও আল্লাহর স্মরণ বান্দাকে অদৃশ্য অনিষ্ট থেকে সুরক্ষিত রাখে এবং সাধারণ কাজকেও ইবাদতে রূপান্তরিত করে।",
                        "Sunnah Etiquette: Recite the Dua BEFORE crossing the threshold (never inside the washroom), enter with the LEFT foot first, and avoid speaking or carrying open Quranic verses inside.",
                        "সুন্নাহ আদব: ভেতরে প্রবেশের আগেই দরজার বাইরে দুআটি পাঠ করুন (ভেতরে নয়), প্রথমে বাম পা দিয়ে প্রবেশ করুন এবং ভেতরে অনর্থক কথা বলা থেকে বিরত থাকুন।"
                    )
                }
            }
            hay.contains("home") || hay.contains("house") -> {
                if (hay.contains("leav") || hay.contains("exit")) {
                    Sextuple(
                        "Authentic Prophetic Context: Anas ibn Malik (RA) narrated in Sunan Abi Dawud (5095) and Jami' at-Tirmidhi (3426, Sahih) that when a believer leaves home saying 'Bismillahi tawakkaltu alallah, la hawla wa la quwwata illa billah', it is proclaimed to them: 'You are guided, you are sufficed, and you are protected,' and Shaytan steps aside from their path.",
                        "প্রামাণ্য নববী প্রেক্ষাপট: আনাস (রা.) থেকে আবু দাউদ (৫০৯৫) ও তিরমিযী (৩৪২৬, সহীহ)-এ বর্ণিত—যে ব্যক্তি ঘর থেকে বের হওয়ার সময় এই দুআ পড়ে, তাকে বলা হয়: 'তোমাকে হেদায়াত দেওয়া হয়েছে, তোমার জন্য যথেষ্ট ব্যবস্থা করা হয়েছে এবং তোমাকে সুরক্ষা দেওয়া হয়েছে' এবং শয়তান তার পথ থেকে সরে যায়।",
                        "Three Pillars of Protection: (1) 'Bismillah' places your work, travel, and errands under Allah's name; (2) 'Tawakkaltu alallah' surrenders anxiety about outcomes to Al-Wakil; (3) 'La hawla wa la quwwata illa billah' acknowledges that all real strength and safety come exclusively from Allah.",
                        "সুরক্ষার তিনটি স্তম্ভ: 'বিসমিল্লাহ' কাজে বরকত আনে, 'তাওয়াক্কালতু আলাল্লাহ' দুশ্চিন্তা দূর করে আল্লাহর ওপর ভরসা শেখায়, এবং 'লা হাওলা ওয়া লা কুওয়াতা ইল্লা বিল্লাহ' প্রমাণ করে সমস্ত শক্তি একমাত্র আল্লাহর।",
                        "Sunnah Etiquette: Step out with the LEFT foot (or calmly with presence of heart), recite clearly before entering traffic or work, and renew sincere intention for halal effort.",
                        "সুন্নাহ আদব: ঘর থেকে বের হয়েই শান্ত মনে দুআটি পাঠ করুন এবং হালাল উপার্জন ও কল্যাণময় কাজের নিয়ত নবায়ন করুন।"
                    )
                } else {
                    Sextuple(
                        "Authentic Prophetic Context: Jabir ibn Abdullah (RA) reported in Sahih Muslim (2018) that when a person remembers Allah upon entering their home and before eating, Shaytan tells his companions: 'You have no lodging for the night and no dinner here!'",
                        "প্রামাণ্য নববী প্রেক্ষাপট: জাবির ইবনে আবদুল্লাহ (রা.) থেকে সহীহ মুসলিম (২০১৮)-এ বর্ণিত—যে ব্যক্তি ঘরে প্রবেশের সময় ও খাওয়ার আগে আল্লাহকে স্মরণ করে, শয়তান তার সঙ্গীদের বলে: 'আজ রাতে এখানে তোমাদের থাকার জায়গা ও খাবার কিছুই নেই!'",
                        "Bringing Barakah & Peace Into Family Life: Entering with Allah's name and greeting family with 'Assalamu Alaikum' fills the home with angelic tranquility (Sakinah), softens household tension, and keeps quarrels and envy away.",
                        "পরিবারে বরকত ও শান্তি: আল্লাহর নামে প্রবেশ ও পরিবারকে সালাম দেওয়া ঘরে ফেরেশতাদের রহমত ও প্রশান্তি (সাকীনাহ) বয়ে আনে এবং পারিবারিক কলহ দূর করে।",
                        "Sunnah Etiquette: Step in with the RIGHT foot, recite the Dua softly, and offer a warm 'Assalamu Alaikum' even if the house is empty ('Assalamu alayna wa ala ibadillahis-salihin').",
                        "সুন্নাহ আদব: ডান পা দিয়ে প্রবেশ করুন, দুআটি পড়ুন এবং ঘরে প্রবেশ করে পরিবারকে—এমনকি ঘর ফাঁকা থাকলেও—সালাম দিন।"
                    )
                }
            }
            hay.contains("market") || hay.contains("bazar") || hay.contains("shop") -> {
                Sextuple(
                    "Authentic Prophetic Context: Umar ibn al-Khattab (RA) narrated in Jami' at-Tirmidhi (3428, Hasan) and Sunan Ibn Majah (2235) that whoever enters a marketplace and recites this declaration of pure Tawhid has one million good deeds recorded, one million sins erased, and is raised one million ranks.",
                    "প্রামাণ্য নববী প্রেক্ষাপট: উমর ইবনুল খাত্তাব (রা.) থেকে তিরমিযী (৩৪২৮, হাসান) ও ইবনে মাজাহ (২২৩৫)-এ বর্ণিত—যে ব্যক্তি বাজারে প্রবেশ করে এই তাওহীদের যিকির পাঠ করে, আল্লাহ তার আমলনামায় দশ লক্ষ নেকি লেখেন, দশ লক্ষ গুনাহ মাফ করেন এবং দশ লক্ষ মর্যাদা উন্নীত করেন।",
                    "Why Such Immense Reward in the Marketplace? Classical scholars explain that markets, malls, and commercial hubs are places where people are most easily distracted by greed, haste, and forgetfulness of Allah. Remembering Allah right where heedlessness dominates carries extraordinary sincerity and weight.",
                    "বাজারে এই দুআর এত বিশাল সওয়াব কেন? আলেমগণ বলেন, বাজার ও বাণিজ্যিক স্থানে মানুষ সাধারণত দুনিয়ার ব্যস্ততা ও লাভ-ক্ষতিতে আল্লাহকে ভুলে যায়; তাই গাফিলতির স্থানে আল্লাহকে স্মরণ করা গভীর ইখলাসের প্রমাণ।",
                    "Sunnah Etiquette: Recite calmly upon entering any market, grocery store, or shopping district—and pair it with honest dealing, kindness to sellers, and avoiding wasteful spending.",
                    "সুন্নাহ আদব: যেকোনো বাজার, দোকান বা শপিং মলে প্রবেশের সময় শান্ত মনে এটি পাঠ করুন এবং ক্রয়-বিক্রয়ে সততা ও বিনয় বজায় রাখুন।"
                )
            }
            hay.contains("stair") || hay.contains("ascend") || hay.contains("descend") || hay.contains("climb") -> {
                Sextuple(
                    "Authentic Prophetic Context: Jabir ibn Abdullah (RA) reported in Sahih al-Bukhari (2993): 'Whenever we ascended (a hill, stairs, or elevation), we said Allahu Akbar, and whenever we descended, we said SubhanAllah.'",
                    "প্রামাণ্য নববী প্রেক্ষাপট: জাবির ইবনে আবদুল্লাহ (রা.) থেকে সহীহ বুখারী (২৯৯৩)-এ বর্ণিত: 'আমরা যখনই উঁচু স্থানে (পাহাড় বা সিঁড়িতে) উঠতাম তখন আল্লাহু আকবার বলতাম, আর যখন নিচে নামতাম তখন সুবহানাল্লাহ বলতাম।'",
                    "Deep Spiritual Balance of Movement: Rising upward naturally stirs a subtle feeling of height or pride—so 'Allahu Akbar' reminds the heart that Allah is infinitely greater than any elevation. Descending reminds us of humility and Allah's transcendence ('SubhanAllah') above all imperfection.",
                    "ওঠা-নামার গভীর আত্মিক প্রজ্ঞা: ওপরে ওঠার সময় মানুষের মনে উচ্চতার অনুভূতি জাগে, তাই 'আল্লাহু আকবার' স্মরণ করিয়ে দেয় আল্লাহই সর্বশ্রেষ্ঠ। আর নিচে নামার সময় 'সুবহানাল্লাহ' আল্লাহর পবিত্রতা ও মহত্ত্ব ঘোষণা করে।",
                    "Sunnah Etiquette: Practice this quietly every day when climbing stairs, riding elevators, escalators, or driving up and down hills so even ordinary commuting becomes continuous Dhikr.",
                    "সুন্নাহ আদব: প্রতিদিন সিঁড়ি বেয়ে ওঠা-নামা, লিফট বা পাহাড়ি পথে চলার সময় নীরবে এই সুন্নাহ অনুশীলন করুন—প্রতিটি পদক্ষেপ যিকিরে পরিণত হবে।"
                )
            }
            hay.contains("morning") || hay.contains("evening") || hay.contains("sabah") || hay.contains("masa") -> {
                Sextuple(
                    "Authentic Prophetic Context: Part of the daily Prophetic fortress of Morning (after Fajr until sunrise) and Evening (after Asr until Maghrib/night) Adhkar explicitly commanded in the Quran (33:41–42, 40:55) and preserved across Sahih al-Bukhari, Sahih Muslim, and Hisn al-Muslim.",
                    "প্রামাণ্য নববী প্রেক্ষাপট: কুরআনের নির্দেশ (৩৩:৪১-৪২) এবং সহীহ বুখারী, মুসলিম ও হিসনুল মুসলিমে সংরক্ষিত সকাল (ফজরের পর) ও সন্ধ্যার (আসরের পর) প্রামাণ্য মাসনূন আযকারের অন্তর্ভুক্ত।",
                    "Fortress of the Heart: Imam Ibn al-Qayyim compared Morning and Evening Adhkar to protective armor—the thicker and more consistent a believer's daily remembrance is, the less spiritual anxiety, envy, or worldly stress can pierce the heart.",
                    "হৃদয়ের দুর্গ: ইমাম ইবনুল কাইয়্যিম (রহ.) সকাল-সন্ধ্যার আযকারকে বর্মের সাথে তুলনা করেছেন—নিয়মিত ও মনোযোগসহ পাঠে অন্তরের অস্থিরতা, ভয় ও দুশ্চিন্তা দূর হয় এবং দিন-রাতে বরকত নেমে আসে।",
                    "Sunnah Etiquette: Recite with calm breathing and present awareness—moving the tongue gently, reflecting on the Arabic meaning, and observing any Sunnah repetition count (1x, 3x, 7x, or 33x).",
                    "সুন্নাহ আদব: তাড়াহুড়ো না করে শান্ত শ্বাসে, অর্থ বুঝে এবং সুন্নাহ নির্ধারিত সংখ্যা (১, ৩, ৭ বা ৩৩ বার) অনুযায়ী নিয়মিত পাঠ করুন।"
                )
            }
            hay.contains("sleep") || hay.contains("wake") || hay.contains("bed") -> {
                Sextuple(
                    "Authentic Prophetic Context: Prophet Muhammad ﷺ taught that sleep is the minor sister of death—each night Allah takes souls in repose and returns those decreed to wake (Quran 39:42). Preserved in Sahih al-Bukhari (6312, 6314) and Sahih Muslim (2710).",
                    "প্রামাণ্য নববী প্রেক্ষাপট: নবীজি ﷺ শিখিয়েছেন ঘুম হলো ছোট মৃত্যু—প্রতি রাতে আল্লাহ আমাদের রূহ কবজ করেন এবং যাদের হায়াত বাকি আছে সকালে ফিরিয়ে দেন (কুরআন ৩৯:৪২; সহীহ বুখারী ৬৩১২)।",
                    "Peaceful Surrender & Morning Renewal: Ending the night with Dhikr entrusts your life, family, and worries to Al-Hayy Al-Qayyum, while waking with praise ('Alhamdulillahilladhi ahyana...') frames the new day as a precious second chance for good.",
                    "শান্তিপূর্ণ সমর্পণ ও নতুন সূচনা: ঘুমানোর আগে যিকির মন থেকে সারা দিনের চাপ দূর করে আল্লাহর হেফাজতে সমর্পণ করে, আর ঘুম থেকে উঠে প্রশংসা নতুন দিনকে নেক আমলের সুযোগ হিসেবে বরণ করে।",
                    "Sunnah Etiquette: Perform Wudu before bed when possible, dust the bed lightly three times, lie on your RIGHT side with your right hand beneath your cheek, and keep Dhikr as your final conscious words.",
                    "সুন্নাহ আদব: সম্ভব হলে ওযু করে বিছানা ঝেড়ে ডান কাত হয়ে শুয়ে দুআটি পড়ুন এবং আল্লাহর স্মরণেই ঘুমিয়ে পড়ুন।"
                )
            }
            hay.contains("travel") || hay.contains("journey") || hay.contains("vehicle") -> {
                Sextuple(
                    "Authentic Prophetic Context: Narrated by Abdullah ibn Umar (RA) in Sahih Muslim (1342), whenever the Prophet ﷺ mounted his riding animal for a journey, he proclaimed 'Allahu Akbar' three times and recited the Quranic travel verse (43:13–14) followed by this comprehensive prayer for ease, righteousness, and family protection.",
                    "প্রামাণ্য নববী প্রেক্ষাপট: আবদুল্লাহ ইবনে উমর (রা.) থেকে সহীহ মুসলিম (১৩৪২)-এ বর্ণিত—নবীজি ﷺ সফরের বাহনে আরোহণ করে তিনবার আল্লাহু আকবার বলতেন এবং কুরআনের আয়াত (৪৩:১৩-১৪) সহ সফরের পূর্ণাঙ্গ দুআ পাঠ করতেন।",
                    "Gratitude for Motion & Guardian of Home: It reminds the traveler that no car, plane, or ship moves without Allah's laws subjecting it to human service, and entrusts both the journey ahead and the loved ones left behind to Allah's care.",
                    "যাত্রার কৃতজ্ঞতা ও পরিবারের নিরাপত্তা: কোনো যানবাহনই আল্লাহর অনুগ্রহ ছাড়া মানুষের বশীভূত নয়—এই দুআয় যেমন নিরাপদ সফরের প্রার্থনা আছে, তেমনি পেছনে রেখে আসা পরিবারের হেফাজতের দায়িত্বও আল্লাহর কাছে সঁপে দেওয়া হয়।",
                    "Sunnah Etiquette: Say 'Bismillah' when stepping in, 'Alhamdulillah' when seated, recite the travel Dua aloud with family or companions, and remember that a traveler's Dua is specially accepted.",
                    "সুন্নাহ আদব: বাহনে ওঠার সময় বিসমিল্লাহ, বসে আলহামদুলিল্লাহ এবং যাত্রা শুরুতে সফরের দুআ পড়ুন; সফরের অবস্থায় বেশি বেশি দুআ করুন।"
                )
            }
            hay.contains("food") || hay.contains("eat") || hay.contains("meal") || hay.contains("fast") || hay.contains("iftar") || hay.contains("drink") -> {
                Sextuple(
                    "Authentic Prophetic Context: Grounded in Sahih al-Bukhari (5376), Sahih Muslim (2022), and Sunan Abi Dawud (3849), the Prophet ﷺ taught believers to begin meals with Allah's name and close with heartfelt gratitude acknowledging that sustenance arrives without our own ultimate power.",
                    "প্রামাণ্য নববী প্রেক্ষাপট: সহীহ বুখারী (৫৩৭৬), মুসলিম (২০২২) ও আবু দাউদ (৩৮৪৯)-এ বর্ণিত—নবীজি ﷺ আল্লাহর নামে খাবার শুরু করা এবং শেষে নিজ সামর্থ্য ছাড়াই রিজিক দানের জন্য আন্তরিক শুকরিয়া আদায়ের শিক্ষা দিয়েছেন।",
                    "Barakah in Sustenance: Mentioning Allah's name invites blessing into the meal, protects against greed or overeating, and turns daily nourishment into gratitude toward Ar-Razzaq—with Sahih hadith promising forgiveness of minor past sins for praising Allah after eating (Tirmidhi 3458).",
                    "রিজিকে বরকত ও কৃতজ্ঞতা: আল্লাহর নামে খাবার শুরু করলে তাতে বরকত হয় এবং খাওয়ার পর প্রশংসার দুআ পাঠ করলে পূর্বের সগীরা গুনাহ ক্ষমা করে দেওয়া হয় (তিরমিযী ৩৪৫৮)।",
                    "Sunnah Etiquette: Wash hands before eating, sit calmly, eat with the RIGHT hand from what is nearest to you, never criticize food, and avoid wasting a single morsel.",
                    "সুন্নাহ আদব: খাওয়ার আগে হাত ধুয়ে নিন, বসে ডান হাতে নিজের দিক থেকে খান, খাবারের দোষ ধরবেন না এবং অপচয় থেকে বিরত থাকুন।"
                )
            }
            hay.contains("masjid") || hay.contains("mosque") || hay.contains("wudu") || hay.contains("adhan") || hay.contains("salah") || hay.contains("prayer") -> {
                Sextuple(
                    "Authentic Prophetic Context: Preserved in Sahih al-Bukhari, Sahih Muslim (713, 384), and Sunan Abi Dawud, these sacred supplications connect purification (Wudu), answering the Adhan, stepping into the House of Allah, and standing in Salah into one continuous spiritual ascent.",
                    "প্রামাণ্য নববী প্রেক্ষাপট: সহীহ বুখারী ও সহীহ মুসলিম (৭১৩, ৩৮৪)-এ বর্ণিত এই পবিত্র দুআসমূহ ওযু, আযানের জবাব, মসজিদে প্রবেশ ও সালাতকে একটি অবিচ্ছিন্ন আত্মিক উন্নতির ধারায় যুক্ত করে।",
                    "Doors of Mercy & Intercession: Asking Allah to open the gates of His mercy upon entering the Masjid prepares the heart for khushu' (humble focus), while asking for His bounty upon exiting reminds us that lawful livelihood outside the Masjid is also worship when pursued honestly.",
                    "রহমতের দুয়ার ও সুপারিশ: মসজিদে প্রবেশের সময় রহমতের দরজা খোলার প্রার্থনা নামাজে খুশু আনে, আর বের হওয়ার সময় অনুগ্রহ (রিজিক) কামনা প্রমাণ করে হালাল উপার্জনও ইবাদতের অংশ।",
                    "Sunnah Etiquette: Enter the Masjid with the RIGHT foot and exit with the LEFT foot; walk with serenity and dignity (never rushing breathlessly); and offer two rak'ahs of Tahiyyat al-Masjid before sitting.",
                    "সুন্নাহ আদব: ডান পা দিয়ে মসজিদে প্রবেশ ও বাম পা দিয়ে বের হোন, শান্ত ও গম্ভীরভাবে হাঁটুন এবং বসার আগে দুই রাকাত তাহিয়্যাতুল মসজিদ আদায় করুন।"
                )
            }
            hay.contains("distress") || hay.contains("anxiety") || hay.contains("grief") || hay.contains("forgiveness") || hay.contains("istighfar") || hay.contains("yunus") || hay.contains("mercy") -> {
                Sextuple(
                    "Authentic Prophetic Context: Rooted in the verified Duas of Prophet Muhammad ﷺ and the Prophets in the Quran (such as Yunus AS in Quran 21:87, Ayyub AS in 21:83, and Sayyid al-Istighfar in Sahih al-Bukhari 6306) taught specifically for moments when the chest feels tight, burdens feel heavy, or repentance is sought.",
                    "প্রামাণ্য নববী প্রেক্ষাপট: কুরআনের নবীদের দুআ (যেমন ইউনুস আ. ২১:৮৭, আইয়ুব আ. ২১:৮৩) এবং সহীহ বুখারী (৬৩০৬)-এ বর্ণিত নবীজির শিখিয়ে দেওয়া দুআ—যা বিশেষত হৃদয়ের সংকীর্ণতা, দুশ্চিন্তা ও গভীর তাওবার মুহূর্তের জন্য প্রামাণ্য।",
                    "Healing the Heart Through Pure Reliance: Notice how Prophetic Duas for distress never complain against Allah; instead, they combine glorifying His Names, acknowledging our human dependence, and placing full hope in His unmatched mercy—bringing immediate emotional relief (Sakinah).",
                    "অন্তরের প্রশান্তি ও তাওবা: বিপদের নববী দুআগুলোতে কখনো হতাশা বা অভিযোগ থাকে না; বরং আল্লাহর মহান নামগুলোর প্রশংসা, নিজের অসহায়ত্ব স্বীকার এবং তাঁর অসীম রহমতের ওপর ভরসা করার মাধ্যমে অন্তরে দ্রুত প্রশান্তি নেমে আসে।",
                    "Sunnah Etiquette: Raise your palms humbly facing the Qibla when possible, begin with praise of Allah and Salawat upon the Prophet ﷺ, recite with quiet conviction, and trust Allah's timing.",
                    "সুন্নাহ আদব: সম্ভব হলে কিবলামুখী হয়ে দুই হাত তুলে আল্লাহর প্রশংসা ও নবীজির ওপর দরূদ পড়ে একান্ত বিনয় ও দৃঢ় বিশ্বাসের সাথে দুআটি পাঠ করুন।"
                )
            }
            else -> {
                Sextuple(
                    "Authentic Prophetic Context ($sourceRef): Preserved in the authentic books of Hadith and Prophetic supplications (Hisn al-Muslim / Sahih collections), Prophet Muhammad ﷺ practiced and taught this Dua so believers keep their hearts linked to Allah across every everyday moment.",
                    "প্রামাণ্য নববী প্রেক্ষাপট ($sourceRef): সহীহ হাদীস গ্রন্থ ও হিসনুল মুসলিমে সংরক্ষিত এই মাসনূন দুআটি নবী মুহাম্মদ ﷺ নিজে নিয়মিত পাঠ করতেন এবং উম্মতকে শিখিয়েছেন যাতে জীবনের প্রতিটি মুহূর্ত আল্লাহর স্মরণে আলোকিত থাকে।",
                    "Spiritual Meaning & Tawhid Depth: Every Prophetic Dua transforms ordinary human actions into conscious worship (Ibadah)—aligning intention, inviting unseen divine Barakah, and replacing heedlessness or anxiety with peaceful certainty in Allah's mercy and wisdom.",
                    "আত্মিক তাৎপর্য ও তাওহীদের গভীরতা: প্রতিটি নববী দুআ দৈনন্দিন সাধারণ কাজকে সচেতন ইবাদতে পরিণত করে—নিয়তকে বিশুদ্ধ করে, কাজে অদৃশ্য বরকত আনে এবং গাফিলতি ও অস্থিরতা দূর করে আল্লাহর ওপর ভরসা দৃঢ় করে।",
                    "Sunnah Etiquette: Recite with presence of heart rather than rushing; understand its translation; begin and end extended personal supplications with praise of Allah (Alhamdulillah) and Salawat upon the Prophet ﷺ.",
                    "সুন্নাহ আদব: তাড়াহুড়ো না করে অর্থ বুঝে মনোযোগসহ পাঠ করুন; এবং যেকোনো বিস্তৃত দুআর শুরু ও শেষে আল্লাহর প্রশংসা ও নবীজি ﷺ-এর ওপর দরূদ পাঠ করুন।"
                )
            }
        }

        // Preserve any item-specific curated insight right at the top of Prophetic Occasion!
        val fullOccasionEn = if (existingExplanationEn.isNotBlank()) {
            "$existingExplanationEn\n\n$occasionEn"
        } else occasionEn

        val fullOccasionBn = if (existingExplanationBn.isNotBlank()) {
            "$existingExplanationBn\n\n$occasionBn"
        } else occasionBn

        return RichDuaAuthenticContext(
            propheticOccasionEn = fullOccasionEn,
            propheticOccasionBn = fullOccasionBn,
            spiritualMeaningEn = meaningEn,
            spiritualMeaningBn = meaningBn,
            sunnahEtiquetteEn = etiquetteEn,
            sunnahEtiquetteBn = etiquetteBn
        )
    }

    private data class Sextuple<A, B, C, D, E, F>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D,
        val fifth: E,
        val sixth: F
    )
}
