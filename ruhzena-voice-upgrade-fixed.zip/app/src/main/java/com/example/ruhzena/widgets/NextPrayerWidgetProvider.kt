package com.example.ruhzena.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.example.R
import com.example.ruhzena.core.i18n.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NextPrayerWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val snap = RuhZenaWidgetUpdater.loadSnapshot(context)
                val isBn = snap.prefs.language == AppLanguage.BANGLA
                val prayerLabel = when (snap.nextPrayerName) {
                    "FAJR" -> if (isBn) "ফজর" else "Fajr"
                    "DHUHR" -> if (isBn) "যোহর" else "Dhuhr"
                    "ASR" -> if (isBn) "আসর" else "Asr"
                    "MAGHRIB" -> if (isBn) "মাগরিব" else "Maghrib"
                    else -> if (isBn) "ইশা" else "Isha"
                }
                val remH = snap.nextPrayerMinutesRemaining / 60
                val remM = snap.nextPrayerMinutesRemaining % 60
                val remText = if (remH > 0) "${remH}h ${remM}m" else "${remM}m"
                val subtitle = if (snap.prefs.ramadanModeEnabled) {
                    "${snap.prefs.locationName} • $remText (Ramadan)"
                } else {
                    "${snap.prefs.locationName} • in $remText"
                }

                for (appWidgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_next_prayer).apply {
                        setTextViewText(R.id.widget_prayer_brand, if (isBn) "রূহজেনা • পরবর্তী সালাত" else "RuhZena • NEXT PRAYER")
                        setTextViewText(R.id.widget_prayer_name, prayerLabel)
                        setTextViewText(R.id.widget_prayer_time, snap.nextPrayerTime)
                        setTextViewText(R.id.widget_prayer_subtitle, subtitle)
                        setOnClickPendingIntent(
                            R.id.widget_prayer_root,
                            RuhZenaWidgetUpdater.launchAppPendingIntent(context, 4101)
                        )
                    }
                    appWidgetManager.updateAppWidget(appWidgetId, views)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
