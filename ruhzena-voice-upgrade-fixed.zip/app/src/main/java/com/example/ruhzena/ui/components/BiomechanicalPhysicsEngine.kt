package com.example.ruhzena.ui.components

import com.example.ruhzena.ui.exercises.MuscleZone
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Real-time Biomechanical Physics, Human Locomotion & Neuromuscular Load Engine.
 *
 * Replaces uniform robotic cosine easing with:
 * 1. Asymmetric eccentric / isometric peak / concentric drive kinematics (reflecting gravity + muscle force).
 * 2. True parabolic ballistic flight arcs (y = 4h * u * (1 - u)) + ground-impact knee/ankle shock absorption
 *    for plyometric & locomotion movements.
 * 3. Weighted Center-of-Mass (CoM) horizontal balance compensation over the base of support.
 * 4. Individual muscle-complex tension recruitment (Pecs, Deltoids, Biceps, Triceps, Core, Glutes, Quads,
 *    Hamstrings, Calves) for realistic dynamic muscle bulge & pennation striation activation.
 * 5. Diaphragmatic ribcage breathing expansion and gravity-coupled cloth/garment inertia for Salah & Wudu.
 */
data class BiomechanicalTelemetry(
    val easedT: Float = 0f,
    val phaseType: BiomechanicalPhase = BiomechanicalPhase.TRANSITION,
    val phaseLabelEn: String = "Control",
    val phaseLabelBn: String = "নিয়ন্ত্রণ",
    val eccentricLoad: Float = 0f,
    val concentricLoad: Float = 0f,
    val isometricTension: Float = 0f,
    /** Normalized upward ballistic flight lift in head units (0 = grounded, >0 = airborne) */
    val gravityFlightLiftU: Float = 0f,
    /** Normalized landing shock absorption compression [0..1] right after foot strike */
    val landingCompression: Float = 0f,
    /** Ground impact ripple ring progress [0..1] (0 = inactive) */
    val landingImpactRipple: Float = 0f,
    /** Horizontal Center-of-Mass balance counter-shift in head units */
    val comShiftXU: Float = 0f,
    /** Subtle neuromuscular micro-stabilization tremor under peak isometric load (head units) */
    val isometricMicroJitterU: Float = 0f,
    /** Diaphragmatic chest/ribcage breathing expansion [-1..+1] */
    val breathExpansion: Float = 0f,
    /** Locomotion heel-to-toe foot roll intensity [0..1] */
    val footRollPhase: Float = 0f,
    /** Gravity-coupled secondary garment drag */
    val clothInertia: Float = 0f,
    /** Individual anatomical muscle recruitment [0..1] */
    val pecTension: Float = 0.15f,
    val deltTension: Float = 0.15f,
    val bicepTension: Float = 0.15f,
    val tricepTension: Float = 0.15f,
    val forearmTension: Float = 0.15f,
    val coreTension: Float = 0.20f,
    val gluteTension: Float = 0.15f,
    val quadTension: Float = 0.15f,
    val hamTension: Float = 0.15f,
    val calfTension: Float = 0.15f,
    /** True when the exercise involves grounded floor contact with CoM balance indicator */
    val showComBalanceGuide: Boolean = false
)

enum class BiomechanicalPhase {
    ECCENTRIC,
    ISOMETRIC_HOLD,
    CONCENTRIC,
    BALLISTIC_FLIGHT,
    LANDING_ABSORB,
    LOCOMOTION,
    RECOVERY,
    TRANSITION
}

private enum class MovementPhysicsProfile {
    PUSH_PRESS,        // Push-ups (regular, diamond, military, wide, incline, decline, pike, archer), dips
    SQUAT_HINGE,       // Squats, lunges, glute bridge, hip hinge, calf raises
    PLYO_BALLISTIC,    // Jumping jacks, burpees, squat jumps, plank jacks
    GAIT_LOCOMOTION,   // High knees, mountain climbers, marching, shadow cardio
    CORE_ISOMETRIC,    // Planks, hollow body, dead bug, bird dog, superman, v-ups, bicycle crunch
    MOBILITY_FLOW      // Cat-cow, cobra, child's pose, stretches
}

private fun classifyExercisePhysics(exerciseId: String, activeZone: MuscleZone): MovementPhysicsProfile {
    val id = exerciseId.lowercase()
    return when {
        id.contains("jump") || id.contains("burpee") || id.contains("plyo") || id.contains("hop") ->
            MovementPhysicsProfile.PLYO_BALLISTIC
        id.contains("high_knee") || id.contains("climber") || id.contains("run") || id.contains("march") || id.contains("shadow") || id.contains("skip") ->
            MovementPhysicsProfile.GAIT_LOCOMOTION
        id.contains("push") || id.contains("dip") || id.contains("pike") || id.contains("archer") || id.contains("diamond") || id.contains("army") || id.contains("military") ->
            MovementPhysicsProfile.PUSH_PRESS
        id.contains("squat") || id.contains("lunge") || id.contains("bridge") || id.contains("calf") || id.contains("hinge") || id.contains("step") ->
            MovementPhysicsProfile.SQUAT_HINGE
        id.contains("stretch") || id.contains("cobra") || id.contains("cat") || id.contains("child") || id.contains("mobility") || id.contains("pose") ->
            MovementPhysicsProfile.MOBILITY_FLOW
        id.contains("plank") || id.contains("hollow") || id.contains("crunch") || id.contains("v_up") || id.contains("superman") || id.contains("bird") || id.contains("dead_bug") || id.contains("leg_raise") ->
            MovementPhysicsProfile.CORE_ISOMETRIC
        activeZone == MuscleZone.CHEST_ARMS -> MovementPhysicsProfile.PUSH_PRESS
        activeZone == MuscleZone.LEGS_GLUTES -> MovementPhysicsProfile.SQUAT_HINGE
        activeZone == MuscleZone.CORE || activeZone == MuscleZone.SPINE_BACK -> MovementPhysicsProfile.CORE_ISOMETRIC
        else -> MovementPhysicsProfile.SQUAT_HINGE
    }
}

/**
 * Solves realistic human physics, asymmetric eccentric/concentric tempo, ballistic gravity arcs,
 * landing shock absorption, CoM balance shifts, and individual muscle-group recruitment for exercises.
 */
fun solveExerciseBiomechanics(
    exerciseId: String,
    effectiveProgress: Float,
    activeZone: MuscleZone
): BiomechanicalTelemetry {
    val wrapped = ((effectiveProgress % 4f) + 4f) % 4f
    val phaseIdx = wrapped.toInt().coerceIn(0, 3)
    val rawT = (wrapped - phaseIdx).coerceIn(0f, 1f)
    val profile = classifyExercisePhysics(exerciseId, activeZone)
    val id = exerciseId.lowercase()

    // 1. Asymmetric physics-driven easing per phase (Eccentric brake -> Isometric tension -> Concentric drive -> Settle)
    val easedT = when (profile) {
        MovementPhysicsProfile.PUSH_PRESS, MovementPhysicsProfile.SQUAT_HINGE -> when (phaseIdx) {
            // Phase 0: Controlled eccentric descent against gravity (starts smooth, brakes hard near bottom)
            0 -> easeEccentricBraked(rawT)
            // Phase 1: Deep isometric peak load with minimal displacement
            1 -> easeIsometricHold(rawT)
            // Phase 2: Explosive concentric drive overcoming gravity with smooth lock-out deceleration
            2 -> easeConcentricDrive(rawT)
            // Phase 3: Top recovery & ribcage reset
            else -> easeCriticallyDamped(rawT)
        }
        MovementPhysicsProfile.PLYO_BALLISTIC -> when (phaseIdx) {
            // Quick countermovement dip
            0 -> easeInQuad(rawT)
            // Explosive takeoff into parabolic flight
            1 -> easeOutCubic(rawT)
            // Airborne apex & descent
            2 -> easeInOutQuad(rawT)
            // Ground impact & elastic recoil
            else -> easeOutQuartLocal(rawT)
        }
        MovementPhysicsProfile.GAIT_LOCOMOTION -> {
            // Snappy spring-mass athletic stride (rapid swing acceleration + firm foot strike)
            easeAthleticStride(rawT)
        }
        MovementPhysicsProfile.CORE_ISOMETRIC -> when (phaseIdx) {
            0 -> easeOutCubic(rawT)
            1, 2 -> easeIsometricHold(rawT)
            else -> easeCriticallyDamped(rawT)
        }
        MovementPhysicsProfile.MOBILITY_FLOW -> {
            // Smooth, deliberate breathing-coupled elastic stretch
            easeSmoothQuintic(rawT)
        }
    }

    // 2. Ballistic gravity flight parabola & landing impact shock absorption
    var flightLiftU = 0f
    var landingComp = 0f
    var impactRipple = 0f
    var footRoll = 0f

    when (profile) {
        MovementPhysicsProfile.PLYO_BALLISTIC -> {
            val peakJumpU = when {
                id.contains("burpee") -> 0.52f
                id.contains("squat_jump") -> 0.62f
                id.contains("plank_jack") -> 0.14f
                else -> 0.42f // Jumping jack
            }
            // Parabolic gravity flight during phases 1 -> 2 (true 4*h*u*(1-u) trajectory)
            if (wrapped in 1.0f..2.70f) {
                val uAir = ((wrapped - 1.0f) / 1.70f).coerceIn(0f, 1f)
                flightLiftU = 4f * peakJumpU * uAir * (1f - uAir)
            }
            // Ground-impact shock absorption right after touchdown (wrapped 2.70..3.45)
            if (wrapped in 2.68f..3.55f) {
                val uLand = ((wrapped - 2.68f) / 0.87f).coerceIn(0f, 1f)
                // Fast compression on strike, smooth elastic rebound
                landingComp = sin(uLand * PI).toFloat().pow(1.4f) * (1f - uLand * 0.45f)
                impactRipple = uLand
            }
        }
        MovementPhysicsProfile.GAIT_LOCOMOTION -> {
            // Spring-mass double-bounce running/high-knees vertical oscillation
            val strideBounce = abs(sin(wrapped * PI)).toFloat()
            flightLiftU = if (id.contains("climber")) 0.04f * strideBounce else 0.18f * strideBounce.pow(1.35f)
            val strikePulse = (1f - strideBounce).pow(3f)
            landingComp = strikePulse * 0.35f
            impactRipple = if (strikePulse > 0.45f) (1f - strikePulse) * 1.8f else 0f
            footRoll = (wrapped % 1f)
        }
        MovementPhysicsProfile.SQUAT_HINGE -> {
            // Subtle heel-to-ball weight roll and elastic rebound at bottom of squat/lunge
            footRoll = if (phaseIdx == 2) sin(rawT * PI).toFloat() * 0.35f else 0f
            if (phaseIdx == 1) {
                landingComp = 0.12f * sin(rawT * PI).toFloat()
            }
        }
        else -> Unit
    }

    // 3. Real Center-of-Mass (CoM) horizontal counter-balance shift
    val comShiftXU = when (profile) {
        MovementPhysicsProfile.SQUAT_HINGE -> {
            // During squat/lunge descent hips sit slightly posteriorly so CoM stays centered over mid-foot
            val depth = when (phaseIdx) {
                0 -> easedT
                1 -> 1f
                2 -> 1f - easedT
                else -> 0f
            }
            if (id.contains("lunge")) 0.12f * depth else -0.14f * depth
        }
        MovementPhysicsProfile.PUSH_PRESS -> {
            // Slight forward scapular protraction/shift over wrists during eccentric lowering
            val depth = when (phaseIdx) {
                0 -> easedT
                1 -> 1f
                2 -> 1f - easedT
                else -> 0f
            }
            if (id.contains("archer")) 0.18f * sin(wrapped * PI * 0.5f).toFloat() else 0.08f * depth
        }
        MovementPhysicsProfile.GAIT_LOCOMOTION -> {
            sin(wrapped * PI).toFloat() * 0.07f
        }
        else -> 0f
    }

    // 4. Phase classification & load metrics
    val (phaseType, labelEn, labelBn) = when {
        flightLiftU > 0.10f -> Triple(BiomechanicalPhase.BALLISTIC_FLIGHT, "Ballistic Flight", "শূন্যে লাফ")
        landingComp > 0.25f -> Triple(BiomechanicalPhase.LANDING_ABSORB, "Impact Absorb", "অবতরণ নিয়ন্ত্রণ")
        profile == MovementPhysicsProfile.GAIT_LOCOMOTION -> Triple(BiomechanicalPhase.LOCOMOTION, "Stride Drive", "ছন্দময় গতি")
        profile == MovementPhysicsProfile.CORE_ISOMETRIC && (phaseIdx == 1 || phaseIdx == 2) ->
            Triple(BiomechanicalPhase.ISOMETRIC_HOLD, "Isometric Brace", "স্থির পেশী চাপ")
        phaseIdx == 0 -> Triple(BiomechanicalPhase.ECCENTRIC, "Eccentric Lower", "ধীরে নিচে নামা")
        phaseIdx == 1 -> Triple(BiomechanicalPhase.ISOMETRIC_HOLD, "Peak Tension", "সর্বোচ্চ সংকোচন")
        phaseIdx == 2 -> Triple(BiomechanicalPhase.CONCENTRIC, "Concentric Drive", "শক্তিশালী উঠান")
        else -> Triple(BiomechanicalPhase.RECOVERY, "Reset & Inhale", "স্থিতি ও শ্বাস")
    }

    val eccentricLoad = if (phaseIdx == 0) (0.35f + 0.65f * easedT) else 0f
    val isometricTension = when {
        profile == MovementPhysicsProfile.CORE_ISOMETRIC && (phaseIdx == 1 || phaseIdx == 2) -> 0.96f
        phaseIdx == 1 -> 0.92f + 0.08f * sin(rawT * PI).toFloat()
        else -> 0.15f
    }
    val concentricLoad = if (phaseIdx == 2) (1f - 0.30f * easedT) else 0f

    // Subtle realistic neuromuscular micro-stabilization tremor at peak isometric/eccentric strain
    val peakLoad = maxOf(isometricTension * 0.9f, eccentricLoad * 0.55f, concentricLoad * 0.65f)
    val microJitterU = if (peakLoad > 0.72f && profile != MovementPhysicsProfile.MOBILITY_FLOW) {
        sin(wrapped * 28f * PI.toFloat()) * 0.012f * ((peakLoad - 0.72f) / 0.28f)
    } else 0f

    // Realistic diaphragmatic breath expansion (inhale on eccentric/recovery, braced exhale on concentric)
    val breathExpansion = when (phaseIdx) {
        0 -> 0.35f + 0.65f * easedT
        1 -> 0.85f * (1f - rawT * 0.25f)
        2 -> 0.60f - 1.10f * easedT
        else -> -0.50f + 0.85f * easedT
    }.coerceIn(-1f, 1f)

    // 5. Anatomical per-muscle recruitment model
    val baseWork = when (phaseIdx) {
        0 -> 0.32f + 0.56f * easedT
        1 -> 0.94f + 0.06f * sin(rawT * PI).toFloat()
        2 -> 0.98f - 0.32f * easedT
        else -> 0.30f * (1f - easedT) + 0.14f
    }.coerceIn(0.12f, 1f)

    var pec = 0.14f
    var delt = 0.16f
    var bicep = 0.14f
    var tricep = 0.14f
    var forearm = 0.16f
    var core = 0.26f
    var glute = 0.16f
    var quad = 0.16f
    var ham = 0.15f
    var calf = 0.16f

    when {
        id.contains("diamond") -> {
            pec = baseWork * 0.92f
            tricep = baseWork * 1.00f
            delt = baseWork * 0.82f
            forearm = baseWork * 0.55f
            core = baseWork * 0.72f
        }
        id.contains("pike") -> {
            delt = baseWork * 1.00f
            tricep = baseWork * 0.92f
            pec = baseWork * 0.64f
            core = baseWork * 0.75f
            ham = 0.45f
        }
        id.contains("wide") -> {
            pec = baseWork * 1.00f
            delt = baseWork * 0.84f
            tricep = baseWork * 0.74f
            core = baseWork * 0.68f
        }
        id.contains("push") || id.contains("dip") || id.contains("army") || id.contains("military") || id.contains("archer") -> {
            pec = baseWork * 0.96f
            tricep = baseWork * 0.94f
            delt = baseWork * 0.85f
            bicep = baseWork * 0.42f
            forearm = baseWork * 0.58f
            core = baseWork * 0.78f
            glute = baseWork * 0.45f
        }
        id.contains("squat") || id.contains("lunge") -> {
            quad = baseWork * 1.00f
            glute = baseWork * 0.94f
            ham = baseWork * 0.76f
            calf = baseWork * (0.58f + landingComp * 0.42f)
            core = baseWork * 0.66f
        }
        id.contains("bridge") -> {
            glute = baseWork * 1.00f
            ham = baseWork * 0.88f
            core = baseWork * 0.72f
            quad = baseWork * 0.52f
        }
        id.contains("calf") -> {
            calf = baseWork * 1.00f
            quad = baseWork * 0.35f
            core = baseWork * 0.35f
        }
        profile == MovementPhysicsProfile.PLYO_BALLISTIC -> {
            quad = (baseWork * 0.88f + landingComp * 0.40f).coerceAtMost(1f)
            calf = (baseWork * 0.95f + flightLiftU * 0.80f).coerceAtMost(1f)
            glute = baseWork * 0.82f
            delt = baseWork * 0.76f
            core = baseWork * 0.78f
            if (id.contains("burpee")) {
                pec = baseWork * 0.84f
                tricep = baseWork * 0.82f
            }
        }
        profile == MovementPhysicsProfile.GAIT_LOCOMOTION -> {
            quad = baseWork * 0.90f
            ham = baseWork * 0.78f
            calf = baseWork * 0.92f
            core = baseWork * 0.84f
            delt = if (id.contains("climber")) 0.82f else baseWork * 0.52f
            tricep = if (id.contains("climber")) 0.76f else baseWork * 0.35f
        }
        profile == MovementPhysicsProfile.CORE_ISOMETRIC -> {
            core = baseWork * 1.00f
            glute = baseWork * 0.68f
            delt = if (id.contains("plank")) baseWork * 0.78f else baseWork * 0.32f
            tricep = if (id.contains("plank")) baseWork * 0.65f else baseWork * 0.25f
            quad = baseWork * 0.58f
        }
        else -> {
            when (activeZone) {
                MuscleZone.CHEST_ARMS -> {
                    pec = baseWork * 0.92f; delt = baseWork * 0.85f; bicep = baseWork * 0.70f; tricep = baseWork * 0.88f
                }
                MuscleZone.LEGS_GLUTES -> {
                    quad = baseWork * 0.95f; glute = baseWork * 0.90f; ham = baseWork * 0.78f; calf = baseWork * 0.72f
                }
                MuscleZone.CORE, MuscleZone.SPINE_BACK -> {
                    core = baseWork * 0.95f; glute = baseWork * 0.60f
                }
                MuscleZone.FULL_BODY -> {
                    pec = baseWork * 0.72f; delt = baseWork * 0.75f; core = baseWork * 0.85f
                    quad = baseWork * 0.82f; glute = baseWork * 0.78f; calf = baseWork * 0.70f
                }
            }
        }
    }

    return BiomechanicalTelemetry(
        easedT = easedT,
        phaseType = phaseType,
        phaseLabelEn = labelEn,
        phaseLabelBn = labelBn,
        eccentricLoad = eccentricLoad,
        concentricLoad = concentricLoad,
        isometricTension = isometricTension,
        gravityFlightLiftU = flightLiftU,
        landingCompression = landingComp,
        landingImpactRipple = impactRipple,
        comShiftXU = comShiftXU,
        isometricMicroJitterU = microJitterU,
        breathExpansion = breathExpansion,
        footRollPhase = footRoll,
        clothInertia = (easedT - rawT) * 0.85f,
        pecTension = pec.coerceIn(0f, 1f),
        deltTension = delt.coerceIn(0f, 1f),
        bicepTension = bicep.coerceIn(0f, 1f),
        tricepTension = tricep.coerceIn(0f, 1f),
        forearmTension = forearm.coerceIn(0f, 1f),
        coreTension = core.coerceIn(0f, 1f),
        gluteTension = glute.coerceIn(0f, 1f),
        quadTension = quad.coerceIn(0f, 1f),
        hamTension = ham.coerceIn(0f, 1f),
        calfTension = calf.coerceIn(0f, 1f),
        showComBalanceGuide = true
    )
}

/**
 * Solves serene, physically grounded human weight-shift locomotion, natural diaphragmatic breathing,
 * and gravity-coupled cloth inertia for Salah & Wudu demonstrations.
 */
fun solveSalahWuduBiomechanics(
    stepId: String,
    phase: Float,
    motionT: Float,
    motionVelocity: Float
): BiomechanicalTelemetry {
    val breath = sin(phase * 2f * PI.toFloat())
    // Authentic horizontal weight-shift over feet/knees during Ruku bow, Sujud prostration, and Jalsa
    val comShiftXU = when (stepId) {
        "salah_step_3" -> -0.14f * motionT // Hips shift slightly back in Ruku to keep CoM balanced over heels/midfoot
        "salah_step_5" -> 0.10f * motionT  // Controlled forward descent into 7-point Sujud
        "salah_step_6", "salah_step_7" -> -0.06f * motionT // Settling weight smoothly onto heels in Jalsa/Tashahhud
        "wudu_step_2", "wudu_step_3" -> 0.08f * motionT // Natural slight forward lean toward stone basin
        else -> 0f
    }

    // Subtle knee cushioning during transitions into Ruku/Sujud
    val transitionSettle = (abs(motionVelocity) * 0.16f).coerceIn(0f, 0.20f)
    val clothInertia = (motionVelocity * 0.65f + sin(phase * 2f * PI.toFloat()) * 0.08f).coerceIn(-1.2f, 1.2f)

    return BiomechanicalTelemetry(
        easedT = motionT,
        phaseType = BiomechanicalPhase.TRANSITION,
        phaseLabelEn = "Khushu",
        phaseLabelBn = "খুশু",
        landingCompression = transitionSettle,
        comShiftXU = comShiftXU,
        breathExpansion = breath * 0.65f,
        clothInertia = clothInertia,
        coreTension = 0.25f,
        quadTension = if (stepId == "salah_step_3") 0.35f * motionT else 0.15f,
        showComBalanceGuide = false
    )
}

// --- Biomechanical Physics Easing Functions ---

private fun easeEccentricBraked(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    // Smooth acceleration under gravity followed by strong muscular braking at bottom
    val quadIn = 2f * x * x
    val brakeOut = 1f - (-2f * x + 2f).pow(3f) / 2f
    return if (x < 0.45f) quadIn * 0.85f else (0.34425f + (brakeOut - 0.34425f) * 1.0f).coerceIn(0f, 1f)
}

private fun easeIsometricHold(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    // Smooth, subtle organic micro-settling at peak hold
    return x * x * (3f - 2f * x)
}

private fun easeConcentricDrive(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    // Powerful initial concentric force overcoming inertia, then critically damped top lock-out
    return 1f - (1f - x).pow(2.85f)
}

private fun easeCriticallyDamped(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    return 1f - (1f - x).pow(2.2f) * cos(x * PI * 0.5).toFloat().coerceAtLeast(0f)
}

private fun easeInQuad(t: Float): Float = t * t
private fun easeOutCubic(t: Float): Float = 1f - (1f - t).pow(3f)
private fun easeOutQuartLocal(t: Float): Float = 1f - (1f - t).pow(4f)
private fun easeInOutQuad(t: Float): Float = if (t < 0.5f) 2f * t * t else 1f - (-2f * t + 2f).pow(2f) / 2f
private fun easeSmoothQuintic(t: Float): Float = t * t * t * (t * (t * 6f - 15f) + 10f)

private fun easeAthleticStride(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    // Rapid mid-swing velocity with crisp heel/forefoot strike deceleration
    return (0.5f - 0.5f * cos(x * PI).toFloat()).let { s ->
        sqrt(s.coerceIn(0f, 1f)) * 0.35f + s * 0.65f
    }
}
