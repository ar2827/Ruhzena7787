package com.example.ruhzena.core.i18n

val ArabicStrings: AppStrings = EnglishStrings.copy(
    core = EnglishStrings.core.copy(
        appName = "روح زينة",
        tagline = "رفيقك الذكي للحياة الإسلامية والعافية",
        navHome = "الرئيسية",
        navSpirituality = "القرآن والدين",
        navAi = "روح زيبا AI",
        navWellness = "العافية",
        navDiscipline = "الانضباط"
    ),
    onboarding = EnglishStrings.onboarding.copy(
        welcomeTitle = "مرحباً بك في روح زينة",
        welcomeQuote = "الخطوات الصادقة الصغيرة، بهدي الإيمان والانضباط، تحوّل يومك العادي إلى حياة مليئة بالغاية. نحن هنا لنرافقك في هذا التغيير.",
        chooseLanguage = "اختر لغة التطبيق",
        startCompanion = "ادخل روح زينة",
        profileSetupTitle = "تخصيص ملفك الشخصي",
        profileSetupSubtitle = "أدخل بياناتك لتخصيص التمارين والترطيب والتوجيه لك بدقة.",
        fullNameLabel = "الاسم",
        ageLabel = "العمر (سنة)",
        weightKgLabel = "الوزن (كجم)",
        heightCmLabel = "الطول (سم)",
        startMyJourney = "ابدأ رحلتي"
    ),
    home = EnglishStrings.home.copy(
        salamGreeting = "السلام عليكم",
        nextPrayerLabel = "الصلاة القادمة",
        prayerInPrefix = "بعد",
        dailyOverviewTitle = "الإيقاع اليومي",
        hydrationLabel = "الترطيب",
        workoutLabel = "التمارين",
        habitsLabel = "العادات",
        nutritionLabel = "التغذية",
        continueReadingQuran = "متابعة القراءة",
        dailyIslamicLesson = "فائدة اليوم الموثقة",
        quickActionsTitle = "وصول سريع",
        qiblaAction = "القبلة",
        tasbihAction = "التسبيح",
        adhkarAction = "الأذكار",
        duaAction = "الدعاء",
        journalAction = "المفكرة",
        aiCoachAction = "اسأل AI"
    ),
    quran = EnglishStrings.quran.copy(
        tabQuran = "القرآن",
        tabPrayerQibla = "الصلاة والقبلة",
        tabAdhkarDua = "الأذكار والدعاء",
        tabTasbih = "التسبيح",
        tabLessons = "الحكمة اليومية"
    ),
    prayerAndDeen = EnglishStrings.prayerAndDeen.copy(
        fajr = "الفجر",
        sunrise = "الشروق",
        dhuhr = "الظهر",
        asr = "العصر",
        maghrib = "المغرب",
        isha = "العشاء"
    ),
    ai = EnglishStrings.ai.copy(
        aiTitle = "روح زيبا AI",
        aiSend = "إرسال"
    ),
    settings = EnglishStrings.settings.copy(
        settingsTitle = "الإعدادات",
        themeModeLabel = "مظهر التطبيق",
        darkGlassTheme = "زجاج داكن",
        lightGlassTheme = "زجاج أبيض ورمادي",
        countrySetting = "الدولة / المنطقة",
        characterGenderLabel = "شخصية التمارين",
        maleCharacter = "شخصية ذكورية",
        femaleCharacter = "شخصية أنثوية",
        safetyPrivacyTitle = "الأمان والخصوصية",
        closeAction = "إغلاق",
        saveSettings = "حفظ"
    )
)

val UrduStrings: AppStrings = EnglishStrings.copy(
    core = EnglishStrings.core.copy(
        appName = "روح زینہ",
        tagline = "متوازن اسلامی طرزِ زندگی اور صحت کا ذہین ساتھی",
        navHome = "ہوم",
        navSpirituality = "قرآن و دین",
        navAi = "روح زیبا AI",
        navWellness = "صحت",
        navDiscipline = "نظم و ضبط"
    ),
    onboarding = EnglishStrings.onboarding.copy(
        welcomeTitle = "روح زینہ میں خوش آمدید",
        welcomeQuote = "ایمان اور نظم و ضبط کے ساتھ چھوٹے مخلصانہ قدم عام دن کو بامقصد زندگی میں بدل دیتے ہیں۔ ہم اس تبدیلی میں آپ کے ساتھ ہیں۔",
        chooseLanguage = "زبان منتخب کریں",
        startCompanion = "روح زینہ میں داخل ہوں",
        profileSetupTitle = "اپنا پروفائل مکمل کریں",
        fullNameLabel = "آپ کا نام",
        ageLabel = "عمر (سال)",
        weightKgLabel = "وزن (کلوگرام)",
        heightCmLabel = "قد (سینٹی میٹر)",
        startMyJourney = "اپنا سفر شروع کریں"
    ),
    home = EnglishStrings.home.copy(
        salamGreeting = "السلام علیکم",
        nextPrayerLabel = "اگلی نماز",
        prayerInPrefix = "باقی",
        hydrationLabel = "پانی",
        workoutLabel = "ورزش",
        habitsLabel = "عادات",
        nutritionLabel = "غذا"
    ),
    quran = EnglishStrings.quran.copy(
        tabQuran = "قرآن",
        tabPrayerQibla = "نماز و قبلہ",
        tabAdhkarDua = "اذکار و دعا",
        tabTasbih = "تسبیح"
    ),
    prayerAndDeen = EnglishStrings.prayerAndDeen.copy(
        fajr = "فجر",
        sunrise = "طلوع آفتاب",
        dhuhr = "ظہر",
        asr = "عصر",
        maghrib = "مغرب",
        isha = "عشاء"
    ),
    ai = EnglishStrings.ai.copy(
        aiTitle = "روح زیبا AI"
    ),
    settings = EnglishStrings.settings.copy(
        settingsTitle = "ترتیبات",
        themeModeLabel = "تھیم",
        darkGlassTheme = "ڈارک گلاس",
        lightGlassTheme = "وائٹ اور گرے گلاس",
        countrySetting = "ملک / علاقہ",
        characterGenderLabel = "ورزش کردار",
        maleCharacter = "مردانہ کردار",
        femaleCharacter = "نسوانی کردار",
        safetyPrivacyTitle = "حفاظت اور رازداری",
        closeAction = "بند کریں",
        saveSettings = "محفوظ کریں"
    )
)

val TurkishStrings: AppStrings = EnglishStrings.copy(
    core = EnglishStrings.core.copy(
        tagline = "Akıllı İslami Yaşam Tarzı ve Sağlık Rehberi",
        navHome = "Ana Sayfa",
        navSpirituality = "Kur'an ve Din",
        navAi = "RuhZeba AI",
        navWellness = "Sağlık",
        navDiscipline = "Disiplin"
    ),
    onboarding = EnglishStrings.onboarding.copy(
        welcomeTitle = "RuhZena'ya Hoş Geldiniz",
        welcomeQuote = "İman ve disiplinle atılan küçük samimi adımlar sıradan bir günü anlamlı bir hayata dönüştürür. Bu kalıcı değişimde yanınızdayız.",
        chooseLanguage = "Uygulama Dilini Seçin",
        startCompanion = "RuhZena'ya Gir",
        profileSetupTitle = "Profilinizi Oluşturun",
        fullNameLabel = "Adınız",
        ageLabel = "Yaş (yıl)",
        weightKgLabel = "Kilo (kg)",
        heightCmLabel = "Boy (cm)",
        startMyJourney = "Yolculuğuma Başla"
    ),
    home = EnglishStrings.home.copy(
        salamGreeting = "Selamün Aleyküm",
        nextPrayerLabel = "Sıradaki Namaz",
        dailyOverviewTitle = "Günlük Ritim",
        hydrationLabel = "Su Takibi",
        workoutLabel = "Antrenman",
        habitsLabel = "Alışkanlıklar",
        nutritionLabel = "Beslenme",
        qiblaAction = "Kıble",
        tasbihAction = "Tesbih",
        adhkarAction = "Zikirler",
        duaAction = "Dua",
        journalAction = "Günlük"
    ),
    prayerAndDeen = EnglishStrings.prayerAndDeen.copy(
        fajr = "İmsak",
        sunrise = "Güneş",
        dhuhr = "Öğle",
        asr = "İkindi",
        maghrib = "Akşam",
        isha = "Yatsı"
    ),
    settings = EnglishStrings.settings.copy(
        settingsTitle = "Ayarlar",
        themeModeLabel = "Görünüm Teması",
        darkGlassTheme = "Koyu Obsidyen Cam",
        lightGlassTheme = "Açık Beyaz & Gri-Siyah Cam",
        countrySetting = "Ülke / Bölge",
        characterGenderLabel = "Egzersiz Rehber Karakteri",
        maleCharacter = "Erkek Figür",
        femaleCharacter = "Kadın Figür",
        safetyPrivacyTitle = "Güvenlik ve Gizlilik",
        closeAction = "Kapat",
        saveSettings = "Kaydet"
    )
)

val IndonesianStrings: AppStrings = EnglishStrings.copy(
    core = EnglishStrings.core.copy(
        tagline = "Pendamping Gaya Hidup Islami & Kesehatan Cerdas",
        navHome = "Beranda",
        navSpirituality = "Al-Qur'an & Din",
        navAi = "RuhZeba AI",
        navWellness = "Kesehatan",
        navDiscipline = "Disiplin"
    ),
    onboarding = EnglishStrings.onboarding.copy(
        welcomeTitle = "Selamat Datang di RuhZena",
        welcomeQuote = "Langkah kecil yang tulus, dipandu iman dan disiplin, mengubah hari biasa menjadi hidup penuh makna. Kami hadir menemani perubahan baik Anda.",
        chooseLanguage = "Pilih Bahasa Aplikasi",
        startCompanion = "Masuk ke RuhZena",
        profileSetupTitle = "Atur Profil Anda",
        fullNameLabel = "Nama Anda",
        ageLabel = "Usia (tahun)",
        weightKgLabel = "Berat Badan (kg)",
        heightCmLabel = "Tinggi Badan (cm)",
        startMyJourney = "Mulai Perjalanan Saya"
    ),
    home = EnglishStrings.home.copy(
        salamGreeting = "Assalamu'alaikum",
        nextPrayerLabel = "Salat Berikutnya",
        dailyOverviewTitle = "Ritme Harian",
        hydrationLabel = "Hidrasi",
        workoutLabel = "Latihan",
        habitsLabel = "Kebiasaan",
        nutritionLabel = "Nutrisi",
        qiblaAction = "Kiblat",
        tasbihAction = "Tasbih",
        adhkarAction = "Dzikir",
        duaAction = "Doa",
        journalAction = "Jurnal"
    ),
    prayerAndDeen = EnglishStrings.prayerAndDeen.copy(
        fajr = "Subuh",
        sunrise = "Terbit",
        dhuhr = "Dzuhur",
        asr = "Ashar",
        maghrib = "Maghrib",
        isha = "Isya"
    ),
    settings = EnglishStrings.settings.copy(
        settingsTitle = "Pengaturan",
        themeModeLabel = "Tema Tampilan",
        darkGlassTheme = "Kaca Obsidian Gelap",
        lightGlassTheme = "Kaca Putih & Abu-Hitam",
        countrySetting = "Negara / Wilayah",
        characterGenderLabel = "Karakter Panduan Latihan",
        maleCharacter = "Karakter Pria",
        femaleCharacter = "Karakter Wanita",
        safetyPrivacyTitle = "Keamanan & Privasi",
        closeAction = "Tutup",
        saveSettings = "Simpan"
    )
)

val MalayStrings: AppStrings = EnglishStrings.copy(
    core = EnglishStrings.core.copy(
        tagline = "Teman Gaya Hidup Islam & Kesejahteraan Pintar",
        navHome = "Utama",
        navSpirituality = "Al-Quran & Din",
        navAi = "RuhZeba AI",
        navWellness = "Kesihatan",
        navDiscipline = "Disiplin"
    ),
    onboarding = EnglishStrings.onboarding.copy(
        welcomeTitle = "Selamat Datang ke RuhZena",
        welcomeQuote = "Langkah kecil yang ikhlas berpandukan iman dan disiplin mengubah hari biasa menjadi kehidupan bermakna. Kami di sini untuk membantu perubahan anda.",
        chooseLanguage = "Pilih Bahasa Antara Muka",
        startCompanion = "Masuk ke RuhZena",
        profileSetupTitle = "Peribadikan Profil Anda",
        fullNameLabel = "Nama Anda",
        ageLabel = "Umur (tahun)",
        weightKgLabel = "Berat (kg)",
        heightCmLabel = "Tinggi (cm)",
        startMyJourney = "Mulakan Perjalanan"
    ),
    home = EnglishStrings.home.copy(
        salamGreeting = "Assalamualaikum",
        nextPrayerLabel = "Solat Seterusnya",
        dailyOverviewTitle = "Ritma Harian",
        hydrationLabel = "Penghidratan",
        workoutLabel = "Senaman",
        habitsLabel = "Amalan",
        nutritionLabel = "Pemakanan",
        qiblaAction = "Kiblat",
        tasbihAction = "Tasbih",
        adhkarAction = "Zikir",
        duaAction = "Doa",
        journalAction = "Jurnal"
    ),
    prayerAndDeen = EnglishStrings.prayerAndDeen.copy(
        fajr = "Subuh",
        sunrise = "Syuruk",
        dhuhr = "Zohor",
        asr = "Asar",
        maghrib = "Maghrib",
        isha = "Isyak"
    ),
    settings = EnglishStrings.settings.copy(
        settingsTitle = "Tetapan",
        themeModeLabel = "Tema Visual",
        darkGlassTheme = "Kaca Gelap Obsidian",
        lightGlassTheme = "Kaca Putih & Kelabu Gelap",
        countrySetting = "Negara / Wilayah",
        characterGenderLabel = "Watak Panduan Senaman",
        maleCharacter = "Watak Lelaki",
        femaleCharacter = "Watak Wanita",
        safetyPrivacyTitle = "Keselamatan & Privasi",
        closeAction = "Tutup",
        saveSettings = "Simpan"
    )
)

val FrenchStrings: AppStrings = EnglishStrings.copy(
    core = EnglishStrings.core.copy(
        tagline = "Compagnon Intelligent de Vie Islamique et Bien-être",
        navHome = "Accueil",
        navSpirituality = "Coran & Foi",
        navAi = "RuhZeba AI",
        navWellness = "Bien-être",
        navDiscipline = "Discipline"
    ),
    onboarding = EnglishStrings.onboarding.copy(
        welcomeTitle = "Bienvenue dans RuhZena",
        welcomeQuote = "De petits pas sincères, guidés par la foi et la discipline, transforment une journée ordinaire en une vie pleine de sens. Nous sommes là pour vous accompagner.",
        chooseLanguage = "Choisissez la langue",
        startCompanion = "Entrer dans RuhZena",
        profileSetupTitle = "Personnalisez votre profil",
        fullNameLabel = "Votre nom",
        ageLabel = "Âge (ans)",
        weightKgLabel = "Poids (kg)",
        heightCmLabel = "Taille (cm)",
        startMyJourney = "Commencer mon parcours"
    ),
    home = EnglishStrings.home.copy(
        salamGreeting = "Assalamou Alaykoum",
        nextPrayerLabel = "Prochaine prière",
        dailyOverviewTitle = "Rythme quotidien",
        hydrationLabel = "Hydratation",
        workoutLabel = "Entraînements",
        habitsLabel = "Habitudes",
        nutritionLabel = "Nutrition",
        qiblaAction = "Qibla",
        tasbihAction = "Tasbih",
        adhkarAction = "Adhkar",
        duaAction = "Doua",
        journalAction = "Journal"
    ),
    prayerAndDeen = EnglishStrings.prayerAndDeen.copy(
        fajr = "Fajr",
        sunrise = "Lever du soleil",
        dhuhr = "Dhuhr",
        asr = "Asr",
        maghrib = "Maghrib",
        isha = "Icha"
    ),
    settings = EnglishStrings.settings.copy(
        settingsTitle = "Paramètres",
        themeModeLabel = "Thème visuel",
        darkGlassTheme = "Verre Noir Obsidienne",
        lightGlassTheme = "Verre Blanc & Gris-Noir",
        countrySetting = "Pays / Région",
        characterGenderLabel = "Personnage du guide sportif",
        maleCharacter = "Silhouette Homme",
        femaleCharacter = "Silhouette Femme",
        safetyPrivacyTitle = "Sécurité et Confidentialité",
        closeAction = "Fermer",
        saveSettings = "Enregistrer"
    )
)
