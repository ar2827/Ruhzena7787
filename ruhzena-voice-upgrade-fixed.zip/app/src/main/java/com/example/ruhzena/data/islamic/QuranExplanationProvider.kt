package com.example.ruhzena.data.islamic

data class AyahExplanation(
    val surahNumber: Int,
    val ayahNumber: Int,
    val titleEn: String,
    val titleBn: String,
    val explanationEn: String,
    val explanationBn: String,
    val lifeLessonEn: String,
    val lifeLessonBn: String,
    val surahContextEn: String,
    val surahContextBn: String,
    val sourceNote: String,
    val deeperContextEn: String = "",
    val deeperContextBn: String = ""
)

object QuranExplanationProvider {
    private val curatedMap: Map<Pair<Int, Int>, Pair<Pair<String, String>, Pair<String, String>>> = mapOf(
        // (surah, ayah) to ((explanationEn, explanationBn) to (lessonEn, lessonBn))
        (1 to 1) to (
            ("This opening invokes Allah's two encompassing names of Mercy: Ar-Rahman (vast mercy toward all creation) and Ar-Rahim (special, enduring mercy for believers). Beginning every action with Bismillah aligns intention and seeks divine barakah." to
                "এই আয়াতের মাধ্যমে আল্লাহর দুটি মহান রহমতের নাম—আর-রাহমান (সর্বব্যাপী দয়া) ও আর-রাহীম (মুমিনদের প্রতি বিশেষ দয়া)—স্মরণ করে প্রতিটি কাজ শুরু করা হয়। বিসমিল্লাহ নিয়তকে পবিত্র করে ও কাজে বরকত আনে।") to
                ("Say Bismillah intentionally before studying, eating, leaving home, or exercising." to
                    "পড়াশোনা, খাবার, ঘর থেকে বের হওয়া বা শরীরচর্চার আগে সচেতনভাবে বিসমিল্লাহ বলার অভ্যাস গড়ে তুলুন।")
            ),
        (1 to 2) to (
            ("Hamd combines deep praise and heartfelt gratitude directed solely to Allah as Rabb—Creator, Sustainer, Nurturer, and Guardian of all realms seen and unseen." to
                "হামদ অর্থ ভালোবাসা ও শ্রদ্ধাসহ আল্লাহর প্রশংসা ও কৃতজ্ঞতা। তিনি কেবল সৃষ্টিকর্তাই নন, বরং সমগ্র জগতের লালনপালনকারী ও রক্ষাকর্তা (রব)।") to
                ("Anchor your day by noticing blessings around you and uttering Alhamdulillah with presence." to
                    "দিনের শুরু ও শেষে চারপাশের নেয়ামত লক্ষ্য করে মন থেকে 'আলহামদুলিল্লাহ' বলুন।")
            ),
        (1 to 3) to (
            ("Repeating Ar-Rahman Ar-Rahim after Rabbul-'Alamin reminds humanity that Allah's Lordship is fundamentally anchored in compassion, patience, and mercy rather than harshness." to
                "জগতের প্রতিপালক বলার পরপরই আবার পরম করুণাময় বলা হয়েছে—যাতে বান্দা বুঝতে পারে আল্লাহর শাসন ও প্রতিপালন মূলত অসীম দয়া ও ভালোবাসার ওপর প্রতিষ্ঠিত।") to
                ("Reflect Allah's mercy by staying gentle with family, coworkers, and yourself after mistakes." to
                    "পরিবার, মানুষ এবং ভুলের পর নিজের প্রতিও দয়াশীল ও সহনশীল আচরণ করুন।")
            ),
        (1 to 4) to (
            ("Yawm ad-Din is the Day of Accountability when every hidden patience, honest effort, and overlooked injustice receives perfect justice without favoritism." to
                "ইয়াওমিদ্দীন হলো বিচার ও প্রতিদান দিবস—যেদিন মানুষের প্রতিটি গোপন ধৈর্য, সৎ প্রচেষ্টা এবং অন্যায়ের সম্পূর্ণ ন্যায়বিচার প্রতিষ্ঠিত হবে।") to
                ("Act with integrity even when nobody is watching; nothing good is ever wasted." to
                    "কেউ না দেখলেও সততা বজায় রাখুন; আপনার কোনো ভালো কাজই কখনো বৃথা যাবে না।")
            ),
        (1 to 5) to (
            ("The centerpiece of Al-Fatihah unites exclusive devotion ('You alone we worship') with humble reliance ('You alone we ask for help'). Neither arrogance without worship nor helplessness without seeking Allah belongs in a believer's heart." to
                "সূরা ফাতিহার মূল কেন্দ্রবিন্দু হলো এই আয়াত—এখানে একদিকে আল্লাহর একান্ত ইবাদতের অঙ্গীকার এবং অন্যদিকে একমাত্র তাঁরই সাহায্য প্রার্থনার ঘোষণা রয়েছে।") to
                ("Before tackling hard tasks or anxiety, pair action with sincere Dua for Allah's help." to
                    "যেকোনো কঠিন কাজ বা দুশ্চিন্তার আগে পরিশ্রমের সাথে একমাত্র আল্লাহর সাহায্য প্রার্থনা করুন।")
            ),
        (1 to 6) to (
            ("Al-Sirat al-Mustaqim is the balanced path of truth, spiritual clarity, physical stewardship, and moral steadiness connecting this life cleanly to Allah's pleasure." to
                "সিরাতুল মুস্তাক্বীম হলো সত্য, ন্যায়, ভারসাম্যপূর্ণ জীবনধারা ও আত্মিক স্বচ্ছতার সরল পথ—যা দুনিয়া ও আখিরাতে সাফল্যের দিকে নিয়ে যায়।") to
                ("Repeat this prayer inside Salah knowing guidance is a daily need, not a one-time event." to
                    "প্রতিটি নামাজে মনোযোগসহ হেদায়াত কামনা করুন; সঠিক পথের দিকনির্দেশনা আমাদের প্রতিদিন প্রয়োজন।")
            ),
        (1 to 7) to (
            ("Seeking the path of the prophets, truthful, and righteous guards the heart against both knowingly ignoring truth and acting zealously without sound knowledge." to
                "নবী-রাসূল ও নেককার বান্দাদের পথ চাওয়ার মাধ্যমে বান্দা জেনে-শুনে সত্য ত্যাগ করা এবং অজ্ঞতাবশত বিভ্রান্ত হওয়া—উভয় বিপদ থেকে আশ্রয় প্রার্থনা করে।") to
                ("Pair sincerity with authentic knowledge before judging or acting." to
                    "যেকোনো আমল ও সিদ্ধান্তে আন্তরিকতার পাশাপাশি সহীহ জ্ঞান অর্জনের চেষ্টা করুন।")
            ),
        (2 to 255) to (
            ("Ayat al-Kursi is celebrated as the greatest verse in the Quran (Sahih Muslim 810). It affirms Allah's eternal life (Al-Hayy), self-subsisting sovereignty (Al-Qayyum), limitless knowledge, and effortless protection of the entire cosmos." to
                "আয়াতুল কুরসি কুরআনের সর্বশ্রেষ্ঠ আয়াত (সহীহ মুসলিম ৮১০)। এতে আল্লাহর চিরঞ্জীব সত্তা (আল-হাইয়্যু), সমগ্র জগতের ধারক ও পরিচালনাকারী (আল-কাইয়্যুম) এবং তাঁর অসীম জ্ঞান ও ক্ষমতার ঘোষণা দেওয়া হয়েছে।") to
                ("Recite after every obligatory Salah and before sleep for spiritual serenity and protection." to
                    "প্রতি ফরজ নামাজের পর এবং ঘুমানোর আগে আয়াতুল কুরসি নিয়মিত পাঠ করুন।")
            ),
        (97 to 1) to (
            ("Laylat al-Qadr marks the monumental night when the Quran began its descent into human history—a night of divine decree, peace, and destiny." to
                "লাইলাতুল ক্বদর হলো সেই মহিমান্বিত রজনী যে রাতে মানবজাতির হিদায়াত হিসেবে পবিত্র কুরআন অবতীর্ণ হওয়া শুরু হয়।") to
                ("Revisit the Quran during calm night hours, especially in Ramadan's last ten nights." to
                    "রাতের নীরবতায়—বিশেষত রমজানের শেষ দশ রাতে—কুরআন তিলাওয়াত ও চিন্তায় সময় দিন।")
            ),
        (97 to 3) to (
            ("A single night of sincere worship during Laylat al-Qadr carries reward surpassing 1,000 months (over 83 years) of ordinary devotion." to
                "লাইলাতুল ক্বদরের মাত্র এক রাতের আন্তরিক ইবাদত হাজার মাসের (৮৩ বছরেরও বেশি সময়ের) ইবাদতের চেয়ে উত্তম।") to
                ("Never underestimate one focused night of prayer, forgiveness, and heartfelt Dua." to
                    "একটি রাতের আন্তরিক ইবাদত ও তওবাকেও কখনো ছোট করে দেখবেন না।")
            ),
        (103 to 1) to (
            ("Allah swears by Al-'Asr—fleeting human time—warning that every passing hour is our irreplaceable capital in this world." to
                "আল্লাহ মহাকাল বা সময়ের শপথ করেছেন—মানুষকে সতর্ক করার জন্য যে জীবন থেকে চলে যাওয়া প্রতিটি মুহূর্ত অমূল্য পুঁজি।") to
                ("Audit how your waking hours are spent so screens and distraction do not steal your purpose." to
                    "প্রতিদিন আপনার সময় কীভাবে কাটছে তা পর্যালোচনা করুন; অপ্রয়োজনীয় কাজে সময় নষ্ট করবেন না।")
            ),
        (103 to 2) to (
            ("Left merely to drift, distraction, and worldly chasing, humanity gradually incurs spiritual and existential loss." to
                "সঠিক দিকনির্দেশনা ও আমল ছাড়া সময় অতিবাহিত করলে মানুষ ধীরে ধীরে প্রকৃত সফলতা থেকে ক্ষতিগ্রস্ত হয়।") to
                ("Replace aimless habits with clear, small daily goals." to
                    "লক্ষ্যহীন অভ্যাস ত্যাগ করে প্রতিদিন ছোট কিন্তু অর্থপূর্ণ লক্ষ্য ঠিক করুন।")
            ),
        (103 to 3) to (
            ("Imam al-Shafi'i famously noted this concise Surah suffices for guidance: salvation rests on four pillars—Iman (faith), righteous action, advising each other toward truth, and encouraging patience together." to
                "ইমাম শাফেয়ী (রহ.) বলেছিলেন, এই একটি সূরাই মানুষের হেদায়াতের জন্য যথেষ্ট। ক্ষতির হাত থেকে বাঁচার চারটি শর্ত: ঈমান, সৎকর্ম, সত্যের উপদেশ এবং ধৈর্যের পরামর্শ।") to
                ("Build positive community habits: do good privately and encourage truth gently with others." to
                    "নিজে ভালো কাজ করুন এবং পরিবার ও বন্ধুদেরও ধৈর্য ও সত্যের পথে উৎসাহ দিন।")
            ),
        (108 to 1) to (
            ("Revealed when critics mocked the Prophet (ﷺ) during grief, Allah promised Al-Kawthar—abundant goodness in this life and a blessed river in Paradise." to
                "নবীজী (ﷺ)-এর শোক ও বিপদের সময়ে বিরোধীদের বিদ্রূপের জবাবে আল্লাহ তাঁকে 'কাউসার'—অফুরন্ত কল্যাণ ও জান্নাতের ঝরনা—দানের সুসংবাদ দিয়েছেন।") to
                ("Stay patient under criticism; Allah defends sincerity and expands blessings in unexpected ways." to
                    "মানুষের কটূক্তিতে ভেঙে পড়বেন না; আল্লাহর ওপর ভরসা রাখলে তিনি অপ্রত্যাশিত কল্যাণ দান করেন।")
            ),
        (108 to 2) to (
            ("In gratitude for Allah's gifts, worship Him solely through Salah and compassionate sacrifice/charity benefiting the poor." to
                "আল্লাহর দেওয়া নিয়ামতের কৃতজ্ঞতাস্বরূপ একনিষ্ঠভাবে নামাজ আদায় করুন এবং অসহায় মানুষের কল্যাণে কুরবানি ও দান করুন।") to
                ("Respond to blessings with worship and generosity, not pride." to
                    "জীবনে সুখ বা সফলতা এলে অহংকার নয়, বরং নামাজ ও দানের মাধ্যমে কৃতজ্ঞতা প্রকাশ করুন।")
            ),
        (110 to 1) to (
            ("When victory and success arrive cleanly, remember all openings come solely by Allah's help and mercy." to
                "জীবনে যখন বড় সাফল্য বা বিজয় আসে, তখন স্মরণ রাখুন তা কেবল আল্লাহরই সাহায্য ও অনুগ্রহে অর্জিত হয়েছে।") to
                ("Stay humble at the peak of success." to
                    "সাফল্যের শিখরে পৌঁছেও বিনয় ও কৃতজ্ঞতা বজায় রাখুন।")
            ),
        (110 to 3) to (
            ("Success closes with Tasbih (glorifying Allah), Hamd (thanking Him), and Istighfar (seeking forgiveness for any human shortcomings)." to
                "যে কোনো কাজ বা সাফল্যের সমাপ্তি হওয়া উচিত আল্লাহর তাসবিহ, প্রশংসা (হামদ) এবং নিজ ত্রুটির জন্য ক্ষমা প্রার্থনার (ইস্তিগফার) মাধ্যমে।") to
                ("Say SubhanAllah, Alhamdulillah, Astaghfirullah after completing tasks or workouts." to
                    "যেকোনো ভালো কাজ শেষে সুবহানাল্লাহ, আলহামদুলিল্লাহ ও আস্তাগফিরুল্লাহ পড়ার অভ্যাস করুন।")
            ),
        (112 to 1) to (
            ("Surah Al-Ikhlas equals one-third of the Quran in core meaning (Sahih al-Bukhari 5013) because it crystallizes pure Tawhid: Allah is Al-Ahad—indivisibly One." to
                "সূরা ইখলাস অর্থের দিক থেকে কুরআনের এক-তৃতীয়াংশের সমতুল্য (সহীহ বুখারী ৫০১৩), কারণ এতে বিশুদ্ধ তাওহীদের ঘোষণা রয়েছে—আল্লাহ এক ও অদ্বিতীয়।") to
                ("Purify your heart from seeking validation from creation; worship the One Creator alone." to
                    "মানুষের প্রশংসার মোহ ত্যাগ করে কেবল এক আল্লাহর সন্তুষ্টির জন্য আমল করুন।")
            ),
        (112 to 2) to (
            ("As-Samad means the Eternal Refuge upon Whom all creation depends for every breath and need, while He needs nothing whatsoever." to
                "আস-সামাদ অর্থ তিনি অমুখাপেক্ষী ও চিরস্থায়ী আশ্রয়স্থল—সমগ্র সৃষ্টি প্রতিটি নিঃশ্বাস ও প্রয়োজনে তাঁর ওপর নির্ভরশীল, অথচ তিনি কারও মুখাপেক্ষী নন।") to
                ("Bring every big or tiny need directly to As-Samad in Dua." to
                    "ছোট-বড় প্রতিটি প্রয়োজনের কথা সরাসরি চির-অমুখাপেক্ষী আল্লাহর কাছে তুলে ধরুন।")
            ),
        (113 to 1) to (
            ("Al-Falaq opens by seeking refuge with the Lord of Daybreak—He who splits darkness with dawn light can split any outward harm or anxiety." to
                "আল-ফালাক সূরায় প্রভাতের স্রষ্টার কাছে আশ্রয় চাওয়া হয়েছে—যিনি রাতের অন্ধকার ভেদ করে ভোরের আলো ফোটাতে পারেন, তিনি যেকোনো বিপদ ও ভয় দূর করতে সক্ষম।") to
                ("Recite morning, evening, and at bedtime seeking protection from outward harms and envy." to
                    "সকাল-সন্ধ্যায় ও ঘুমানোর আগে দৃশ্যমান ও অদৃশ্য ক্ষতি এবং হিংসা থেকে বাঁচতে এটি পাঠ করুন।")
            ),
        (114 to 1) to (
            ("An-Nas seeks refuge with the Rabb (Lord), Malik (King), and Ilah (God) of mankind against subtle internal whispers that stir doubt, arrogance, or despair." to
                "সূরা নাস-এ মানবজাতির প্রতিপালক, অধিপতি ও মা'বুদের কাছে অন্তরের গোপন কুমন্ত্রণা ও হতাশা থেকে আশ্রয় প্রার্থনা করা হয়েছে।") to
                ("Guard your mind against negative self-talk and temptation through mindful remembrance." to
                    "মনের নেতিবাচক চিন্তা ও কুমন্ত্রণা এলে সাথে সাথে আল্লাহর আশ্রয় চেয়ে যিকির করুন।")
            )
    )

    fun buildExplanation(ayah: QuranAyah, webContextEn: String? = null): AyahExplanation {
        val meta = SurahCatalog.getMeta(ayah.surahNumber)
        val surahAuth = SurahAuthenticContextCatalog.forSurah(ayah.surahNumber)
        val curated = curatedMap[ayah.surahNumber to ayah.ayahNumber]

        val explanationEn = curated?.first?.first?.let { curatedText ->
            buildString {
                append(curatedText)
                append("\n\n")
                append(surahAuth.coreThemesEn)
                if (!webContextEn.isNullOrBlank()) {
                    append("\n\nAdditional Classical Context: ").append(webContextEn)
                }
            }
        } ?: buildString {
            append("Verse Meaning & Thematic Focus (${ayah.surahNumber}:${ayah.ayahNumber}): ")
            append("In Surah ${meta.englishName} ('${meta.englishMeaning}'), this verse states: \"${ayah.englishTranslation}\". ")
            append("\n\n")
            append(surahAuth.coreThemesEn)
            append("\n\nProphetic Virtue & Guidance: ")
            append(surahAuth.propheticVirtueEn)
            if (!webContextEn.isNullOrBlank()) {
                append("\n\nAdditional Reference Context: ").append(webContextEn)
            }
        }

        val explanationBn = curated?.first?.second?.let { curatedText ->
            buildString {
                append(curatedText)
                append("\n\n")
                append(surahAuth.coreThemesBn)
                if (!webContextEn.isNullOrBlank()) {
                    append("\n\nঅতিরিক্ত প্রাসঙ্গিক তথ্য (EN): ").append(webContextEn)
                }
            }
        } ?: buildString {
            append("আয়াতের ভাবার্থ ও বিশ্লেষণ (${ayah.surahNumber}:${ayah.ayahNumber}): ")
            append("সূরা ${meta.banglaName}-এর এই আয়াতে বলা হয়েছে: \"${ayah.banglaTranslation}\"। ")
            append("\n\n")
            append(surahAuth.coreThemesBn)
            append("\n\nনববী ফজিলত ও নির্দেশনা: ")
            append(surahAuth.propheticVirtueBn)
            if (!webContextEn.isNullOrBlank()) {
                append("\n\nঐতিহাসিক/প্রাসঙ্গিক তথ্য (EN): ").append(webContextEn)
            }
        }

        val lessonEn = curated?.second?.first ?: when {
            ayah.englishTranslation.contains("mercy", true) || ayah.englishTranslation.contains("forgiv", true) ->
                "Turn to Allah with sincere hope and reflect mercy in how you treat your family, neighbors, and yourself today."
            ayah.englishTranslation.contains("pray", true) || ayah.englishTranslation.contains("worship", true) ->
                "Strengthen khushu' and consistency in your five daily prayers and quiet remembrance of Allah."
            ayah.englishTranslation.contains("patient", true) || ayah.englishTranslation.contains("endure", true) ->
                "Hold steady with Sabr (patience); every test carries unseen wisdom and elevates your rank with Allah."
            else ->
                "Pause on this verse after listening to the recitation, reflect on its place within Surah ${meta.englishName}, and apply one concrete good deed from its message today."
        }

        val lessonBn = curated?.second?.second ?: when {
            ayah.banglaTranslation.contains("ক্ষমা") || ayah.banglaTranslation.contains("রহমত") || ayah.banglaTranslation.contains("দয়া") ->
                "আল্লাহর অসীম রহমতের আশা রাখুন এবং পরিবার ও মানুষের সাথেও ক্ষমা ও দয়াশীল আচরণ করুন।"
            ayah.banglaTranslation.contains("নামাজ") || ayah.banglaTranslation.contains("ইবাদত") ->
                "পাঁচ ওয়াক্ত নামাজ সময়মতো, ধীরস্থিরভাবে ও গভীর মনোযোগের সাথে আদায়ের চেষ্টা করুন।"
            ayah.banglaTranslation.contains("ধৈর্য") || ayah.banglaTranslation.contains("সবর") ->
                "কঠিন পরিস্থিতিতে অটল ধৈর্য ধারণ করুন; আল্লাহর ফয়সালায় কল্যাণ নিহিত থাকে।"
            else ->
                "ক্বারীর তিলাওয়াত শোনার পর সূরা ${meta.banglaName}-এর মূল প্রেক্ষাপট মাথায় রেখে আয়াতটি নিয়ে ভাবুন এবং আজকের জীবনে একটি বাস্তব আমল প্রয়োগ করুন।"
        }

        val surahContextEn = "Surah ${meta.number}: ${meta.englishName} (${meta.arabicName}) — ${surahAuth.periodDetailEn} • ${meta.ayahCount} Ayahs"
        val surahContextBn = "সূরা ${meta.number}: ${meta.banglaName} (${meta.arabicName}) — ${surahAuth.periodDetailBn} • ${meta.ayahCount} আয়াত"

        val deeperContextEn = buildString {
            append(surahAuth.revelationBackgroundEn)
            append("\n\n")
            append(surahAuth.propheticVirtueEn)
            if (!webContextEn.isNullOrBlank()) {
                append("\n\n").append(webContextEn)
            }
        }
        val deeperContextBn = buildString {
            append(surahAuth.revelationBackgroundBn)
            append("\n\n")
            append(surahAuth.propheticVirtueBn)
            if (!webContextEn.isNullOrBlank()) {
                append("\n\nপ্রাসঙ্গিক তথ্য (EN): ").append(webContextEn)
            }
        }

        return AyahExplanation(
            surahNumber = ayah.surahNumber,
            ayahNumber = ayah.ayahNumber,
            titleEn = "Ayah ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.englishName}",
            titleBn = "আয়াত ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.banglaName}",
            explanationEn = explanationEn,
            explanationBn = explanationBn,
            lifeLessonEn = lessonEn,
            lifeLessonBn = lessonBn,
            surahContextEn = surahContextEn,
            surahContextBn = surahContextBn,
            sourceNote = if (!webContextEn.isNullOrBlank()) {
                "${surahAuth.classicalSourceRef} + Online Context"
            } else {
                surahAuth.classicalSourceRef
            },
            deeperContextEn = deeperContextEn,
            deeperContextBn = deeperContextBn
        )
    }
}
