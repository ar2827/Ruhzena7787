package com.example.ruhzena.data.islamic

import kotlinx.serialization.Serializable

data class SurahMeta(
    val number: Int,
    val arabicName: String,
    val englishName: String,
    val englishMeaning: String,
    val banglaName: String,
    val ayahCount: Int,
    val revelationPlace: String // Meccan or Medinan
)

@Serializable
data class QuranAyah(
    val surahNumber: Int,
    val ayahNumber: Int,
    val globalNumber: Int,
    val arabicText: String,
    val englishTranslation: String,
    val banglaTranslation: String,
    val englishTransliteration: String,
    val banglaTransliteration: String
)

data class QuranReciter(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val style: String,
    val bitrate: Int = 128
) {
    fun audioUrlForGlobalAyah(globalAyahNumber: Int): String =
        "https://cdn.islamic.network/quran/audio/$bitrate/$id/$globalAyahNumber.mp3"
}

object SurahCatalog {
    val reciters = listOf(
        QuranReciter("ar.alafasy", "Mishary Rashid Alafasy", "মিশারি রশিদ আল-আফাসি", "Murattal • Kuwait", 128),
        QuranReciter("ar.abdulbasitmurattal", "Abdul Basit Abdul Samad", "আবদুল বাসিত আবদুস সামাদ", "Murattal • Egypt", 64),
        QuranReciter("ar.husary", "Mahmoud Khalil Al-Husary", "মাহমুদ খলিল আল-হুসারি", "Tajweed Clarity • Egypt", 128),
        QuranReciter("ar.minshawi", "Muhammad Siddiq Al-Minshawi", "মুহাম্মাদ সিদ্দিক আল-মিনশাভি", "Murattal • Egypt", 128),
        QuranReciter("ar.mahermuaiqly", "Maher Al-Muaiqly", "মাহের আল-মুআইকলি", "Murattal • Makkah", 128)
    )

    val allSurahs: List<SurahMeta> = listOf(
        SurahMeta(1, "الفاتحة", "Al-Fatihah", "The Opener", "আল-ফাতিহা", 7, "Meccan"),
        SurahMeta(2, "البقرة", "Al-Baqarah", "The Cow", "আল-বাকারা", 286, "Medinan"),
        SurahMeta(3, "آل عمران", "Ali 'Imran", "Family of Imran", "আলে-ইমরান", 200, "Medinan"),
        SurahMeta(4, "النساء", "An-Nisa", "The Women", "আন-নিসা", 176, "Medinan"),
        SurahMeta(5, "المائدة", "Al-Ma'idah", "The Table Spread", "আল-মায়িদা", 120, "Medinan"),
        SurahMeta(6, "الأنعام", "Al-An'am", "The Cattle", "আল-আনআম", 165, "Meccan"),
        SurahMeta(7, "الأعراف", "Al-A'raf", "The Heights", "আল-আরাফ", 206, "Meccan"),
        SurahMeta(8, "الأنفال", "Al-Anfal", "The Spoils of War", "আল-আনফাল", 75, "Medinan"),
        SurahMeta(9, "التوبة", "At-Tawbah", "The Repentance", "আত-তাওবা", 129, "Medinan"),
        SurahMeta(10, "يونس", "Yunus", "Jonah", "ইউনুস", 109, "Meccan"),
        SurahMeta(11, "هود", "Hud", "Hud", "হুদ", 123, "Meccan"),
        SurahMeta(12, "يوسف", "Yusuf", "Joseph", "ইউসুফ", 111, "Meccan"),
        SurahMeta(13, "الرعد", "Ar-Ra'd", "The Thunder", "আর-রাদ", 43, "Medinan"),
        SurahMeta(14, "إبراهيم", "Ibrahim", "Abraham", "ইবরাহিম", 52, "Meccan"),
        SurahMeta(15, "الحجر", "Al-Hijr", "The Rocky Tract", "আল-হিজর", 99, "Meccan"),
        SurahMeta(16, "النحل", "An-Nahl", "The Bee", "আন-নাহল", 128, "Meccan"),
        SurahMeta(17, "الإسراء", "Al-Isra", "The Night Journey", "বনী ইসরাইল", 111, "Meccan"),
        SurahMeta(18, "الكهف", "Al-Kahf", "The Cave", "আল-কাহফ", 110, "Meccan"),
        SurahMeta(19, "مريم", "Maryam", "Mary", "মারইয়াম", 98, "Meccan"),
        SurahMeta(20, "طه", "Taha", "Ta-Ha", "ত্বা-হা", 135, "Meccan"),
        SurahMeta(21, "الأنبياء", "Al-Anbya", "The Prophets", "আল-আম্বিয়া", 112, "Meccan"),
        SurahMeta(22, "الحج", "Al-Hajj", "The Pilgrimage", "আল-হাজ্জ", 78, "Medinan"),
        SurahMeta(23, "المؤمنون", "Al-Mu'minun", "The Believers", "আল-মুমিনুন", 118, "Meccan"),
        SurahMeta(24, "النور", "An-Nur", "The Light", "আন-নূর", 64, "Medinan"),
        SurahMeta(25, "الفرقان", "Al-Furqan", "The Criterion", "আল-ফুরকান", 77, "Meccan"),
        SurahMeta(26, "الشعراء", "Ash-Shu'ara", "The Poets", "আশ-শুআরা", 227, "Meccan"),
        SurahMeta(27, "النمل", "An-Naml", "The Ant", "আন-নামল", 93, "Meccan"),
        SurahMeta(28, "القصص", "Al-Qasas", "The Stories", "আল-কাসাস", 88, "Meccan"),
        SurahMeta(29, "العنكبوت", "Al-'Ankabut", "The Spider", "আল-আনকাবুত", 69, "Meccan"),
        SurahMeta(30, "الروم", "Ar-Rum", "The Romans", "আর-রূম", 60, "Meccan"),
        SurahMeta(31, "لقمان", "Luqman", "Luqman", "লুকমান", 34, "Meccan"),
        SurahMeta(32, "السجدة", "As-Sajdah", "The Prostration", "আস-সাজদা", 30, "Meccan"),
        SurahMeta(33, "الأحزاب", "Al-Ahzab", "The Combined Forces", "আল-আহযাব", 73, "Medinan"),
        SurahMeta(34, "سبإ", "Saba", "Sheba", "সাবা", 54, "Meccan"),
        SurahMeta(35, "فاطر", "Fatir", "Originator", "ফাতির", 45, "Meccan"),
        SurahMeta(36, "يس", "Ya-Sin", "Ya Sin", "ইয়াসীন", 83, "Meccan"),
        SurahMeta(37, "الصافات", "As-Saffat", "Those Who Set the Ranks", "আস-সাফফাত", 182, "Meccan"),
        SurahMeta(38, "ص", "Sad", "The Letter Sad", "সোয়াদ", 88, "Meccan"),
        SurahMeta(39, "الزمر", "Az-Zumar", "The Troops", "আয-যুমার", 75, "Meccan"),
        SurahMeta(40, "غافر", "Ghafir", "The Forgiver", "গাফির", 85, "Meccan"),
        SurahMeta(41, "فصلت", "Fussilat", "Explained in Detail", "ফুসসিলাত", 54, "Meccan"),
        SurahMeta(42, "الشورى", "Ash-Shuraa", "The Consultation", "আশ-শূরা", 53, "Meccan"),
        SurahMeta(43, "الزخرف", "Az-Zukhruf", "The Ornaments of Gold", "আয-যুখরুফ", 89, "Meccan"),
        SurahMeta(44, "الدخان", "Ad-Dukhan", "The Smoke", "আদ-দুখান", 59, "Meccan"),
        SurahMeta(45, "الجاثية", "Al-Jathiyah", "The Crouching", "আল-জাসিয়া", 37, "Meccan"),
        SurahMeta(46, "الأحقاف", "Al-Ahqaf", "The Wind-Curved Sandhills", "আল-আহকাফ", 35, "Meccan"),
        SurahMeta(47, "محمد", "Muhammad", "Muhammad", "মুহাম্মাদ", 38, "Medinan"),
        SurahMeta(48, "الفتح", "Al-Fath", "The Victory", "আল-ফাতহ", 29, "Medinan"),
        SurahMeta(49, "الحجرات", "Al-Hujurat", "The Rooms", "আল-হুজুরাত", 18, "Medinan"),
        SurahMeta(50, "ق", "Qaf", "The Letter Qaf", "ক্বাফ", 45, "Meccan"),
        SurahMeta(51, "الذاريات", "Adh-Dhariyat", "The Winnowing Winds", "আয-যারিয়াত", 60, "Meccan"),
        SurahMeta(52, "الطور", "At-Tur", "The Mount", "আত-তূর", 49, "Meccan"),
        SurahMeta(53, "النجم", "An-Najm", "The Star", "আন-নাজম", 62, "Meccan"),
        SurahMeta(54, "القمر", "Al-Qamar", "The Moon", "আল-ক্বামার", 55, "Meccan"),
        SurahMeta(55, "الرحمن", "Ar-Rahman", "The Beneficent", "আর-রহমান", 78, "Medinan"),
        SurahMeta(56, "الواقعة", "Al-Waqi'ah", "The Inevitable", "আল-ওয়াকিয়া", 96, "Meccan"),
        SurahMeta(57, "الحديد", "Al-Hadid", "The Iron", "আল-হাদীদ", 29, "Medinan"),
        SurahMeta(58, "المجادلة", "Al-Mujadila", "The Pleading Woman", "আল-মুজাদিলা", 22, "Medinan"),
        SurahMeta(59, "الحشر", "Al-Hashr", "The Exile", "আল-হাশর", 24, "Medinan"),
        SurahMeta(60, "الممتحنة", "Al-Mumtahanah", "She That Is to Be Examined", "আল-মুমতাহিনা", 13, "Medinan"),
        SurahMeta(61, "الصف", "As-Saf", "The Ranks", "আস-সাফ", 14, "Medinan"),
        SurahMeta(62, "الجمعة", "Al-Jumu'ah", "The Congregation", "আল-জুমুআ", 11, "Medinan"),
        SurahMeta(63, "المنافقون", "Al-Munafiqun", "The Hypocrites", "আল-মুনাফিকুন", 11, "Medinan"),
        SurahMeta(64, "التغابن", "At-Taghabun", "The Mutual Disillusion", "আত-তাগাবুন", 18, "Medinan"),
        SurahMeta(65, "الطلاق", "At-Talaq", "The Divorce", "আত-তালাক", 12, "Medinan"),
        SurahMeta(66, "التحريم", "At-Tahrim", "The Prohibition", "আত-তাহরীম", 12, "Medinan"),
        SurahMeta(67, "الملك", "Al-Mulk", "The Sovereignty", "আল-মুলক", 30, "Meccan"),
        SurahMeta(68, "القلم", "Al-Qalam", "The Pen", "আল-কলম", 52, "Meccan"),
        SurahMeta(69, "الحاقة", "Al-Haqqah", "The Reality", "আল-হাক্কাহ", 52, "Meccan"),
        SurahMeta(70, "المعارج", "Al-Ma'arij", "The Ascending Stairways", "আল-মাআরিজ", 44, "Meccan"),
        SurahMeta(71, "نوح", "Nuh", "Noah", "নূহ", 28, "Meccan"),
        SurahMeta(72, "الجن", "Al-Jinn", "The Jinn", "আল-জিন", 28, "Meccan"),
        SurahMeta(73, "المزمل", "Al-Muzzammil", "The Enshrouded One", "আল-মুযযাম্মিল", 20, "Meccan"),
        SurahMeta(74, "المدثر", "Al-Muddaththir", "The Cloaked One", "আল-মুদ্দাসসির", 56, "Meccan"),
        SurahMeta(75, "القيامة", "Al-Qiyamah", "The Resurrection", "আল-কিয়ামাহ", 40, "Meccan"),
        SurahMeta(76, "الانسان", "Al-Insan", "The Man", "আল-ইনসান", 31, "Medinan"),
        SurahMeta(77, "المرسلات", "Al-Mursalat", "The Emissaries", "আল-মুরসালাত", 50, "Meccan"),
        SurahMeta(78, "النبإ", "An-Naba", "The Tidings", "আন-নাবা", 40, "Meccan"),
        SurahMeta(79, "النازعات", "An-Nazi'at", "Those Who Drag Forth", "আন-নাযিয়াত", 46, "Meccan"),
        SurahMeta(80, "عبس", "'Abasa", "He Frowned", "আবাসা", 42, "Meccan"),
        SurahMeta(81, "التكوير", "At-Takwir", "The Overthrowing", "আত-তাকভীর", 29, "Meccan"),
        SurahMeta(82, "الإنفطار", "Al-Infitar", "The Cleaving", "আল-ইনফিতার", 19, "Meccan"),
        SurahMeta(83, "المطففين", "Al-Mutaffifin", "The Defrauding", "আল-মুতাফফিফীন", 36, "Meccan"),
        SurahMeta(84, "الإنشقاق", "Al-Inshiqaq", "The Sundering", "আল-ইনশিকাক", 25, "Meccan"),
        SurahMeta(85, "البروج", "Al-Buruj", "The Mansions of the Stars", "আল-বুরূজ", 22, "Meccan"),
        SurahMeta(86, "الطارق", "At-Tariq", "The Nightcommer", "আত-তারিক", 17, "Meccan"),
        SurahMeta(87, "الأعلى", "Al-A'la", "The Most High", "আল-আ'লা", 19, "Meccan"),
        SurahMeta(88, "الغاشية", "Al-Ghashiyah", "The Overwhelming", "আল-গাশিয়াহ", 26, "Meccan"),
        SurahMeta(89, "الفجر", "Al-Fajr", "The Dawn", "আল-ফজর", 30, "Meccan"),
        SurahMeta(90, "البلد", "Al-Balad", "The City", "আল-বালাদ", 20, "Meccan"),
        SurahMeta(91, "الشمس", "Ash-Shams", "The Sun", "আশ-শামস", 15, "Meccan"),
        SurahMeta(92, "الليل", "Al-Layl", "The Night", "আল-লাইল", 21, "Meccan"),
        SurahMeta(93, "الضحى", "Ad-Duhaa", "The Morning Hours", "আদ-দুহা", 11, "Meccan"),
        SurahMeta(94, "الشرح", "Ash-Sharh", "The Relief", "আল-ইনশিরাহ", 8, "Meccan"),
        SurahMeta(95, "التين", "At-Tin", "The Fig", "আত-তীন", 8, "Meccan"),
        SurahMeta(96, "العلق", "Al-'Alaq", "The Clot", "আল-আলাক", 19, "Meccan"),
        SurahMeta(97, "القدر", "Al-Qadr", "The Power", "আল-ক্বদর", 5, "Meccan"),
        SurahMeta(98, "البينة", "Al-Bayyinah", "The Clear Proof", "আল-বাইয়্যিনাহ", 8, "Medinan"),
        SurahMeta(99, "الزلزلة", "Az-Zalzalah", "The Earthquake", "আয-যিলযাল", 8, "Medinan"),
        SurahMeta(100, "العاديات", "Al-'Adiyat", "The Courser", "আল-আদিয়াত", 11, "Meccan"),
        SurahMeta(101, "القارعة", "Al-Qari'ah", "The Calamity", "আল-ক্বারিয়াহ", 11, "Meccan"),
        SurahMeta(102, "التكاثر", "At-Takathur", "The Rivalry in World Increase", "আত-তাকাসুর", 8, "Meccan"),
        SurahMeta(103, "العصر", "Al-'Asr", "The Declining Day", "আল-আসর", 3, "Meccan"),
        SurahMeta(104, "الهمزة", "Al-Humazah", "The Traducer", "আল-হুমাযাহ", 9, "Meccan"),
        SurahMeta(105, "الفيل", "Al-Fil", "The Elephant", "আল-ফীল", 5, "Meccan"),
        SurahMeta(106, "قريش", "Quraysh", "Quraysh", "কুরাইশ", 4, "Meccan"),
        SurahMeta(107, "الماعون", "Al-Ma'un", "The Small Kindnesses", "আল-মাউন", 7, "Meccan"),
        SurahMeta(108, "الكوثر", "Al-Kawthar", "The Abundance", "আল-কাউসার", 3, "Meccan"),
        SurahMeta(109, "الكافرون", "Al-Kafirun", "The Disbelievers", "আল-কাফিরূন", 6, "Meccan"),
        SurahMeta(110, "النصر", "An-Nasr", "The Divine Support", "আন-নাসর", 3, "Medinan"),
        SurahMeta(111, "المسد", "Al-Masad", "The Palm Fiber", "আল-লাহাব", 5, "Meccan"),
        SurahMeta(112, "الإخلاص", "Al-Ikhlas", "The Sincerity", "আল-ইখলাস", 4, "Meccan"),
        SurahMeta(113, "الفلق", "Al-Falaq", "The Daybreak", "আল-ফালাক", 5, "Meccan"),
        SurahMeta(114, "الناس", "An-Nas", "Mankind", "আন-নাস", 6, "Meccan")
    )

    private val globalStartOffsets: IntArray by lazy {
        val offsets = IntArray(115)
        var running = 1
        for (surah in allSurahs) {
            offsets[surah.number] = running
            running += surah.ayahCount
        }
        offsets
    }

    fun globalAyahNumber(surahNumber: Int, ayahNumber: Int): Int {
        val safeSurah = surahNumber.coerceIn(1, 114)
        return globalStartOffsets[safeSurah] + (ayahNumber - 1).coerceAtLeast(0)
    }

    fun getMeta(surahNumber: Int): SurahMeta =
        allSurahs.getOrElse((surahNumber - 1).coerceIn(0, 113)) { allSurahs.first() }
}
