package com.example.ruhzena.data.cloud

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import org.json.JSONArray
import org.json.JSONObject

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write")
}

fun buildFirestoreErrorJson(
    error: Throwable,
    operationType: OperationType,
    path: String?
): String {
    val user = runCatching { Firebase.auth.currentUser }.getOrNull()
    val providerArray = JSONArray().apply {
        user?.providerData?.forEach { info ->
            put(
                JSONObject().apply {
                    put("providerId", info.providerId)
                    put("displayName", info.displayName ?: JSONObject.NULL)
                    put("email", info.email ?: JSONObject.NULL)
                    put("photoUrl", info.photoUrl?.toString() ?: JSONObject.NULL)
                }
            )
        }
    }
    val authInfo = JSONObject().apply {
        put("userId", user?.uid ?: JSONObject.NULL)
        put("email", user?.email ?: JSONObject.NULL)
        put("emailVerified", user?.isEmailVerified ?: false)
        put("isAnonymous", user?.isAnonymous ?: false)
        put("tenantId", user?.tenantId ?: JSONObject.NULL)
        put("providerInfo", providerArray)
    }
    return JSONObject().apply {
        put("error", error.message ?: error.toString())
        put("operationType", operationType.value)
        put("path", path ?: JSONObject.NULL)
        put("authInfo", authInfo)
    }.toString()
}

fun logFirestoreError(
    error: Throwable,
    operationType: OperationType,
    path: String?
): String {
    val errJson = buildFirestoreErrorJson(error, operationType, path)
    Log.e("FirestoreError", errJson, error)
    return errJson
}

fun handleFirestoreError(
    error: Throwable,
    operationType: OperationType,
    path: String?
): Nothing {
    val errJson = logFirestoreError(error, operationType, path)
    throw IllegalStateException(errJson, error)
}
