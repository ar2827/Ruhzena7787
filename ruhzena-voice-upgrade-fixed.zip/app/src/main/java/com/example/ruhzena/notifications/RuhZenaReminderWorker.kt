package com.example.ruhzena.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.islamic.DailyPrayerSchedule
import com.example.ruhzena.data.islamic.PrayerCalcMethod
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.local.RuhZenaDatabase
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.UserPreferencesRepository
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class RuhZenaReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val type = inputData.getString(KEY_TYPE) ?: return Result.success()
        if (!RuhZenaNotificationHelper.hasNotificationPermission(applicationContext)) {
            return Result.success()
        }
        val prefs = UserPreferencesRepository(applicationContext).preferencesFlow.first()
        val isPrayer = type == TYPE_PRAYER_EXACT || type == TYPE_PRAYER

        if (System.currentTimeMillis() < prefs.mutedUntilEpochMs) {
            if (isPrayer && prefs.prayerRemindersEnabled) {
                ReminderScheduler.scheduleNextExactPrayer(applicationContext, prefs, minFutureOffsetMs = 70_000L)
            }
            return Result.success()
        }

        // Quiet hours never silence Salah Adhan
        if (!isPrayer && isWithinQuietHours(prefs)) {
            return Result.success()
        }

        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val waterTodayMl = runCatching {
            RuhZenaDatabase.getInstance(applicationContext).waterLogDao().getTotalMlForDateSnapshot(todayKey)
        }.getOrDefault(0)

        dispatchNotification(applicationContext, type, prefs, waterTodayMl)

        if (isPrayer && prefs.prayerRemindersEnabled) {
            ReminderScheduler.scheduleNextExactPrayer(applicationContext, prefs, minFutureOffsetMs = 70_000L)
        }
        return Result.success()
    }

    private fun isWithinQuietHours(prefs: UserPreferences): Boolean {
        if (!prefs.quietHoursEnabled) return false
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val start = prefs.quietStartHour
        val end = prefs.quietEndHour
        return if (start <= end) {
            hour in start until end
        } else {
            hour >= start || hour < end
        }
    }

    companion object {
        const val KEY_TYPE = "reminder_type"
        const val TYPE_WATER = "water"
        const val TYPE_ADHKAR = "adhkar"
        const val TYPE_WORKOUT = "workout"
        const val TYPE_BEDTIME = "bedtime"
        const val TYPE_LESSON = "lesson"
        const val TYPE_PRAYER = "prayer"
        const val TYPE_PRAYER_EXACT = "prayer_exact"
        const val TYPE_HOURLY_MOTIVATION = "hourly_motivation"

        fun isInRamadanDaylightFast(
            prefs: UserPreferences,
            schedule: DailyPrayerSchedule,
            now: Calendar
        ): Boolean {
            if (!prefs.ramadanModeEnabled) return false
            val nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            return nowMinutes in schedule.fajrMinutes until schedule.maghribMinutes
        }

        fun dispatchNotification(
            context: Context,
            type: String,
            prefs: UserPreferences,
            waterTodayMl: Int,
            ignoreRamadanFastSkip: Boolean = false,
            forcePreview: Boolean = false,
            exactPrayerKeyOverride: String? = null,
            exactPrayerTimeOverride: String? = null
        ) {
            val isBn = prefs.language == AppLanguage.BANGLA
            val tz = runCatching { TimeZone.getTimeZone(prefs.locationTimeZoneId) }.getOrDefault(TimeZone.getDefault())
            val now = Calendar.getInstance(tz)
            val method = PrayerCalcMethod.fromId(prefs.prayerCalcMethod)
            val asrShadow = if (prefs.asrJuristicMethod == "HANAFI") 2.0 else 1.0
            val schedule = PrayerCalculator.calculateForDate(
                latitude = prefs.latitude,
                longitude = prefs.longitude,
                method = method,
                calendar = now,
                timeZone = tz,
                asrShadowFactorOverride = asrShadow
            )
            val nextPrayer = PrayerCalculator.getNextPrayer(schedule, now)
            val hour = now.get(Calendar.HOUR_OF_DAY)

            when (type) {
                TYPE_WATER -> if (forcePreview || prefs.waterRemindersEnabled) {
                    if (!forcePreview && !ignoreRamadanFastSkip && isInRamadanDaylightFast(prefs, schedule, now)) {
                        return
                    }
                    val remaining = (prefs.hydrationGoalMl - waterTodayMl).coerceAtLeast(0)
                    val body = if (isBn) {
                        "আজ ${waterTodayMl}/${prefs.hydrationGoalMl} মি.লি. পান হয়েছে (বাকি ${remaining} মি.লি.)। সরাসরি পরিমাণ লিখুন অথবা ৫ মি. স্নুজ করুন।"
                    } else {
                        "Logged ${waterTodayMl}/${prefs.hydrationGoalMl} ml today ($remaining ml left). Tap 'Type ml' to enter your exact amount or Snooze 5m."
                    }
                    RuhZenaNotificationHelper.showNotification(
                        context = context,
                        channelId = RuhZenaNotificationHelper.CHANNEL_HYDRATION,
                        notificationId = 1001,
                        title = if (isBn) "পানি পানের রিমাইন্ডার" else "Hydration Check-In",
                        body = body,
                        reminderType = TYPE_WATER,
                        toneUri = prefs.notificationToneUri,
                        vibrationEnabled = prefs.notificationVibrationEnabled,
                        isWaterReminder = true,
                        isBn = isBn
                    )
                }

                TYPE_ADHKAR -> if (forcePreview || prefs.adhkarRemindersEnabled) {
                    val morning = hour < 13
                    RuhZenaNotificationHelper.showNotification(
                        context = context,
                        channelId = RuhZenaNotificationHelper.CHANNEL_SPIRITUAL,
                        notificationId = 1002,
                        title = if (isBn) (if (morning) "সকালের আযকার" else "সন্ধ্যার আযকার") else (if (morning) "Morning Adhkar" else "Evening Adhkar"),
                        body = if (isBn) "অন্তরের প্রশান্তির জন্য আজকের সুন্নাহ সম্মত যিকির পাঠ করুন।" else "Take 2 minutes for verified prophetic remembrances to anchor your day.",
                        reminderType = TYPE_ADHKAR,
                        toneUri = prefs.notificationToneUri,
                        vibrationEnabled = prefs.notificationVibrationEnabled,
                        isBn = isBn
                    )
                }

                TYPE_WORKOUT -> if (forcePreview || prefs.workoutRemindersEnabled) {
                    RuhZenaNotificationHelper.showNotification(
                        context = context,
                        channelId = RuhZenaNotificationHelper.CHANNEL_WELLNESS,
                        notificationId = 1003,
                        title = if (isBn) "ব্যায়াম ও শরীরচর্চা" else "Movement & Strength Session",
                        body = if (isBn) "আপনার ব্যক্তিগত হোম ওয়ার্কআউট শুরু করতে প্রস্তুত?" else "Ready for your personalized home movement routine?",
                        reminderType = TYPE_WORKOUT,
                        toneUri = prefs.notificationToneUri,
                        vibrationEnabled = prefs.notificationVibrationEnabled,
                        isBn = isBn
                    )
                }

                TYPE_BEDTIME -> if (forcePreview || prefs.bedtimeRemindersEnabled) {
                    RuhZenaNotificationHelper.showNotification(
                        context = context,
                        channelId = RuhZenaNotificationHelper.CHANNEL_WELLNESS,
                        notificationId = 1004,
                        title = if (isBn) "ঘুমানোর প্রস্তুতি" else "Wind-Down & Bedtime Sunnah",
                        body = if (isBn) "স্ক্রিন থেকে দূরে সরে ঘুমানোর পূর্বে সুন্নাহ দুআ পাঠ করুন।" else "Dim screens, recite Bedtime Adhkar, and prepare for restorative rest.",
                        reminderType = TYPE_BEDTIME,
                        toneUri = prefs.notificationToneUri,
                        vibrationEnabled = prefs.notificationVibrationEnabled,
                        isBn = isBn
                    )
                }

                TYPE_LESSON -> if (forcePreview || prefs.lessonRemindersEnabled) {
                    RuhZenaNotificationHelper.showNotification(
                        context = context,
                        channelId = RuhZenaNotificationHelper.CHANNEL_SPIRITUAL,
                        notificationId = 1005,
                        title = if (isBn) "আজকের প্রামাণিক শিক্ষা" else "Daily Islamic Reflection",
                        body = if (isBn) "রূহযেনায় আজকের কুরআন ও সহীহ হাদিসের সংক্ষিপ্ত শিক্ষা দেখুন।" else "Explore today's sourced Quranic & Hadith reflection in RuhZena.",
                        reminderType = TYPE_LESSON,
                        toneUri = prefs.notificationToneUri,
                        vibrationEnabled = prefs.notificationVibrationEnabled,
                        isBn = isBn
                    )
                }

                TYPE_PRAYER, TYPE_PRAYER_EXACT -> if (forcePreview || prefs.prayerRemindersEnabled) {
                    val activeKey = exactPrayerKeyOverride ?: nextPrayer.prayerKey
                    val activeTime = exactPrayerTimeOverride ?: nextPrayer.timeFormatted
                    val pLabel = localizedPrayerName(activeKey, isBn)
                    val title = if (isBn) "$pLabel-এর আযান ($activeTime)" else "$pLabel Adhan • $activeTime"
                    val body = if (isBn) {
                        "${prefs.locationName} অনুযায়ী এখন $pLabel নামাজের ওয়াক্ত হয়েছে। আল্লাহু আকবার — নামাজের জন্য প্রস্তুত হোন।"
                    } else {
                        "It is now time for $pLabel prayer in ${prefs.locationName} ($activeTime). Hayya 'alas-Salah."
                    }
                    RuhZenaNotificationHelper.showNotification(
                        context = context,
                        channelId = RuhZenaNotificationHelper.CHANNEL_PRAYER,
                        notificationId = 1006,
                        title = title,
                        body = body,
                        reminderType = TYPE_PRAYER_EXACT,
                        toneUri = prefs.notificationToneUri,
                        vibrationEnabled = prefs.notificationVibrationEnabled,
                        isBn = isBn
                    )
                }

                TYPE_HOURLY_MOTIVATION -> if (forcePreview || prefs.hourlyMotivationEnabled) {
                    val insight = MotivationKnowledgeCatalog.forHour(hour)
                    val title = if (isBn) {
                        "ঘণ্টাভিত্তিক হিকমাহ • ${insight.themeBn}"
                    } else {
                        "Hourly Hikmah • ${insight.themeEn}"
                    }
                    val body = if (isBn) {
                        "${insight.motivationBn}\n\n${insight.knowledgeBn} (${insight.reference})"
                    } else {
                        "${insight.motivationEn}\n\n${insight.knowledgeEn} (${insight.reference})"
                    }
                    RuhZenaNotificationHelper.showNotification(
                        context = context,
                        channelId = RuhZenaNotificationHelper.CHANNEL_MOTIVATION,
                        notificationId = 1007,
                        title = title,
                        body = body,
                        reminderType = TYPE_HOURLY_MOTIVATION,
                        toneUri = prefs.notificationToneUri,
                        vibrationEnabled = prefs.notificationVibrationEnabled,
                        isBn = isBn
                    )
                }
            }
        }

        private fun localizedPrayerName(key: String, isBn: Boolean): String = when (key) {
            "FAJR" -> if (isBn) "ফজর" else "Fajr"
            "DHUHR" -> if (isBn) "যোহর" else "Dhuhr"
            "ASR" -> if (isBn) "আসর" else "Asr"
            "MAGHRIB" -> if (isBn) "মাগরিব" else "Maghrib"
            "ISHA" -> if (isBn) "ইশা" else "Isha"
            else -> key
        }
    }
}

object ReminderScheduler {
    private const val DEDUP_PREFS = "ruhzena_notif_dedup"

    private const val REQ_PRAYER = 7001
    private const val REQ_WATER = 7002
    private const val REQ_ADHKAR = 7003
    private const val REQ_WORKOUT = 7004
    private const val REQ_BEDTIME = 7005
    private const val REQ_LESSON = 7006
    private const val REQ_HOURLY = 7007

    fun syncSchedules(context: Context, prefs: UserPreferences) {
        val appCtx = context.applicationContext
        val wm = runCatching { WorkManager.getInstance(appCtx) }.getOrNull()

        // Always cancel legacy periodic/repeating WorkManager prayer & reminder jobs so there is
        // ZERO 10-15 minute duplicate spam — AlarmManager now owns exact-time delivery!
        wm?.cancelUniqueWork("ruhzena_prayer")
        wm?.cancelUniqueWork("ruhzena_next_prayer_exact")
        wm?.cancelUniqueWork("ruhzena_water")
        wm?.cancelUniqueWork("ruhzena_adhkar")
        wm?.cancelUniqueWork("ruhzena_workout")
        wm?.cancelUniqueWork("ruhzena_bedtime")
        wm?.cancelUniqueWork("ruhzena_lesson")
        wm?.cancelUniqueWork("ruhzena_hourly_motivation")

        if (!RuhZenaNotificationHelper.hasNotificationPermission(appCtx)) {
            cancelAllExactAlarms(appCtx)
            return
        }

        if (prefs.prayerRemindersEnabled) {
            scheduleNextExactPrayer(appCtx, prefs, minFutureOffsetMs = 20_000L)
        } else {
            cancelExactAlarm(appCtx, REQ_PRAYER, RuhZenaReminderWorker.TYPE_PRAYER_EXACT)
        }

        if (prefs.waterRemindersEnabled) {
            scheduleNextWaterAlarm(appCtx, minDelayMinutes = 120L)
        } else {
            cancelExactAlarm(appCtx, REQ_WATER, RuhZenaReminderWorker.TYPE_WATER)
        }

        if (prefs.adhkarRemindersEnabled) {
            scheduleNextDailyAlarm(appCtx, RuhZenaReminderWorker.TYPE_ADHKAR, listOf(6 to 30, 17 to 30), minDelayMinutes = 10L)
        } else {
            cancelExactAlarm(appCtx, REQ_ADHKAR, RuhZenaReminderWorker.TYPE_ADHKAR)
        }

        if (prefs.workoutRemindersEnabled) {
            scheduleNextDailyAlarm(appCtx, RuhZenaReminderWorker.TYPE_WORKOUT, listOf(18 to 0), minDelayMinutes = 10L)
        } else {
            cancelExactAlarm(appCtx, REQ_WORKOUT, RuhZenaReminderWorker.TYPE_WORKOUT)
        }

        if (prefs.bedtimeRemindersEnabled) {
            scheduleNextDailyAlarm(appCtx, RuhZenaReminderWorker.TYPE_BEDTIME, listOf(22 to 0), minDelayMinutes = 10L)
        } else {
            cancelExactAlarm(appCtx, REQ_BEDTIME, RuhZenaReminderWorker.TYPE_BEDTIME)
        }

        if (prefs.lessonRemindersEnabled) {
            scheduleNextDailyAlarm(appCtx, RuhZenaReminderWorker.TYPE_LESSON, listOf(20 to 0), minDelayMinutes = 10L)
        } else {
            cancelExactAlarm(appCtx, REQ_LESSON, RuhZenaReminderWorker.TYPE_LESSON)
        }

        if (prefs.hourlyMotivationEnabled) {
            scheduleNextHourlyHikmahAlarm(appCtx)
        } else {
            cancelExactAlarm(appCtx, REQ_HOURLY, RuhZenaReminderWorker.TYPE_HOURLY_MOTIVATION)
        }
    }

    fun scheduleSnooze(context: Context, reminderType: String, delayMinutes: Long = 5L) {
        val wm = runCatching { WorkManager.getInstance(context) }.getOrNull() ?: return
        val request = OneTimeWorkRequestBuilder<RuhZenaReminderWorker>()
            .addTag("ruhzena_reminder_snooze")
            .setInitialDelay(delayMinutes.coerceAtLeast(1L), TimeUnit.MINUTES)
            .setInputData(workDataOf(RuhZenaReminderWorker.KEY_TYPE to reminderType))
            .build()
        wm.enqueueUniqueWork("ruhzena_snooze_$reminderType", ExistingWorkPolicy.REPLACE, request)
    }

    /**
     * Schedules the next Salah Adhan at its EXACT calculated minute (never 10–15 min early,
     * never repeating in a 5-min loop). Checks all 5 prayers today, and if all have passed,
     * calculates tomorrow's exact Fajr timestamp.
     */
    fun scheduleNextExactPrayer(
        context: Context,
        prefs: UserPreferences,
        minFutureOffsetMs: Long = 20_000L
    ) {
        val appCtx = context.applicationContext
        val tz = runCatching { TimeZone.getTimeZone(prefs.locationTimeZoneId) }.getOrDefault(TimeZone.getDefault())
        val nowMs = System.currentTimeMillis()
        val thresholdMs = nowMs + minFutureOffsetMs
        val method = PrayerCalcMethod.fromId(prefs.prayerCalcMethod)
        val asrShadow = if (prefs.asrJuristicMethod == "HANAFI") 2.0 else 1.0

        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }

        // Check today (offset 0) and tomorrow (offset 1) to find the exact next Adhan > thresholdMs
        for (dayOffset in 0..1) {
            val dayCal = Calendar.getInstance(tz).apply {
                timeInMillis = nowMs
                add(Calendar.DAY_OF_YEAR, dayOffset)
            }
            val schedule = PrayerCalculator.calculateForDate(
                latitude = prefs.latitude,
                longitude = prefs.longitude,
                method = method,
                calendar = dayCal,
                timeZone = tz,
                asrShadowFactorOverride = asrShadow
            )
            val dateKey = dayFmt.format(dayCal.time)
            val slots = listOf(
                "FAJR" to schedule.fajrMinutes,
                "DHUHR" to schedule.dhuhrMinutes,
                "ASR" to schedule.asrMinutes,
                "MAGHRIB" to schedule.maghribMinutes,
                "ISHA" to schedule.ishaMinutes
            )
            for ((prayerKey, totalMinutes) in slots) {
                val eventKey = "${dateKey}_$prayerKey"
                if (hasAlreadyFiredEvent(appCtx, RuhZenaReminderWorker.TYPE_PRAYER_EXACT, eventKey)) {
                    continue
                }
                val triggerCal = Calendar.getInstance(tz).apply {
                    timeInMillis = dayCal.timeInMillis
                    set(Calendar.HOUR_OF_DAY, (totalMinutes / 60).coerceIn(0, 23))
                    set(Calendar.MINUTE, (totalMinutes % 60).coerceIn(0, 59))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val triggerMs = triggerCal.timeInMillis
                if (triggerMs > thresholdMs) {
                    val formattedTime = PrayerCalculator.formatMinutes(totalMinutes)
                    scheduleAlarm(
                        context = appCtx,
                        requestCode = REQ_PRAYER,
                        triggerAtMillis = triggerMs,
                        type = RuhZenaReminderWorker.TYPE_PRAYER_EXACT,
                        eventKey = eventKey,
                        prayerKey = prayerKey,
                        prayerTime = formattedTime
                    )
                    return
                }
            }
        }
    }

    fun scheduleNextWaterAlarm(context: Context, minDelayMinutes: Long = 120L) {
        val nowMs = System.currentTimeMillis()
        val triggerMs = nowMs + minDelayMinutes.coerceAtLeast(60L) * 60_000L
        val eventKey = "water_${triggerMs / (60 * 60_000L)}"
        scheduleAlarm(
            context = context.applicationContext,
            requestCode = REQ_WATER,
            triggerAtMillis = triggerMs,
            type = RuhZenaReminderWorker.TYPE_WATER,
            eventKey = eventKey
        )
    }

    fun scheduleNextHourlyHikmahAlarm(context: Context) {
        val cal = Calendar.getInstance().apply {
            add(Calendar.HOUR_OF_DAY, 1)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        // Ensure at least 15 minutes from now so opening the app right before :00 doesn't surprise immediately
        if (cal.timeInMillis - System.currentTimeMillis() < 15 * 60_000L) {
            cal.add(Calendar.HOUR_OF_DAY, 1)
        }
        val keyFmt = SimpleDateFormat("yyyy-MM-dd_HH", Locale.US)
        scheduleAlarm(
            context = context.applicationContext,
            requestCode = REQ_HOURLY,
            triggerAtMillis = cal.timeInMillis,
            type = RuhZenaReminderWorker.TYPE_HOURLY_MOTIVATION,
            eventKey = "hikmah_${keyFmt.format(cal.time)}"
        )
    }

    fun scheduleNextDailyAlarm(
        context: Context,
        type: String,
        targets: List<Pair<Int, Int>>,
        minDelayMinutes: Long = 10L
    ) {
        val nowMs = System.currentTimeMillis()
        val thresholdMs = nowMs + minDelayMinutes * 60_000L
        var bestMs = Long.MAX_VALUE
        for (dayOffset in 0..1) {
            for ((hour, minute) in targets) {
                val cal = Calendar.getInstance().apply {
                    timeInMillis = nowMs
                    add(Calendar.DAY_OF_YEAR, dayOffset)
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (cal.timeInMillis > thresholdMs && cal.timeInMillis < bestMs) {
                    bestMs = cal.timeInMillis
                }
            }
        }
        if (bestMs == Long.MAX_VALUE) return
        val reqCode = when (type) {
            RuhZenaReminderWorker.TYPE_ADHKAR -> REQ_ADHKAR
            RuhZenaReminderWorker.TYPE_WORKOUT -> REQ_WORKOUT
            RuhZenaReminderWorker.TYPE_BEDTIME -> REQ_BEDTIME
            RuhZenaReminderWorker.TYPE_LESSON -> REQ_LESSON
            else -> REQ_ADHKAR
        }
        val keyFmt = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US)
        scheduleAlarm(
            context = context.applicationContext,
            requestCode = reqCode,
            triggerAtMillis = bestMs,
            type = type,
            eventKey = "${type}_${keyFmt.format(Date(bestMs))}"
        )
    }

    private fun scheduleAlarm(
        context: Context,
        requestCode: Int,
        triggerAtMillis: Long,
        type: String,
        eventKey: String,
        prayerKey: String = "",
        prayerTime: String = ""
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, RuhZenaExactAlarmReceiver::class.java).apply {
            action = RuhZenaExactAlarmReceiver.ACTION_EXACT_REMINDER
            putExtra(RuhZenaExactAlarmReceiver.EXTRA_REMINDER_TYPE, type)
            putExtra(RuhZenaExactAlarmReceiver.EXTRA_EVENT_KEY, eventKey)
            if (prayerKey.isNotBlank()) putExtra(RuhZenaExactAlarmReceiver.EXTRA_PRAYER_KEY, prayerKey)
            if (prayerTime.isNotBlank()) putExtra(RuhZenaExactAlarmReceiver.EXTRA_PRAYER_TIME, prayerTime)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        runCatching {
            val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()
            if (canExact) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        }
    }

    private fun cancelExactAlarm(context: Context, requestCode: Int, type: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, RuhZenaExactAlarmReceiver::class.java).apply {
            action = RuhZenaExactAlarmReceiver.ACTION_EXACT_REMINDER
            putExtra(RuhZenaExactAlarmReceiver.EXTRA_REMINDER_TYPE, type)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            alarmManager.cancel(pi)
            pi.cancel()
        }
    }

    private fun cancelAllExactAlarms(context: Context) {
        cancelExactAlarm(context, REQ_PRAYER, RuhZenaReminderWorker.TYPE_PRAYER_EXACT)
        cancelExactAlarm(context, REQ_WATER, RuhZenaReminderWorker.TYPE_WATER)
        cancelExactAlarm(context, REQ_ADHKAR, RuhZenaReminderWorker.TYPE_ADHKAR)
        cancelExactAlarm(context, REQ_WORKOUT, RuhZenaReminderWorker.TYPE_WORKOUT)
        cancelExactAlarm(context, REQ_BEDTIME, RuhZenaReminderWorker.TYPE_BEDTIME)
        cancelExactAlarm(context, REQ_LESSON, RuhZenaReminderWorker.TYPE_LESSON)
        cancelExactAlarm(context, REQ_HOURLY, RuhZenaReminderWorker.TYPE_HOURLY_MOTIVATION)
    }

    fun hasAlreadyFiredEvent(context: Context, type: String, eventKey: String): Boolean {
        if (eventKey.isBlank()) return false
        val prefs = context.getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
        return prefs.getString("last_event_$type", "") == eventKey
    }

    fun isWithinCooldown(context: Context, type: String): Boolean {
        val prefs = context.getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
        val lastMs = prefs.getLong("last_ts_$type", 0L)
        val cooldownMs = when (type) {
            RuhZenaReminderWorker.TYPE_PRAYER_EXACT, RuhZenaReminderWorker.TYPE_PRAYER -> 30 * 60_000L
            RuhZenaReminderWorker.TYPE_HOURLY_MOTIVATION -> 50 * 60_000L
            RuhZenaReminderWorker.TYPE_WATER -> 100 * 60_000L
            else -> 60 * 60_000L
        }
        return (System.currentTimeMillis() - lastMs) < cooldownMs
    }

    fun markEventFired(context: Context, type: String, eventKey: String) {
        val prefs = context.getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putLong("last_ts_$type", System.currentTimeMillis())
            .apply {
                if (eventKey.isNotBlank()) putString("last_event_$type", eventKey)
            }
            .apply()
    }
}
