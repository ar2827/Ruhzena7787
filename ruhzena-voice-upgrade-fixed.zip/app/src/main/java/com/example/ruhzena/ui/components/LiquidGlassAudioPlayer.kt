package com.example.ruhzena.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.QuranReciter
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.media.AudioPlaybackState
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette

private fun formatAudioClock(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%d:%02d".format(min, sec)
}

private fun formatCountdownSec(sec: Int): String {
    val s = sec.coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LiquidGlassAudioPlayerBar(
    state: AudioPlaybackState,
    onTogglePlayPause: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onJumpToAyah: (Int) -> Unit,
    onSelectReciter: (QuranReciter) -> Unit,
    onRepeatAyah: () -> Unit,
    onRepeatSurah: () -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSeek: (Long) -> Unit,
    onSetVolume: (Float) -> Unit,
    onSetSleepTimerMinutes: (Int) -> Unit,
    onSetSleepAtEndOfSurah: () -> Unit,
    onCancelSleepTimer: () -> Unit,
    onOpenHifzDialog: (() -> Unit)? = null,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val meta = if (!state.isDhikrMode && state.activeSurahNumber > 0) SurahCatalog.getMeta(state.activeSurahNumber) else null
    var showFullSheet by rememberSaveable { mutableStateOf(false) }

    val titleLine = if (state.isDhikrMode || meta == null) {
        state.activeTitle.ifBlank { if (isBn) "মানব কণ্ঠে তিলাওয়াত" else "Human Recitation" }
    } else {
        "${if (isBn) meta.banglaName else meta.englishName} • ${strings.ayahsLabel} ${state.currentAyahNumber}/${state.totalAyahs}"
    }
    val subtitleLine = when {
        state.errorMessage != null -> state.errorMessage
        state.isHifzGapPause -> if (isBn) "হিফজ বিরতি চলছে..." else "Hifz memory pause..."
        state.isDhikrMode -> state.activeSubtitle.ifBlank { if (isBn) state.reciter.nameBn else state.reciter.nameEn }
        else -> if (isBn) state.reciter.nameBn else state.reciter.nameEn
    }
    val progressFrac = if (state.durationMs > 0L) (state.positionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    // Floating Liquid Glass Mini-Bar
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        palette.cardElevatedBg.copy(alpha = 0.96f),
                        palette.surfaceBg.copy(alpha = 0.94f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(palette.borderAccent, palette.gold.copy(alpha = 0.45f))
                ),
                shape = RoundedCornerShape(22.dp)
            )
            .clickable { showFullSheet = true }
            .testTag("persistent_audio_player")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Live Animated Waveform Equalizer Badge
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(palette.accentContainer)
                    .border(0.8.dp, palette.borderAccent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                LiveWaveformBars(
                    isPlaying = state.isPlaying,
                    barColor = palette.accentSoft,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = titleLine,
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (state.sleepTimerRemainingSec > 0 || state.sleepStopAtEndOfSurah) {
                        Icon(
                            Icons.Default.Bedtime,
                            contentDescription = "Sleep Timer Active",
                            tint = palette.gold,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
                Text(
                    text = subtitleLine,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (state.errorMessage != null) palette.coral else palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (!state.isDhikrMode) {
                IconButton(onClick = onPrev, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous Ayah", tint = palette.textPrimary)
                }
            }

            IconButton(
                onClick = onTogglePlayPause,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(palette.accentPrimary)
                    .testTag("audio_play_pause_button")
            ) {
                if (state.isBuffering) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = palette.onAccent, strokeWidth = 2.dp)
                } else {
                    Icon(
                        imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (state.isPlaying) "Pause" else "Play",
                        tint = palette.onAccent,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            if (!state.isDhikrMode) {
                IconButton(onClick = onNext, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next Ayah", tint = palette.textPrimary)
                }
            }

            IconButton(
                onClick = { showFullSheet = true },
                modifier = Modifier.size(34.dp).testTag("audio_expand_sheet_button")
            ) {
                Icon(Icons.Default.ExpandLess, contentDescription = "Expand Audio Player", tint = palette.gold)
            }

            IconButton(onClick = onClose, modifier = Modifier.size(32.dp).testTag("audio_close_button")) {
                Icon(Icons.Default.Close, contentDescription = "Close Audio", tint = palette.textMuted, modifier = Modifier.size(18.dp))
            }
        }

        // Thin luminous progress hairline along bottom edge of mini-bar
        LinearProgressIndicator(
            progress = { progressFrac },
            modifier = Modifier
                .fillMaxWidth()
                .height(2.5.dp),
            color = palette.accentSoft,
            trackColor = palette.blockBg
        )
    }

    // Maxed-Out Full-Screen Liquid Glass Now Playing Modal Sheet
    if (showFullSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var reciterMenuExpanded by remember { mutableStateOf(false) }
        var reciterQuery by remember { mutableStateOf("") }
        val filteredReciters = remember(reciterQuery) {
            val q = reciterQuery.trim().lowercase()
            if (q.isEmpty()) SurahCatalog.reciters
            else SurahCatalog.reciters.filter {
                it.nameEn.lowercase().contains(q) || it.nameBn.lowercase().contains(q) || it.style.lowercase().contains(q)
            }
        }

        ModalBottomSheet(
            onDismissRequest = { showFullSheet = false },
            sheetState = sheetState,
            containerColor = palette.surfaceBg,
            contentColor = palette.textPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 40.dp)
                    .testTag("audio_now_playing_sheet"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top Sheet Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(
                        label = when {
                            state.isHifzMode -> if (isBn) "হিফজ লুপ মোড (${state.hifzRepeatIndex}/${state.hifzTotalRepeats})" else "Hifz Loop (${state.hifzRepeatIndex}/${state.hifzTotalRepeats})"
                            state.isDhikrMode -> if (isBn) "যিকির ও দুআ অডিও" else "Dhikr & Dua Audio"
                            else -> if (isBn) "কুরআন তিলাওয়াত স্টুডিও" else "Quran Recitation Studio"
                        },
                        accentColor = palette.gold
                    )
                    IconButton(onClick = { showFullSheet = false }) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Minimize", tint = palette.textSecondary)
                    }
                }

                // Hero Surah / Medallion Artwork Card
                GlassCard(accentBorder = true, elevated = true, cornerRadius = 24.dp) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (meta != null) {
                            Text(
                                text = meta.arabicName,
                                style = MaterialTheme.typography.displaySmall.copy(
                                    fontFamily = ArabicFontFamily,
                                    textDirection = TextDirection.Rtl
                                ),
                                color = palette.gold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                        Text(
                            text = titleLine,
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = subtitleLine,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.accentSoft
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        LiveWaveformBars(
                            isPlaying = state.isPlaying,
                            barColor = palette.gold,
                            barCount = 12,
                            modifier = Modifier
                                .fillMaxWidth(0.62f)
                                .height(34.dp)
                        )
                    }
                }

                // Timeline Scrubber
                Column(modifier = Modifier.fillMaxWidth()) {
                    val maxDur = state.durationMs.coerceAtLeast(1000L).toFloat()
                    Slider(
                        value = state.positionMs.coerceIn(0L, state.durationMs.coerceAtLeast(1000L)).toFloat(),
                        onValueChange = { onSeek(it.toLong()) },
                        valueRange = 0f..maxDur,
                        colors = SliderDefaults.colors(
                            thumbColor = palette.accentSoft,
                            activeTrackColor = palette.accentPrimary,
                            inactiveTrackColor = palette.blockBg
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("audio_seek_slider")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatAudioClock(state.positionMs),
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = palette.textMuted
                        )
                        Text(
                            text = formatAudioClock(state.durationMs),
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = palette.textMuted
                        )
                    }
                }

                // Primary Transport Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onRepeatAyah,
                        modifier = Modifier.size(48.dp).testTag("audio_repeat_ayah_button")
                    ) {
                        Icon(
                            Icons.Default.RepeatOne,
                            contentDescription = "Repeat Ayah",
                            tint = if (state.repeatAyah) palette.accentSoft else palette.textMuted
                        )
                    }

                    if (!state.isDhikrMode) {
                        IconButton(onClick = onPrev, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Previous Ayah", tint = palette.textPrimary, modifier = Modifier.size(32.dp))
                        }
                    }

                    IconButton(
                        onClick = onTogglePlayPause,
                        modifier = Modifier
                            .size(66.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(palette.accentSoft, palette.accentPrimary)))
                            .border(1.4.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                            .testTag("audio_sheet_play_pause")
                    ) {
                        if (state.isBuffering) {
                            CircularProgressIndicator(modifier = Modifier.size(26.dp), color = palette.onAccent, strokeWidth = 2.5.dp)
                        } else {
                            Icon(
                                imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (state.isPlaying) "Pause" else "Play",
                                tint = palette.onAccent,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }

                    if (!state.isDhikrMode) {
                        IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Next Ayah", tint = palette.textPrimary, modifier = Modifier.size(32.dp))
                        }
                    }

                    IconButton(
                        onClick = onRepeatSurah,
                        modifier = Modifier.size(48.dp).testTag("audio_repeat_surah_button")
                    ) {
                        Icon(
                            Icons.Default.Repeat,
                            contentDescription = "Repeat Surah",
                            tint = if (state.repeatSurah) palette.gold else palette.textMuted
                        )
                    }
                }

                // Ayah Jump Scrubber (for Surah mode)
                if (!state.isDhikrMode && state.totalAyahs > 1) {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isBn) "আয়াত পরিবর্তন করুন" else "Jump to Ayah",
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.textPrimary
                            )
                            Text(
                                text = "${state.currentAyahNumber} / ${state.totalAyahs}",
                                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = palette.gold
                            )
                        }
                        Slider(
                            value = state.currentAyahNumber.toFloat(),
                            onValueChange = { onJumpToAyah(it.toInt().coerceIn(1, state.totalAyahs)) },
                            valueRange = 1f..state.totalAyahs.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = palette.gold,
                                activeTrackColor = palette.gold,
                                inactiveTrackColor = palette.blockBg
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (onOpenHifzDialog != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            GlassFilterChip(
                                label = if (isBn) "হিফজ আয়াত লুপ চালু করুন" else "Open Hifz Range Repeat Loop",
                                selected = state.isHifzMode,
                                icon = Icons.Default.Loop,
                                onClick = {
                                    showFullSheet = false
                                    onOpenHifzDialog()
                                },
                                modifier = Modifier.fillMaxWidth().testTag("audio_open_hifz_button")
                            )
                        }
                    }
                }

                // Searchable Reciter Dropdown Selector
                if (!state.isDhikrMode) {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isBn) "কারী নির্বাচন করুন" else "Reciter Voice",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(palette.blockBg)
                                    .border(0.9.dp, palette.borderAccent, RoundedCornerShape(14.dp))
                                    .clickable { reciterMenuExpanded = true }
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                                    .testTag("audio_reciter_dropdown"),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isBn) state.reciter.nameBn else state.reciter.nameEn,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = palette.textPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = state.reciter.style,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.gold
                                    )
                                }
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Select Reciter", tint = palette.accentSoft)
                            }
                            DropdownMenu(
                                expanded = reciterMenuExpanded,
                                onDismissRequest = { reciterMenuExpanded = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.86f)
                                    .background(palette.cardElevatedBg)
                            ) {
                                OutlinedTextField(
                                    value = reciterQuery,
                                    onValueChange = { reciterQuery = it },
                                    placeholder = { Text(if (isBn) "এখানে লিখুন" else "Type here", color = palette.textMuted) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = palette.accentPrimary,
                                        unfocusedBorderColor = palette.borderNeutral,
                                        focusedTextColor = palette.textPrimary,
                                        unfocusedTextColor = palette.textPrimary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                                filteredReciters.forEach { rec ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(
                                                    text = if (isBn) rec.nameBn else rec.nameEn,
                                                    color = if (rec.id == state.reciter.id) palette.accentSoft else palette.textPrimary,
                                                    fontWeight = if (rec.id == state.reciter.id) FontWeight.Bold else FontWeight.Normal
                                                )
                                                Text(rec.style, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                                            }
                                        },
                                        onClick = {
                                            onSelectReciter(rec)
                                            reciterMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Playback Speed & Sleep Timer
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = palette.sky, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBn) "তিলাওয়াতের গতি" else "Playback Speed",
                            style = MaterialTheme.typography.titleSmall,
                            color = palette.textPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f).forEach { spd ->
                            val selected = kotlin.math.abs(state.playbackSpeed - spd) < 0.05f
                            GlassFilterChip(
                                label = "${spd}×",
                                selected = selected,
                                onClick = { onSetSpeed(spd) },
                                modifier = Modifier.testTag("audio_speed_${(spd * 100).toInt()}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bedtime, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isBn) "স্লিপ টাইমার" else "Sleep Timer",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary
                            )
                        }
                        if (state.sleepTimerRemainingSec > 0) {
                            StatusPillBadge(
                                label = formatCountdownSec(state.sleepTimerRemainingSec),
                                accentColor = palette.gold
                            )
                        } else if (state.sleepStopAtEndOfSurah) {
                            StatusPillBadge(
                                label = if (isBn) "সূরা শেষে বন্ধ" else "End of Surah",
                                accentColor = palette.gold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GlassFilterChip(
                            label = if (isBn) "বন্ধ" else "Off",
                            selected = state.sleepTimerRemainingSec == 0 && !state.sleepStopAtEndOfSurah,
                            onClick = onCancelSleepTimer,
                            modifier = Modifier.testTag("audio_sleep_off")
                        )
                        listOf(15, 30, 45).forEach { mins ->
                            GlassFilterChip(
                                label = "${mins}m",
                                selected = state.sleepTimerRemainingSec > 0 && !state.sleepStopAtEndOfSurah &&
                                    ((state.sleepTimerRemainingSec + 59) / 60) in (mins - 14)..mins,
                                onClick = { onSetSleepTimerMinutes(mins) },
                                modifier = Modifier.testTag("audio_sleep_${mins}m")
                            )
                        }
                        if (!state.isDhikrMode) {
                            GlassFilterChip(
                                label = if (isBn) "সূরা শেষে" else "End of Surah",
                                selected = state.sleepStopAtEndOfSurah,
                                onClick = onSetSleepAtEndOfSurah,
                                modifier = Modifier.testTag("audio_sleep_end_surah")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Volume", tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Slider(
                            value = state.volume,
                            onValueChange = onSetVolume,
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = palette.accentSoft,
                                activeTrackColor = palette.accentPrimary,
                                inactiveTrackColor = palette.blockBg
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun LiveWaveformBars(
    isPlaying: Boolean,
    barColor: Color,
    barCount: Int = 4,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "waveform")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(950, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    Canvas(modifier = modifier) {
        val gap = size.width / (barCount * 2f)
        val barWidth = gap.coerceAtLeast(3f)
        val totalSpan = barCount * barWidth + (barCount - 1) * gap
        val startX = (size.width - totalSpan) / 2f

        for (i in 0 until barCount) {
            val fraction = if (isPlaying) {
                val wave = kotlin.math.sin((phase + i * 0.9f).toDouble()).toFloat()
                0.28f + 0.68f * ((wave + 1f) * 0.5f)
            } else {
                0.24f + (i % 3) * 0.14f
            }
            val barH = size.height * fraction
            val top = (size.height - barH) / 2f
            val x = startX + i * (barWidth + gap)
            drawRoundRect(
                color = barColor,
                topLeft = Offset(x, top),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
