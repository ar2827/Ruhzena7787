package com.example.ruhzena.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Brightness2
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.DailyPrayerSchedule
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.local.UserPreferences
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import java.util.Calendar
import java.util.TimeZone

data class RamadanCountdownState(
    val nextMilestoneKey: String, // "SUHOOR" or "IFTAR"
    val targetTimeFormatted: String,
    val minutesRemaining: Int,
    val isCurrentlyFastingWindow: Boolean
)

fun calculateRamadanCountdown(
    schedule: DailyPrayerSchedule,
    now: Calendar = Calendar.getInstance()
): RamadanCountdownState {
    val nowMins = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
    return when {
        nowMins < schedule.fajrMinutes -> RamadanCountdownState(
            nextMilestoneKey = "SUHOOR",
            targetTimeFormatted = PrayerCalculator.formatMinutes(schedule.fajrMinutes),
            minutesRemaining = (schedule.fajrMinutes - nowMins).coerceAtLeast(0),
            isCurrentlyFastingWindow = false
        )
        nowMins < schedule.maghribMinutes -> RamadanCountdownState(
            nextMilestoneKey = "IFTAR",
            targetTimeFormatted = PrayerCalculator.formatMinutes(schedule.maghribMinutes),
            minutesRemaining = (schedule.maghribMinutes - nowMins).coerceAtLeast(0),
            isCurrentlyFastingWindow = true
        )
        else -> RamadanCountdownState(
            nextMilestoneKey = "SUHOOR",
            targetTimeFormatted = PrayerCalculator.formatMinutes(schedule.fajrMinutes),
            minutesRemaining = ((24 * 60 - nowMins) + schedule.fajrMinutes).coerceAtLeast(0),
            isCurrentlyFastingWindow = false
        )
    }
}

@Composable
fun RamadanHomeSummaryCard(
    prefs: UserPreferences,
    schedule: DailyPrayerSchedule,
    onOpenTracker: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    val now = Calendar.getInstance(TimeZone.getTimeZone(prefs.locationTimeZoneId))
    val countdown = calculateRamadanCountdown(schedule, now)
    val h = countdown.minutesRemaining / 60
    val m = countdown.minutesRemaining % 60
    val countdownLabel = if (h > 0) "${h}h ${m}m" else "${m}m"

    val fastCount = remember(prefs.ramadanFastedDaysCsv) {
        prefs.ramadanFastedDaysCsv.split(',').mapNotNull { it.trim().toIntOrNull() }.size
    }
    val juzCount = remember(prefs.ramadanCompletedJuzCsv) {
        prefs.ramadanCompletedJuzCsv.split(',').mapNotNull { it.trim().toIntOrNull() }.size
    }

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_ramadan_card"),
        elevated = true,
        accentBorder = true,
        contentPadding = PaddingValues(14.dp),
        onClick = onOpenTracker
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(palette.gold.copy(alpha = 0.16f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Brightness2, contentDescription = null, tint = palette.gold, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (countdown.nextMilestoneKey == "IFTAR") {
                            if (isBn) "ইফতারের বাকি $countdownLabel" else "Iftar in $countdownLabel"
                        } else {
                            if (isBn) "সেহরি শেষ হতে $countdownLabel" else "Suhoor ends in $countdownLabel"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.gold
                    )
                    Text(
                        text = if (isBn) {
                            "লক্ষ্য: ${countdown.targetTimeFormatted} • রোজা $fastCount/৩০ • জুয $juzCount/৩০"
                        } else {
                            "At ${countdown.targetTimeFormatted} • Fasts $fastCount/30 • Juz $juzCount/30"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                }
            }
            StatusPillBadge(label = if (isBn) "ট্র্যাকার" else "Tracker", accentColor = palette.gold)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RamadanTrackerDialog(
    prefs: UserPreferences,
    schedule: DailyPrayerSchedule,
    onToggleRamadanMode: (Boolean) -> Unit,
    onToggleFastDay: (Int) -> Unit,
    onToggleJuz: (Int) -> Unit,
    onIncrementTarawih: () -> Unit,
    onIncrementSadaqah: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val strings = LocalStrings.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current

    val now = Calendar.getInstance(TimeZone.getTimeZone(prefs.locationTimeZoneId))
    val countdown = calculateRamadanCountdown(schedule, now)
    val h = countdown.minutesRemaining / 60
    val m = countdown.minutesRemaining % 60
    val countdownStr = if (h > 0) "${h}h ${m}m" else "${m}m"

    val fastedSet = remember(prefs.ramadanFastedDaysCsv) {
        prefs.ramadanFastedDaysCsv.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet()
    }
    val juzSet = remember(prefs.ramadanCompletedJuzCsv) {
        prefs.ramadanCompletedJuzCsv.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet()
    }

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler { onDismiss() }

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("ramadan_tracker_dialog"),
            color = palette.voidBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "রমজান সঙ্গী ও ৩০-জুয ট্র্যাকার" else "Ramadan Companion & 30-Juz Tracker",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary
                        )
                        Text(
                            text = prefs.locationName,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.gold
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_ramadan_dialog")) {
                        Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textPrimary)
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Countdown Hero Card
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (countdown.nextMilestoneKey == "IFTAR") {
                                            if (isBn) "পরবর্তী ইফতার (মাগরিব)" else "NEXT IFTAR (MAGHRIB)"
                                        } else {
                                            if (isBn) "সেহরির শেষ সময় (ফজর)" else "SUHOOR ENDS (FAJR)"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.gold
                                    )
                                    Text(
                                        text = "${countdown.targetTimeFormatted} • $countdownStr",
                                        style = MaterialTheme.typography.headlineMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                                        color = palette.textPrimary
                                    )
                                }
                                GlassFilterChip(
                                    label = if (prefs.ramadanModeEnabled) (if (isBn) "সক্রিয়" else "Active") else (if (isBn) "চালু করুন" else "Enable"),
                                    selected = prefs.ramadanModeEnabled,
                                    icon = if (prefs.ramadanModeEnabled) Icons.Default.Check else Icons.Default.Brightness2,
                                    onClick = { onToggleRamadanMode(!prefs.ramadanModeEnabled) },
                                    modifier = Modifier.testTag("ramadan_dialog_enable_chip")
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (isBn) {
                                    "সেহরি শেষ: ${PrayerCalculator.formatMinutes(schedule.fajrMinutes)} • ইফতার: ${PrayerCalculator.formatMinutes(schedule.maghribMinutes)}"
                                } else {
                                    "Suhoor ends at ${PrayerCalculator.formatMinutes(schedule.fajrMinutes)} • Iftar at ${PrayerCalculator.formatMinutes(schedule.maghribMinutes)}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                    }

                    // Tarawih & Sadaqah Counters
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = if (isBn) "তারাবীহ ও সদকা" else "Tarawih & Daily Sadaqah",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                GlassFilterChip(
                                    label = if (isBn) "তারাবীহ: ${prefs.ramadanTarawihDays} রাত (+১)" else "Tarawih: ${prefs.ramadanTarawihDays} nights (+1)",
                                    selected = prefs.ramadanTarawihDays > 0,
                                    icon = Icons.Default.Add,
                                    onClick = onIncrementTarawih,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("ramadan_tarawih_inc")
                                )
                                GlassFilterChip(
                                    label = if (isBn) "সদকা: ${prefs.ramadanSadaqahCount} বার (+১)" else "Sadaqah: ${prefs.ramadanSadaqahCount} (+1)",
                                    selected = prefs.ramadanSadaqahCount > 0,
                                    icon = Icons.Default.VolunteerActivism,
                                    onClick = onIncrementSadaqah,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("ramadan_sadaqah_inc")
                                )
                            }
                        }
                    }

                    // 30-Day Fasting Grid
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isBn) "৩০ দিনের রোজা চেক-ইন" else "30-Day Fasting Check-In",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textPrimary
                                )
                                StatusPillBadge(label = "${fastedSet.size}/30", accentColor = palette.accentSoft)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                (1..30).forEach { day ->
                                    GlassFilterChip(
                                        label = "Day $day",
                                        selected = fastedSet.contains(day),
                                        onClick = { onToggleFastDay(day) }
                                    )
                                }
                            }
                        }
                    }

                    // 30-Juz Khatam Tracker
                    item {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ramadan_juz_tracker")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isBn) "৩০ পারা কুরআন খতম" else "30-Juz Quran Completion",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textPrimary
                                )
                                StatusPillBadge(label = "${juzSet.size}/30", accentColor = palette.gold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                (1..30).forEach { juz ->
                                    GlassFilterChip(
                                        label = "Juz $juz",
                                        selected = juzSet.contains(juz),
                                        onClick = { onToggleJuz(juz) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                GoldSourceTag(
                                    sourceText = "Quran 2:185 ↗",
                                    modifier = Modifier.clickable {
                                        runCatching {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://quran.com/2/185")))
                                        }
                                    }
                                )
                                GoldSourceTag(
                                    sourceText = "Sahih al-Bukhari 1903 ↗",
                                    modifier = Modifier.clickable {
                                        runCatching {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://sunnah.com/bukhari:1903")))
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
