package com.example.ruhzena.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.ruhzena.data.local.UserPreferencesRepository
import com.example.ruhzena.media.AdhanMuezzin
import com.example.ruhzena.media.FullAdhanAudioManager
import com.example.ruhzena.media.RuhZenaMediaNotificationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

object RuhZenaNotificationHelper {
    // Versioned _v5 channels with futuristic liquid-glass presentation & full Adhan audio support
    const val CHANNEL_PRAYER = "ruhzena_prayer_v5"
    const val CHANNEL_HYDRATION = "ruhzena_hydration_v5"
    const val CHANNEL_WELLNESS = "ruhzena_wellness_v5"
    const val CHANNEL_SPIRITUAL = "ruhzena_spiritual_v5"
    const val CHANNEL_MOTIVATION = "ruhzena_motivation_v5"
    const val CHANNEL_STATUS = "ruhzena_status_silent_v5"

    const val KEY_WATER_ML_INPUT = "key_water_ml_input"

    private val legacyChannels = listOf(
        "ruhzena_prayer", "ruhzena_prayer_v2", "ruhzena_prayer_v3", "ruhzena_prayer_v4",
        "ruhzena_hydration", "ruhzena_hydration_v2", "ruhzena_hydration_v3", "ruhzena_hydration_v4",
        "ruhzena_wellness", "ruhzena_wellness_v2", "ruhzena_wellness_v3", "ruhzena_wellness_v4",
        "ruhzena_spiritual", "ruhzena_spiritual_v2", "ruhzena_spiritual_v3", "ruhzena_spiritual_v4",
        "ruhzena_motivation", "ruhzena_motivation_v2", "ruhzena_motivation_v3", "ruhzena_motivation_v4",
        "ruhzena_status_silent_v4"
    )

    @Volatile
    private var activeAlertPlayer: MediaPlayer? = null

    fun prayerAdhanUri(context: Context): Uri =
        Uri.parse("android.resource://${context.packageName}/${R.raw.ruhzena_adhan_prayer}")

    fun prayerRingtoneUri(context: Context): Uri = prayerAdhanUri(context)

    fun waterDropUri(context: Context): Uri =
        Uri.parse("android.resource://${context.packageName}/${R.raw.ruhzena_water_drop}")

    fun hikmahBellUri(context: Context): Uri =
        Uri.parse("android.resource://${context.packageName}/${R.raw.ruhzena_hikmah_bell}")

    fun signatureNotificationUri(context: Context): Uri =
        Uri.parse("android.resource://${context.packageName}/${R.raw.ruhzena_notification}")

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        legacyChannels.forEach { oldId ->
            runCatching { manager.deleteNotificationChannel(oldId) }
        }

        val notifAudioAttr = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        // Prayer channel is silent on the channel itself so FullAdhanAudioManager plays the
        // actual full ~3-minute human Muezzin Adhan cleanly without overlapping a short beep!
        val prayerChannel = NotificationChannel(
            CHANNEL_PRAYER,
            "Prayer & Full Adhan Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Full authentic Muezzin Adhan alerts for Salah times"
            setSound(null, null)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 340, 150, 340, 150, 420)
            enableLights(true)
        }

        val hydrationChannel = NotificationChannel(
            CHANNEL_HYDRATION,
            "Hydration Reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Interactive liquid-glass water reminders with direct ml input, 5m snooze, and mute"
            setSound(waterDropUri(context), notifAudioAttr)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 180, 90, 180)
        }

        val wellnessChannel = NotificationChannel(
            CHANNEL_WELLNESS,
            "Workout & Sleep Rhythm",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Workout and sleep schedule alerts"
            setSound(signatureNotificationUri(context), notifAudioAttr)
            enableVibration(true)
        }

        val spiritualChannel = NotificationChannel(
            CHANNEL_SPIRITUAL,
            "Adhkar & Spiritual Nudges",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Morning/Evening Adhkar and habit consistency alerts"
            setSound(signatureNotificationUri(context), notifAudioAttr)
            enableVibration(true)
        }

        val motivationChannel = NotificationChannel(
            CHANNEL_MOTIVATION,
            "Hourly Hikmah & Daily Duas",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Hourly wisdom, short Sunnah Duas, and daily motivation"
            setSound(hikmahBellUri(context), notifAudioAttr)
            enableVibration(true)
        }

        val statusChannel = NotificationChannel(
            CHANNEL_STATUS,
            "Quick Action Confirmations",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Silent liquid-glass confirmations for water logging, snooze, and mute timers"
            setSound(null, null)
            enableVibration(false)
        }

        manager.createNotificationChannels(
            listOf(prayerChannel, hydrationChannel, wellnessChannel, spiritualChannel, motivationChannel, statusChannel)
        )
        RuhZenaMediaNotificationManager.ensureChannel(context)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun triggerAudibleAlert(context: Context, soundUri: Uri, isPrayer: Boolean, prayerTitle: String = "Adhan • Call to Prayer") {
        runCatching {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (am != null && am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return

            if (isPrayer) {
                // Play the ACTUAL FULL human Muezzin Adhan (cached locally for offline use)
                CoroutineScope(Dispatchers.IO).launch {
                    val muezzinId = runCatching {
                        UserPreferencesRepository(context.applicationContext).preferencesFlow.first().adhanMuezzinId
                    }.getOrDefault(AdhanMuezzin.MAKKAH.id)
                    FullAdhanAudioManager.playFullAdhan(
                        context = context.applicationContext,
                        muezzinId = muezzinId,
                        prayerTitle = prayerTitle
                    )
                }
                return
            }

            activeAlertPlayer?.let { prev ->
                runCatching {
                    if (prev.isPlaying) prev.stop()
                    prev.release()
                }
            }
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(context.applicationContext, soundUri)
                isLooping = false
                setOnCompletionListener { mp ->
                    runCatching { mp.release() }
                    if (activeAlertPlayer === mp) activeAlertPlayer = null
                }
                setOnErrorListener { mp, _, _ ->
                    runCatching { mp.release() }
                    if (activeAlertPlayer === mp) activeAlertPlayer = null
                    true
                }
                prepare()
                start()
            }
            activeAlertPlayer = player
        }
    }

    fun stopActiveAlertSound(context: Context? = null) {
        activeAlertPlayer?.let { mp ->
            runCatching {
                if (mp.isPlaying) mp.stop()
                mp.release()
            }
            activeAlertPlayer = null
        }
        FullAdhanAudioManager.stop(context)
    }

    fun showNotification(
        context: Context,
        channelId: String,
        notificationId: Int,
        title: String,
        body: String,
        reminderType: String = "",
        toneUri: String = "",
        vibrationEnabled: Boolean = true,
        isWaterReminder: Boolean = false,
        isBn: Boolean = false
    ) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)

        val isPrayer = channelId == CHANNEL_PRAYER
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (reminderType.isNotBlank()) putExtra("reminder_type", reminderType)
            if (isWaterReminder) putExtra("open_hydration", true)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val defaultSound = when (channelId) {
            CHANNEL_PRAYER -> prayerAdhanUri(context)
            CHANNEL_HYDRATION -> waterDropUri(context)
            CHANNEL_MOTIVATION -> hikmahBellUri(context)
            else -> signatureNotificationUri(context)
        }
        val resolvedSoundUri: Uri = if (toneUri.isNotBlank()) {
            runCatching { Uri.parse(toneUri) }.getOrElse { defaultSound }
        } else {
            defaultSound
        }

        val categoryBadge = when (channelId) {
            CHANNEL_PRAYER -> if (isBn) "নামাজ • পূর্ণ আযান" else "SALAH • FULL ADHAN"
            CHANNEL_HYDRATION -> if (isBn) "হাইড্রেশন • পানি" else "HYDRATION • LIVE"
            CHANNEL_MOTIVATION -> if (isBn) "প্রতি ঘণ্টার হিকমাহ" else "HOURLY HIKMAH"
            CHANNEL_SPIRITUAL -> if (isBn) "আযকার ও দ্বীন" else "ADHKAR & DEEN"
            else -> if (isBn) "রূহযেনা সুস্থতা" else "RUHZENA WELLNESS"
        }
        val accentColor = when (channelId) {
            CHANNEL_PRAYER -> 0xFFCFA75E.toInt()
            CHANNEL_HYDRATION -> 0xFF38BDF8.toInt()
            CHANNEL_MOTIVATION -> 0xFF22D3EE.toInt()
            else -> 0xFF94A3B8.toInt()
        }

        val effectiveType = reminderType.ifBlank {
            if (isWaterReminder) RuhZenaReminderWorker.TYPE_WATER else RuhZenaReminderWorker.TYPE_HOURLY_MOTIVATION
        }

        // Action PendingIntents wired into the Futuristic Liquid-Glass Expanded Card buttons
        val primaryLabel: String
        val primaryPi: PendingIntent
        if (isWaterReminder) {
            primaryLabel = if (isBn) "+২৫০ মি.লি." else "+250 ml"
            primaryPi = broadcastActionPendingIntent(
                context = context,
                requestCode = notificationId * 10 + 6,
                action = NotificationActionReceiver.ACTION_WATER_250,
                notificationId = notificationId,
                reminderType = effectiveType,
                isBn = isBn
            )
        } else if (isPrayer) {
            primaryLabel = if (isBn) "আযান থামান" else "Stop Adhan"
            primaryPi = broadcastActionPendingIntent(
                context = context,
                requestCode = notificationId * 10 + 1,
                action = NotificationActionReceiver.ACTION_DONE,
                notificationId = notificationId,
                reminderType = effectiveType,
                isBn = isBn
            )
        } else {
            primaryLabel = if (isBn) "সম্পন্ন" else "Done"
            primaryPi = broadcastActionPendingIntent(
                context = context,
                requestCode = notificationId * 10 + 1,
                action = NotificationActionReceiver.ACTION_DONE,
                notificationId = notificationId,
                reminderType = effectiveType,
                isBn = isBn
            )
        }

        val snoozeLabel = if (isBn) "৫ মি. পরে" else "Snooze 5m"
        val snoozePi = broadcastActionPendingIntent(
            context = context,
            requestCode = notificationId * 10 + 2,
            action = NotificationActionReceiver.ACTION_SNOOZE_5,
            notificationId = notificationId,
            reminderType = effectiveType,
            isBn = isBn
        )

        val muteLabel = if (isBn) "মিউট" else "Mute"
        val muteMenuPi = broadcastActionPendingIntent(
            context = context,
            requestCode = notificationId * 10 + 3,
            action = NotificationActionReceiver.ACTION_SHOW_MUTE_OPTIONS,
            notificationId = notificationId,
            reminderType = effectiveType,
            isBn = isBn
        )

        // Futuristic Liquid-Glass Collapsed & Expanded Views
        val collapsedGlass = RemoteViews(context.packageName, R.layout.notification_liquid_glass_collapsed).apply {
            setTextViewText(R.id.notif_badge, categoryBadge)
            setTextViewText(R.id.notif_title, title)
            setTextViewText(R.id.notif_body, body)
        }

        val expandedGlass = RemoteViews(context.packageName, R.layout.notification_liquid_glass_expanded).apply {
            setTextViewText(R.id.notif_badge, categoryBadge)
            setTextViewText(R.id.notif_title, title)
            setTextViewText(R.id.notif_body, body)
            setViewVisibility(R.id.notif_actions_row, View.VISIBLE)
            setTextViewText(R.id.notif_btn_primary, primaryLabel)
            setTextViewText(R.id.notif_btn_secondary, snoozeLabel)
            setTextViewText(R.id.notif_btn_tertiary, muteLabel)
            setOnClickPendingIntent(R.id.notif_btn_primary, primaryPi)
            setOnClickPendingIntent(R.id.notif_btn_secondary, snoozePi)
            setOnClickPendingIntent(R.id.notif_btn_tertiary, muteMenuPi)
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setSubText(categoryBadge)
            .setColor(accentColor)
            .setContentTitle(title)
            .setContentText(body)
            .setCustomContentView(collapsedGlass)
            .setCustomBigContentView(expandedGlass)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCategory(
                if (isPrayer) NotificationCompat.CATEGORY_ALARM
                else NotificationCompat.CATEGORY_REMINDER
            )
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        if (!isPrayer) {
            builder.setSound(resolvedSoundUri)
        }

        if (!vibrationEnabled) {
            builder.setVibrate(longArrayOf(0L))
        } else {
            builder.setVibrate(
                if (isPrayer) longArrayOf(0, 340, 150, 340, 150, 420)
                else longArrayOf(0, 180, 90, 180)
            )
        }

        // Keep native inline RemoteInput on Water reminders so user can type exact ml right inside notification!
        if (isWaterReminder) {
            val remoteInput = RemoteInput.Builder(KEY_WATER_ML_INPUT)
                .setLabel(if (isBn) "কত মি.লি. পানি? (যেমন: 300)" else "Enter water ml (e.g. 300)")
                .setChoices(arrayOf("200", "250", "350", "500"))
                .build()
            val waterInputIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_WATER_CUSTOM_INPUT
                putExtra(NotificationActionReceiver.EXTRA_NOTIFICATION_ID, notificationId)
                putExtra(NotificationActionReceiver.EXTRA_REMINDER_TYPE, effectiveType)
                putExtra(NotificationActionReceiver.EXTRA_IS_BN, isBn)
            }
            val mutableFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val waterInputPi = PendingIntent.getBroadcast(
                context,
                notificationId * 10 + 1,
                waterInputIntent,
                mutableFlags
            )
            val waterLogAction = NotificationCompat.Action.Builder(
                android.R.drawable.ic_input_add,
                if (isBn) "কাস্টম ml লিখুন" else "Type ml",
                waterInputPi
            )
                .addRemoteInput(remoteInput)
                .setAllowGeneratedReplies(false)
                .build()
            builder.addAction(waterLogAction)
        }

        runCatching {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        }

        // Play actual Full Adhan for Prayer alerts, or crisp custom sound for other reminders
        triggerAudibleAlert(
            context = context,
            soundUri = resolvedSoundUri,
            isPrayer = isPrayer,
            prayerTitle = title
        )
    }

    /**
     * Clicking "Mute" transforms the notification in-place into a sleek Liquid-Glass
     * duration selector (1h / 4h / 8h) with glowing glass pill buttons!
     */
    fun showMuteDurationChooserNotification(
        context: Context,
        notificationId: Int,
        reminderType: String,
        isBn: Boolean
    ) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)
        stopActiveAlertSound(context)

        val openMuteIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_mute_picker", true)
        }
        val bodyPi = PendingIntent.getActivity(
            context,
            notificationId * 10 + 9,
            openMuteIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isBn) "কত ঘণ্টার জন্য মিউট করবেন?" else "Mute RuhZena alerts for how long?"
        val body = if (isBn) "নিচ থেকে সময় বেছে নিন অথবা ১–২৪ ঘণ্টার জন্য ট্যাপ করুন।" else "Choose a glass preset below, or tap for 1h–24h options."
        val badge = if (isBn) "মিউট সময়কাল" else "MUTE DURATION"

        val pi1h = broadcastActionPendingIntent(context, notificationId * 10 + 4, NotificationActionReceiver.ACTION_MUTE_HOURS, notificationId, reminderType, isBn, 1)
        val pi4h = broadcastActionPendingIntent(context, notificationId * 10 + 5, NotificationActionReceiver.ACTION_MUTE_HOURS, notificationId, reminderType, isBn, 4)
        val pi8h = broadcastActionPendingIntent(context, notificationId * 10 + 6, NotificationActionReceiver.ACTION_MUTE_HOURS, notificationId, reminderType, isBn, 8)

        val collapsedGlass = RemoteViews(context.packageName, R.layout.notification_liquid_glass_collapsed).apply {
            setTextViewText(R.id.notif_badge, badge)
            setTextViewText(R.id.notif_title, title)
            setTextViewText(R.id.notif_body, body)
        }

        val expandedGlass = RemoteViews(context.packageName, R.layout.notification_liquid_glass_expanded).apply {
            setTextViewText(R.id.notif_badge, badge)
            setTextViewText(R.id.notif_title, title)
            setTextViewText(R.id.notif_body, body)
            setViewVisibility(R.id.notif_actions_row, View.VISIBLE)
            setTextViewText(R.id.notif_btn_primary, if (isBn) "১ ঘণ্টা" else "1 Hour")
            setTextViewText(R.id.notif_btn_secondary, if (isBn) "৪ ঘণ্টা" else "4 Hours")
            setTextViewText(R.id.notif_btn_tertiary, if (isBn) "৮ ঘণ্টা" else "8 Hours")
            setOnClickPendingIntent(R.id.notif_btn_primary, pi1h)
            setOnClickPendingIntent(R.id.notif_btn_secondary, pi4h)
            setOnClickPendingIntent(R.id.notif_btn_tertiary, pi8h)
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_STATUS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setSubText(badge)
            .setColor(0xFFCFA75E.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setCustomContentView(collapsedGlass)
            .setCustomBigContentView(expandedGlass)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setAutoCancel(true)
            .setSilent(true)
            .setContentIntent(bodyPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        runCatching {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        }
    }

    /**
     * Silent liquid-glass confirmation after logging custom water ml, snoozing 5m, or muting.
     */
    fun showSilentConfirmation(
        context: Context,
        notificationId: Int,
        title: String,
        body: String,
        showUnmuteAction: Boolean = false,
        isBn: Boolean = false
    ) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPi = PendingIntent.getActivity(
            context,
            notificationId * 10 + 8,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val badge = if (isBn) "রূহযেনা • সম্পন্ন" else "RUHZENA • UPDATED"
        val collapsedGlass = RemoteViews(context.packageName, R.layout.notification_liquid_glass_collapsed).apply {
            setTextViewText(R.id.notif_badge, badge)
            setTextViewText(R.id.notif_title, title)
            setTextViewText(R.id.notif_body, body)
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_STATUS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setColor(0xFF22D3EE.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setCustomContentView(collapsedGlass)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setAutoCancel(true)
            .setSilent(true)
            .setTimeoutAfter(8_000L)
            .setContentIntent(openPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (showUnmuteAction) {
            val unmutePi = broadcastActionPendingIntent(
                context = context,
                requestCode = notificationId * 10 + 7,
                action = NotificationActionReceiver.ACTION_UNMUTE,
                notificationId = notificationId,
                reminderType = "",
                isBn = isBn
            )
            builder.addAction(
                android.R.drawable.ic_lock_silent_mode_off,
                if (isBn) "আনমিউট করুন" else "Unmute",
                unmutePi
            )
        }

        runCatching {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        }
    }

    private fun broadcastActionPendingIntent(
        context: Context,
        requestCode: Int,
        action: String,
        notificationId: Int,
        reminderType: String,
        isBn: Boolean,
        muteHours: Int = 0
    ): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra(NotificationActionReceiver.EXTRA_NOTIFICATION_ID, notificationId)
            putExtra(NotificationActionReceiver.EXTRA_REMINDER_TYPE, reminderType)
            putExtra(NotificationActionReceiver.EXTRA_IS_BN, isBn)
            if (muteHours > 0) {
                putExtra(NotificationActionReceiver.EXTRA_MUTE_HOURS, muteHours)
            }
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
