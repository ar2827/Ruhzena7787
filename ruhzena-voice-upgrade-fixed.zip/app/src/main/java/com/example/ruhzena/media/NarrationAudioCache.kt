package com.example.ruhzena.media

import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Disk cache for AI narration PCM only. Never touches Quran audio storage: it owns exactly one
 * directory (`<cacheDir>/ruhzena_voice_cache`) and only deletes files inside it.
 *
 * File layout: 4-byte magic "RZP1" + 4-byte big-endian sample rate + raw 16-bit mono PCM.
 * Writes go to `<name>.tmp` and are renamed on [PendingWrite.commit], so an interrupted or
 * cancelled generation can never leave a half-written file that looks valid.
 */
class NarrationAudioCache(
    private val dir: File,
    private val maxBytes: Long = 120L * 1024 * 1024,
    private val maxAgeMs: Long = 30L * 24 * 60 * 60 * 1000
) {
    class Hit(val file: File, val sampleRate: Int) {
        val pcmBytes: Long get() = file.length() - HEADER_SIZE
    }

    init { dir.mkdirs() }

    private fun fileFor(key: String) = File(dir, "$key.rzpcm")

    /** Returns a validated cache hit, or null (and deletes the file if it is corrupt). */
    fun lookup(key: String): Hit? {
        val f = fileFor(key)
        if (!f.isFile) return null
        return try {
            if (f.length() < HEADER_SIZE + MIN_PCM_BYTES) throw IllegalStateException("too short")
            DataInputStream(FileInputStream(f)).use { input ->
                val magic = ByteArray(4)
                input.readFully(magic)
                if (!magic.contentEquals(MAGIC)) throw IllegalStateException("bad magic")
                val rate = input.readInt()
                if (rate !in 8_000..48_000) throw IllegalStateException("bad rate")
                if ((f.length() - HEADER_SIZE) % 2L != 0L) throw IllegalStateException("odd length")
                f.setLastModified(System.currentTimeMillis()) // LRU touch
                Hit(f, rate)
            }
        } catch (_: Exception) {
            f.delete()
            null
        }
    }

    inner class PendingWrite internal constructor(private val key: String, sampleRate: Int) {
        private val tmp = File(dir, "$key.tmp")
        private val out = BufferedOutputStream(FileOutputStream(tmp), 32 * 1024)
        private var pcmBytes = 0L
        private var closed = false

        init {
            out.write(MAGIC)
            out.write(byteArrayOf(
                (sampleRate shr 24).toByte(), (sampleRate shr 16).toByte(),
                (sampleRate shr 8).toByte(), sampleRate.toByte()
            ))
        }

        fun write(bytes: ByteArray, offset: Int = 0, length: Int = bytes.size) {
            if (closed) return
            out.write(bytes, offset, length)
            pcmBytes += length
        }

        /** Only call when EVERY chunk was generated and fully played. */
        fun commit(): Boolean {
            if (closed) return false
            closed = true
            return try {
                out.flush(); out.close()
                if (pcmBytes < MIN_PCM_BYTES || pcmBytes % 2L != 0L) { tmp.delete(); return false }
                val dest = fileFor(key)
                dest.delete()
                val ok = tmp.renameTo(dest)
                if (!ok) tmp.delete()
                ok
            } catch (_: Exception) {
                tmp.delete(); false
            }
        }

        fun abort() {
            if (closed) return
            closed = true
            runCatching { out.close() }
            tmp.delete()
        }
    }

    fun beginWrite(key: String, sampleRate: Int): PendingWrite? =
        runCatching { PendingWrite(key, sampleRate) }.getOrNull()

    /**
     * Removes: orphaned temp files, files from older cache formats (v3_*, *.mime, play_tmp.*),
     * entries older than [maxAgeMs], then oldest-first until the directory is under [maxBytes].
     * Call from a background thread.
     */
    fun cleanup(now: Long = System.currentTimeMillis()) {
        val files = dir.listFiles() ?: return
        val live = mutableListOf<File>()
        for (f in files) {
            if (!f.isFile) continue
            val n = f.name
            val stale = when {
                n.endsWith(".tmp") -> now - f.lastModified() > 60 * 60 * 1000L
                n.endsWith(".rzpcm") -> now - f.lastModified() > maxAgeMs
                else -> true // legacy v3_* / .mime / play_tmp.* from the previous implementation
            }
            if (stale) f.delete() else live.add(f)
        }
        var total = live.sumOf { it.length() }
        if (total <= maxBytes) return
        for (f in live.sortedBy { it.lastModified() }) {
            if (total <= maxBytes) break
            total -= f.length()
            f.delete()
        }
    }

    companion object {
        const val HEADER_SIZE = 8
        const val MIN_PCM_BYTES = 1024L
        val MAGIC = byteArrayOf('R'.code.toByte(), 'Z'.code.toByte(), 'P'.code.toByte(), '1'.code.toByte())
    }
}
