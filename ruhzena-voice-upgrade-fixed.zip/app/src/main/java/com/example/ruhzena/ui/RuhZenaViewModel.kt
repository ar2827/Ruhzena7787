package com.example.ruhzena.ui

import com.example.ruhzena.media.NarrationVoiceResolver
import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ruhzena.RuhZenaApplication
import com.example.ruhzena.ai.AiEvidenceResponse
import com.example.ruhzena.ai.MealPhotoAnalysis
import com.example.ruhzena.ai.agent.AgentStreamEvent
import com.example.ruhzena.ai.agent.AiPersonality
import com.example.ruhzena.ai.agent.AiProviderId
import com.example.ruhzena.ai.agent.CandidateMemoryProposal
import com.example.ruhzena.ai.agent.ProviderCredentialsSnapshot
import com.example.ruhzena.ai.agent.ProviderPingResult
import com.example.ruhzena.ai.agent.WellnessTelemetryContext
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.sensors.LocationFetchResult
import com.example.ruhzena.core.sensors.LocationHelper
import com.example.ruhzena.data.cloud.CloudSyncStatus
import com.example.ruhzena.data.islamic.AyahExplanation
import com.example.ruhzena.data.islamic.CityPreset
import com.example.ruhzena.data.islamic.CountryCatalog
import com.example.ruhzena.data.islamic.CountryPreset
import com.example.ruhzena.data.islamic.DailyPrayerSchedule
import com.example.ruhzena.data.islamic.NextPrayerInfo
import com.example.ruhzena.data.islamic.PrayerCalcMethod
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.islamic.QuranAudioRef
import com.example.ruhzena.data.islamic.QuranAyah
import com.example.ruhzena.data.islamic.QuranReciter
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.islamic.SurahLoadResult
import com.example.ruhzena.data.local.AiMemoryEntity
import com.example.ruhzena.data.local.AiMessageEntity
import com.example.ruhzena.data.local.AiProviderHealthEntity
import com.example.ruhzena.data.local.AiTaskStateEntity
import com.example.ruhzena.data.local.BookmarkEntity
import com.example.ruhzena.data.local.HabitCheckEntity
import com.example.ruhzena.data.local.HabitEntity
import com.example.ruhzena.data.local.JournalEntryEntity
import com.example.ruhzena.data.local.MealLogEntity
import com.example.ruhzena.data.local.SleepLogEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.data.local.WorkoutLogEntity
import com.example.ruhzena.media.AudioPlaybackState
import com.example.ruhzena.notifications.ReminderScheduler
import com.example.ruhzena.notifications.RuhZenaNotificationHelper
import com.example.ruhzena.notifications.RuhZenaReminderWorker
import com.example.ruhzena.widgets.RuhZenaWidgetUpdater
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private const val VM_TAG = "RuhZenaViewModel"

data class QuranReaderUiState(
    val selectedSurahNumber: Int = 1,
    val ayahs: List<QuranAyah> = emptyList(),
    val isLoading: Boolean = false,
    val isFromOfflineCache: Boolean = true,
    val errorMessage: String? = null,
    val isDownloadingAll: Boolean = false,
    val downloadProgressCount: Int = 0
)

data class AyahExplanationState(
    val selectedAyah: QuranAyah? = null,
    val isLoading: Boolean = false,
    val explanation: AyahExplanation? = null,
    val isAiGenerated: Boolean = false,
    val networkError: String? = null
)

data class AiChatUiState(
    val personality: AiPersonality = AiPersonality.PEACE_COMPANION,
    val researchOnlineEnabled: Boolean = true,
    val isThinking: Boolean = false,
    val statusHint: String = "",
    val streamingText: String = "",
    val errorMessage: String? = null,
    val lastFailedPrompt: String? = null,
    val prefillPrompt: String? = null,
    val pendingMemoryProposal: CandidateMemoryProposal? = null
)

sealed interface MealScanUiState {
    data object Idle : MealScanUiState
    data object Analyzing : MealScanUiState
    data class Success(val analysis: MealPhotoAnalysis, val previewBitmap: Bitmap) : MealScanUiState
    data class Error(val message: String) : MealScanUiState
}

class RuhZenaViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as RuhZenaApplication
    private val prefsRepo = app.preferencesRepository
    private val dataRepo = app.dataRepository
    private val cloudRepo = app.cloudRepository
    private val quranRepo = app.quranRepository
    private val aiCoordinator = app.aiCoordinator
    private val agentEngine = app.agentEngine
    private val credentialStore = app.aiCredentialStore
    val audioController = app.audioController
    val speechPlayer = app.speechPlayer
    val soundEngine = app.soundEngine

    private val json = Json { ignoreUnknownKeys = true }

    private val _preferencesReady = MutableStateFlow(false)
    val preferencesReady: StateFlow<Boolean> = _preferencesReady.asStateFlow()

    val preferences: StateFlow<UserPreferences> = prefsRepo.preferencesFlow
        .onEach { _preferencesReady.value = true }
        .stateIn(viewModelScope, SharingStarted.Eagerly, prefsRepo.initialFastBootPreferences())

    val isOnline: StateFlow<Boolean> = app.connectivityMonitor.isOnline

    val audioState: StateFlow<AudioPlaybackState> = audioController.state

    val speakingItemId: StateFlow<String?> = speechPlayer.speakingItemId

    val cachedSurahNumbers: StateFlow<List<Int>> = quranRepo.observeCachedSurahNumbers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val waterMlToday: StateFlow<Int> = dataRepo.observeWaterMlToday()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val waterLogsToday: StateFlow<List<WaterLogEntity>> = dataRepo.observeWaterLogsToday()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val waterLogsLast7Days: StateFlow<List<WaterLogEntity>> = dataRepo.observeWaterLogsLast7Days()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val waterLogsLast30Days: StateFlow<List<WaterLogEntity>> = dataRepo.observeWaterLogsLast30Days()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mealsToday: StateFlow<List<MealLogEntity>> = dataRepo.observeMealsToday()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mealsLast7Days: StateFlow<List<MealLogEntity>> = dataRepo.observeMealsLast7Days()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mealsLast30Days: StateFlow<List<MealLogEntity>> = dataRepo.observeMealsLast30Days()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sleepLogs: StateFlow<List<SleepLogEntity>> = dataRepo.observeSleepLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentWorkouts: StateFlow<List<WorkoutLogEntity>> = dataRepo.observeRecentWorkouts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workoutsLast7Days: StateFlow<List<WorkoutLogEntity>> = dataRepo.observeWorkoutsLast7Days()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workoutsLast30Days: StateFlow<List<WorkoutLogEntity>> = dataRepo.observeWorkoutsLast30Days()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workoutsTodayCount: StateFlow<Int> = dataRepo.observeWorkoutsTodayCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val habits: StateFlow<List<HabitEntity>> = dataRepo.observeHabits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habitChecksToday: StateFlow<List<HabitCheckEntity>> = dataRepo.observeHabitChecksToday()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habitChecksLast30Days: StateFlow<List<HabitCheckEntity>> = dataRepo.observeHabitChecksLast30Days()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val journalEntries: StateFlow<List<JournalEntryEntity>> = dataRepo.observeJournalEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks: StateFlow<List<BookmarkEntity>> = dataRepo.observeBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unifiedAiMessages: StateFlow<List<AiMessageEntity>> = dataRepo.observeAllAiMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aiMemories: StateFlow<List<AiMemoryEntity>> = dataRepo.observeAiMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aiTasks: StateFlow<List<AiTaskStateEntity>> = dataRepo.observeAiTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAiTask: StateFlow<AiTaskStateEntity?> = dataRepo.observeActiveAiTask()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val providerHealth: StateFlow<List<AiProviderHealthEntity>> = dataRepo.observeProviderHealth()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _providerCredentials = MutableStateFlow(credentialStore.getSnapshot())
    val providerCredentials: StateFlow<ProviderCredentialsSnapshot> = _providerCredentials.asStateFlow()

    private val _providerPingResults = MutableStateFlow<Map<AiProviderId, ProviderPingResult>>(emptyMap())
    val providerPingResults: StateFlow<Map<AiProviderId, ProviderPingResult>> = _providerPingResults.asStateFlow()

    private val _testingProviderId = MutableStateFlow<AiProviderId?>(null)
    val testingProviderId: StateFlow<AiProviderId?> = _testingProviderId.asStateFlow()

    private val _quranState = MutableStateFlow(QuranReaderUiState())
    val quranState: StateFlow<QuranReaderUiState> = _quranState.asStateFlow()

    private val _ayahExplanationState = MutableStateFlow(AyahExplanationState())
    val ayahExplanationState: StateFlow<AyahExplanationState> = _ayahExplanationState.asStateFlow()

    private val _aiUiState = MutableStateFlow(AiChatUiState())
    val aiUiState: StateFlow<AiChatUiState> = _aiUiState.asStateFlow()

    private val _mealScanState = MutableStateFlow<MealScanUiState>(MealScanUiState.Idle)
    val mealScanState: StateFlow<MealScanUiState> = _mealScanState.asStateFlow()

    private val _previousMealScan = MutableStateFlow<Pair<MealPhotoAnalysis, Bitmap>?>(null)
    val hasPreviousMealScan: StateFlow<Boolean> = _previousMealScan
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _citySearchResults = MutableStateFlow<List<CityPreset>>(emptyList())
    val citySearchResults: StateFlow<List<CityPreset>> = _citySearchResults.asStateFlow()

    private val _isSearchingCity = MutableStateFlow(false)
    val isSearchingCity: StateFlow<Boolean> = _isSearchingCity.asStateFlow()

    private val _backupStatusMessage = MutableStateFlow<String?>(null)
    val backupStatusMessage: StateFlow<String?> = _backupStatusMessage.asStateFlow()

    private val _cloudSyncStatus = MutableStateFlow(CloudSyncStatus())
    val cloudSyncStatus: StateFlow<CloudSyncStatus> = _cloudSyncStatus.asStateFlow()

    private var activeCloudUid: String? = null
    private var activeCloudDisplayName: String? = null
    private var activeCloudEmail: String? = null

    private val _prayerSchedule = MutableStateFlow(
        PrayerCalculator.calculateForDate(
            latitude = 23.8103,
            longitude = 90.4125,
            method = PrayerCalcMethod.KARACHI,
            timeZone = TimeZone.getTimeZone("Asia/Dhaka")
        )
    )
    val prayerSchedule: StateFlow<DailyPrayerSchedule> = _prayerSchedule.asStateFlow()

    private val _nextPrayer = MutableStateFlow(
        PrayerCalculator.getNextPrayer(
            _prayerSchedule.value,
            Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"))
        )
    )
    val nextPrayer: StateFlow<NextPrayerInfo> = _nextPrayer.asStateFlow()

    private val _tasbihCurrentCount = MutableStateFlow(0)
    val tasbihCurrentCount: StateFlow<Int> = _tasbihCurrentCount.asStateFlow()

    init {
        loadSurah(1)

        viewModelScope.launch {
            habits.collect { list ->
                if (list.isEmpty()) {
                    dataRepo.seedStarterHabitsIfEmpty(list)
                }
            }
        }

        viewModelScope.launch {
            preferences.collect { prefs ->
                val method = PrayerCalcMethod.fromId(prefs.prayerCalcMethod)
                val asrShadow = if (prefs.asrJuristicMethod == "HANAFI") 2.0 else 1.0
                val tz = TimeZone.getTimeZone(prefs.locationTimeZoneId)
                val cal = Calendar.getInstance(tz)
                val sched = PrayerCalculator.calculateForDate(
                    latitude = prefs.latitude,
                    longitude = prefs.longitude,
                    method = method,
                    calendar = cal,
                    timeZone = tz,
                    asrShadowFactorOverride = asrShadow
                )
                _prayerSchedule.value = sched
                _nextPrayer.value = PrayerCalculator.getNextPrayer(sched, cal)
                _aiUiState.update { cur ->
                    val savedPersonality = AiPersonality.fromId(prefs.aiPersonalityMode)
                    if (cur.personality != savedPersonality) cur.copy(personality = savedPersonality) else cur
                }
                // Single source of truth for narration voice: the onboarding/profile gender.
                speechPlayer.applyVoicePreference(prefs.characterGender, prefs.speechVoiceStyle)
                // Keep the stored tone variant consistent with the gender (e.g. after a gender change
                // in the profile, or for legacy accounts that had a mismatched voice style).
                val resolvedVoice = NarrationVoiceResolver.resolve(prefs.characterGender, prefs.speechVoiceStyle)
                if (NarrationVoiceResolver.parseGender(prefs.characterGender) != null &&
                    !prefs.speechVoiceStyle.equals(resolvedVoice.styleId, ignoreCase = true)
                ) {
                    prefsRepo.setSpeechVoiceStyle(resolvedVoice.styleId)
                }
                com.example.ruhzena.media.FullAdhanAudioManager.prefetchFullAdhan(app, prefs.adhanMuezzinId)
                ReminderScheduler.syncSchedules(app, prefs)
            }
        }

        // Minute ticker for live prayer countdown
        viewModelScope.launch {
            while (isActive) {
                val tz = TimeZone.getTimeZone(preferences.value.locationTimeZoneId)
                _nextPrayer.value = PrayerCalculator.getNextPrayer(_prayerSchedule.value, Calendar.getInstance(tz))
                delay(30_000L)
            }
        }
    }

    fun bindAuthenticatedUser(uid: String, displayName: String?, email: String?) {
        if (activeCloudUid == uid) return
        activeCloudUid = uid
        activeCloudDisplayName = displayName
        activeCloudEmail = email
        syncWithFirebaseCloud()
    }

    fun clearAuthenticatedUser() {
        activeCloudUid = null
        activeCloudDisplayName = null
        activeCloudEmail = null
        _cloudSyncStatus.value = CloudSyncStatus()
    }

    fun syncWithFirebaseCloud() {
        val uid = activeCloudUid ?: return
        if (_cloudSyncStatus.value.syncing) return
        viewModelScope.launch {
            _cloudSyncStatus.update { it.copy(syncing = true, errorMessage = null) }
            try {
                // 1. Pull remote cloud state & merge any records missing locally
                val pullRes = cloudRepo.pullCloudBundle()
                pullRes.onSuccess { bundle ->
                    val currentPrefs = preferences.value
                    bundle.profile?.let { remote ->
                        // Restore the saved gender (and therefore the narration voice) on a fresh device/login.
                        if (currentPrefs.characterGender.isBlank() && remote.characterGender.isNotBlank()) {
                            prefsRepo.setCharacterGender(remote.characterGender)
                        }
                        if (currentPrefs.lastReadSurah == 1 && currentPrefs.lastReadAyah == 1 &&
                            (remote.lastReadSurah > 1 || remote.lastReadAyah > 1)
                        ) {
                            prefsRepo.setLastRead(remote.lastReadSurah, remote.lastReadAyah)
                        }
                        if (remote.hydrationGoalMl in 500..10000 && currentPrefs.hydrationGoalMl == 2500) {
                            prefsRepo.setHydrationGoal(remote.hydrationGoalMl)
                        }
                    }

                    val existingHabitTitles = habits.value.map { it.title.trim().lowercase() }.toSet()
                    bundle.habits.forEach { remote ->
                        if (remote.title.trim().lowercase() !in existingHabitTitles) {
                            dataRepo.addHabit(
                                title = remote.title,
                                category = remote.category,
                                reminderEnabled = false,
                                reminderTime = "08:00"
                            )
                        }
                    }

                    val existingJournalKeys = journalEntries.value.map { "${it.dateKey}|${it.title.trim()}" }.toSet()
                    bundle.journal.forEach { remote ->
                        val key = "${remote.dateKey}|${remote.title.trim()}"
                        if (key !in existingJournalKeys) {
                            dataRepo.addJournalEntry(
                                title = remote.title,
                                content = remote.content,
                                mood = remote.mood,
                                achievement = remote.achievement
                            )
                        }
                    }

                    val existingBookmarkKeys = bookmarks.value.map { it.key }.toSet()
                    bundle.bookmarks.forEach { remote ->
                        val candidateKey = remote.id.removePrefix("bm_").ifBlank { "${remote.itemType}_${remote.surahNumber}_${remote.ayahNumber}" }
                        if (candidateKey !in existingBookmarkKeys) {
                            dataRepo.toggleBookmark(
                                BookmarkEntity(
                                    key = candidateKey,
                                    itemType = remote.itemType,
                                    title = remote.title,
                                    subtitle = remote.subtitle,
                                    arabicText = remote.arabicText,
                                    surahNumber = remote.surahNumber,
                                    ayahNumber = remote.ayahNumber
                                ),
                                currentlySaved = false
                            )
                        }
                    }
                }

                // 2. Push current local profile & user-authored collections to Firestore
                val profileResult = cloudRepo.upsertUserProfile(
                    prefs = preferences.value,
                    displayNameOverride = activeCloudDisplayName,
                    emailOverride = activeCloudEmail
                )
                habits.value.take(30).forEach { cloudRepo.upsertHabit(it) }
                journalEntries.value.take(30).forEach { cloudRepo.saveJournalEntry(it) }
                recentWorkouts.value.take(20).forEach { cloudRepo.saveWorkoutLog(it) }
                waterLogsToday.value.take(20).forEach { cloudRepo.saveWaterLog(it) }
                bookmarks.value.take(40).forEach { cloudRepo.saveBookmark(it) }

                if (profileResult.isSuccess) {
                    val totalCount = habits.value.size + journalEntries.value.size +
                        recentWorkouts.value.size + bookmarks.value.size
                    _cloudSyncStatus.value = CloudSyncStatus(
                        synced = true,
                        syncing = false,
                        lastSyncedEpochMs = System.currentTimeMillis(),
                        syncedCountsSummary = "$totalCount records synced",
                        errorMessage = null
                    )
                } else {
                    _cloudSyncStatus.update {
                        it.copy(
                            syncing = false,
                            errorMessage = profileResult.exceptionOrNull()?.message ?: "Cloud sync paused — will retry when online."
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(VM_TAG, "Cloud sync failed for uid=$uid", e)
                _cloudSyncStatus.update {
                    it.copy(
                        syncing = false,
                        errorMessage = "Cloud sync paused — local data is safe."
                    )
                }
            }
        }
    }

    private fun mirrorProfileToCloud() {
        if (activeCloudUid == null) return
        viewModelScope.launch {
            cloudRepo.upsertUserProfile(
                prefs = preferences.value,
                displayNameOverride = activeCloudDisplayName,
                emailOverride = activeCloudEmail
            )
        }
    }

    // Language, Theme, Country & Onboarding
    fun setLanguage(language: AppLanguage) = viewModelScope.launch {
        prefsRepo.setLanguage(language)
        mirrorProfileToCloud()
    }

    fun setThemeMode(themeMode: String) = viewModelScope.launch {
        prefsRepo.setThemeMode(themeMode)
    }

    fun setCountry(country: CountryPreset, updateLocationDefaults: Boolean = true) = viewModelScope.launch {
        prefsRepo.setCountry(country, updateLocationDefaults)
    }

    fun setUiFontScale(scale: Float) = viewModelScope.launch {
        prefsRepo.setUiFontScale(scale)
    }

    fun setReducedMotion(enabled: Boolean) = viewModelScope.launch {
        prefsRepo.setReducedMotion(enabled)
    }

    fun setAsrJuristicMethod(method: String) = viewModelScope.launch {
        prefsRepo.setAsrJuristicMethod(method)
    }

    fun setHijriOffsetDays(offset: Int) = viewModelScope.launch {
        prefsRepo.setHijriOffsetDays(offset)
    }

    fun setRamadanModeEnabled(enabled: Boolean) = viewModelScope.launch {
        prefsRepo.setRamadanModeEnabled(enabled)
        RuhZenaWidgetUpdater.updateAll(app)
    }

    fun recordHifzSession(surahNumber: Int) = viewModelScope.launch {
        prefsRepo.recordHifzSession(surahNumber)
    }

    fun toggleRamadanFastDay(dayNumber: Int) = viewModelScope.launch {
        prefsRepo.toggleRamadanFastDay(dayNumber)
    }

    fun toggleRamadanJuz(juzNumber: Int) = viewModelScope.launch {
        prefsRepo.toggleRamadanJuz(juzNumber)
    }

    fun incrementRamadanTarawih() = viewModelScope.launch {
        prefsRepo.incrementRamadanTarawih()
    }

    fun incrementRamadanSadaqah() = viewModelScope.launch {
        prefsRepo.incrementRamadanSadaqah()
    }

    fun setLearningMode(mode: String) = viewModelScope.launch {
        prefsRepo.setLearningMode(mode)
    }

    fun selectLearningTrack(mode: String) = viewModelScope.launch {
        prefsRepo.selectLearningTrack(mode)
    }

    fun toggleArabicLetterMastered(letterKey: String) = viewModelScope.launch {
        prefsRepo.toggleArabicLetterMastered(letterKey)
    }

    fun completeLearningStep(stepNumber: Int) = viewModelScope.launch {
        prefsRepo.completeLearningStep(stepNumber)
    }

    fun setLearningAllAccess(enabled: Boolean) = viewModelScope.launch {
        prefsRepo.setLearningAllAccess(enabled)
    }

    fun selectLearningExperience(isExperienced: Boolean) = viewModelScope.launch {
        prefsRepo.selectLearningTrack(if (isExperienced) "EXPERIENCED" else "BEGINNER")
        prefsRepo.setLearningAllAccess(isExperienced)
    }

    fun speakArabic(itemId: String, arabicText: String, fallbackPronunciation: String = "") {
        speechPlayer.toggleSpeakArabic(itemId, arabicText, fallbackPronunciation)
    }

    fun speakLocalized(itemId: String, text: String) {
        speechPlayer.toggleSpeakLocalized(itemId, text, preferences.value.language == AppLanguage.BANGLA)
    }

    fun speakAiReply(itemId: String, markdownText: String) {
        speechPlayer.toggleSpeakAiReply(itemId, markdownText, preferences.value.language == AppLanguage.BANGLA)
    }

    fun stopSpeech() {
        speechPlayer.stop()
    }

    fun setKidsModeEnabled(enabled: Boolean) = viewModelScope.launch {
        prefsRepo.setKidsModeEnabled(enabled)
    }

    fun detectCountryViaGps(onResult: (CountryPreset?, LocationFetchResult) -> Unit) = viewModelScope.launch {
        val locRes = LocationHelper.fetchCurrentOrLastLocation(app)
        if (locRes is LocationFetchResult.Success) {
            val matched = CountryCatalog.findByLocationLabel(locRes.location.name)
                ?: CountryPreset(
                    code = "GPS",
                    nameEn = locRes.location.name.substringAfterLast(",").trim().ifBlank { locRes.location.name },
                    defaultCity = locRes.location.name,
                    latitude = locRes.location.latitude,
                    longitude = locRes.location.longitude,
                    timeZoneId = locRes.location.timeZoneId,
                    defaultMethodId = "MWL"
                )
            prefsRepo.setCountry(matched, updateLocationDefaults = false)
            prefsRepo.setLocation(
                locRes.location.name,
                locRes.location.latitude,
                locRes.location.longitude,
                locRes.location.timeZoneId
            )
            onResult(matched, locRes)
        } else {
            onResult(null, locRes)
        }
    }

    fun setNotificationTone(uriString: String) = viewModelScope.launch {
        prefsRepo.setNotificationTone(uriString)
    }

    fun setNotificationVibration(enabled: Boolean) = viewModelScope.launch {
        prefsRepo.setNotificationVibration(enabled)
    }

    fun setMotivationBannerDismissed(dismissed: Boolean) = viewModelScope.launch {
        prefsRepo.setMotivationBannerDismissed(dismissed)
    }

    fun setQuickJumpSlots(shortcuts: List<com.example.ruhzena.ui.components.PortalQuickLaunch>) = viewModelScope.launch {
        prefsRepo.setQuickJumpSlotsCsv(com.example.ruhzena.ui.components.PortalQuickLaunch.toCsv(shortcuts))
    }

    fun setTutorialCompleted(completed: Boolean) = viewModelScope.launch {
        prefsRepo.setTutorialCompleted(completed)
    }

    fun markTutorialPageCompleted(pageId: String) = viewModelScope.launch {
        prefsRepo.markTutorialPageCompleted(pageId)
    }

    fun resetAllTutorials() = viewModelScope.launch {
        prefsRepo.resetAllTutorials()
    }

    fun setAdhanMuezzinId(muezzinId: String) = viewModelScope.launch {
        prefsRepo.setAdhanMuezzinId(muezzinId)
        com.example.ruhzena.media.FullAdhanAudioManager.prefetchFullAdhan(app, muezzinId)
    }

    /** Tone variant inside the user's gender. A style of the other gender is ignored (gender is authoritative). */
    fun setSpeechVoiceStyle(style: String) = viewModelScope.launch {
        val current = preferences.value
        val resolved = NarrationVoiceResolver.resolve(current.characterGender, style)
        speechPlayer.applyVoicePreference(current.characterGender, resolved.styleId)
        prefsRepo.setSpeechVoiceStyle(resolved.styleId)
    }

    fun completeOnboarding() = viewModelScope.launch {
        prefsRepo.completeOnboarding()
    }

    fun saveOnboardingProfile(
        name: String,
        ageYears: Int,
        weightKg: Int,
        heightCm: Int,
        characterGender: String,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) = viewModelScope.launch {
        prefsRepo.saveOnboardingProfile(
            name = name,
            ageYears = ageYears,
            weightKg = weightKg,
            heightCm = heightCm,
            characterGender = characterGender,
            level = level,
            goal = goal,
            equipment = equipment,
            limitation = limitation
        )
    }

    // Quran Reader, Explanations & Audio
    fun loadSurah(surahNumber: Int) = viewModelScope.launch {
        _quranState.update { it.copy(selectedSurahNumber = surahNumber, isLoading = true, errorMessage = null) }
        when (val res = quranRepo.loadSurah(surahNumber, isOnline.value)) {
            is SurahLoadResult.Success -> {
                _quranState.update {
                    it.copy(
                        ayahs = res.ayahs,
                        isLoading = false,
                        isFromOfflineCache = res.fromOfflineCache,
                        errorMessage = null
                    )
                }
                if (preferences.value.lastReadSurah != surahNumber) {
                    prefsRepo.setLastRead(surahNumber, 1)
                }
            }
            is SurahLoadResult.Error -> {
                _quranState.update {
                    it.copy(
                        ayahs = emptyList(),
                        isLoading = false,
                        isFromOfflineCache = false,
                        errorMessage = res.message
                    )
                }
            }
        }
    }

    fun loadAyahExplanation(ayah: QuranAyah, forceRefresh: Boolean = false) = viewModelScope.launch {
        _ayahExplanationState.value = AyahExplanationState(selectedAyah = ayah, isLoading = true, explanation = null)
        val res = quranRepo.loadAyahExplanation(ayah, isOnline.value, preferences.value.language, forceRefresh)
        _ayahExplanationState.value = AyahExplanationState(
            selectedAyah = ayah,
            isLoading = false,
            explanation = res.explanation,
            isAiGenerated = res.isAiGenerated,
            networkError = res.networkError
        )
    }

    fun clearAyahExplanation() {
        _ayahExplanationState.value = AyahExplanationState()
    }

    fun updateLastReadAyah(surah: Int, ayah: Int) = viewModelScope.launch {
        prefsRepo.setLastRead(surah, ayah)
        mirrorProfileToCloud()
    }

    fun downloadAllSurahsOffline() = viewModelScope.launch {
        if (_quranState.value.isDownloadingAll) return@launch
        _quranState.update { it.copy(isDownloadingAll = true, downloadProgressCount = 0) }
        quranRepo.downloadAllMissingSurahs(isOnline.value) { done, _ ->
            _quranState.update { it.copy(downloadProgressCount = done) }
        }
        _quranState.update { it.copy(isDownloadingAll = false) }
        loadSurah(_quranState.value.selectedSurahNumber)
    }

    fun selectReciter(reciter: QuranReciter) = viewModelScope.launch {
        prefsRepo.setSelectedReciter(reciter.id)
        audioController.switchReciter(reciter)
    }

    fun playSurahAudio(surahNumber: Int, startAyah: Int = 1) {
        val reciter = SurahCatalog.reciters.firstOrNull { it.id == preferences.value.selectedReciterId }
            ?: SurahCatalog.reciters.first()
        audioController.playSurah(surahNumber, startAyah, reciter)
    }

    fun playHifzRangeAudio(
        surahNumber: Int,
        startAyah: Int,
        endAyah: Int,
        repeatCountPerAyah: Int,
        pauseGapSeconds: Int
    ) {
        val reciter = SurahCatalog.reciters.firstOrNull { it.id == preferences.value.selectedReciterId }
            ?: SurahCatalog.reciters.first()
        audioController.playHifzRange(
            surahNumber = surahNumber,
            startAyah = startAyah,
            endAyah = endAyah,
            repeatCountPerAyah = repeatCountPerAyah,
            pauseGapSeconds = pauseGapSeconds,
            reciter = reciter
        )
    }

    fun playDhikrOrDuaAudio(
        trackId: String,
        title: String,
        subtitle: String,
        quranRef: QuranAudioRef?,
        hisnChapterId: Int?,
        arabicText: String
    ) {
        val reciter = SurahCatalog.reciters.firstOrNull { it.id == preferences.value.selectedReciterId }
            ?: SurahCatalog.reciters.first()
        audioController.playHumanDhikrOrDua(
            trackId = trackId,
            title = title,
            subtitle = subtitle,
            quranRef = quranRef,
            hisnChapterId = hisnChapterId,
            arabicText = arabicText,
            reciter = reciter
        )
    }

    fun setQuranFontSize(sizeSp: Int) = viewModelScope.launch { prefsRepo.setQuranFontSize(sizeSp) }
    fun setShowPronunciation(show: Boolean) = viewModelScope.launch { prefsRepo.setShowPronunciation(show) }

    fun toggleBookmark(bookmark: BookmarkEntity, isSaved: Boolean) = viewModelScope.launch {
        dataRepo.toggleBookmark(bookmark, isSaved)
        if (activeCloudUid != null) {
            if (isSaved) {
                cloudRepo.deleteBookmark(bookmark.key)
            } else {
                cloudRepo.saveBookmark(bookmark)
            }
        }
    }

    // Prayer, City Search & Location
    fun selectCityPreset(name: String, lat: Double, lon: Double, timeZoneId: String) = viewModelScope.launch {
        prefsRepo.setLocation(name, lat, lon, timeZoneId)
    }

    fun selectCalcMethod(method: PrayerCalcMethod) = viewModelScope.launch {
        prefsRepo.setPrayerCalcMethod(method.id)
    }

    fun searchCities(query: String) = viewModelScope.launch {
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            _citySearchResults.value = emptyList()
            return@launch
        }
        _isSearchingCity.value = true
        _citySearchResults.value = LocationHelper.searchCityOnline(trimmed)
        _isSearchingCity.value = false
    }

    fun refreshGpsLocation(onResult: (LocationFetchResult) -> Unit) = viewModelScope.launch {
        val result = LocationHelper.fetchCurrentOrLastLocation(app)
        if (result is LocationFetchResult.Success) {
            prefsRepo.setLocation(
                result.location.name,
                result.location.latitude,
                result.location.longitude,
                result.location.timeZoneId
            )
        }
        onResult(result)
    }

    // Tasbih
    fun incrementTasbih(target: Int) = viewModelScope.launch {
        val next = _tasbihCurrentCount.value + 1
        val completed = next >= target
        _tasbihCurrentCount.value = if (completed) 0 else next
        prefsRepo.recordTasbihTap(completedSession = completed)
        RuhZenaWidgetUpdater.updateAll(app)
        if (completed || next % 10 == 0) {
            mirrorProfileToCloud()
        }
    }

    fun resetTasbih() {
        _tasbihCurrentCount.value = 0
    }

    fun undoTasbih() = viewModelScope.launch {
        if (_tasbihCurrentCount.value > 0) {
            _tasbihCurrentCount.value = (_tasbihCurrentCount.value - 1).coerceAtLeast(0)
            prefsRepo.undoTasbihTap()
        }
    }

    // Unified Persistent RuhZena AI Assistant
    fun setAiPersonality(personality: AiPersonality) {
        _aiUiState.update { it.copy(personality = personality, errorMessage = null) }
        viewModelScope.launch {
            prefsRepo.setAiPersonalityMode(personality.id)
        }
    }

    fun setResearchOnline(enabled: Boolean) {
        _aiUiState.update { it.copy(researchOnlineEnabled = enabled) }
    }

    fun dismissAiError() {
        _aiUiState.update { it.copy(errorMessage = null) }
    }

    fun setAiPrefillPrompt(prompt: String?, targetPersonality: AiPersonality? = null) {
        _aiUiState.update { cur ->
            cur.copy(
                personality = targetPersonality ?: cur.personality,
                prefillPrompt = prompt?.trim()?.takeIf { it.isNotEmpty() },
                errorMessage = null
            )
        }
    }

    fun consumeAiPrefillPrompt() {
        _aiUiState.update { it.copy(prefillPrompt = null) }
    }

    fun retryLastAiPrompt() {
        val failed = _aiUiState.value.lastFailedPrompt ?: return
        askAi(prompt = failed, skipSaveUserMessage = true)
    }

    fun approveMemoryProposal(proposal: CandidateMemoryProposal) = viewModelScope.launch {
        dataRepo.saveAiMemory(
            AiMemoryEntity(
                category = proposal.category,
                content = proposal.content,
                sourcePrompt = proposal.sourcePrompt,
                isApproved = true,
                isActive = true
            )
        )
        _aiUiState.update { it.copy(pendingMemoryProposal = null) }
    }

    fun dismissMemoryProposal() {
        _aiUiState.update { it.copy(pendingMemoryProposal = null) }
    }

    fun addManualAiMemory(category: String, content: String) = viewModelScope.launch {
        val clean = content.trim()
        if (clean.isNotBlank()) {
            dataRepo.saveAiMemory(
                AiMemoryEntity(category = category.uppercase(), content = clean, isApproved = true, isActive = true)
            )
        }
    }

    fun toggleAiMemoryActive(memory: AiMemoryEntity) = viewModelScope.launch {
        dataRepo.updateAiMemory(memory.copy(isActive = !memory.isActive, updatedAt = System.currentTimeMillis()))
    }

    fun deleteAiMemory(id: Long) = viewModelScope.launch {
        dataRepo.deleteAiMemory(id)
    }

    fun completeAiTask(id: Long) = viewModelScope.launch {
        dataRepo.updateAiTaskStatus(id, "COMPLETED")
    }

    fun deleteAiTask(id: Long) = viewModelScope.launch {
        dataRepo.deleteAiTask(id)
    }

    fun saveAiProviderCredentials(
        groqKey: String?,
        openRouterKey: String?,
        cloudflareAccountId: String?,
        cloudflareApiToken: String?,
        customProxyUrl: String?
    ) {
        credentialStore.saveUserOverrides(
            groqKey = groqKey,
            openRouterKey = openRouterKey,
            cloudflareAccountId = cloudflareAccountId,
            cloudflareApiToken = cloudflareApiToken,
            customProxyBaseUrl = customProxyUrl
        )
        _providerCredentials.value = credentialStore.getSnapshot()
        viewModelScope.launch {
            agentEngine.healthTracker.resetAll()
            dataRepo.clearProviderHealth()
        }
    }

    fun clearAiProviderCredentials() {
        credentialStore.clearUserOverrides()
        _providerCredentials.value = credentialStore.getSnapshot()
        _providerPingResults.value = emptyMap()
        viewModelScope.launch {
            agentEngine.healthTracker.resetAll()
            dataRepo.clearProviderHealth()
        }
    }

    fun testAiProvider(providerId: AiProviderId) {
        if (_testingProviderId.value != null) return
        viewModelScope.launch {
            _testingProviderId.value = providerId
            try {
                val res = agentEngine.testSingleProvider(providerId)
                _providerPingResults.update { it + (providerId to res) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _providerPingResults.update {
                    it + (providerId to ProviderPingResult(
                        providerId = providerId,
                        modelId = "",
                        success = false,
                        latencyMs = 0L,
                        detail = e.message?.take(140) ?: "Connection test failed"
                    ))
                }
            } finally {
                _testingProviderId.value = null
            }
        }
    }

    private var hasGreetedInCurrentSession: Boolean = false

    fun onExitAiSession() {
        hasGreetedInCurrentSession = false
    }

    fun askAi(prompt: String, skipSaveUserMessage: Boolean = false) {
        val clean = prompt.trim()
        if (clean.isEmpty() || _aiUiState.value.isThinking) return
        val personality = _aiUiState.value.personality
        val onlineResearch = _aiUiState.value.researchOnlineEnabled
        val currentlyOnline = isOnline.value
        val alreadyGreeted = hasGreetedInCurrentSession

        viewModelScope.launch {
            _aiUiState.update {
                it.copy(
                    isThinking = true,
                    statusHint = "",
                    streamingText = "",
                    errorMessage = null,
                    lastFailedPrompt = null
                )
            }

            if (!skipSaveUserMessage) {
                dataRepo.saveAiMessage(
                    AiMessageEntity(
                        sessionId = "unified",
                        mode = personality.id,
                        role = "USER",
                        content = clean
                    )
                )
            }

            if (currentlyOnline) {
                try {
                    val doneHabitIds = habitChecksToday.value.map { it.habitId }.toSet()
                    val habitsDone = habits.value.count { doneHabitIds.contains(it.id) }
                    val telemetry = WellnessTelemetryContext(
                        waterTodayMl = waterMlToday.value,
                        mealsToday = mealsToday.value,
                        workoutsThisWeek = recentWorkouts.value.size,
                        habitsDoneCount = habitsDone,
                        totalHabitsCount = habits.value.size
                    )

                    agentEngine.streamAgentResponse(
                        userPrompt = clean,
                        personality = personality,
                        language = preferences.value.language,
                        prefs = preferences.value,
                        telemetry = telemetry,
                        includeTelemetry = false,
                        alreadyGreetedInSession = alreadyGreeted
                    ).collect { event ->
                        when (event) {
                            is AgentStreamEvent.Status -> {
                                _aiUiState.update { it.copy(statusHint = event.friendlyMessage) }
                            }
                            is AgentStreamEvent.TextProgress -> {
                                _aiUiState.update { it.copy(streamingText = event.accumulatedText) }
                            }
                            is AgentStreamEvent.Completed -> {
                                hasGreetedInCurrentSession = true
                                val evidence = AiEvidenceResponse(
                                    topic = event.topic,
                                    quranicEvidence = "",
                                    hadithEvidence = "",
                                    scholarlyExplanations = event.explanation,
                                    scholarlyDifferences = "",
                                    aiSynthesis = event.mainReply,
                                    sourceLinks = event.citedSources,
                                    retrievalModeLabel = "RuhZena AI",
                                    actionTags = event.actionTags
                                )
                                dataRepo.saveAiMessage(
                                    AiMessageEntity(
                                        sessionId = "unified",
                                        mode = personality.id,
                                        role = "ASSISTANT",
                                        content = event.mainReply,
                                        evidenceJson = json.encodeToString(evidence),
                                        usedOnlineResearch = true,
                                        engineLabel = "RuhZena AI"
                                    )
                                )
                                _aiUiState.update {
                                    it.copy(
                                        isThinking = false,
                                        statusHint = "",
                                        streamingText = "",
                                        lastFailedPrompt = null,
                                        pendingMemoryProposal = event.memoryProposal ?: it.pendingMemoryProposal
                                    )
                                }
                            }
                            is AgentStreamEvent.Failed -> {
                                _aiUiState.update {
                                    it.copy(
                                        isThinking = false,
                                        statusHint = "",
                                        streamingText = "",
                                        errorMessage = event.friendlyMessage,
                                        lastFailedPrompt = event.preservedUserPrompt
                                    )
                                }
                            }
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(VM_TAG, "RuhZena AI unexpected failure", e)
                    _aiUiState.update {
                        it.copy(
                            isThinking = false,
                            statusHint = "",
                            streamingText = "",
                            errorMessage = "RuhZena AI hit a temporary connection issue. Your message is saved — tap Retry.",
                            lastFailedPrompt = clean
                        )
                    }
                }
            } else {
                // Offline / local grounded fallback (strictly verified corpus, never fabricates citations)
                try {
                    val recentHistory = unifiedAiMessages.value.takeLast(8).map { (it.role == "USER") to it.content }
                    val qLower = clean.lowercase()
                    val isWellnessQuery = listOf("workout", "water", "hydrat", "meal", "calorie", "protein", "sleep", "weight", "fat", "muscle", "ব্যায়াম", "পানি", "খাবার")
                        .any { qLower.contains(it) }
                    if (!isWellnessQuery) {
                        val res = aiCoordinator.answerIslamicQuestion(
                            query = clean,
                            language = preferences.value.language,
                            researchOnlineEnabled = false,
                            isOnline = false,
                            history = recentHistory,
                            alreadyGreetedInSession = alreadyGreeted
                        )
                        hasGreetedInCurrentSession = true
                        val evidenceStr = json.encodeToString(res)
                        dataRepo.saveAiMessage(
                            AiMessageEntity(
                                sessionId = "unified",
                                mode = personality.id,
                                role = "ASSISTANT",
                                content = res.aiSynthesis,
                                evidenceJson = evidenceStr,
                                usedOnlineResearch = false,
                                engineLabel = "RuhZena AI • Offline Corpus"
                            )
                        )
                    } else {
                        val recentSleep = sleepLogs.value
                        val avgSleep = if (recentSleep.isEmpty()) 420 else recentSleep.map { it.durationMinutes }.average().toInt()
                        val doneHabitIds = habitChecksToday.value.map { it.habitId }.toSet()
                        val habitsDone = habits.value.count { doneHabitIds.contains(it.id) }
                        val reply = aiCoordinator.answerWellnessQuestion(
                            query = clean,
                            prefs = preferences.value,
                            waterTodayMl = waterMlToday.value,
                            avgSleepMinutes = avgSleep,
                            workoutsThisWeek = recentWorkouts.value.size,
                            mealsToday = mealsToday.value,
                            habitsDoneCount = habitsDone,
                            totalHabitsCount = habits.value.size,
                            researchOnlineEnabled = false,
                            isOnline = false,
                            history = recentHistory
                        )
                        dataRepo.saveAiMessage(
                            AiMessageEntity(
                                sessionId = "unified",
                                mode = personality.id,
                                role = "ASSISTANT",
                                content = reply,
                                engineLabel = "RuhZena AI • Offline Engine"
                            )
                        )
                    }
                    _aiUiState.update { it.copy(isThinking = false, statusHint = "", streamingText = "", lastFailedPrompt = null) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(VM_TAG, "Offline AI evaluation failed", e)
                    _aiUiState.update {
                        it.copy(
                            isThinking = false,
                            statusHint = "",
                            streamingText = "",
                            errorMessage = "Offline assistant could not process this message. Tap Retry.",
                            lastFailedPrompt = clean
                        )
                    }
                }
            }
        }
    }

    fun clearAllAiChatHistory() = viewModelScope.launch {
        dataRepo.clearAllAiHistory()
        _aiUiState.update {
            it.copy(errorMessage = null, streamingText = "", statusHint = "", lastFailedPrompt = null, pendingMemoryProposal = null)
        }
    }

    // Wellness
    fun addWater(amountMl: Int) = viewModelScope.launch {
        dataRepo.addWater(amountMl)
        RuhZenaWidgetUpdater.updateAll(app)
        if (activeCloudUid != null) {
            cloudRepo.saveWaterLog(
                WaterLogEntity(amountMl = amountMl, dateKey = dataRepo.todayDateKey())
            )
        }
    }
    fun deleteWaterLog(id: Long) = viewModelScope.launch {
        dataRepo.deleteWaterLog(id)
        RuhZenaWidgetUpdater.updateAll(app)
    }
    fun setHydrationGoal(goalMl: Int) = viewModelScope.launch {
        prefsRepo.setHydrationGoal(goalMl)
        RuhZenaWidgetUpdater.updateAll(app)
        mirrorProfileToCloud()
    }

    fun addMeal(name: String, mealType: String, calories: Int, protein: Int, carbs: Int, fat: Int, verified: Boolean, source: String) =
        viewModelScope.launch {
            dataRepo.addMeal(
                MealLogEntity(
                    name = name,
                    mealType = mealType,
                    calories = calories,
                    proteinGrams = protein,
                    carbsGrams = carbs,
                    fatGrams = fat,
                    isVerifiedReference = verified,
                    sourceAttribution = source,
                    dateKey = dataRepo.todayDateKey()
                )
            )
        }
    fun deleteMeal(id: Long) = viewModelScope.launch { dataRepo.deleteMeal(id) }

    fun analyzeMealPhoto(bitmap: Bitmap, mealType: String) {
        if (!isOnline.value) {
            val isBn = preferences.value.language == AppLanguage.BANGLA
            _mealScanState.value = MealScanUiState.Error(
                if (isBn) "খাবারের ছবি বিশ্লেষণ করতে ইন্টারনেট সংযোগ প্রয়োজন।"
                else "Internet connection is required to analyze meal photos with RuhZena AI."
            )
            return
        }
        viewModelScope.launch {
            _mealScanState.value = MealScanUiState.Analyzing
            try {
                val (analysis, _) = withContext(Dispatchers.IO) {
                    agentEngine.analyzeMealPhotoWithFailover(bitmap, preferences.value, mealType)
                }
                _previousMealScan.value = analysis to bitmap
                _mealScanState.value = MealScanUiState.Success(analysis, bitmap)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(VM_TAG, "Meal photo analysis failed across providers", e)
                val isBn = preferences.value.language == AppLanguage.BANGLA
                _mealScanState.value = MealScanUiState.Error(
                    if (isBn) "এই মুহূর্তে ছবির বিশ্লেষণ সম্পন্ন করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।"
                    else "Could not analyze this meal photo right now. Please tap Retry or try a clearer photo."
                )
            }
        }
    }

    fun restorePreviousMealScan() {
        val prev = _previousMealScan.value ?: return
        _mealScanState.value = MealScanUiState.Success(prev.first, prev.second)
    }

    fun reanalyzeLastMealPhoto(mealType: String) {
        val prev = _previousMealScan.value ?: return
        analyzeMealPhoto(prev.second, mealType)
    }

    fun clearMealScan() {
        _mealScanState.value = MealScanUiState.Idle
    }

    fun addSleepLog(durationMin: Int, bedtime: String, wake: String, quality: Int, note: String) =
        viewModelScope.launch {
            dataRepo.addSleepLog(
                SleepLogEntity(
                    durationMinutes = durationMin,
                    bedtimeLabel = bedtime,
                    wakeTimeLabel = wake,
                    qualityRating = quality,
                    note = note,
                    dateKey = dataRepo.todayDateKey()
                )
            )
        }
    fun deleteSleepLog(id: Long) = viewModelScope.launch { dataRepo.deleteSleepLog(id) }

    fun logWorkout(title: String, exercises: Int, durationMin: Int, calories: Int) =
        viewModelScope.launch {
            dataRepo.logWorkout(title, exercises, durationMin, calories)
            if (activeCloudUid != null) {
                cloudRepo.saveWorkoutLog(
                    WorkoutLogEntity(
                        routineTitle = title,
                        exercisesCompleted = exercises,
                        durationMinutes = durationMin,
                        estimatedCalories = calories,
                        dateKey = dataRepo.todayDateKey()
                    )
                )
            }
        }

    fun updateFitnessProfile(
        name: String? = null,
        ageYears: Int? = null,
        weightKg: Int? = null,
        heightCm: Int? = null,
        characterGender: String? = null,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) = viewModelScope.launch {
        prefsRepo.updateFitnessProfile(
            name = name,
            ageYears = ageYears,
            weightKg = weightKg,
            heightCm = heightCm,
            characterGender = characterGender,
            level = level,
            goal = goal,
            equipment = equipment,
            limitation = limitation
        )
        mirrorProfileToCloud()
    }

    // Habits & Journal
    fun addHabit(title: String, category: String, reminder: Boolean, time: String) =
        viewModelScope.launch {
            dataRepo.addHabit(title, category, reminder, time)
            if (activeCloudUid != null) {
                cloudRepo.upsertHabit(
                    HabitEntity(
                        title = title,
                        category = category,
                        reminderEnabled = reminder,
                        reminderTime = time
                    )
                )
            }
        }

    fun toggleHabit(habit: HabitEntity, completedToday: Boolean) =
        viewModelScope.launch {
            dataRepo.toggleHabitToday(habit, completedToday)
            if (activeCloudUid != null) {
                val today = dataRepo.todayDateKey()
                val updated = if (completedToday) {
                    habit.copy(currentStreak = (habit.currentStreak - 1).coerceAtLeast(0))
                } else {
                    val nextStreak = if (habit.lastCompletedDate == today) habit.currentStreak else habit.currentStreak + 1
                    habit.copy(
                        currentStreak = nextStreak,
                        bestStreak = maxOf(habit.bestStreak, nextStreak),
                        lastCompletedDate = today
                    )
                }
                cloudRepo.upsertHabit(updated)
            }
        }

    fun saveHabitRecovery(habit: HabitEntity, note: String) =
        viewModelScope.launch {
            dataRepo.saveHabitRecovery(habit, note)
            if (activeCloudUid != null) {
                cloudRepo.upsertHabit(habit.copy(recoveryNote = note))
            }
        }

    fun deleteHabit(id: Long) = viewModelScope.launch {
        val target = habits.value.firstOrNull { it.id == id }
        dataRepo.deleteHabit(id)
        if (activeCloudUid != null && target != null) {
            cloudRepo.deleteHabitByTitle(target.title)
        }
    }

    fun addJournalEntry(title: String, content: String, mood: String, achievement: String) =
        viewModelScope.launch {
            dataRepo.addJournalEntry(title, content, mood, achievement)
            if (activeCloudUid != null) {
                cloudRepo.saveJournalEntry(
                    JournalEntryEntity(
                        title = title,
                        content = content,
                        mood = mood,
                        achievement = achievement,
                        dateKey = dataRepo.todayDateKey()
                    )
                )
            }
        }

    fun deleteJournalEntry(id: Long) = viewModelScope.launch { dataRepo.deleteJournalEntry(id) }

    suspend fun exportJournalJson(): String = dataRepo.exportJournalAsJson()

    // Backup & Restore (SAF zero-permission JSON)
    fun clearBackupStatus() {
        _backupStatusMessage.value = null
    }

    fun exportBackupToUri(uri: Uri) = viewModelScope.launch {
        val isBn = preferences.value.language == AppLanguage.BANGLA
        val ok = withContext(Dispatchers.IO) {
            runCatching {
                val payload = dataRepo.exportFullBackupJson(preferences.value)
                app.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(payload.toByteArray(Charsets.UTF_8))
                } ?: error("Cannot open output stream")
            }.isSuccess
        }
        _backupStatusMessage.value = if (ok) {
            if (isBn) "ব্যাকআপ JSON ফাইল সফলভাবে সংরক্ষিত হয়েছে।" else "Full backup JSON exported successfully."
        } else {
            if (isBn) "ব্যাকআপ সংরক্ষণ করা যায়নি। পুনরায় চেষ্টা করুন।" else "Unable to save backup file."
        }
    }

    fun importBackupFromUri(uri: Uri) = viewModelScope.launch {
        val isBn = preferences.value.language == AppLanguage.BANGLA
        val raw = withContext(Dispatchers.IO) {
            runCatching {
                app.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            }.getOrNull()
        }
        if (raw.isNullOrBlank()) {
            _backupStatusMessage.value = if (isBn) "ফাইল পড়া যায়নি।" else "Could not read selected backup file."
            return@launch
        }
        val res = dataRepo.importFullBackupJson(raw, prefsRepo)
        res.fold(
            onSuccess = { summary ->
                _backupStatusMessage.value = if (isBn) {
                    "পুনরুদ্ধার সম্পন্ন: ${summary.habitsRestored} অভ্যাস, ${summary.journalRestored} জার্নাল, ${summary.wellnessLogsRestored} স্বাস্থ্য লগ।"
                } else {
                    "Restored ${summary.habitsRestored} habits, ${summary.journalRestored} journal entries, ${summary.wellnessLogsRestored} wellness logs."
                }
            },
            onFailure = {
                _backupStatusMessage.value = if (isBn) {
                    "অবৈধ ব্যাকআপ ফাইল। সঠিক RuhZena JSON নির্বাচন করুন।"
                } else {
                    "Invalid backup JSON format. Select a RuhZena backup file."
                }
            }
        )
    }

    // Reminders & Settings
    fun updateReminderSettings(
        prayer: Boolean? = null,
        water: Boolean? = null,
        adhkar: Boolean? = null,
        workout: Boolean? = null,
        bedtime: Boolean? = null,
        lesson: Boolean? = null,
        hourlyMotivation: Boolean? = null,
        quietEnabled: Boolean? = null,
        quietStart: Int? = null,
        quietEnd: Int? = null
    ) = viewModelScope.launch {
        prefsRepo.updateReminderSettings(
            prayer = prayer,
            water = water,
            adhkar = adhkar,
            workout = workout,
            bedtime = bedtime,
            lesson = lesson,
            hourlyMotivation = hourlyMotivation,
            quietEnabled = quietEnabled,
            quietStart = quietStart,
            quietEnd = quietEnd
        )
    }

    fun sendPreviewNotification(type: String): Boolean {
        if (!RuhZenaNotificationHelper.hasNotificationPermission(app)) return false
        RuhZenaReminderWorker.dispatchNotification(
            context = app,
            type = type,
            prefs = preferences.value,
            waterTodayMl = waterMlToday.value,
            forcePreview = true
        )
        return true
    }

    fun muteNotificationsForHours(hours: Int) = viewModelScope.launch {
        val clamped = hours.coerceIn(1, 24)
        val untilMs = System.currentTimeMillis() + clamped * 3_600_000L
        prefsRepo.setMutedUntil(untilMs)
        RuhZenaNotificationHelper.stopActiveAlertSound()
    }

    fun unmuteNotifications() = viewModelScope.launch {
        prefsRepo.setMutedUntil(0L)
    }

    fun snoozeReminder(type: String, minutes: Long = 5L) {
        RuhZenaNotificationHelper.stopActiveAlertSound()
        ReminderScheduler.scheduleSnooze(app, type, minutes)
    }

    // Selective Clear & Factory Reset (Safety & Privacy)
    fun clearJournalData() = viewModelScope.launch {
        dataRepo.clearJournalEntries()
        _backupStatusMessage.value = "Journal entries cleared."
    }

    fun clearHabitsData() = viewModelScope.launch {
        dataRepo.clearHabitsAndChecks()
        _backupStatusMessage.value = "Habits and streaks cleared."
    }

    fun clearWellnessData() = viewModelScope.launch {
        dataRepo.clearWellnessLogs()
        _backupStatusMessage.value = "Hydration, meal & workout logs cleared."
    }

    fun resetAllAppData() = viewModelScope.launch {
        dataRepo.clearAllUserData()
        prefsRepo.clearAllPreferences()
        _backupStatusMessage.value = null
    }

    fun formatTimestamp(ts: Long): String =
        SimpleDateFormat("MMM d • h:mm a", Locale.getDefault()).format(Date(ts))

    override fun onCleared() {
        audioController.release()
        super.onCleared()
    }
}
