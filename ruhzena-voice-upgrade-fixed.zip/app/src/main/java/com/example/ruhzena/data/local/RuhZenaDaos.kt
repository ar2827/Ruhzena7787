package com.example.ruhzena.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WaterLogDao {
    @Query("SELECT * FROM water_logs WHERE dateKey = :dateKey ORDER BY timestamp DESC")
    fun getLogsForDate(dateKey: String): Flow<List<WaterLogEntity>>

    @Query("SELECT COALESCE(SUM(amountMl), 0) FROM water_logs WHERE dateKey = :dateKey")
    fun getTotalMlForDate(dateKey: String): Flow<Int>

    @Query("SELECT COALESCE(SUM(amountMl), 0) FROM water_logs WHERE dateKey = :dateKey")
    suspend fun getTotalMlForDateSnapshot(dateKey: String): Int

    @Query("SELECT * FROM water_logs WHERE dateKey >= :startDateKey ORDER BY timestamp DESC")
    fun getLogsSince(startDateKey: String): Flow<List<WaterLogEntity>>

    @Query("SELECT * FROM water_logs ORDER BY timestamp DESC")
    suspend fun getAllSnapshot(): List<WaterLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: WaterLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<WaterLogEntity>)

    @Query("DELETE FROM water_logs WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM water_logs")
    suspend fun deleteAll()
}

@Dao
interface MealLogDao {
    @Query("SELECT * FROM meal_logs WHERE dateKey = :dateKey ORDER BY timestamp DESC")
    fun getMealsForDate(dateKey: String): Flow<List<MealLogEntity>>

    @Query("SELECT * FROM meal_logs WHERE dateKey >= :startDateKey ORDER BY timestamp DESC")
    fun getMealsSince(startDateKey: String): Flow<List<MealLogEntity>>

    @Query("SELECT * FROM meal_logs ORDER BY timestamp DESC")
    suspend fun getAllSnapshot(): List<MealLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(meal: MealLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(meals: List<MealLogEntity>)

    @Query("DELETE FROM meal_logs WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM meal_logs")
    suspend fun deleteAll()
}

@Dao
interface SleepLogDao {
    @Query("SELECT * FROM sleep_logs ORDER BY timestamp DESC LIMIT 30")
    fun getRecentSleepLogs(): Flow<List<SleepLogEntity>>

    @Query("SELECT * FROM sleep_logs ORDER BY timestamp DESC")
    suspend fun getAllSnapshot(): List<SleepLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: SleepLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<SleepLogEntity>)

    @Query("DELETE FROM sleep_logs WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM sleep_logs")
    suspend fun deleteAll()
}

@Dao
interface WorkoutLogDao {
    @Query("SELECT * FROM workout_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentWorkouts(): Flow<List<WorkoutLogEntity>>

    @Query("SELECT * FROM workout_logs WHERE dateKey >= :startDateKey ORDER BY timestamp DESC")
    fun getWorkoutsSince(startDateKey: String): Flow<List<WorkoutLogEntity>>

    @Query("SELECT * FROM workout_logs ORDER BY timestamp DESC")
    suspend fun getAllSnapshot(): List<WorkoutLogEntity>

    @Query("SELECT COUNT(*) FROM workout_logs WHERE dateKey = :dateKey")
    fun getWorkoutCountForDate(dateKey: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: WorkoutLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<WorkoutLogEntity>)

    @Query("DELETE FROM workout_logs")
    suspend fun deleteAll()
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY createdAt ASC")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits ORDER BY createdAt ASC")
    suspend fun getAllHabitsSnapshot(): List<HabitEntity>

    @Query("SELECT * FROM habit_checks WHERE dateKey = :dateKey")
    fun getChecksForDate(dateKey: String): Flow<List<HabitCheckEntity>>

    @Query("SELECT * FROM habit_checks WHERE dateKey >= :startDateKey ORDER BY timestamp DESC")
    fun getChecksSince(startDateKey: String): Flow<List<HabitCheckEntity>>

    @Query("SELECT * FROM habit_checks ORDER BY timestamp DESC")
    suspend fun getAllChecksSnapshot(): List<HabitCheckEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabits(habits: List<HabitEntity>)

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Query("DELETE FROM habits WHERE id = :habitId")
    suspend fun deleteHabit(habitId: Long)

    @Query("DELETE FROM habits")
    suspend fun deleteAllHabits()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheck(check: HabitCheckEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChecks(checks: List<HabitCheckEntity>)

    @Query("DELETE FROM habit_checks WHERE habitId = :habitId AND dateKey = :dateKey")
    suspend fun removeCheck(habitId: Long, dateKey: String)

    @Query("DELETE FROM habit_checks")
    suspend fun deleteAllChecks()
}

@Dao
interface JournalDao {
    @Query("SELECT * FROM journal_entries ORDER BY timestamp DESC")
    fun getAllEntries(): Flow<List<JournalEntryEntity>>

    @Query("SELECT * FROM journal_entries ORDER BY timestamp DESC")
    suspend fun getAllEntriesSnapshot(): List<JournalEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: JournalEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entries: List<JournalEntryEntity>)

    @Query("DELETE FROM journal_entries WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM journal_entries")
    suspend fun deleteAll()
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    suspend fun getAllSnapshot(): List<BookmarkEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: BookmarkEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(bookmarks: List<BookmarkEntity>)

    @Query("DELETE FROM bookmarks WHERE `key` = :key")
    suspend fun deleteByKey(key: String)

    @Query("DELETE FROM bookmarks")
    suspend fun deleteAll()
}

@Dao
interface AiMessageDao {
    @Query("SELECT * FROM ai_messages ORDER BY timestamp ASC, id ASC")
    fun getAllMessages(): Flow<List<AiMessageEntity>>

    @Query("SELECT * FROM ai_messages ORDER BY timestamp ASC, id ASC")
    suspend fun getAllMessagesSnapshot(): List<AiMessageEntity>

    @Query("SELECT * FROM ai_messages WHERE mode = :mode ORDER BY timestamp ASC")
    fun getMessagesForMode(mode: String): Flow<List<AiMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: AiMessageEntity): Long

    @Query("DELETE FROM ai_messages WHERE mode = :mode")
    suspend fun clearModeHistory(mode: String)

    @Query("DELETE FROM ai_messages")
    suspend fun clearAllHistory()
}

@Dao
interface AiMemoryDao {
    @Query("SELECT * FROM ai_memories ORDER BY updatedAt DESC")
    fun getAllMemories(): Flow<List<AiMemoryEntity>>

    @Query("SELECT * FROM ai_memories WHERE isApproved = 1 AND isActive = 1 ORDER BY updatedAt DESC")
    suspend fun getActiveApprovedMemoriesSnapshot(): List<AiMemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(memory: AiMemoryEntity): Long

    @Update
    suspend fun update(memory: AiMemoryEntity)

    @Query("DELETE FROM ai_memories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM ai_memories")
    suspend fun clearAll()
}

@Dao
interface AiConversationSummaryDao {
    @Query("SELECT * FROM ai_conversation_summaries WHERE sessionId = :sessionId LIMIT 1")
    suspend fun getSummary(sessionId: String): AiConversationSummaryEntity?

    @Query("SELECT * FROM ai_conversation_summaries WHERE sessionId = :sessionId LIMIT 1")
    fun observeSummary(sessionId: String): Flow<AiConversationSummaryEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(summary: AiConversationSummaryEntity)

    @Query("DELETE FROM ai_conversation_summaries")
    suspend fun clearAll()
}

@Dao
interface AiTaskStateDao {
    @Query("SELECT * FROM ai_task_states ORDER BY updatedAt DESC")
    fun observeAllTasks(): Flow<List<AiTaskStateEntity>>

    @Query("SELECT * FROM ai_task_states WHERE status = 'ACTIVE' ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getActiveTaskSnapshot(): AiTaskStateEntity?

    @Query("SELECT * FROM ai_task_states WHERE status = 'ACTIVE' ORDER BY updatedAt DESC LIMIT 1")
    fun observeActiveTask(): Flow<AiTaskStateEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: AiTaskStateEntity): Long

    @Query("UPDATE ai_task_states SET status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM ai_task_states WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM ai_task_states")
    suspend fun clearAll()
}

@Dao
interface AiProviderHealthDao {
    @Query("SELECT * FROM ai_provider_health")
    fun observeAllHealth(): Flow<List<AiProviderHealthEntity>>

    @Query("SELECT * FROM ai_provider_health")
    suspend fun getAllHealthSnapshot(): List<AiProviderHealthEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AiProviderHealthEntity)

    @Query("DELETE FROM ai_provider_health")
    suspend fun clearAll()
}

@Dao
interface CachedSurahDao {
    @Query("SELECT surahNumber FROM cached_surahs")
    fun getCachedSurahNumbers(): Flow<List<Int>>

    @Query("SELECT * FROM cached_surahs WHERE surahNumber = :surahNumber")
    suspend fun getSurah(surahNumber: Int): CachedSurahEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSurah(entity: CachedSurahEntity)
}

