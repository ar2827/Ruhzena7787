package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class RuhZenaThemeMode(val id: String) {
    DARK_GLASS("DARK_GLASS"),
    LIGHT_GLASS("LIGHT_GLASS");

    companion object {
        fun fromId(id: String?): RuhZenaThemeMode =
            entries.firstOrNull { it.id == id } ?: DARK_GLASS
    }
}

@Immutable
data class RuhZenaGlassPalette(
    val isLight: Boolean,
    val voidBg: Color,
    val surfaceBg: Color,
    val elevatedSurfaceBg: Color,
    val cardBg: Color,
    val cardElevatedBg: Color,
    val pillBg: Color,
    val blockBg: Color,
    val navBarBg: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val borderNeutral: Color,
    val borderAccent: Color,
    val highlightTop: Color,
    val accentPrimary: Color,
    val accentSoft: Color,
    val accentContainer: Color,
    val onAccent: Color,
    val gold: Color,
    val sky: Color,
    val amber: Color,
    val coral: Color,
    val success: Color
)

val DarkGlassPalette = RuhZenaGlassPalette(
    isLight = false,
    voidBg = ObsidianVoid,
    surfaceBg = ObsidianCharcoal,
    elevatedSurfaceBg = ObsidianElevated,
    cardBg = GlassCardBg,
    cardElevatedBg = GlassCardElevatedBg,
    pillBg = GlassPillBg,
    blockBg = Color(0x990A0C0F),
    navBarBg = ObsidianCharcoal.copy(alpha = 0.96f),
    textPrimary = SilverPrimary,
    textSecondary = SilverSecondary,
    textMuted = SilverMuted,
    borderNeutral = GlassBorderSilver,
    borderAccent = GlassBorderEmerald,
    highlightTop = GlassHighlightTop,
    accentPrimary = EmeraldAccent,
    accentSoft = EmeraldSoft,
    accentContainer = EmeraldContainer,
    onAccent = ObsidianVoid, // High-contrast dark ink on bright brushed sterling silver buttons
    gold = ChampagneGold,
    sky = StatusSky,
    amber = StatusAmber,
    coral = StatusCoral,
    success = StatusSuccess
)

val LightGlassPalette = RuhZenaGlassPalette(
    isLight = true,
    voidBg = LightVoid,
    surfaceBg = LightCharcoal,
    elevatedSurfaceBg = LightElevated,
    cardBg = LightGlassCardBg,
    cardElevatedBg = LightGlassCardElevatedBg,
    pillBg = LightGlassPillBg,
    blockBg = Color(0x141A1E24),
    navBarBg = Color(0xF5F2F4F7),
    textPrimary = LightInkPrimary,
    textSecondary = LightInkSecondary,
    textMuted = LightInkMuted,
    borderNeutral = LightBorderGreyBlack,
    borderAccent = LightBorderEmerald,
    highlightTop = LightHighlightTop,
    accentPrimary = EmeraldDeep,
    accentSoft = EmeraldDeepInk,
    accentContainer = LightEmeraldContainer,
    onAccent = Color.White,
    gold = ChampagneGoldDeep,
    sky = StatusSkyDeep,
    amber = StatusAmberDeep,
    coral = StatusCoralDeep,
    success = StatusSuccessDeep
)

val LocalRuhZenaPalette = staticCompositionLocalOf { DarkGlassPalette }
val LocalReducedMotion = staticCompositionLocalOf { false }

private val RuhZenaDarkColorScheme = darkColorScheme(
    primary = EmeraldAccent,
    onPrimary = ObsidianVoid,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldSoft,
    secondary = SilverPrimary,
    onSecondary = ObsidianVoid,
    secondaryContainer = ObsidianElevated,
    onSecondaryContainer = SilverPrimary,
    tertiary = ChampagneGold,
    onTertiary = ObsidianVoid,
    tertiaryContainer = ChampagneGoldMuted,
    onTertiaryContainer = ChampagneGold,
    background = ObsidianVoid,
    onBackground = SilverPrimary,
    surface = ObsidianCharcoal,
    onSurface = SilverPrimary,
    surfaceVariant = ObsidianSurface,
    onSurfaceVariant = SilverSecondary,
    outline = GlassBorderSilver,
    outlineVariant = GlassBorderEmerald,
    error = StatusCoral,
    onError = Color.White
)

private val RuhZenaLightColorScheme = lightColorScheme(
    primary = EmeraldDeep,
    onPrimary = Color.White,
    primaryContainer = LightEmeraldContainer,
    onPrimaryContainer = EmeraldDeepInk,
    secondary = LightInkPrimary,
    onSecondary = Color.White,
    secondaryContainer = LightSurface,
    onSecondaryContainer = LightInkPrimary,
    tertiary = ChampagneGoldDeep,
    onTertiary = Color.White,
    tertiaryContainer = ChampagneGoldMuted,
    onTertiaryContainer = ChampagneGoldDeep,
    background = LightVoid,
    onBackground = LightInkPrimary,
    surface = LightElevated,
    onSurface = LightInkPrimary,
    surfaceVariant = LightCharcoal,
    onSurfaceVariant = LightInkSecondary,
    outline = LightBorderGreyBlack,
    outlineVariant = LightBorderEmerald,
    error = StatusCoralDeep,
    onError = Color.White
)

val RuhZenaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun RuhZenaTheme(
    themeMode: RuhZenaThemeMode = RuhZenaThemeMode.DARK_GLASS,
    isBangla: Boolean = false,
    fontScale: Float = 1.0f,
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val palette = if (themeMode == RuhZenaThemeMode.LIGHT_GLASS) LightGlassPalette else DarkGlassPalette
    val colorScheme = if (themeMode == RuhZenaThemeMode.LIGHT_GLASS) RuhZenaLightColorScheme else RuhZenaDarkColorScheme

    CompositionLocalProvider(
        LocalRuhZenaPalette provides palette,
        LocalReducedMotion provides reducedMotion
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = buildRuhZenaTypography(isBangla = isBangla, fontScale = fontScale),
            shapes = RuhZenaShapes,
            content = content
        )
    }
}
